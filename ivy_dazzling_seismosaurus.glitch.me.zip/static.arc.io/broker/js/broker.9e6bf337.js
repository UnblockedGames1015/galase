(function(t) {
    function e(e) {
        for (var r, o, a = e[0], c = e[1], u = e[2], d = 0, f = []; d < a.length; d++) o = a[d], s[o] && f.push(s[o][0]), s[o] = 0;
        for (r in c) Object.prototype.hasOwnProperty.call(c, r) && (t[r] = c[r]);
        l && l(e);
        while (f.length) f.shift()();
        return i.push.apply(i, u || []), n()
    }

    function n() {
        for (var t, e = 0; e < i.length; e++) {
            for (var n = i[e], r = !0, o = 1; o < n.length; o++) {
                var c = n[o];
                0 !== s[c] && (r = !1)
            }
            r && (i.splice(e--, 1), t = a(a.s = n[0]))
        }
        return t
    }
    var r = {},
        s = {
            broker: 0
        },
        i = [];

    function o(t) {
        return a.p + "broker/js/" + ({
            "lazy-iwc": "lazy-iwc",
            "lazy-modules": "lazy-modules"
        }[t] || t) + "." + {
            "lazy-iwc": "9b430e25",
            "lazy-modules": "a169b1ec"
        }[t] + ".js"
    }

    function a(e) {
        if (r[e]) return r[e].exports;
        var n = r[e] = {
            i: e,
            l: !1,
            exports: {}
        };
        return t[e].call(n.exports, n, n.exports, a), n.l = !0, n.exports
    }
    a.e = function(t) {
        var e = [],
            n = s[t];
        if (0 !== n)
            if (n) e.push(n[2]);
            else {
                var r = new Promise((function(e, r) {
                    n = s[t] = [e, r]
                }));
                e.push(n[2] = r);
                var i, c = document.createElement("script");
                c.charset = "utf-8", c.timeout = 120, a.nc && c.setAttribute("nonce", a.nc), c.src = o(t), i = function(e) {
                    c.onerror = c.onload = null, clearTimeout(u);
                    var n = s[t];
                    if (0 !== n) {
                        if (n) {
                            var r = e && ("load" === e.type ? "missing" : e.type),
                                i = e && e.target && e.target.src,
                                o = new Error("Loading chunk " + t + " failed.\n(" + r + ": " + i + ")");
                            o.type = r, o.request = i, n[1](o)
                        }
                        s[t] = void 0
                    }
                };
                var u = setTimeout((function() {
                    i({
                        type: "timeout",
                        target: c
                    })
                }), 12e4);
                c.onerror = c.onload = i, document.head.appendChild(c)
            }
        return Promise.all(e)
    }, a.m = t, a.c = r, a.d = function(t, e, n) {
        a.o(t, e) || Object.defineProperty(t, e, {
            enumerable: !0,
            get: n
        })
    }, a.r = function(t) {
        "undefined" !== typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(t, "__esModule", {
            value: !0
        })
    }, a.t = function(t, e) {
        if (1 & e && (t = a(t)), 8 & e) return t;
        if (4 & e && "object" === typeof t && t && t.__esModule) return t;
        var n = Object.create(null);
        if (a.r(n), Object.defineProperty(n, "default", {
                enumerable: !0,
                value: t
            }), 2 & e && "string" != typeof t)
            for (var r in t) a.d(n, r, function(e) {
                return t[e]
            }.bind(null, r));
        return n
    }, a.n = function(t) {
        var e = t && t.__esModule ? function() {
            return t["default"]
        } : function() {
            return t
        };
        return a.d(e, "a", e), e
    }, a.o = function(t, e) {
        return Object.prototype.hasOwnProperty.call(t, e)
    }, a.p = "https://static.arc.io/", a.oe = function(t) {
        throw console.error(t), t
    };
    var c = window["webpackJsonp"] = window["webpackJsonp"] || [],
        u = c.push.bind(c);
    c.push = e, c = c.slice();
    for (var d = 0; d < c.length; d++) e(c[d]);
    var l = u;
    i.push(["0fe7", "chunk-vendors"]), n()
})({
    "04ed": function(t, e, n) {
        "use strict";
        (function(t) {
            n.d(e, "a", (function() {
                return p
            }));
            var r = n("3d15"),
                s = n("2677"),
                i = n.n(s),
                o = n("364d"),
                a = n.n(o),
                c = n("460a"),
                u = n("cee5");
            const d = n("34eb")("arc:storage:store");
            console.log;

            function l(t, e) {
                return `chunk-${t}-${e}`
            }

            function f(t, e = "Async") {
                const {
                    prototype: n
                } = t.constructor, r = ["get", "put", "close", "destroy", "remove"];
                for (const s of r) {
                    if (!(s in n)) continue;
                    const t = s + e;
                    n[t] = a()(n[s])
                }
                return t
            }
            class h {
                constructor(t, e = {}) {
                    this.chunkLength = t, this.fid = e.fid, this.dbAsync = e.dbAsync, this.closed = !1
                }
                async get(e, n, r) {
                    if ("function" === typeof n) return this.get(e, null, n);
                    if (this.closed) return this._alreadyClosedErrback(r);
                    try {
                        const s = [this.fid, e],
                            i = await (await this.dbAsync).get(c["CHUNK_STORE"], s);
                        if (!i) {
                            const n = new Error(`No chunk at index ${e}.`);
                            return void t.nextTick(r, n)
                        }
                        n = n || {};
                        const {
                            buffer: o
                        } = i, a = n.offset || 0, u = n.length || o.length - a, d = o.slice(a, a + u);
                        t.nextTick(r, null, d)
                    } catch (s) {
                        d(s), t.nextTick(r, s)
                    }
                }
                async put(e, n, r) {
                    if (this.closed) this._alreadyClosedErrback(r);
                    else try {
                        await (await this.dbAsync).put(c["CHUNK_STORE"], {
                            fid: this.fid,
                            index: e,
                            buffer: n
                        }), t.nextTick(r, null)
                    } catch (s) {
                        t.nextTick(r, s)
                    }
                }
                async remove(e, n) {
                    if (this.closed) this._alreadyClosedErrback(n);
                    else try {
                        const r = [this.fid, e];
                        await (await this.dbAsync).delete(c["CHUNK_STORE"], r), t.nextTick(n, null)
                    } catch (r) {
                        t.nextTick(n, r)
                    }
                }
                async close(e) {
                    this.closed ? this._alreadyClosedErrback(e) : ((await this.dbAsync).close(), this.closed = !0, t.nextTick(e, null))
                }
                async destroy(e) {
                    if (this.closed) this._alreadyClosedErrback(e);
                    else try {
                        const n = IDBKeyRange.bound([this.fid, 0], [this.fid, 1 / 0]);
                        await (await this.dbAsync).delete(c["CHUNK_STORE"], n), t.nextTick(e, null)
                    } catch (n) {
                        t.nextTick(e, n)
                    }
                }
                _alreadyClosedErrback(e) {
                    t.nextTick(e, new Error("Store is closed"))
                }
            }
            class p {
                constructor(t) {
                    const {
                        fid: e,
                        torrentFileObj: n
                    } = t;
                    this.fid = e;
                    const r = n.pieceLength,
                        s = Object(c["initDb"])();
                    this.dbAsync = s;
                    const o = f;
                    this.diskStore = o(new h(r, {
                        fid: e,
                        dbAsync: s
                    })), this.memStore = o(new i.a(r, n)), this.quota = new u["a"](e, s), this.promises = [Object(c["storeFileInfo"])(t)], this._addQuotaListeners()
                }
                _addQuotaListeners() {
                    this.quota.onEviction((t, e) => {
                        d("eviction, storing in memStore", t, e.length), this.memStore.putAsync(t, e)
                    })
                }
                async get(e, n, s) {
                    this.promises.push(this.quota.updateAccessTime());
                    let i = null;
                    try {
                        i = await this.memStore.getAsync(e, n)
                    } catch (a) {
                        i = null
                    }
                    const o = l(e, this.fid);
                    if (null !== i) return d("memStore get: " + o), void t.nextTick(s, null, r["c"](i, [i.buffer]));
                    try {
                        i = await this.diskStore.getAsync(e, n), d("diskStore get: " + o), t.nextTick(s, null, r["c"](i, [i.buffer]))
                    } catch (a) {
                        t.nextTick(s, a)
                    }
                }
                async put(e, n, r) {
                    const s = l(e, this.fid);
                    let i = !1;
                    try {
                        await this.quota.willExceedCustomQuota(n.length) && await this.quota.clearStorageForChunk(n.length), d("diskStore put: " + s), await this.diskStore.putAsync(e, n), t.nextTick(r, null)
                    } catch (o) {
                        i = !0, "QuotaExceededError" === o.name && await this.quota.clearStorageForChunk(n.length)
                    }
                    if (i) try {
                        d("memStore put: " + s), await this.memStore.putAsync(e, n), t.nextTick(r, null)
                    } catch (o) {
                        t.nextTick(r, o)
                    }
                }
                async remove(e, n) {
                    if (this.closed) this._alreadyClosedErrback(n);
                    else try {
                        await this.diskStore.removeAsync(e), t.nextTick(n, null)
                    } catch (r) {
                        t.nextTick(n, r)
                    }
                }
                async close(e) {
                    if (this.closed) this._alreadyClosedErrback(e);
                    else {
                        this.closed = !0;
                        try {
                            await Promise.all([this.diskStore.closeAsync(), this.memStore.closeAsync()]), t.nextTick(e, null)
                        } catch (n) {
                            t.nextTick(e, n)
                        }
                    }
                }
                async destroy(e) {
                    if (this.closed) this._alreadyClosedErrback(e);
                    else {
                        this.closed = !0;
                        try {
                            await Promise.all(this.promises), await Promise.all([this.diskStore.destroyAsync(), this.memStore.destroyAsync(), (await this.dbAsync).delete(c["FILE_INFO_STORE"], this.fid)]), t.nextTick(e, null)
                        } catch (n) {
                            t.nextTick(e, n)
                        }
                    }
                }
                _alreadyClosedErrback(e) {
                    t.nextTick(e, new Error("FileChunkStore is closed."))
                }
            }
        }).call(this, n("4362"))
    },
    "0fe7": function(t, e, n) {
        "use strict";
        n.r(e);
        var r = {};
        n.r(r), n.d(r, "getWidgetOptState", (function() {
            return v
        })), n.d(r, "setWidgetOptState", (function() {
            return N
        })), n.d(r, "enableWidget", (function() {
            return D
        })), n.d(r, "disableWidget", (function() {
            return A
        }));
        var s = {};
        n.r(s), n.d(s, "hasNewPropertySession", (function() {
            return U
        })), n.d(s, "enableMasterEligibility", (function() {
            return W
        })), n.d(s, "getBrokerIds", (function() {
            return K
        })), n.d(s, "listPropertySessions", (function() {
            return H
        }));
        n("8011");
        var i = n("c4d1"),
            o = n("a5a5"),
            a = n("3d15");
        n("5cc6");
        console.log;

        function c(t = "-") {
            const e = (new Date).getTime(),
                n = String(Math.random()).slice(2, 11);
            return e + t + n
        }

        function u(t) {
            const {
                name: e,
                message: n,
                stack: r
            } = t;
            return {
                name: e,
                message: n,
                stack: r
            }
        }

        function d() {
            a["d"].set("error", {
                canHandle: t => t instanceof Error,
                serialize: t => {
                    const e = u(t),
                        n = [];
                    return [e, n]
                },
                deserialize: t => Object.assign(Error(), t)
            }), a["d"].set("babelError", {
                canHandle: t => t && 1 === t.length && t[0] instanceof Error,
                serialize: t => {
                    const e = [u(t[0])],
                        n = [];
                    return [e, n]
                },
                deserialize: t => [Object.assign(Error(), t[0])]
            })
        }
        var l = n("81e8"),
            f = n("5de4");
        const {
            COMLINK_INIT: h
        } = o["e"];
        async function p(t, e) {
            const [n, r] = e;
            a["a"](t, n);
            const s = a["e"](r);
            await s._confirmRpc()
        }
        async function y(t, e) {
            const [n, r] = e, s = a["e"](r);
            await s._rejectRpc(t)
        }
        var b = n("ade3"),
            g = n("a78e"),
            w = n.n(g),
            m = n("2677"),
            O = n.n(m);
        const I = new Date("January 1, 2036"),
            _ = "arc.io",
            E = {
                state: o["d"].UNDECIDED,
                date: new Date,
                dismissedAt: null
            },
            T = () => ({
                domain: S(),
                expires: I,
                sameSite: "None",
                secure: !0
            });

        function S() {
            const {
                hostname: t
            } = window.location;
            return k(t) ? _ : t
        }

        function k(t) {
            return t.endsWith("." + _) || t === _
        }
        async function v() {
            let t = w.a.get(o["c"]);
            return t ? (t = JSON.parse(t), t.date = new Date(t.date), t) : (N(E), E)
        }
        async function N(t) {
            return t = JSON.stringify(t), w.a.set(o["c"], t, T())
        }
        async function D(t, e) {
            const n = {
                state: o["d"].OPTED_IN,
                date: Date.now(),
                referrerPropertyId: t,
                referrerOrigin: e
            };
            return N(n)
        }
        async function A(t, e) {
            const n = {
                state: o["d"].OPTED_OUT,
                date: Date.now(),
                referrerPropertyId: t,
                referrerOrigin: e
            };
            return N(n)
        }
        var C = n("04ed"),
            R = n("460a"),
            x = n("612d");
        const j = n("34eb")("arc:broker"),
            P = "propertySessions";
        class F {
            static establishRpc(t) {
                return "_rpc|establish:" + t
            }
            static confirmRpc(t) {
                return "_rpc|confirm:" + t
            }
            static rpcPair(t, e) {
                return `_rpc|pair:${t}-${e}`
            }
        }
        const L = () => n.e("lazy-iwc").then(n.bind(null, "4be7")).then(t => t.SJ.iwc),
            G = t => new Promise(e => t.onReady(e));

        function B(t, e) {
            const n = new Set(e),
                r = {};
            for (const [s, i] of Object.entries(t)) {
                const t = i.activeBrokers.filter(t => {
                    const e = n.has(t.brokerId);
                    return e
                });
                t.length > 0 && (r[s] = {
                    propertySessionId: i.propertySessionId,
                    activeBrokers: t
                })
            }
            return r
        }

        function M(t, e, n, r) {
            t = t || {}, t = B(t, e);
            const {
                propertyId: s,
                myBrokerId: i,
                ...o
            } = n;
            s in t || (t[s] = {
                propertySessionId: r,
                activeBrokers: []
            });
            const {
                activeBrokers: a
            } = t[s];
            return a.find(t => t.brokerId === i) || t[s].activeBrokers.push({
                brokerId: i,
                propertyId: s,
                ...o
            }), t
        }

        function U(t, e) {
            const n = Object.values(t),
                r = e.some(t => n.some(({
                    activeBrokers: e
                }) => {
                    const n = 1 === e.length && e[0].brokerId === t;
                    return n
                }));
            return r
        }
        async function W(t, e, n = !1) {
            const r = this;
            window.name = c();
            const [s, {
                uuid4: i
            }] = await Promise.all([L(), Object(x["a"])()]), o = s.WindowMonitor;
            await G(o);
            const a = o.getThisWindowId();
            j("broker is eligible to become master. myBrokerId: " + a);
            const u = new s.SharedData("master"),
                d = new s.SharedData(P);

            function l() {
                const t = u.get();
                return a === t
            }

            function f(t, e, n) {
                for (const r of n) s.EventBus.un(F.rpcPair(r, a));
                const i = t.getOpenWindowIds();
                i.sort(), u.change(t => (t = t || null, i.includes(t) || (t = null), t || i[0] !== a || (t = a), t)), j("brokers changed. \nmyBrokerId %s \nbrokerIds %o \nnewBrokers %o \nclosedBrokers %o", a, i, e, n), l() && (e.length && d.onceChanged(t => {
                    U(t, e) && r.emit("newSession")
                }), n.length && (j("master: cleaning sessions b/c brokers closed. %o", n), d.change(t => (t = t || {}, B(t, i)))))
            }
            u.onChanged(() => {
                if (l()) {
                    r.emit("master"), j("master: cleaning sessions b/c im the new master");
                    const t = o.getOpenWindowIds();
                    d.change(e => (e = e || {}, B(e, t)))
                }
            }), d.onChanged((e = {}) => {
                if (j("propertySessions changed %o", e), !(t in e)) return;
                const {
                    propertySessionId: n
                } = e[t];
                r.emit("propertySessionId", n)
            });
            const h = () => {
                const r = o.getOpenWindowIds(),
                    s = {
                        myBrokerId: a,
                        propertyId: t,
                        origin: e,
                        isSwActive: n
                    };
                d.change(t => M(t, r, s, i()))
            };
            h(), setInterval(h, 3e4), f(o, [a], []), o.onWindowsChanged((...t) => f(o, ...t))
        }
        async function K() {
            const t = await L(),
                e = t.WindowMonitor;
            await G(e);
            const n = e.getOpenWindowIds();
            return n
        }
        async function H() {
            const t = await L(),
                e = [],
                n = new t.SharedData(P).get();
            for (const [r, s] of Object.entries(n)) {
                const {
                    activeBrokers: t = [],
                    propertySessionId: n
                } = s;
                if (!t.length) continue;
                const i = [...new Set(t.map(t => t.origin))].filter(Boolean),
                    o = t.some(t => t.isSwActive);
                e.push({
                    propertyId: r,
                    propertySessionId: n,
                    origins: i,
                    isSwActive: o,
                    status: "open"
                })
            }
            return e
        }
        class z {
            constructor() {
                Object(b["a"])(this, "events", {})
            }
            async on(t, e) {
                t in this.events || (this.events[t] = []), this.events[t].push(e)
            }
            async once(t, e) {
                const n = this;
                this.on(t, (function r() {
                    n.removeListener(t, r), e()
                }))
            }
            async emit(t, ...e) {
                if (!(t in this.events)) return;
                const n = this.events[t].slice();
                for (const r of n) r(...e)
            }
            async removeListener(t, e) {
                if (!(t in this.events)) return;
                const n = this.events[t].indexOf(e); - 1 !== n && this.events[t].splice(n, 1)
            }
            async removeAllListeners(t) {
                t ? this.events[t] = [] : this.events = {}
            }
            async destroy() {
                this.removeAllListeners()
            }
        }
        class q extends z {
            constructor() {
                super(), Object(b["a"])(this, "Cookies", a["b"](w.a)), Object(b["a"])(this, "localStorage", a["b"](localStorage)), Object.assign(this, s), Object.assign(this, R), Object.assign(this, r)
            }
            async createStore(t) {
                return new C["a"](t)
            }
        }
        class J extends q {
            async createStore(t) {
                const e = new C["a"](t);
                return a["b"](e)
            }
        }
        class Q extends q {
            async createStore({
                torrentFileObj: t
            }) {
                const {
                    pieceLength: e,
                    length: n
                } = t, r = O()(e, {
                    length: n
                });
                return a["b"](r)
            }
        }
        const {
            COMLINK_INIT: V,
            BROKER_LOAD: Y
        } = o["e"];
        window.cl = console.log, async function() {
            d(), Object(i["b"])(), Object(l["a"])(), window.addEventListener("message", async t => {
                const {
                    arcEvent: e,
                    wrappedPort: n,
                    exposedPort: r,
                    parentUrl: s
                } = t.data;
                if (e === V)
                    if (await Object(R["isStorageAccessDenied"])()) {
                        const e = new Error("Storage access denied");
                        y(e, t.ports)
                    } else {
                        const e = s && Object(f["a"])(s) ? new Q : new J;
                        let i;
                        i = n && r ? [n, r] : t.ports, p(e, i)
                    }
            }), window.parent.postMessage({
                arcEvent: Y
            }, "*");
            const t = await Object(R["getOrGenerateMyNodeId"])();
            i["a"].configureScope(e => {
                e.setTag("nodeId", t), e.setTag("arcClient", "broker")
            })
        }()
    },
    "460a": function(t, e, n) {
        "use strict";
        n.r(e), n.d(e, "CHUNK_STORE", (function() {
            return f
        })), n.d(e, "FILE_INFO_STORE", (function() {
            return h
        })), n.d(e, "getOrGenerateMyNodeId", (function() {
            return p
        })), n.d(e, "isStorageAccessDenied", (function() {
            return y
        })), n.d(e, "initDb", (function() {
            return b
        })), n.d(e, "destroyDb", (function() {
            return g
        })), n.d(e, "forceDbCompaction", (function() {
            return w
        })), n.d(e, "storeFileInfo", (function() {
            return m
        })), n.d(e, "getFilesToSeed", (function() {
            return O
        })), n.d(e, "listFilesToSeed", (function() {
            return I
        })), n.d(e, "getTorrentFileObject", (function() {
            return _
        })), n.d(e, "destroyFile", (function() {
            return E
        })), n.d(e, "generateStorageReport", (function() {
            return T
        })), n.d(e, "getStoredFids", (function() {
            return S
        })), n.d(e, "getCustomStorageEstimate", (function() {
            return k
        }));
        var r = n("3f4f"),
            s = n("8665"),
            i = n("a5a5"),
            o = n("5de4"),
            a = n("612d");
        const c = n("34eb")("arc:broker"),
            u = "Arc_nodeId",
            d = "arc",
            l = 60,
            f = (console.log, "fileChunks"),
            h = "fileInfo";
        async function p() {
            let t = await s["a"].get(u);
            if (!t) {
                const {
                    guid: e
                } = await Object(a["a"])();
                t = e(), await s["a"].set(u, t)
            }
            return t
        }
        async function y() {
            try {
                return window.localStorage.getItem("test"), await b(), !1
            } catch {
                return !0
            }
        }
        async function b() {
            const t = await Object(r["b"])(d, l, {
                upgrade(t, e, n, r) {
                    let s, i;
                    if (t.objectStoreNames.contains(f)) s = r.objectStore(f);
                    else {
                        const e = {
                            keyPath: ["fid", "index"]
                        };
                        s = t.createObjectStore(f, e)
                    }
                    if (s.indexNames.contains("fid") || s.createIndex("fid", "fid"), t.objectStoreNames.contains(h)) i = r.objectStore(h);
                    else {
                        const e = {
                            keyPath: "fid"
                        };
                        i = t.createObjectStore(h, e)
                    }
                    i.indexNames.contains("accessTime") || i.createIndex("accessTime", "accessTime"), i.indexNames.contains("expiresAt") || i.createIndex("expiresAt", "expiresAt"), i.indexNames.contains("seedTaskDate") || i.createIndex("seedTaskDate", "seedTaskDate")
                },
                blocked() {},
                blocking() {},
                terminated() {}
            });
            return t
        }
        async function g() {
            return Object(r["a"])(d)
        }
        async function w() {
            try {
                const t = "tempDb",
                    e = "temp",
                    n = await Object(r["b"])(t, 1, {
                        upgrade(t) {
                            t.createObjectStore(e, {
                                keyPath: "id"
                            })
                        }
                    });
                await n.put(e, {
                    id: "fucboi"
                }), await Object(r["a"])(t)
            } catch (t) {
                console.log(t)
            }
        }
        async function m(t) {
            const {
                parseTorrent: e
            } = await Object(a["a"])(), {
                fid: n,
                torrentFileObj: r,
                expiresAt: s,
                seedTaskDate: i
            } = t, o = e.toTorrentFile(r), c = {
                fid: n,
                torrentFile: o,
                expiresAt: s ? new Date(s) : null,
                seedTaskDate: i ? new Date(i) : null,
                accessTime: new Date
            }, u = await b();
            await u.put(h, c)
        }
        async function O(t = 5, e = []) {
            const {
                parseTorrent: n,
                Buffer: r
            } = await Object(a["a"])(), s = {};
            let o = 0;
            const c = await b();
            let u = await c.transaction(h).store.openCursor();
            while (u && o < t) {
                const {
                    fid: t,
                    torrentFile: a
                } = u.value, c = n(r.from(a)), d = e.includes(t), l = c.length > i["a"];
                !d && l && (s[t] = c, o++), u = await u.continue()
            }
            return s
        }
        async function I(t = 5, e = []) {
            const {
                parseTorrent: n,
                Buffer: r
            } = await Object(a["a"])(), s = [], o = await b(), c = o.transaction(h).store, u = async o => {
                while (o && s.length < t) {
                    const {
                        fid: t,
                        torrentFile: a,
                        ...c
                    } = o.value, u = n(r.from(a)), d = e.includes(t) || s.some(e => e.fid === t), l = u.length > i["a"];
                    !d && l && s.push({
                        fid: t,
                        torrentFileObj: u,
                        ...c
                    }), o = await o.continue()
                }
            };
            if (c.indexNames.contains("seedTaskDate")) {
                const t = c.index("seedTaskDate"),
                    e = await t.openCursor(null, "prev");
                await u(e)
            }
            if (s.length < t) {
                const t = await c.openCursor();
                await u(t)
            }
            return s
        }
        async function _(t) {
            const {
                parseTorrent: e,
                Buffer: n
            } = await Object(a["a"])(), r = await b(), s = await r.get(h, t);
            if (!s) return null;
            const {
                torrentFile: i
            } = s, o = e(n.from(i));
            return o
        }
        async function E(t) {
            const e = await b(),
                n = IDBKeyRange.bound([t, 0], [t, 1 / 0]);
            await Promise.all([e.delete(f, n), e.delete(h, t)])
        }
        async function T() {
            const t = {};
            try {
                const e = await b(),
                    n = await e.getAll(h);
                for (const s of n) {
                    const {
                        fid: e,
                        torrentFile: n,
                        ...r
                    } = s;
                    t[e] = { ...r,
                        isSeeding: !1,
                        clientName: null,
                        hasTorrentFile: !!n,
                        chunkIndexes: []
                    }
                }
                const r = await e.getAllKeys(f);
                for (const [s, i] of r) t[s] = t[s] || {
                    chunkIndexes: []
                }, t[s].chunkIndexes.push(i)
            } catch (e) {
                c(e)
            }
            return t
        }
        async function S() {
            let t = [];
            try {
                const e = await b();
                t = await e.getAllKeys(h)
            } catch (e) {
                c(e)
            }
            return t
        }
        async function k() {
            const {
                storage: t
            } = navigator;
            if (!t || !t.estimate || Object(o["b"])()) return {
                usage: 0,
                quota: 0,
                customQuota: 0
            };
            const e = o["c"].asNumber("quotaSizeMb", i["b"]),
                {
                    usage: n,
                    quota: r
                } = await t.estimate(),
                s = 1048576,
                a = Math.min(r, e * s);
            return {
                usage: n,
                quota: r,
                customQuota: a
            }
        }
    },
    "5de4": function(t, e, n) {
        "use strict";
        n.d(e, "c", (function() {
            return r
        })), n.d(e, "a", (function() {
            return s
        })), n.d(e, "b", (function() {
            return i
        }));
        console.log;
        const r = {
            _searchParams(t = window.location.href) {
                const {
                    searchParams: e
                } = new URL(t);
                return e
            },
            exists(t, e) {
                return this._searchParams(e).has(t)
            },
            get(t, e = null, n) {
                return this._searchParams(n).get(t) || e
            },
            isTruthy(t, e = !1, n) {
                const r = this._searchParams(n);
                return r.has(t) ? ["1", "true"].includes(r.get(t).toLowerCase()) : e
            },
            asNumber(t, e, n) {
                const r = this._searchParams(n);
                return r.has(t) ? Number(r.get(t)) : e
            }
        };

        function s(t) {
            const e = r.isTruthy("diskstore", !0, t);
            return !e || i() || o(t)
        }

        function i() {
            return /^((?!chrome|android).)*safari/i.test(navigator.userAgent)
        }

        function o(t) {
            return t.startsWith("https://arc.io/demo")
        }
    },
    "612d": function(t, e, n) {
        "use strict";
        async function r() {
            return n.e("lazy-modules").then(n.bind(null, "e8a7"))
        }
        n.d(e, "a", (function() {
            return r
        }))
    },
    8011: function(t, e) {
        (function(t, e, n, r, s, i, o, a, c) {
            for (var u = !0, d = !1, l = 0; l < document.scripts.length; l++)
                if (document.scripts[l].src.indexOf(o) > -1) {
                    u = !("no" === document.scripts[l].getAttribute("data-lazy"));
                    break
                }
            var f = !1,
                h = [],
                p = function(t) {
                    ("e" in t || "p" in t || t.f && t.f.indexOf("capture") > -1 || t.f && t.f.indexOf("showReportDialog") > -1) && u && y(h), p.data.push(t)
                };

            function y(o) {
                if (!f) {
                    f = !0;
                    var u = e.getElementsByTagName(n)[0],
                        d = e.createElement(n);
                    d.src = a, d.setAttribute("crossorigin", "anonymous"), d.addEventListener("load", (function() {
                        try {
                            t[r] = g, t[s] = w;
                            var e = t[i],
                                n = e.init;
                            e.init = function(t) {
                                var e = c;
                                for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
                                n(e)
                            }, b(o, e)
                        } catch (a) {
                            console.error(a)
                        }
                    })), u.parentNode.insertBefore(d, u)
                }
            }

            function b(e, n) {
                try {
                    for (var i = p.data, o = 0; o < e.length; o++) "function" === typeof e[o] && e[o]();
                    var a = !1,
                        c = t["__SENTRY__"];
                    "undefined" !== typeof c && c.hub && c.hub.getClient() && (a = !0);
                    var u = !1;
                    for (o = 0; o < i.length; o++)
                        if (i[o].f) {
                            u = !0;
                            var d = i[o];
                            !1 === a && "init" !== d.f && n.init(), a = !0, n[d.f].apply(n, d.a)
                        }!1 === a && !1 === u && n.init();
                    var l = t[r],
                        f = t[s];
                    for (o = 0; o < i.length; o++) "e" in i[o] && l ? l.apply(t, i[o].e) : "p" in i[o] && f && f.apply(t, [i[o].p])
                } catch (h) {
                    console.error(h)
                }
            }
            p.data = [], t[i] = t[i] || {}, t[i].onLoad = function(t) {
                h.push(t), u && !d || y(h)
            }, t[i].forceLoad = function() {
                d = !0, u && setTimeout((function() {
                    y(h)
                }))
            }, ["init", "addBreadcrumb", "captureMessage", "captureException", "captureEvent", "configureScope", "withScope", "showReportDialog"].forEach((function(e) {
                t[i][e] = function() {
                    p({
                        f: e,
                        a: arguments
                    })
                }
            }));
            var g = t[r];
            t[r] = function(e, n, r, s, i) {
                p({
                    e: [].slice.call(arguments)
                }), g && g.apply(t, arguments)
            };
            var w = t[s];
            t[s] = function(e) {
                p({
                    p: "reason" in e ? e.reason : "detail" in e && "reason" in e.detail ? e.detail.reason : e
                }), w && w.apply(t, arguments)
            }, u || setTimeout((function() {
                y(h)
            }))
        })(window, document, "script", "onerror", "onunhandledrejection", "Sentry", "7e5c2fad7a564ff8bffd4effc2abb26d", "https://browser.sentry-cdn.com/6.2.2/bundle.min.js", {
            dsn: "https://7e5c2fad7a564ff8bffd4effc2abb26d@sentry.arc.io/2"
        })
    },
    "81e8": function(t, e, n) {
        "use strict";
        (function(t) {
            function r() {
                const e = Promise.resolve();

                function n(t, ...n) {
                    e.then(() => {
                        t(...n)
                    })
                }
                t.nextTick = n, t.nextTickAsync = () => e.then()
            }
            n.d(e, "a", (function() {
                return r
            }))
        }).call(this, n("4362"))
    },
    a5a5: function(t, e, n) {
        "use strict";
        n.d(e, "e", (function() {
            return s
        })), n.d(e, "b", (function() {
            return i
        })), n.d(e, "a", (function() {
            return o
        })), n.d(e, "d", (function() {
            return a
        })), n.d(e, "c", (function() {
            return c
        }));
        const r = "arc:",
            s = {
                COMLINK_INIT: r + "comlink:init",
                NODE_ID: r + ":nodeId",
                CLIENT_TEARDOWN: r + "client:teardown",
                CLIENT_TAB_ID: r + "client:tabId",
                CDN_CONFIG: r + "cdn:config",
                P2P_CLIENT_READY: r + "cdn:ready",
                STORED_FIDS: r + "cdn:storedFids",
                SW_HEALTH_CHECK: r + "cdn:healthCheck",
                WIDGET_CONFIG: r + "widget:config",
                WIDGET_INIT: r + "widget:init",
                WIDGET_UI_LOAD: r + "widget:load",
                BROKER_LOAD: r + "broker:load",
                RENDER_FILE: r + "inlay:renderFile",
                FILE_RENDERED: r + "inlay:fileRendered"
            },
            i = 300,
            o = 2 ** 17,
            a = {
                UNDECIDED: "UNDECIDED",
                OPTED_IN: "OPTED_IN",
                OPTED_OUT: "OPTED_OUT"
            },
            c = "widgetOptState"
    },
    c490: function(t, e) {
        t.exports = Sentry
    },
    c4d1: function(t, e, n) {
        "use strict";
        var r = n("c490");
        const s = Object({
            NODE_ENV: "production",
            BASE_URL: "https://static.arc.io/",
            ACCOUNT_ORIGIN: "https://account.arc.io",
            BANDWIDTH_WARDEN_ORIGIN: "https://warden.arc.io",
            COGNITO_APP_ID: "431634imeo45noat90ccl0lkep",
            COGNITO_REGION: "us-east-2",
            COGNITO_IDENTITY_POOL_ID: "us-east-2:cec1bb4c-3aa1-4d9a-87df-b75ae59441d0",
            COGNITO_USER_POOL_ID: "us-east-2_3sKO4HOjv",
            COMMIT_HASH: "d8d6825",
            CORE_ORIGIN: "https://core.arc.io",
            DEMO_VUE_ORIGIN: "https://demo.arc.io",
            DOCS_ORIGIN: "https://docs.arc.io",
            FIREBASE_API_KEY: "AIzaSyCGmeUDT5F7Bq77JvXlN8IXBwJjIXJwvcI",
            GA_TID_HOMEPAGE: "UA-123508647-1",
            GA_TID_USER_TIMING: "UA-123508647-2",
            GATEWAY_ORIGIN: "https://gateway.arc.io",
            GOOGLE_PROJECT_FIRESTORE_ID: "prod-firestore-arc",
            HOMEPAGE_ORIGIN: "https://arc.io",
            INLAY_ORIGIN: "https://inlay.arc.io",
            OVERMIND_ORIGIN: "https://overmind.arc.io",
            PORTAL_VUE_ORIGIN: "https://portal.arc.io",
            PORTAL_ORIGIN: "https://portal.arc.io",
            NODE_REPORT_MAILBOX_ORIGIN: "https://warden.arc.io",
            ROOT_DOMAIN: "arc.io",
            SOCKETCLUSTER_HOSTNAME: "socket.arc.io",
            SOCKETCLUSTER_PORT: "443",
            STATIC_ORIGIN: "https://static.arc.io",
            STORAGE_ORIGIN: "https://storage.arc.io",
            STRIPE_CLIENT_ID: "ca_DMhwnlBqMfP4Vx8mJF4M1nGxTNU5263W",
            STRIPE_PUBLISHABLE_KEY: "pk_live_Df4EdjIuSE8fW21HyuwWhJcm",
            SW_ORIGIN: "https://arc.io",
            TCDN_ORIGIN: "https://tcdn.arc.io",
            TRACKER_ANNOUNCE_URL: "wss://tkr.arc.io/announce",
            TRACKER_ORIGIN: "https://tkr.arc.io",
            WEBSEED_ORIGIN: "https://webseed.arc.io",
            WIDGET_ORIGIN: "https://arc.io",
            DEBUG: "false"
        });
        s.IS_PROD = "production" === s.NODE_ENV;
        var i = s;
        const o = [/extensions\//i, /-extension:\/\//i];
        n.d(e, "a", (function() {
            return d
        })), n.d(e, "b", (function() {
            return h
        }));
        const {
            NODE_ENV: a,
            COMMIT_HASH: c
        } = i, u = ["SecurityError IDBFactory.open() called in an invalid security context"];
        let d = r;

        function l(t) {
            !d.SDK_NAME && self.Sentry && (d = self.Sentry), d.init({
                dsn: "https://7e5c2fad7a564ff8bffd4effc2abb26d@sentry.arc.io/2",
                enabled: !1,
                environment: a,
                release: c,
                maxBreadcrumbs: 5,
                ignoreErrors: u,
                autoSessionTracking: !1,
                denyUrls: o,
                blacklistUrls: o,
                ...t
            })
        }

        function f() {
            const t = {};
            l(t)
        }

        function h() {
            d.onLoad(f)
        }
    },
    cee5: function(t, e, n) {
        "use strict";
        n.d(e, "a", (function() {
            return a
        }));
        var r = n("517b"),
            s = (n("c4d1"), n("460a"));
        const i = n("34eb")("arc:storage:quota"),
            o = 300;
        console.log;
        class a {
            constructor(t, e) {
                this.fid = t, this.dbAsync = e, this.evictionCallback = () => {}, this.updateAccessTime = Object(r["a"])(this.updateAccessTime, 2500)
            }
            onEviction(t) {
                this.evictionCallback = t
            }
            async willExceedCustomQuota(t) {
                const {
                    usage: e,
                    customQuota: n
                } = await Object(s["getCustomStorageEstimate"])();
                return e + t > n
            }
            async clearStorageForChunk(t) {
                const e = 1.25;
                t *= e;
                try {
                    const e = await this._evictChunks(t);
                    for (const t of e) {
                        const {
                            index: e,
                            buffer: n
                        } = t;
                        this.evictionCallback(e, n)
                    }
                } catch (n) {
                    i(n)
                }
            }
            async _evictChunks(t) {
                const e = await this.dbAsync,
                    n = [];
                let r = 0;
                const o = await this._getFilesEligibleForEviction();
                for (const a of o) {
                    const {
                        fid: o
                    } = a;
                    let c = !0;
                    const u = e.transaction(s["CHUNK_STORE"], "readwrite"),
                        d = IDBKeyRange.bound([o, 0], [o, 1 / 0]);
                    let l = await u.store.openCursor(d, "prev");
                    while (l) {
                        if (r > t) {
                            c = !1;
                            break
                        }
                        const e = l.value,
                            {
                                index: s,
                                buffer: a
                            } = e;
                        this._isCurrentFile(o) && n.push(e), r += a.length, i(`Deleting fid: ${o}, index: ${s}`), await l.delete(), l = await l.continue()
                    }
                    if (c && !this._isCurrentFile(o) && (i("Deleting torrentFile: " + o), await e.delete(s["FILE_INFO_STORE"], o)), r > t) break
                }
                return n
            }
            async _getFilesEligibleForEviction() {
                const t = await this.dbAsync,
                    e = await t.getAll(s["FILE_INFO_STORE"]);
                return e.filter(t => {
                    const {
                        fid: e,
                        accessTime: n
                    } = t;
                    return this._isCurrentFile(e) || this._hasTimedOut(n)
                }).sort((t, e) => t.accessTime.getTime() - e.accessTime.getTime())
            }
            _hasTimedOut(t) {
                const e = ((new Date).getTime() - t.getTime()) / 1e3,
                    n = Math.abs(e) > o;
                return n
            }
            async updateAccessTime() {
                try {
                    const t = await this.dbAsync,
                        e = t.transaction(s["FILE_INFO_STORE"], "readwrite"),
                        n = e.store,
                        r = await n.get(this.fid);
                    if (!r) return;
                    r.accessTime = new Date, await n.put(r)
                } catch (t) {}
            }
            _isCurrentFile(t) {
                return t === this.fid
            }
        }
    }
});
//# sourceMappingURL=broker.9e6bf337.js.map