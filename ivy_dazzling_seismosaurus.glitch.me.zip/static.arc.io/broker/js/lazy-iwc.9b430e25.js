(window["webpackJsonp"] = window["webpackJsonp"] || []).push([
    ["lazy-iwc"], {
        "4be7": function(e, n, t) {
            "use strict";
            t.r(n), t.d(n, "SJ", (function() {
                return o
            }));
            var o = o || {};
            o.ns = function(e) {
                    var n = e.split("."),
                        t = o;
                    "SJ" === n[0] && (n = n.slice(1));
                    for (var r = 0; r < n.length; r++) {
                        var i = n[r];
                        "undefined" === typeof t[i] && (t[i] = {}), t = t[i]
                    }
                    return t
                },
                function(e) {
                    var n = {},
                        t = 0,
                        r = {}.toString,
                        i = {
                            appName: window.applicationName || "DEFAULT",
                            generateGUID: function() {
                                var e = (new Date).getTime(),
                                    n = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (function(n) {
                                        var t = (e + 16 * Math.random()) % 16 | 0;
                                        return e = Math.floor(e / 16), ("x" == n ? t : 7 & t | 8).toString(16)
                                    }));
                                return n
                            },
                            callback: function(e) {
                                if (o.isFunction(e)) {
                                    var n = Array.prototype.slice.call(arguments, 1);
                                    e.apply(window, n)
                                }
                            },
                            windowOn: function(e, o) {
                                o.handlerId = ++t;
                                var r = function(e) {
                                    e = e || window.event, o(e)
                                };
                                n[o.handlerId] = o, window.addEventListener ? window.addEventListener(e, r, !1) : window.attachEvent && window.attachEvent("on" + e, r)
                            },
                            windowUn: function(e, t) {
                                window.removeEventListener ? window.removeEventListener(e, n[t.handlerId], !1) : window.detachEvent && window.detachEvent("un" + e, n[t.handlerId]), delete n[t.handlerId]
                            },
                            isIE: function() {
                                var e = !window.ActiveXObject && "ActiveXObject" in window;
                                if (e) return 11;
                                var n = navigator.userAgent.toLowerCase();
                                return -1 !== n.indexOf("msie") && parseInt(n.split("msie")[1])
                            },
                            copy: function(e, n) {
                                var t;
                                for (t in n) e[t] = n[t];
                                return e
                            },
                            emptyFn: function() {},
                            isEmpty: function(e) {
                                return null == e || "" === e || o.isArray(e) && 0 === e.length
                            },
                            isArray: "isArray" in Array ? Array.isArray : function(e) {
                                return "[object Array]" === r.call(e)
                            },
                            isDate: function(e) {
                                return "[object Date]" === r.call(e)
                            },
                            isObject: function(e) {
                                return null !== e && void 0 !== e && "[object Object]" === r.call(e)
                            },
                            isPrimitive: function(e) {
                                var n = typeof e;
                                return "number" === n || "string" === n || "boolean" === n
                            },
                            isFunction: function(e) {
                                return !!e && "[object Function]" === r.call(e)
                            },
                            isNumber: function(e) {
                                return "number" === typeof e && isFinite(e)
                            },
                            isNumeric: function(e) {
                                return !isNaN(parseFloat(e)) && isFinite(e)
                            },
                            isString: function(e) {
                                return "string" === typeof e
                            },
                            isBoolean: function(e) {
                                return "boolean" === typeof e
                            }
                        };
                    i.copy(e, i)
                }(o),
                function(e) {
                    var n = {
                        each: function(e, n) {
                            for (var t in e)
                                if (e.hasOwnProperty(t) && !1 === n(e[t], t)) break
                        }
                    };
                    o.copy(e, n)
                }(o.ns("Object")),
                function(e) {
                    function n(e) {
                        var n = {};

                        function t(e, t) {
                            for (var o = 0; o < n[e].length; o++) n[e][o] === t && n[e].splice(o, 1)
                        }

                        function o(e, t, o) {
                            var r = n[e];
                            if (r)
                                for (var i = 0; i < r.length; i++)
                                    if (r[i].fn === t && r[i].scope === o) return r[i];
                            return null
                        }
                        return e.on = function(e, t, r) {
                            n[e] || (n[e] = []), o(e, t, r) || n[e].push({
                                fn: t,
                                scope: r
                            })
                        }, e.once = function(e, t, r) {
                            o(e, t, r) || (n[e] = n[e] || [], n[e].push({
                                fn: t,
                                scope: r,
                                single: !0
                            }))
                        }, e.un = function(e, n, r) {
                            var i = o(e, n, r);
                            i && t(e, i)
                        }, e.fire = function(e) {
                            var o = n[e];
                            if (o) {
                                o = [].concat(o);
                                for (var r = Array.prototype.slice.call(arguments, 1), i = 0; i < o.length; i++) o[i].fn.apply(o[i].scope, r), o[i].single && t(e, o[i])
                            }
                        }, e
                    }

                    function t() {
                        n(this)
                    }
                    t.decorate = function(e, o) {
                        var r;
                        return o ? (r = new t, e.on = r.on, e.un = r.un, e.once = r.once) : r = n(e), r
                    }, e.Observable = t
                }(o.ns("utils")),
                function(e) {
                    var n = window.localStorage;
                    "undefined" === typeof n && (n = {
                        getItem: function() {},
                        setItem: function() {},
                        removeItem: function() {}
                    }, alert("Local storage is not supported on this browser. Some features will not work."));
                    var t, r, i, a = 11 === o.isIE(),
                        c = new o.utils.Observable,
                        s = 10 === o.isIE() || 9 === o.isIE();
                    s || (i = new o.utils.Observable);
                    var u = a ? function(e) {
                        e = e || window.event, t = e.key, r = e.newValue, c.fire("storage", e), i.fire("storage", e)
                    } : s ? function(e) {
                        e = e || window.event, c.fire("storage", e)
                    } : function(e) {
                        e = e || window.event, c.fire("storage", e), i.fire("storage", e)
                    };
                    if (window.addEventListener) {
                        var l = a ? window.top : window;
                        l.addEventListener("storage", u, !1), l != window && window.addEventListener("unload", (function() {
                            l.removeEventListener("storage", u, !1)
                        }))
                    } else window.attachEvent && document.attachEvent("onstorage", u);
                    e.localStorage = {
                        onChanged: function(e, n, t) {
                            t && !s ? i.on("storage", e, n) : c.on("storage", e, n)
                        },
                        onceChanged: function(e, n, t) {
                            t && !s ? i.once("storage", e, n) : c.once("storage", e, n)
                        },
                        unChanged: function(e, n) {
                            c.un("storage", e, n), s || i.un("storage", e, n)
                        },
                        getItem: function(e) {
                            return a && t === e ? r : n.getItem(e)
                        },
                        setItem: s ? function(e, o) {
                            a && t === e && (r = o), n.setItem(e, o)
                        } : function(e, o) {
                            var c = this.getItem(e);
                            a && t === e && (r = o), n.setItem(e, o);
                            var s = {
                                key: e,
                                oldValue: c,
                                newValue: o,
                                url: window.location.href.toString()
                            };
                            i.fire("storage", s)
                        },
                        removeItem: s ? function(e) {
                            a && t === e && (r = null), n.removeItem(e)
                        } : function(e) {
                            var o = this.getItem(e);
                            a && t === e && (r = null), n.removeItem(e);
                            var c = {
                                key: e,
                                oldValue: o,
                                newValue: null,
                                url: window.location.href.toString()
                            };
                            i.fire("storage", c)
                        },
                        forEach: a ? function(e) {
                            for (var o = 0; o < n.length; o++) {
                                var i, a = n.key(o);
                                if (i = a === t ? r : n.getItem(a), !1 === e(a, i)) break
                            }
                        } : function(e) {
                            for (var t = 0; t < n.length; t++) {
                                var o = n.key(t),
                                    r = n.getItem(o);
                                if (!1 === e(o, r)) break
                            }
                        },
                        setVersion: function(e, n) {
                            var t = this,
                                o = t.getItem(e);
                            if (o !== n) {
                                var r = [];
                                t.forEach((function(n) {
                                    n.substr(0, e.length) === e && r.push(n)
                                })), r.forEach((function(e) {
                                    t.removeItem(e)
                                })), t.setItem(e, n)
                            }
                        }
                    }
                }(o),
                function(e) {
                    var n = "IWC_" + o.appName;
                    e.getLocalStoragePrefix = function() {
                        return n
                    }, e.$version = "0.1.3", o.localStorage.setVersion(n, e.$version)
                }(o.ns("iwc")),
                function(e) {
                    var n = o.iwc.getLocalStoragePrefix() + "_TLOCK_",
                        t = 3e3,
                        r = 50,
                        i = o.generateGUID();
                    o.localStorage.onChanged(v);
                    var a = new o.utils.Observable;

                    function c(e) {
                        a.on("storagechanged", e)
                    }

                    function s(e) {
                        a.un("storagechanged", e)
                    }

                    function u() {
                        a.fire("storagechanged")
                    }

                    function l(n, o) {
                        var a = !1,
                            u = !1,
                            l = null,
                            v = e.testingMode && e.lockTimeout || t,
                            g = function() {
                                u || (c(p), l = window.setInterval(p, r), u = !0)
                            },
                            h = function() {
                                u && (s(p), window.clearInterval(l), u = !1)
                            },
                            p = function() {
                                if (!a) {
                                    var t = (new Date).getTime(),
                                        r = d(n);
                                    if (r && t - r.timestamp < v) g();
                                    else {
                                        a = !0, h(), f(n, t);
                                        var c = window.setTimeout((function() {
                                            window.clearTimeout(c);
                                            var r = d(n);
                                            !r || r.timestamp === t && r.lockerId === i ? (h(), r || f(n, t), o(), e.testingMode || w(n)) : (a = !1, g())
                                        }), 10)
                                    }
                                }
                            };
                        p()
                    }

                    function d(e) {
                        var t = n + e,
                            r = o.localStorage.getItem(t),
                            i = null;
                        if (r) {
                            var a = r.split(".");
                            i = {
                                timestamp: parseInt(a[0]) || 0,
                                lockerId: a[1]
                            }
                        }
                        return i
                    }

                    function f(e, t) {
                        var r = n + e;
                        o.localStorage.setItem(r, t + "." + i)
                    }

                    function w(e) {
                        var t = n + e;
                        o.localStorage.removeItem(t)
                    }

                    function v(e) {
                        if (e.key) {
                            var t = !e.newValue && !!e.oldValue;
                            t && e.key.substr(0, n.length) === n && u()
                        } else u()
                    }
                    e.interlockedCall = l, o.interlockedCall = l
                }(o.ns("iwc.Lock")),
                function(e) {
                    var n = function(e) {
                        var n = this;
                        n._dataId = e, n._observable = new o.utils.Observable, n._serializedData = o.localStorage.getItem(n._dataId), o.localStorage.onChanged(n.onStorageChanged, n, !0)
                    };
                    n.prototype = {
                        constructor: n,
                        get: function() {
                            var e = this;
                            e._serializedData = o.localStorage.getItem(e._dataId);
                            var n = null;
                            return e._serializedData && (n = JSON.parse(e._serializedData)), n
                        },
                        set: function(e, n) {
                            var t = this;
                            o.iwc.Lock.interlockedCall(t._dataId, (function() {
                                t.writeToStorage(e), o.callback(n)
                            }))
                        },
                        change: function(e) {
                            var n = this;
                            o.iwc.Lock.interlockedCall(n._dataId, (function() {
                                var t = n.get();
                                t = e(t), n.writeToStorage(t)
                            }))
                        },
                        onChanged: function(e, n) {
                            var t = this;
                            t._observable.on("changed", e, n)
                        },
                        onceChanged: function(e, n) {
                            var t = this;
                            t._observable.once("changed", e, n)
                        },
                        unsubscribe: function(e, n) {
                            var t = this;
                            t._observable.un("changed", e, n)
                        },
                        writeToStorage: function(e) {
                            var n = this,
                                t = null !== e ? JSON.stringify(e) : "";
                            o.localStorage.setItem(n._dataId, t)
                        },
                        onStorageChanged: function(e) {
                            var n = this;
                            if (!e.key || e.key === n._dataId) {
                                var t = o.localStorage.getItem(n._dataId);
                                if (t !== n._serializedData) {
                                    n._serializedData = t;
                                    var r = null;
                                    t && (r = JSON.parse(t)), n._observable.fire("changed", r)
                                }
                            }
                        }
                    }, e.SharedData = n
                }(o.ns("iwc")),
                function(e) {
                    var n = o.generateGUID(),
                        t = new o.utils.Observable,
                        r = new o.utils.Observable,
                        i = o.iwc.getLocalStoragePrefix() + "_EBUS";

                    function a(e) {
                        if (e.key === i && e.newValue) {
                            var o = JSON.parse(e.newValue);
                            o.senderBusNodeId !== n && (t.fire.apply(window, o.args), r.fire.apply(window, o.args))
                        }
                    }

                    function c() {
                        var e = {
                                senderBusNodeId: n,
                                args: Array.prototype.slice.call(arguments, 0)
                            },
                            t = JSON.stringify(e);
                        o.localStorage.setItem(i, t), r.fire.apply(window, e.args)
                    }
                    o.localStorage.onChanged(a), o.copy(e, {
                        on: function(e, n, o, i) {
                            i ? r.on(e, n, o) : t.on(e, n, o)
                        },
                        once: function(e, n, o, i) {
                            i ? r.once(e, n, o) : t.once(e, n, o)
                        },
                        un: function(e, n, o, i) {
                            i ? r.un(e, n, o) : t.un(e, n, o)
                        },
                        fire: c
                    })
                }(o.ns("iwc.EventBus")),
                function(e) {
                    var n = 5e3,
                        t = 2e3,
                        r = {},
                        i = {},
                        a = window.name || o.generateGUID(),
                        c = !1,
                        s = new o.utils.Observable,
                        u = o.iwc.getLocalStoragePrefix() + "_WND_",
                        l = n / 2,
                        d = u + a;

                    function f() {
                        o.localStorage.removeItem(d)
                    }

                    function w(e) {
                        e === a && (p(), o.iwc.EventBus.fire("windowisaliveresponce", e))
                    }

                    function v(e) {
                        e !== a && i[e] && delete i[e]
                    }

                    function g(e) {
                        e.key ? e.key.substr(0, u.length) === u && y() : y()
                    }

                    function h() {
                        var e = {};
                        return o.localStorage.forEach((function(n, t) {
                            if (t && n.substr(0, u.length) === u) {
                                var o = n.substr(u.length);
                                e[o] = parseInt(t)
                            }
                        })), m(e), e
                    }

                    function p() {
                        y();
                        var e = (new Date).getTime();
                        r[a] = e, o.localStorage.setItem(d, e), c || (c = !0, s.fire("windowsmanagerready"))
                    }

                    function m(e) {
                        var r = (new Date).getTime();
                        for (var c in e)
                            if (e.hasOwnProperty(c) && c !== a) {
                                var s = r - e[c];
                                s > 2 * n || s > n && i[c] && r - i[c] > t ? (delete e[c], o.localStorage.removeItem(u + c)) : s > n ? i[c] || (i[c] = r, o.iwc.EventBus.fire("windowisaliverequest", c)) : i[c] && delete i[c]
                            }
                        for (var c in i) i.hasOwnProperty(c) && !e.hasOwnProperty(c) && delete i[c]
                    }

                    function I(e) {
                        return !!r[e]
                    }

                    function y() {
                        var e = h(),
                            n = [];
                        for (var t in e) e.hasOwnProperty(t) && !r[t] && n.push(t);
                        var o = [];
                        for (var t in r) r.hasOwnProperty(t) && !e[t] && o.push(t);
                        r = e, (n.length || o.length) && b(n, o)
                    }

                    function b(e, n) {
                        s.fire("windowschanged", e, n)
                    }

                    function S(e) {
                        e === a && (window.focus(), k())
                    }
                    o.windowOn("unload", f), o.localStorage.onChanged(g), o.iwc.EventBus.on("windowfocusrequest", S), o.iwc.EventBus.on("windowisaliverequest", w), o.iwc.EventBus.on("windowisaliveresponce", v), p(), window.setInterval(p, l);
                    var _ = 0;

                    function k() {
                        if (!_) {
                            var e = 500,
                                n = 3,
                                t = document.title,
                                o = !1;
                            _ = 2 * n;
                            var r = function() {
                                document.title = o ? t : "******", o = !o, _--, _ && window.setTimeout(r, e)
                            };
                            window.setTimeout(r, e)
                        }
                    }
                    o.copy(e, {
                        isWindowOpen: I,
                        getOpenWindowIds: function() {
                            var e = [];
                            for (var n in r) r.hasOwnProperty(n) && e.push(n);
                            return e
                        },
                        setFocus: function(e) {
                            e ? S(a) : o.iwc.EventBus.fire("windowfocusrequest", e)
                        },
                        getThisWindowId: function() {
                            return a
                        },
                        isReady: function() {
                            return c
                        },
                        onReady: function(e, n) {
                            c ? e.call(n) : s.once("windowsmanagerready", e, n)
                        },
                        onWindowsChanged: function(e, n) {
                            s.on("windowschanged", e, n)
                        },
                        onceWindowsChanged: function(e, n) {
                            s.once("windowschanged", e, n)
                        },
                        unsubscribe: function(e, n) {
                            s.un("windowschanged", e, n)
                        }
                    })
                }(o.ns("iwc.WindowMonitor")),
                function(e) {
                    var n = o.iwc.getLocalStoragePrefix() + "_LOCK_",
                        t = 500,
                        r = [],
                        i = !1;
                    o.localStorage.onChanged(w);
                    var a = new o.utils.Observable;

                    function c(e) {
                        a.on("storagechanged", e)
                    }

                    function s(e) {
                        a.un("storagechanged", e)
                    }

                    function u() {
                        a.fire("storagechanged")
                    }

                    function l(e) {
                        a.once("locksinitialized", e)
                    }

                    function d() {
                        i = !0, a.fire("locksinitialized")
                    }

                    function f(e, n) {
                        var r = !1,
                            a = !1,
                            u = !1,
                            d = null,
                            f = {
                                lockId: e,
                                release: function() {
                                    a = !0, u && (s(lock), u = !1), r && (r = !1, I(e))
                                },
                                isCaptured: function() {
                                    return r
                                },
                                isReleased: function() {
                                    return a
                                }
                            },
                            w = function() {
                                u || (c(g), d = window.setInterval(g, t), u = !0)
                            },
                            v = function() {
                                u && (s(g), window.clearInterval(d), u = !1)
                            },
                            g = function() {
                                r || a || (y(e) ? w() : (v(), o.iwc.Lock.interlockedCall(e, (function() {
                                    y(e) ? (w(), y(e) || (v(), m(f), r = !0, n())) : (m(f), r = !0, n())
                                }))))
                            };
                        return i ? g() : l(g), f
                    }

                    function w(e) {
                        if (e.key) {
                            var t = !e.newValue && !!e.oldValue;
                            t && e.key.substr(0, n.length) === n && u()
                        } else u()
                    }

                    function v(e) {
                        o.iwc.WindowMonitor.onReady((function() {
                            o.localStorage.forEach((function(e, t) {
                                if (t && e.substr(0, n.length) === n) {
                                    var r = e.substr(n.length);
                                    g(r, t) && o.iwc.Lock.interlockedCall(r, (function() {
                                        var n = o.localStorage.getItem(e);
                                        n && g(r, n) && (o.localStorage.removeItem(e), u())
                                    }))
                                }
                            })), e && e()
                        }))
                    }

                    function g(e, n) {
                        var t = JSON.parse(n);
                        if (!t || !t.timestamp || !t.ownerWindowId) return !0;
                        var r = t.ownerWindowId === o.iwc.WindowMonitor.getThisWindowId(),
                            i = !o.iwc.WindowMonitor.isWindowOpen(t.ownerWindowId);
                        return i || r && -1 === b(e)
                    }

                    function h() {
                        let e = [].concat(r);
                        for (var n = 0; n < e.length; n++) e[n].release()
                    }

                    function p() {
                        h()
                    }

                    function m(e) {
                        var t = (new Date).getTime(),
                            i = {
                                timestamp: t,
                                ownerWindowId: o.iwc.WindowMonitor.getThisWindowId()
                            },
                            a = n + e.lockId;
                        o.localStorage.setItem(a, JSON.stringify(i)), r.push(e)
                    }

                    function I(e) {
                        var t = b(e); - 1 !== t && r.splice(t, 1);
                        var i = n + e,
                            a = o.localStorage.getItem(i);
                        if (a) {
                            var c = JSON.parse(a);
                            o.iwc.WindowMonitor.getThisWindowId() === c.ownerWindowId && o.localStorage.removeItem(i)
                        }
                        u()
                    }

                    function y(e) {
                        var t = n + e,
                            r = o.localStorage.getItem(t);
                        if (r) {
                            var i = JSON.parse(r);
                            return o.iwc.WindowMonitor.isWindowOpen(i.ownerWindowId)
                        }
                        return !1
                    }

                    function b(e) {
                        for (var n = 0; n < r.length; n++)
                            if (r[n].lockId === e) return n;
                        return -1
                    }
                    o.windowOn("unload", p), v((function() {
                        o.iwc.WindowMonitor.onWindowsChanged((function(e, n) {
                            n.length && v()
                        })), d()
                    })), e.capture = f, o.lock = f
                }(o.ns("iwc.Lock")),
                function(e) {
                    var n = function(e, n) {
                        var t = this;
                        t._serverId = e, t._isReady = !1, t._observable = o.utils.Observable.decorate(t, !0), t._serverDescriptionHolder = new o.iwc.SharedData(e);
                        var r = t._serverDescriptionHolder.get();
                        r && t.updateContract(r), t._serverDescriptionHolder.onChanged((function(e) {
                            t.updateContract(e)
                        })), n && t.onReady(n)
                    };
                    n.prototype = {
                        constructor: n,
                        onReady: function(e, n) {
                            var t = this;
                            t._isReady ? e.call(n) : t._observable.once("ready", e, n)
                        },
                        updateContract: function(e) {
                            var n = this,
                                t = e;
                            t.forEach((function(e) {
                                n[e] || (n[e] = n.createProxyMethod(e))
                            })), n._isReady || (n._isReady = !0, n._observable.fire("ready"))
                        },
                        createProxyMethod: function(e) {
                            var n = this;
                            return function() {
                                var t = null,
                                    r = null,
                                    i = Array.prototype.slice.call(arguments, 0);
                                i.length && o.isFunction(i[i.length - 1]) && (t = o.generateGUID(), r = i.pop());
                                var a = {
                                    methodName: e,
                                    callId: t,
                                    args: i
                                };
                                o.iwc.EventBus.fire("servercall_" + n._serverId, a), t && o.iwc.EventBus.once("servercallback_" + t, r)
                            }
                        }
                    }, e.Client = n
                }(o.ns("iwc")),
                function(e) {
                    var n = function(e, n) {
                        var t = this;
                        t._serverId = e, t._serverDescriptionHolder = new o.iwc.SharedData(t._serverId), o.copy(t, n.exposed);
                        var r = n.exposed;
                        delete n.exposed, o.copy(t, n), o.lock(e, (function() {
                            t.onInit(), t.updateServerDescription(r), o.iwc.EventBus.on("servercall_" + t._serverId, t.onServerCall, t)
                        }))
                    };
                    n.prototype = {
                        constructor: n,
                        onInit: o.emptyFn,
                        updateServerDescription: function(e) {
                            var n = this,
                                t = [];
                            o.Object.each(e, (function(e) {
                                t.push(e)
                            })), n._serverDescriptionHolder.set(t)
                        },
                        onServerCall: function(e) {
                            var n = this,
                                t = e.args || [];
                            if (e.callId) {
                                var r = function() {
                                    var e = Array.prototype.slice.call(arguments, 0);
                                    e.unshift("servercallback_" + callId), o.iwc.EventBus.fire.apply(o.iwc.EventBus, e)
                                };
                                t.unshift(r)
                            } else t.unshift(o.emptyFn);
                            n[e.methodName].apply(n, t)
                        }
                    }, e.Server = n
                }(o.ns("iwc"))
        }
    }
]);
//# sourceMappingURL=lazy-iwc.9b430e25.js.map