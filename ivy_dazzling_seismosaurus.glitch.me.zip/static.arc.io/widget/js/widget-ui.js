(window["arcWidgetJsonp"] = window["arcWidgetJsonp"] || []).push([
    ["widget-ui"], {
        "04b3": function(t, e) {
            t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAOBAMAAADtZjDiAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAG1BMVEUAAAD///////////////////////////8AAADr8xjQAAAAB3RSTlMAM7cPx7jIAE21/gAAAAFiS0dEAIgFHUgAAAAJcEhZcwAACxIAAAsSAdLdfvwAAABESURBVAjXYxAyYGBgYFZkUHcG0ialDCYlBgzM7slA7MxgUgaUNCkzdgfJMbunlIDUMpiUg7hwGiYOVQfTBzMHZi7UHgCB3RAZ7HszogAAAABJRU5ErkJggg=="
        },
        "0766": function(t, e) {
            t.exports = "data:image/svg+xml,%3Csvg viewBox='0 0 44 44' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E %3Cg id='Page-3' stroke='none' stroke-width='1' fill='none' fill-rule='evenodd'%3E %3Cpath d='M44,21.9669858 L22.0329876,0 L0,22.0329858 L21.9669709,44 L44,21.9669858 Z M22.0157493,11.5 L32.5,22.4670529 L11.5,22.5 L22.0157493,11.5 Z' id='Shape' fill='%23FFFFFF' fill-rule='nonzero'%3E%3C/path%3E %3C/g%3E %3C/svg%3E"
        },
        "12e5": function(t, e, i) {},
        1585: function(t, e, i) {},
        1672: function(t, e) {
            t.exports = "data:image/svg+xml,%3Csvg viewBox='0 0 14 14' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E %3Cg id='Widget-Copy' stroke='none' stroke-width='1' fill='none' fill-rule='evenodd'%3E %3Cg id='Group-6' transform='translate(0.000000, -29.000000)' fill-rule='nonzero'%3E %3Cg id='noun_Rocket_780226' transform='translate(0.000000, 29.000000)'%3E %3Cpath d='M1.36714565,5.86444141 L3.0381202,6.52670298 C2.84971744,6.98132961 2.69943236,7.4495549 2.58868567,7.9269525 L2.52530387,8.20232114 L4.92084756,10.4933882 L5.20894662,10.4341839 C5.70841455,10.3283309 6.19828611,10.1846866 6.67393035,10.0046089 L7.36680859,11.601747 C7.38060235,11.6339017 7.41039271,11.657268 7.44607904,11.6639235 C7.48176536,11.670579 7.51856077,11.6596309 7.54398951,11.6347912 L8.5912296,10.6338262 C8.93683986,10.3035268 9.12001156,9.84882481 9.09540295,9.38227575 L9.05795008,8.73928998 C10.9968568,7.37070786 12.9588114,4.97087019 13.4932351,0.782513216 C13.5239597,0.569651728 13.4489353,0.355286158 13.2903939,0.202940033 C13.1318526,0.0505939077 12.9079801,-0.0222576496 12.6851173,0.00597365908 C8.30457103,0.52091301 5.79234722,2.39755027 4.36049489,4.24527383 L3.68922408,4.21222959 C3.20218668,4.18690011 2.72662087,4.35941972 2.37981385,4.68724049 L1.33257376,5.68820548 C1.3030378,5.71220555 1.2892194,5.74949159 1.29636367,5.78591073 C1.30350795,5.82232987 1.33051959,5.85229856 1.36714565,5.86444141 Z M8.08561575,3.42467529 C8.59237251,2.94198983 9.41241796,2.94289702 9.91800438,3.4267024 C10.4235908,3.91050778 10.4235908,4.69431786 9.91800438,5.17812324 C9.41241796,5.66192862 8.59237251,5.6628358 8.08561575,5.18015035 C7.84151076,4.94764052 7.70430265,4.63180373 7.70430265,4.30241282 C7.70430265,3.97302191 7.84151076,3.65718512 8.08561575,3.42467529 Z' id='Shape' fill='%237C87FF'%3E%3C/path%3E %3Cpath d='M1.05455817,10.6765083 C0.777266705,10.5834976 0.479496383,10.5607286 0.190260985,10.6104199 C0.138008797,10.6212226 0.083613494,10.6056251 0.046211455,10.5691146 C-0.000515224252,10.5246279 -0.013175595,10.4569727 0.0145205583,10.3997629 C0.321346058,9.76916869 1.1352259,8.50109611 2.6088526,9.52546744 C2.62442183,9.53878801 2.63331984,9.55781527 2.63331984,9.57778748 C2.63331984,9.5977597 2.62442183,9.61678696 2.6088526,9.63010752 C2.20873443,9.93128802 1.98248387,10.3965133 1.99952309,10.8830348 C2.00174741,10.9414435 2.05077281,10.9883026 2.11188172,10.9904286 C2.61868823,11.0099047 3.10510378,10.7983907 3.42273245,10.4204155 C3.43668494,10.4040869 3.45757489,10.3946144 3.47963201,10.3946144 C3.50168914,10.3946144 3.52257908,10.4040869 3.53653158,10.4204155 C3.74108191,10.653102 4.30431557,11.4131194 3.68058111,12.1469769 C3.40828099,12.459797 3.01812463,12.6576306 2.59444765,12.6977141 C1.98943962,12.7596721 0.871615264,12.9482996 0.414978253,13.4467168 C0.377628514,13.4890142 0.31895326,13.5082285 0.262313339,13.49671 C0.205673418,13.4851915 0.160264322,13.44481 0.144165136,13.3916431 C-0.0171703384,12.865689 -0.267816521,11.6898649 1.05455817,10.6765083 Z' id='Path' fill='%23D4A6FF'%3E%3C/path%3E %3C/g%3E %3C/g%3E %3C/g%3E %3C/svg%3E"
        },
        1860: function(t, e, i) {
            "use strict";
            i("c904")
        },
        2033: function(t, e, i) {
            "use strict";
            i("f4c6")
        },
        "305f": function(t, e) {
            t.exports = {
                headerTitle: "{publisherName} gets a boost from Arc",
                headerSubtitle: "Arc is a content exchange and delivery network.",
                speedValue: {
                    title: "{publisherName} is faster with Arc",
                    desc: "Arc loads content from people's devices near you instead of from slower servers.",
                    adblockDesc: "With Arc, content is loaded from people's devices near you instead of from slower servers."
                },
                moneyValue: {
                    title: "Arc lets websites make money without ads",
                    desc: "Just by being here, you help share this site's content with others to support it and see fewer ads.",
                    adblockDesc: "With Arc, you help share this site's content with others to support it."
                },
                safetyValue: {
                    title: "You're safe and in control",
                    desc: "Arc doesn't impact your data or performance, and you can opt out any time.",
                    adblockDesc: "Arc only shares content on Wi-Fi and doesn't impact your data or performance. You can disable it any time."
                },
                getArc: "Get Arc for your site",
                learnMore: "Learn more",
                optOut: "Opt out",
                optIn: "Opt in to Arc",
                welcomeToArc: "Welcome to Arc",
                optOutConfirmation: "You're now opted out 😢",
                enableArc: "Enable Arc and support {publisherName}",
                arcGoal: "At Arc, we endeavor to replace online ads. We want to improve your experience online and preserve your privacy. You can read more about how Arc does this",
                here: "here",
                optInLeadInMessage: "You previously elected to opt out of Arc. If you'd like to see fewer ads and support your favorite websites, you can opt back into Arc below. You can, of course, always elect to opt back out of Arc later.",
                optOutLeadInMessage: "If you elect to opt out of Arc, websites may show you more ads to recoup lost revenue. Of course, should you elect to opt out of Arc now, you can always elect to opt back in later.",
                thisWebsite: "this website",
                thisWebsiteCaps: "This website"
            }
        },
        "34a3": function(t, e, i) {
            "use strict";
            i("3fc4")
        },
        3506: function(t, e, i) {
            var o = {
                "./ecobricks-org.yaml": ["8ea9", "lang-ecobricks-org-yaml"],
                "./en.yaml": ["305f"]
            };

            function s(t) {
                if (!i.o(o, t)) return Promise.resolve().then((function() {
                    var e = new Error("Cannot find module '" + t + "'");
                    throw e.code = "MODULE_NOT_FOUND", e
                }));
                var e = o[t],
                    s = e[0];
                return Promise.all(e.slice(1).map(i.e)).then((function() {
                    return i.t(s, 7)
                }))
            }
            s.keys = function() {
                return Object.keys(o)
            }, s.id = "3506", t.exports = s
        },
        "3fc4": function(t, e, i) {},
        "4a98": function(t, e, i) {
            "use strict";
            i("a77a")
        },
        6145: function(t, e, i) {
            "use strict";
            i.r(e), i.d(e, "initWidget", (function() {
                return oe
            }));
            var o = i("2b0e"),
                s = i("2103"),
                a = i.n(s),
                n = i("5ff7"),
                r = i("c4d1"),
                c = i("8c32"),
                p = i("5de4"),
                l = i("0ecd"),
                d = function() {
                    var t = this,
                        e = t.$createElement,
                        i = t._self._c || e;
                    return i("div", {
                        style: {
                            height: t.documentHeight + "px"
                        },
                        attrs: {
                            id: "arc-widget-container"
                        }
                    }, [i("div", {
                        directives: [{
                            name: "click-outside",
                            rawName: "v-click-outside",
                            value: t.implicitlyHidePopper,
                            expression: "implicitlyHidePopper"
                        }],
                        staticClass: "intrinsic-ignore",
                        class: {
                            "arc-absolute-left": t.windowHasVerticalScrollbar && !t.isPopperOpen
                        },
                        attrs: {
                            id: "arc-widget"
                        }
                    }, [i("Launcher", {
                        attrs: {
                            isPopperOpen: t.isPopperOpen,
                            isOptedOut: t.isOptedOut
                        },
                        on: {
                            load: t.onLauncherLoad,
                            togglePopover: t.explicitlyTogglePopper
                        }
                    }), i("transition", {
                        attrs: {
                            name: "fade-popper"
                        }
                    }, [i("Popper", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: t.isPopperOpen,
                            expression: "isPopperOpen"
                        }],
                        class: "view-" + t.viewState.toLowerCase(),
                        attrs: {
                            showBackBtn: t.showBackBtn,
                            showOptLink: t.viewState === t.VIEW_STATES.DEFAULT,
                            isOptedOut: t.isOptedOut
                        },
                        on: {
                            back: function(e) {
                                return t.transition(t.VIEW_STATES.DEFAULT)
                            },
                            popperClosed: t.explicitlyTogglePopper,
                            showOptOutPopper: function(e) {
                                return t.transition(t.VIEW_STATES.OPT_OUT)
                            },
                            showOptInPopper: function(e) {
                                return t.transition(t.VIEW_STATES.OPT_IN)
                            }
                        }
                    }, [i(t.popperComponent, {
                        tag: "component",
                        on: {
                            optIn: t.onOptIn,
                            optOut: t.onOptOut
                        }
                    })], 1)], 1), i("div", {
                        style: t.pageShadowStyle,
                        attrs: {
                            id: "arc-page-shadow"
                        }
                    })], 1)])
                },
                u = [],
                h = i("a5a5"),
                C = i("190a"),
                f = i("c74e"),
                g = i("af2a"),
                m = i("3d15"),
                w = i("85b1"),
                v = i("0d31"),
                b = i("a59c");
            Object(b["a"])();

            function _(t) {
                let e = "hidden";

                function i() {
                    t.reportPropertySessionOnUnload()
                }

                function o(t) {
                    const i = !document[e],
                        o = {
                            focus: !0,
                            focusin: !0,
                            pageshow: !0,
                            blur: !1,
                            focusout: !1,
                            pagehide: !1
                        };
                    i || t && o[t.type]
                }
                return e in document ? document.addEventListener("visibilitychange", o) : (e = "mozHidden") in document ? document.addEventListener("mozvisibilitychange", o) : (e = "webkitHidden") in document ? document.addEventListener("webkitvisibilitychange", o) : (e = "msHidden") in document ? document.addEventListener("msvisibilitychange", o) : "onfocusin" in document ? document.onfocusin = document.onfocusout = o : (window.onblur = o, window.onfocus = o, window.onpageshow = o, window.onpagehide = o), window.addEventListener("beforeunload", i, !1), o(), () => {
                    document.removeEventListener("visibilitychange", o), window.removeEventListener("beforeunload", i, !1)
                }
            }
            async function O(t) {
                const e = _(t);
                return e
            }
            var A = i("c688");
            console.log;
            const y = i("34eb")("arc:p2p-client");

            function E(t, ...e) {
                return t.addEventListener(...e), () => t.removeEventListener(...e)
            }
            async function L(t) {
                const e = [];
                return navigator.connection && e.push(E(navigator.connection, "change", t)), e.push(E(window, "offline", t)), e.push(E(window, "online", t)), () => e.forEach(t => t())
            }
            async function k() {
                var t;
                return !Object(p["h"])() && "cellular" !== (null === (t = navigator.connection) || void 0 === t ? void 0 : t.type)
            }
            async function I(t, e, i, o) {
                v["a"].setNodeId(i), v["a"].setBroker(t), v["a"].setReporter(e);
                const s = await O(e);
                if (v["a"].addCleanupFn(s), t.once("master", m["b"](P)), t.on("newSession", m["b"](() => {
                        y("broker emitted new session"), v["a"].overmindClient && v["a"].overmindClient.sendStatusReport()
                    })), t.on("propertySessionId", m["b"](t => {
                        e.setPropertySessionId(t)
                    })), Object(p["f"])(location.href)) return;
                const a = await Object(A["a"])();
                await t.enableMasterEligibility(o, location.origin, a)
            }
            async function P() {
                y("Look at me, I'm the master now.");
                const {
                    default: t
                } = await Promise.all([i.e("vendors~widget-sc-client"), i.e("widget-sc-client")]).then(i.bind(null, "b07c")), e = new t(v["a"]);
                e.connect(), v["a"].setOvermindClient(e);
                const o = Object(w["a"])(async () => {
                        v["a"].updateSeederStatus(await k())
                    }, 1e3),
                    s = await L(o);
                v["a"].addCleanupFn(s), setTimeout(async () => {
                    v["a"].updateSeederStatus(await k())
                }, 4e3), Promise.race([Object(p["a"])(), Object(c["i"])(6e3)]).then(async () => {
                    var t;
                    if ("cellular" === (null === (t = navigator.connection) || void 0 === t ? void 0 : t.type)) return !1;
                    try {
                        const t = await i.e("chunk-2d2088b3").then(i.bind(null, "a4f0"));
                        await t.runSaturnBenchmarkInterval()
                    } catch (e) {}
                })
            }
            var x = function() {
                    var t = this,
                        e = t.$createElement,
                        o = t._self._c || e;
                    return o("i-frame", {
                        class: t.iframeClass,
                        attrs: {
                            title: "Arc.io Widget Launcher",
                            id: "arc-widget-launcher-iframe"
                        },
                        on: {
                            load: t.onLoad
                        }
                    }, [o("div", {
                        class: t.launcherClass,
                        attrs: {
                            id: "launcher"
                        },
                        on: {
                            click: t.togglePopover
                        }
                    }, [o("transition", {
                        attrs: {
                            name: "icon"
                        }
                    }, [t.isPopperOpen ? o("div", {
                        staticClass: "closer"
                    }, [o("img", {
                        key: "close",
                        attrs: {
                            id: "arc-close-icon",
                            src: i("64eb")
                        }
                    })]) : o("img", {
                        key: "arc",
                        attrs: {
                            id: "arc-icon",
                            src: i("0766")
                        }
                    })])], 1)])
                },
                S = [],
                T = i("a925"),
                $ = i("305f"),
                N = i.n($);
            const M = "ecobricks-org",
                U = new Set([M, "gobrik-com", "earthen-io", "russs-net"]);

            function B() {
                const t = Object(c["b"])(window.location.hostname).toLowerCase().replace(".", "-");
                return U.has(t) ? M : t
            }
            console.log;
            o["a"].use(T["a"]);
            const D = new T["a"]({
                    locale: "en",
                    fallbackLocale: "en",
                    messages: {
                        en: N.a
                    }
                }),
                j = ["ecobricks-org", "en"],
                F = ["en"],
                R = new Set([M]);

            function W(t) {
                return D.locale = t, t
            }

            function G() {
                const t = B();
                if (R.has(t)) return H(t);
                for (let e of navigator.languages)
                    if (e = e.split("-")[0], j.includes(e)) return H(e)
            }
            async function H(t) {
                if (D.locale === t) return W(t);
                if (F.includes(t)) return W(t);
                const e = await i("3506")(`./${t}.yaml`);
                return D.setLocaleMessage(t, e.default), F.push(t), W(t)
            }
            const {
                STATIC_ORIGIN: V,
                COMMIT_HASH: Z
            } = n["a"];
            var z, Y, J = {
                    render(t) {
                        return t("iframe", {
                            attrs: {
                                frameborder: 0,
                                title: "Arc Iframe"
                            },
                            class: "arc-iframe",
                            on: {
                                load: this.renderChildren
                            }
                        })
                    },
                    beforeUpdate() {
                        this.bodyApp && (this.bodyApp.children = Object.freeze(this.$slots.default))
                    },
                    methods: {
                        renderChildren() {
                            const {
                                body: t,
                                head: e
                            } = this.$el.contentDocument, {
                                default: i
                            } = this.$slots;
                            t.style.overflow = "hidden", t.style.margin = "0";
                            let s = Object(c["f"])(V, "widget", "widget", "css");
                            s += "?" + Z, this.addStyleSheet(s), this.addStyleSheet("https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.0/normalize.min.css"), e.insertAdjacentHTML("afterbegin", '<meta name="viewport" content="width=device-width,initial-scale=1">');
                            const a = document.createElement("div");
                            t.appendChild(a);
                            const n = B();
                            this.bodyApp = new o["a"]({
                                el: a,
                                i18n: D,
                                data: {
                                    children: Object.freeze(i)
                                },
                                render(t) {
                                    return t("div", {
                                        attrs: {
                                            class: "arc-iframe-app --" + n
                                        }
                                    }, this.children)
                                }
                            }), this.$emit("load")
                        },
                        addStyleSheet(t) {
                            const {
                                head: e
                            } = this.$el.contentDocument, i = document.createElement("link");
                            i.href = t, i.type = "text/css", i.rel = "stylesheet", e.appendChild(i)
                        }
                    }
                },
                q = J,
                K = (i("edb6"), i("2877")),
                Q = Object(K["a"])(q, z, Y, !1, null, null, null),
                X = Q.exports,
                tt = {
                    name: "Launcher",
                    props: {
                        isPopperOpen: Boolean,
                        isOptedOut: Boolean
                    },
                    data: () => ({
                        isMounted: !1
                    }),
                    computed: {
                        launcherClass: t => ({
                            "is-open": t.isPopperOpen,
                            "is-opted-out": t.isOptedOut
                        }),
                        iframeClass: t => ({
                            "is-visible": t.isMounted
                        })
                    },
                    mounted() {
                        setTimeout(() => {
                            this.isMounted = !0
                        }, 25)
                    },
                    methods: {
                        onLoad() {
                            const {
                                document: t
                            } = this.$el.contentWindow;
                            t.addEventListener("click", () => this.$emit("click")), this.$emit("load")
                        },
                        togglePopover() {
                            this.$emit("togglePopover")
                        }
                    },
                    components: {
                        "i-frame": X
                    }
                },
                et = tt,
                it = (i("cd0e"), i("d4c2"), Object(K["a"])(et, x, S, !1, null, "28716f3d", null)),
                ot = it.exports,
                st = function() {
                    var t = this,
                        e = t.$createElement,
                        o = t._self._c || e;
                    return o("i-frame", {
                        attrs: {
                            id: "arc-popper-iframe",
                            title: "Arc.io Widget Body"
                        }
                    }, [o("div", {
                        attrs: {
                            id: "popper"
                        }
                    }, [o("header", {
                        class: {
                            "is-opted-out": t.isOptedOut
                        }
                    }, [o("div", {
                        staticClass: "header-corner-button header-corner-button--left header-corner-button--arc-back"
                    }, [t.showBackBtn ? o("a", {
                        on: {
                            click: function(e) {
                                return t.$emit("back")
                            }
                        }
                    }, [o("svg", {
                        staticClass: "back-button",
                        attrs: {
                            viewBox: "0 0 10 10",
                            "aria-hidden": "true"
                        }
                    }, [o("g", {
                        attrs: {
                            "fill-rule": "evenodd"
                        }
                    }, [o("path", {
                        attrs: {
                            d: "M1 1l4 4-4 4"
                        }
                    })])])]) : o("a", {
                        on: {
                            click: t.openArcWindow
                        }
                    }, [o("img", {
                        staticClass: "header-arc-icon",
                        attrs: {
                            src: i("0766")
                        }
                    })])]), o("div", {
                        staticClass: "header-corner-button header-corner-button--right header-corner-button--close"
                    }, [o("span", {
                        on: {
                            click: function(e) {
                                return t.$emit("popperClosed")
                            }
                        }
                    }, [o("img", {
                        attrs: {
                            src: i("04b3")
                        }
                    })])]), o("div", {
                        staticClass: "header-content"
                    }, [o("div", {
                        staticClass: "header-content__icon"
                    }, [o("img", {
                        attrs: {
                            src: i("d919")
                        }
                    })]), o("div", {
                        staticClass: "header-content__title",
                        class: {
                            "header-content__title--wrapped": t.publisherName.length > t.LONG_PUBLISHER_NAME_LENGTH
                        }
                    }, [t._v(" " + t._s(t.$t("headerTitle", {
                        publisherName: t.publisherName
                    })) + " ")]), o("div", {
                        staticClass: "header-content__subtitle"
                    }, [t._v(" " + t._s(t.$t("headerSubtitle")) + " ")])])]), o("div", {
                        staticClass: "body"
                    }, [o("transition", {
                        attrs: {
                            name: "fade",
                            mode: "out-in"
                        }
                    }, [t._t("default")], 2)], 1), o("footer", [o("div", {
                        staticClass: "footer-liner"
                    }, [o("div", {
                        staticClass: "footer-entry footer-entry--security"
                    }, [o("a", {
                        attrs: {
                            href: t.ARC_SECURITY_URL,
                            target: "_blank"
                        }
                    }, [o("img", {
                        attrs: {
                            src: i("7d9f")
                        }
                    })])]), t.showOptLink ? o("div", {
                        staticClass: "footer-entry footer-entry--opt"
                    }, [t.isOptedOut ? t._e() : o("a", {
                        directives: [{
                            name: "t",
                            rawName: "v-t",
                            value: "optOut",
                            expression: "'optOut'"
                        }],
                        on: {
                            click: function(e) {
                                return t.$emit("showOptOutPopper")
                            }
                        }
                    })]) : t._e()])])])])
                },
                at = [];
            const nt = 17,
                rt = 600,
                ct = 2e3,
                {
                    HOMEPAGE_ORIGIN: pt
                } = n["a"];
            var lt = {
                    name: "Popper",
                    props: {
                        showBackBtn: Boolean,
                        showOptLink: Boolean,
                        isOptedOut: Boolean
                    },
                    data() {
                        const t = Object(c["b"])(window.location.hostname);
                        return {
                            publisherName: t,
                            LONG_PUBLISHER_NAME_LENGTH: nt,
                            ARC_HOME_URL: pt,
                            ABOUT_URL: pt + "/about",
                            ARC_SECURITY_URL: pt + "/about#arc-respects-your-privacy-and-performance",
                            SIGN_UP_URL: `${pt}?ref=${t.toLowerCase()}#signUp`
                        }
                    },
                    methods: {
                        openArcWindow() {
                            window.open(pt, "_blank")
                        }
                    },
                    components: {
                        "i-frame": X
                    }
                },
                dt = lt,
                ut = (i("1860"), Object(K["a"])(dt, st, at, !1, null, "d0762f48", null)),
                ht = ut.exports,
                Ct = function() {
                    var t = this,
                        e = t.$createElement,
                        i = t._self._c || e;
                    return i("div", {
                        staticClass: "popper-body"
                    }, [i("div", {
                        staticClass: "popper-cards"
                    }, [i("div", {
                        staticClass: "popper-card popper-card--speed"
                    }, [i("div", {
                        staticClass: "popper-card__liner"
                    }, [i("div", {
                        staticClass: "popper-card__row"
                    }, [t._m(0), i("div", {
                        staticClass: "popper-card__title"
                    }, [t._v(" " + t._s(t.$t("speedValue.title", {
                        publisherName: t.limitPublisherNameLength(t.$t("thisWebsiteCaps"), t.publisherName)
                    })) + " ")])]), i("div", {
                        staticClass: "popper-card__row"
                    }, [i("div", {
                        staticClass: "popper-card__desc"
                    }, [t._v(" " + t._s(t.$t("speedValue.desc")) + " ")])])])]), i("div", {
                        staticClass: "popper-card popper-card--money"
                    }, [i("div", {
                        staticClass: "popper-card__liner"
                    }, [i("div", {
                        staticClass: "popper-card__row"
                    }, [t._m(1), i("div", {
                        staticClass: "popper-card__title"
                    }, [t._v(" " + t._s(t.$t("moneyValue.title")) + " ")])]), i("div", {
                        staticClass: "popper-card__row"
                    }, [i("div", {
                        staticClass: "popper-card__desc"
                    }, [t._v(" " + t._s(t.$t("moneyValue.desc")) + " ")])])])]), i("div", {
                        staticClass: "popper-card popper-card--safety"
                    }, [i("div", {
                        staticClass: "popper-card__liner"
                    }, [i("div", {
                        staticClass: "popper-card__row"
                    }, [t._m(2), i("div", {
                        staticClass: "popper-card__title"
                    }, [t._v(" " + t._s(t.$t("safetyValue.title")) + " ")])]), i("div", {
                        staticClass: "popper-card__row"
                    }, [i("div", {
                        staticClass: "popper-card__desc"
                    }, [t._v(" " + t._s(t.$t("safetyValue.desc")) + " ")])])])])]), i("div", {
                        staticClass: "popper-action-buttons-container"
                    }, [i("a", {
                        staticClass: "popper-action-button popper-action-button--get-arc",
                        attrs: {
                            href: t.SIGN_UP_URL,
                            target: "_blank"
                        }
                    }, [i("span", [t._v(t._s(t.$t("getArc")))]), i("svg", {
                        staticClass: "hover-arrow",
                        attrs: {
                            width: "9",
                            height: "9",
                            viewBox: "0 0 10 10",
                            "aria-hidden": "true"
                        }
                    }, [i("g", {
                        attrs: {
                            "fill-rule": "evenodd"
                        }
                    }, [i("path", {
                        staticClass: "hover-arrow__line-path",
                        attrs: {
                            d: "M0 5h7"
                        }
                    }), i("path", {
                        staticClass: "hover-arrow__tip-path",
                        attrs: {
                            d: "M1 1l4 4-4 4"
                        }
                    })])])]), i("a", {
                        staticClass: "popper-action-button popper-action-button--learn-more",
                        attrs: {
                            href: t.ABOUT_URL,
                            target: "_blank"
                        }
                    }, [i("span", [t._v(t._s(t.$t("learnMore")))]), i("svg", {
                        staticClass: "hover-arrow",
                        attrs: {
                            width: "9",
                            height: "9",
                            viewBox: "0 0 10 10",
                            "aria-hidden": "true"
                        }
                    }, [i("g", {
                        attrs: {
                            "fill-rule": "evenodd"
                        }
                    }, [i("path", {
                        staticClass: "hover-arrow__line-path",
                        attrs: {
                            d: "M0 5h7"
                        }
                    }), i("path", {
                        staticClass: "hover-arrow__tip-path",
                        attrs: {
                            d: "M1 1l4 4-4 4"
                        }
                    })])])])])])
                },
                ft = [function() {
                    var t = this,
                        e = t.$createElement,
                        o = t._self._c || e;
                    return o("div", {
                        staticClass: "popper-card__icon popper-card__icon--rocket"
                    }, [o("img", {
                        attrs: {
                            src: i("1672")
                        }
                    })])
                }, function() {
                    var t = this,
                        e = t.$createElement,
                        o = t._self._c || e;
                    return o("div", {
                        staticClass: "popper-card__icon popper-card__icon--money"
                    }, [o("img", {
                        attrs: {
                            src: i("98fc")
                        }
                    })])
                }, function() {
                    var t = this,
                        e = t.$createElement,
                        o = t._self._c || e;
                    return o("div", {
                        staticClass: "popper-card__icon popper-card__icon--lock"
                    }, [o("img", {
                        attrs: {
                            src: i("7266")
                        }
                    })])
                }];

            function gt(t, e) {
                return e.length <= nt ? e : t
            }
            const {
                HOMEPAGE_ORIGIN: mt
            } = n["a"];
            var wt = {
                    name: "DefaultPopper",
                    data() {
                        const t = Object(c["b"])(window.location.hostname);
                        return {
                            publisherName: t,
                            ABOUT_URL: mt + "/about",
                            SIGN_UP_URL: `${mt}?ref=${t.toLowerCase()}#signUp`
                        }
                    },
                    methods: {
                        limitPublisherNameLength: gt
                    }
                },
                vt = wt,
                bt = (i("93fe"), Object(K["a"])(vt, Ct, ft, !1, null, "6a81eb44", null)),
                _t = bt.exports,
                Ot = function() {
                    var t = this,
                        e = t.$createElement,
                        i = t._self._c || e;
                    return i("div", {
                        staticClass: "popper-body"
                    }, [i("div", {
                        staticClass: "popper-cards"
                    }, [i("div", {
                        staticClass: "popper-card popper-card--speed"
                    }, [i("div", {
                        staticClass: "popper-card__liner"
                    }, [i("div", {
                        staticClass: "popper-card__row"
                    }, [t._m(0), i("div", {
                        staticClass: "popper-card__title"
                    }, [t._v(" " + t._s(t.$t("speedValue.title", {
                        publisherName: t.limitPublisherNameLength(t.$t("thisWebsiteCaps"), t.publisherName)
                    })) + " ")])]), i("div", {
                        staticClass: "popper-card__row"
                    }, [i("div", {
                        staticClass: "popper-card__desc"
                    }, [t._v(" " + t._s(t.$t("speedValue.adblockDesc")) + " ")])])])]), i("div", {
                        staticClass: "popper-card popper-card--money"
                    }, [i("div", {
                        staticClass: "popper-card__liner"
                    }, [i("div", {
                        staticClass: "popper-card__row"
                    }, [t._m(1), i("div", {
                        staticClass: "popper-card__title"
                    }, [t._v(" " + t._s(t.$t("moneyValue.title")) + " ")])]), i("div", {
                        staticClass: "popper-card__row"
                    }, [i("div", {
                        staticClass: "popper-card__desc"
                    }, [t._v(" " + t._s(t.$t("moneyValue.adblockDesc")) + " ")])])])]), i("div", {
                        staticClass: "popper-card popper-card--safety"
                    }, [i("div", {
                        staticClass: "popper-card__liner"
                    }, [i("div", {
                        staticClass: "popper-card__row"
                    }, [t._m(2), i("div", {
                        staticClass: "popper-card__title"
                    }, [t._v(" " + t._s(t.$t("safetyValue.title")) + " ")])]), i("div", {
                        staticClass: "popper-card__row"
                    }, [i("div", {
                        staticClass: "popper-card__desc"
                    }, [t._v(" " + t._s(t.$t("safetyValue.adblockDesc")) + " ")])])])])]), i("div", {
                        staticClass: "popper-action-buttons-container"
                    }, [i("button", {
                        ref: "button",
                        staticClass: "popper-action-button popper-action-button--opt-in",
                        attrs: {
                            disabled: t.btnClicked
                        },
                        on: {
                            click: t.optIn
                        }
                    }, [t.btnClicked && !t.showOptInConfirmation ? i("span", {
                        staticClass: "chasing-tail-spinner"
                    }, [i("svg", {
                        attrs: {
                            viewBox: "0 0 100 100"
                        }
                    }, [i("circle", {
                        attrs: {
                            cx: "50",
                            cy: "50",
                            r: "45"
                        }
                    })])]) : t.btnClicked ? i("span", [t._v(t._s(t.$t("welcomeToArc")) + "!")]) : i("span", [t._v(" " + t._s(t.$t("enableArc", {
                        publisherName: t.limitPublisherNameLength(t.$t("thisWebsite"), t.publisherName)
                    })) + " ")]), i("div", {
                        staticClass: "confetti-container"
                    }, [i("div", {
                        ref: "confettiRoot",
                        staticClass: "confetti-root",
                        style: {
                            top: t.confettiTop + "px"
                        }
                    })])])])])
                },
                At = [function() {
                    var t = this,
                        e = t.$createElement,
                        o = t._self._c || e;
                    return o("div", {
                        staticClass: "popper-card__icon popper-card__icon--rocket"
                    }, [o("img", {
                        attrs: {
                            src: i("1672")
                        }
                    })])
                }, function() {
                    var t = this,
                        e = t.$createElement,
                        o = t._self._c || e;
                    return o("div", {
                        staticClass: "popper-card__icon popper-card__icon--money"
                    }, [o("img", {
                        attrs: {
                            src: i("98fc")
                        }
                    })])
                }, function() {
                    var t = this,
                        e = t.$createElement,
                        o = t._self._c || e;
                    return o("div", {
                        staticClass: "popper-card__icon popper-card__icon--lock"
                    }, [o("img", {
                        attrs: {
                            src: i("7266")
                        }
                    })])
                }];
            const yt = ["#a864fd", "#29cdff", "#78ff44", "#ff718d", "#fdff6a"];

            function Et(t, e, i) {
                return Array.from({
                    length: e
                }).map((e, o) => {
                    const s = document.createElement("div"),
                        a = i[o % i.length];
                    return s.style["background-color"] = a, s.style.width = "10px", s.style.height = "10px", s.style.position = "absolute", t.appendChild(s), s
                })
            }

            function Lt(t, e, i, o) {
                const s = t * (Math.PI / 180),
                    a = e * (Math.PI / 180);
                return {
                    x: 0,
                    y: 0,
                    wobble: 10 * o(),
                    velocity: .5 * i + o() * i,
                    angle2D: -s + (.5 * a - o() * a),
                    angle3D: -Math.PI / 4 + o() * (Math.PI / 2),
                    tiltAngle: o() * Math.PI
                }
            }

            function kt(t, e, i) {
                t.physics.x += Math.cos(t.physics.angle2D) * t.physics.velocity, t.physics.y += Math.sin(t.physics.angle2D) * t.physics.velocity, t.physics.z += Math.sin(t.physics.angle3D) * t.physics.velocity, t.physics.wobble += .1, t.physics.velocity *= i, t.physics.y += 3, t.physics.tiltAngle += .1;
                const {
                    x: o,
                    y: s,
                    tiltAngle: a,
                    wobble: n
                } = t.physics, r = o + 10 * Math.cos(n), c = s + 10 * Math.sin(n), p = `translate3d(${r}px, ${c}px, 0) rotate3d(1, 1, 1, ${a}rad)`;
                t.element.style.transform = p, t.element.style.opacity = 1 - e
            }

            function It(t, e, i) {
                const o = 200;
                let s = 0;

                function a() {
                    e.forEach(t => kt(t, s / o, i)), s += 1, s < o ? requestAnimationFrame(a) : e.forEach(e => {
                        if (e.element.parentNode === t) return t.removeChild(e.element)
                    })
                }
                requestAnimationFrame(a)
            }

            function Pt(t, {
                angle: e = 90,
                decay: i = .9,
                spread: o = 45,
                startVelocity: s = 45,
                elementCount: a = 50,
                colors: n = yt,
                random: r = Math.random
            } = {}) {
                const c = Et(t, a, n),
                    p = c.map(t => ({
                        element: t,
                        physics: Lt(e, o, s, r)
                    }));
                It(t, p, i)
            }
            const {
                HOMEPAGE_ORIGIN: xt
            } = n["a"];
            var St = {
                    name: "AdblockPopper",
                    data() {
                        const t = Object(c["b"])(window.location.hostname);
                        return {
                            publisherName: t,
                            confettiTop: 0,
                            btnClicked: !1,
                            showOptInConfirmation: !1,
                            ABOUT_URL: xt + "/about",
                            SIGN_UP_URL: `${xt}?ref=${t.toLowerCase()}#signUp`
                        }
                    },
                    methods: {
                        limitPublisherNameLength: gt,
                        async optIn() {
                            this.btnClicked = !0, await Object(c["i"])(rt), this.showOptInConfirmation = !0, this.confettiTop = this.$refs.button.getBoundingClientRect().top, Pt(this.$refs.confettiRoot, {
                                spread: 80,
                                elementCount: 55,
                                startVelocity: 28
                            }), await Object(c["i"])(ct), this.$emit("optIn")
                        }
                    }
                },
                Tt = St,
                $t = (i("e4af"), Object(K["a"])(Tt, Ot, At, !1, null, "4f5018ea", null)),
                Nt = $t.exports,
                Mt = function() {
                    var t = this,
                        e = t.$createElement,
                        i = t._self._c || e;
                    return i("div", {
                        staticClass: "popper-body"
                    }, [i("div", {
                        staticClass: "message-popper-content"
                    }, [i("div", {
                        staticClass: "message-popper-title"
                    }, [t._v(" " + t._s(t.$t("welcomeToArc")) + " ")]), i("div", {
                        staticClass: "message-popper-content-blocks"
                    }, [i("div", {
                        staticClass: "message-popper-content-block"
                    }, [t._v(" " + t._s(t.$t("arcGoal")) + " "), i("a", {
                        attrs: {
                            href: t.$env.HOMEPAGE_ORIGIN + "/about",
                            target: "_blank"
                        }
                    }, [t._v(t._s(t.$t("here")))]), t._v(". ")]), i("div", {
                        staticClass: "message-popper-content-block"
                    }, [t._v(" " + t._s(t.$t("optInLeadInMessage")) + " ")])]), i("div", {
                        staticClass: "popper-action-buttons-container"
                    }, [i("button", {
                        ref: "button",
                        staticClass: "popper-action-button popper-action-button--opt-in",
                        attrs: {
                            disabled: t.btnClicked
                        },
                        on: {
                            click: t.optIn
                        }
                    }, [t.btnClicked && !t.showOptInConfirmation ? i("span", {
                        staticClass: "chasing-tail-spinner"
                    }, [i("svg", {
                        attrs: {
                            viewBox: "0 0 100 100"
                        }
                    }, [i("circle", {
                        attrs: {
                            cx: "50",
                            cy: "50",
                            r: "45"
                        }
                    })])]) : t.btnClicked ? i("span", [t._v(" " + t._s(t.$t("welcomeToArc")) + "! ")]) : i("span", [t._v(t._s(t.$t("optIn")))]), i("div", {
                        staticClass: "confetti-container"
                    }, [i("div", {
                        ref: "confettiRoot",
                        staticClass: "confetti-root",
                        style: {
                            top: t.confettiTop + "px"
                        }
                    })])])])])])
                },
                Ut = [],
                Bt = {
                    name: "OptInPopper",
                    data: () => ({
                        confettiTop: 0,
                        btnClicked: !1,
                        showOptInConfirmation: !1
                    }),
                    methods: {
                        async optIn() {
                            this.btnClicked = !0, await Object(c["i"])(rt), this.showOptInConfirmation = !0, this.confettiTop = this.$refs.button.getBoundingClientRect().top, Pt(this.$refs.confettiRoot, {
                                spread: 80,
                                elementCount: 55,
                                startVelocity: 28
                            }), await Object(c["i"])(ct), this.$emit("optIn")
                        }
                    }
                },
                Dt = Bt,
                jt = (i("34a3"), Object(K["a"])(Dt, Mt, Ut, !1, null, "1929e6be", null)),
                Ft = jt.exports,
                Rt = function() {
                    var t = this,
                        e = t.$createElement,
                        i = t._self._c || e;
                    return i("div", {
                        staticClass: "popper-body"
                    }, [i("div", {
                        staticClass: "message-popper-content"
                    }, [i("div", {
                        staticClass: "message-popper-title"
                    }, [t._v(" Sure about opting out? ")]), i("div", {
                        staticClass: "message-popper-content-blocks"
                    }, [i("div", {
                        staticClass: "message-popper-content-block"
                    }, [t._v(" " + t._s(t.$t("arcGoal")) + " "), i("a", {
                        attrs: {
                            href: t.$env.HOMEPAGE_ORIGIN + "/about",
                            target: "_blank"
                        }
                    }, [t._v(t._s(t.$t("here")))]), t._v(". ")]), i("div", {
                        staticClass: "message-popper-content-block"
                    }, [t._v(" " + t._s(t.$t("optOutLeadInMessage")) + " ")])]), i("div", {
                        staticClass: "popper-action-buttons-container"
                    }, [i("button", {
                        staticClass: "popper-action-button popper-action-button--opt-out",
                        attrs: {
                            disabled: t.btnClicked
                        },
                        on: {
                            click: t.onClick
                        }
                    }, [t.btnClicked && !t.showOptOutConfirmation ? i("span", {
                        staticClass: "chasing-tail-spinner"
                    }, [i("svg", {
                        attrs: {
                            viewBox: "0 0 100 100"
                        }
                    }, [i("circle", {
                        attrs: {
                            cx: "50",
                            cy: "50",
                            r: "45"
                        }
                    })])]) : t.showOptOutConfirmation ? i("span", [t._v(" " + t._s(t.$t("optOutConfirmation")) + " ")]) : i("span", [t._v(t._s(t.$t("optOut")))])])])])])
                },
                Wt = [],
                Gt = {
                    name: "OptOutPopper",
                    data: () => ({
                        btnClicked: !1,
                        showOptOutConfirmation: !1
                    }),
                    methods: {
                        async onClick() {
                            this.btnClicked = !0, await Object(c["i"])(rt), this.showOptOutConfirmation = !0, await Object(c["i"])(ct), this.$emit("optOut")
                        }
                    }
                },
                Ht = Gt,
                Vt = (i("4a98"), Object(K["a"])(Ht, Rt, Wt, !1, null, "178d1527", null)),
                Zt = Vt.exports,
                zt = i("517b");
            const Yt = i("34eb")("arc:p2p-client"),
                Jt = (console.log, 36e5),
                qt = {
                    DEFAULT: "DEFAULT",
                    OPT_OUT: "OPT_OUT",
                    OPT_IN: "OPT_IN",
                    ADBLOCK: "ADBLOCK"
                };
            var Kt = {
                    name: "Widget",
                    data() {
                        return {
                            isLauncherVisible: !0,
                            isPopperOpen: !1,
                            documentHeight: 0,
                            windowHasVerticalScrollbar: !1,
                            hasAdblock: !1,
                            widgetOpt: {},
                            widgetConfig: {},
                            viewState: qt.DEFAULT,
                            demoAdblock: !1,
                            VIEW_STATES: qt
                        }
                    },
                    computed: {
                        pageShadowStyle: t => ({
                            opacity: t.isPopperOpen ? 1 : 0
                        }),
                        isWidgetEnabled: t => t.widgetOpt.state !== h["j"].OPTED_OUT,
                        isOptedIn: t => t.widgetOpt.state === h["j"].OPTED_IN,
                        isOptedOut: t => t.widgetOpt.state === h["j"].OPTED_OUT,
                        isOptUndecided: t => t.widgetOpt.state === h["j"].UNDECIDED,
                        showBackBtn: t => [qt.OPT_OUT, qt.OPT_IN].includes(t.viewState),
                        popperComponent: t => {
                            switch (t.viewState) {
                                case qt.OPT_OUT:
                                    return Zt;
                                case qt.OPT_IN:
                                    return Ft;
                                case qt.ADBLOCK:
                                    return Nt;
                                case qt.DEFAULT:
                                default:
                                    return _t
                            }
                        },
                        requestOptIn() {
                            const t = this.widgetConfig[l["a"]] === l["c"];
                            return t && this.hasAdblock && !Object(p["g"])()
                        },
                        widgetOptDateStr() {
                            const t = {
                                    month: "long",
                                    year: "numeric",
                                    day: "numeric"
                                },
                                e = new Date(this.widgetOpt.date);
                            return e.toLocaleString(this.$i18n.locale, t)
                        }
                    },
                    watch: {
                        async isPopperOpen() {
                            if (this.isPopperOpen && this.reporter && this.reporter.reportWidgetOpened(), !this.isPopperOpen && this.requestOptIn && this.isOptUndecided) {
                                const t = { ...this.widgetOpt,
                                    dismissedAt: Date.now()
                                };
                                Yt("adblock user closed popper without decision, scheduling next popper auto appearance", t), await this.broker.setWidgetOptState(t)
                            }
                        }
                    },
                    async mounted() {
                        var t;
                        const e = Object(zt["a"])(() => {
                            this.documentHeight = document.documentElement.offsetHeight, this.windowHasVerticalScrollbar = this.documentHeight > window.innerHeight
                        }, 100);
                        for (let n = 0; n < 3; n++) setTimeout(e, 0);
                        if (window.addEventListener("resize", e), this.widgetConfig = Object(l["d"])(), null !== (t = this.widgetConfig) && void 0 !== t && t.src) try {
                            const t = new URL(this.widgetConfig.src),
                                e = t.href.split(/#|[?]/)[2],
                                i = (new URLSearchParams(e), "arc-demo-adblock-jwinFQkxWOXN"),
                                o = document.getElementById(i),
                                s = window.location.pathname;
                            this.demoAdblock = null !== o && ("/adblockDemo" === s || "/adblockDemo/" === s)
                        } catch (a) {
                            Yt(a)
                        }
                        const i = await Object(g["a"])(),
                            o = p["i"].get("nodeId", await i.getOrGenerateMyNodeId());
                        this.broker = i, this.hasAdblock = await Object(p["e"])(), f["a"].setClientId(o);
                        const {
                            propertyId: s
                        } = this.widgetConfig;
                        C["a"].setNodeId(o), C["a"].setPropertyId(s), this.reporter = C["a"], this.widgetOpt = await this.broker.getWidgetOptState(), Yt("widgetOpt", { ...this.widgetOpt
                        }), this.checkWidgetStatus(i, C["a"], o), this.reportNodeInfo(i, C["a"], s), r["a"].configureScope(t => {
                            t.setTag("nodeId", o), t.setTag("arcClient", h["p"]), t.setTag("CDN", this.widgetConfig.CDN), t.setTag("locale", this.$i18n.locale)
                        })
                    },
                    methods: {
                        transition(t) {
                            this.viewState = t
                        },
                        async showLauncherIfWidgetIsInstalledCorrectly() {
                            var t;
                            const e = await window.__arc__.cdnConfigPromise,
                                i = (null === e || void 0 === e || null === (t = e.autoCdnConfig) || void 0 === t ? void 0 : t.mappings) || {},
                                o = Object.keys(i).length > 0,
                                s = await window.__arc__.isSwInstalledPromise;
                            s && o ? this.isLauncherVisible = !0 : (s || Yt("INSTALLATION ERR: sw didnt respond to health check"), o || Yt("INSTALLATION ERR: cdnConfig missing at least 1 domain"))
                        },
                        onOptIn() {
                            this.onOptDecision(this.broker.enableWidget)
                        },
                        onOptOut() {
                            this.onOptDecision(this.broker.disableWidget)
                        },
                        async onOptDecision(t) {
                            this.isPopperOpen = !1, await Object(c["i"])(500);
                            const {
                                propertyId: e
                            } = this.widgetConfig, {
                                origin: i
                            } = window.location;
                            await t(e, i), this.widgetOpt = await this.broker.getWidgetOptState();
                            const o = this.isOptedOut ? qt.OPT_IN : qt.DEFAULT;
                            this.transition(o)
                        },
                        implicitlyHidePopper() {
                            this.isPopperOpen && (this.requestOptIn && this.isOptUndecided ? Yt("Refusing to close popper, adblock user must decide or click on launcher to close") : this.isPopperOpen = !1)
                        },
                        explicitlyTogglePopper() {
                            this.isPopperOpen = !this.isPopperOpen
                        },
                        async checkWidgetStatus(t, e, i) {
                            const {
                                dismissedAt: o
                            } = this.widgetOpt, {
                                propertyId: s,
                                isReverseProxied: a
                            } = this.widgetConfig, n = () => I(t, e, i, s);
                            if (this.demoAdblock && this.transition(qt.ADBLOCK), this.isOptedIn) n();
                            else if (this.isOptedOut) this.transition(qt.OPT_IN);
                            else if (this.isOptUndecided)
                                if (!this.hasAdblock || a) n();
                                else if (this.transition(qt.ADBLOCK), this.requestOptIn) {
                                const t = Date.now() - new Date(o),
                                    e = t > 24 * Jt;
                                o && !e || (this.isPopperOpen = !0, Yt(`showing adblockPopper. dismissedAt=${o}, showAgain=${e}`))
                            } else Yt("adblock user is undecided but doing nothing b/c requestOptIn=false.")
                        },
                        async reportNodeInfo(t, e, i) {
                            const o = "lastNodeInfoReportAt",
                                s = 6 * Jt,
                                a = localStorage.getItem(o);
                            if (a && Date.now() - Number(a) < s) return;
                            localStorage.setItem(o, Date.now());
                            const {
                                usage: n,
                                quota: r
                            } = await t.getCustomStorageEstimate(), c = {
                                propertyId: i,
                                ...this.widgetOpt,
                                ...Object(p["c"])(),
                                usedStorage: n,
                                totalStorage: r
                            };
                            e.reportNodeInfo(c)
                        },
                        onLauncherLoad() {
                            window.postMessage(h["k"].WIDGET_UI_LOAD, location.origin)
                        }
                    },
                    components: {
                        Launcher: ot,
                        Popper: ht,
                        DefaultPopper: _t,
                        AdblockPopper: Nt,
                        OptInPopper: Ft,
                        OptOutPopper: Zt
                    }
                },
                Qt = Kt,
                Xt = (i("2033"), Object(K["a"])(Qt, d, u, !1, null, "006c9b03", null)),
                te = Xt.exports;
            i("f04d");

            function ee() {
                try {
                    return window.self !== window.top
                } catch {
                    return !0
                }
            }

            function ie() {
                const {
                    env: t,
                    seeder: e
                } = Object(l["d"])();
                return ("wp" !== t || !ee()) && !!e
            }
            async function oe() {
                if (ie()) try {
                    G(), await Promise.race([Object(p["a"])(), Object(c["i"])(5e3)])
                } finally {
                    const t = Object(p["d"])(),
                        e = document.createElement("div");
                    t.appendChild(e), new o["a"]({
                        i18n: D,
                        render: t => t(te)
                    }).$mount(e)
                }
            }
            o["a"].use(a.a), o["a"].config.productionTip = !1, o["a"].config.errorHandler = function(t, e, i) {
                console.log("Vue global error handler", t, e, i), r["a"].captureException(t)
            }, o["a"].prototype.$env = Object.freeze({ ...n["a"]
            }), o["a"].prototype.$cl = console.log
        },
        "639b": function(t, e, i) {},
        "64eb": function(t, e) {
            t.exports = "data:image/svg+xml,%3Csvg width='82' height='82' viewBox='0 0 82 82' fill='none' xmlns='http://www.w3.org/2000/svg'%3E %3Cpath d='M2.76002 70.76L32.52 41L2.76002 11.24C2.19577 10.6842 1.74714 10.0221 1.44002 9.29208C1.1329 8.56202 0.973367 7.77837 0.970617 6.98635C0.967867 6.19432 1.12196 5.40959 1.424 4.67741C1.72604 3.94523 2.17006 3.2801 2.73044 2.72038C3.29082 2.16065 3.95648 1.71742 4.68901 1.41624C5.42155 1.11506 6.20646 0.961897 6.99848 0.96558C7.79051 0.969263 8.57396 1.12972 9.30367 1.4377C10.0334 1.74568 10.6949 2.19509 11.25 2.76L41 32.52L70.76 2.76C71.3152 2.19509 71.9767 1.74568 72.7064 1.4377C73.4361 1.12972 74.2195 0.969263 75.0116 0.96558C75.8036 0.961897 76.5885 1.11506 77.321 1.41624C78.0536 1.71742 78.7192 2.16065 79.2796 2.72038C79.84 3.2801 80.284 3.94523 80.586 4.67741C80.8881 5.40959 81.0422 6.19432 81.0394 6.98635C81.0367 7.77837 80.8771 8.56202 80.57 9.29208C80.2629 10.0221 79.8143 10.6842 79.25 11.24L49.48 41L79.24 70.76C79.8043 71.3158 80.2529 71.9778 80.56 72.7079C80.8671 73.438 81.0267 74.2216 81.0294 75.0136C81.0322 75.8057 80.8781 76.5904 80.576 77.3226C80.274 78.0548 79.83 78.7199 79.2696 79.2796C78.7092 79.8393 78.0436 80.2826 77.311 80.5837C76.5785 80.8849 75.7936 81.0381 75.0016 81.0344C74.2095 81.0307 73.4261 80.8703 72.6964 80.5623C71.9667 80.2543 71.3052 79.8049 70.75 79.24L41 49.48L11.24 79.24C10.1124 80.3508 8.59148 80.971 7.00863 80.9655C5.42578 80.96 3.90923 80.3292 2.78932 79.2107C1.66941 78.0921 1.03689 76.5763 1.02953 74.9934C1.02216 73.4106 1.64056 71.889 2.75002 70.76H2.76002Z' fill='%23FAF8FF'/%3E %3C/svg%3E"
        },
        7266: function(t, e) {
            t.exports = "data:image/svg+xml,%3Csvg viewBox='0 0 12 14' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E %3Cg id='Widget-Copy' stroke='none' stroke-width='1' fill='none' fill-rule='evenodd'%3E %3Cg id='Group-6' transform='translate(0.000000, -12.000000)' fill-rule='nonzero'%3E %3Cg id='stripe-lock' transform='translate(0.000000, 12.000000)'%3E %3Cpath d='M8.26874668,6 L8.26874668,4.32 C8.25229363,2.86873 7.09205791,1.70104994 5.66649332,1.70104994 C4.24092874,1.70104994 3.08069305,2.86873 3.06424,4.32 L3.06424,6 L1.33333333,6 L1.33333333,4.41176469 C1.33333333,1.97541176 3.27328,0 5.66666667,0 C8.06005334,0 10,1.97541176 10,4.41176469 L10,6 L8.26874668,6 Z' id='Shape' fill='%237C87FF'%3E%3C/path%3E %3Cpath d='M4.66666668,9.19999998 C4.66666668,9.6736 4.93500001,10.0864 5.33333334,10.3072 L5.33333334,11.44 C5.33333334,11.7934622 5.63181019,12.08 6,12.08 L6,14 L1.33333334,14 C0.596953666,14 0,13.4269245 0,12.72 L0,7.27999999 C0,6.57307552 0.596953666,6 1.33333334,6 L6,6 L6,7.91999999 C5.26362034,7.91999999 4.66666668,8.4930755 4.66666668,9.19999998 Z' id='Shape' fill='%23D4A6FF'%3E%3C/path%3E %3Cpath d='M10.5882353,14 L6,14 L6,12.08 C6.38984808,12.08 6.70588235,11.7934622 6.70588235,11.44 L6.70588235,10.3072 C7.14276939,10.0792686 7.4119765,9.65700825 7.41176473,9.19999998 C7.41176473,8.4930755 6.77969611,7.91999999 6,7.91999999 L6,6 L10.5882353,6 C11.3679314,6 12,6.57307552 12,7.27999999 L12,12.72 C12,13.4269245 11.3679314,14 10.5882353,14 Z' id='Shape' fill='%237C87FF'%3E%3C/path%3E %3C/g%3E %3C/g%3E %3C/g%3E %3C/svg%3E"
        },
        "72a2": function(t, e, i) {},
        "7d9f": function(t, e) {
            t.exports = "data:image/svg+xml,%3Csvg viewBox='0 0 12 14' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E %3Cg stroke='none' stroke-width='1' fill='none' fill-rule='evenodd'%3E %3Cg fill='%23525F7F' fill-rule='nonzero'%3E %3Cpath d='M8.26874668,6 L8.26874668,4.32 C8.25229363,2.86873 7.09205791,1.70104994 5.66649332,1.70104994 C4.24092874,1.70104994 3.08069305,2.86873 3.06424,4.32 L3.06424,6 L1.33333333,6 L1.33333333,4.41176469 C1.33333333,1.97541176 3.27328,0 5.66666667,0 C8.06005334,0 10,1.97541176 10,4.41176469 L10,6 L8.26874668,6 Z' id='Shape'%3E%3C/path%3E %3Cpath d='M4.66666668,9.19999998 C4.66666668,9.6736 4.93500001,10.0864 5.33333334,10.3072 L5.33333334,11.44 C5.33333334,11.7934622 5.63181019,12.08 6,12.08 L6,14 L1.33333334,14 C0.596953666,14 0,13.4269245 0,12.72 L0,7.27999999 C0,6.57307552 0.596953666,6 1.33333334,6 L6,6 L6,7.91999999 C5.26362034,7.91999999 4.66666668,8.4930755 4.66666668,9.19999998 Z' id='Shape'%3E%3C/path%3E %3Cpath d='M10.5882353,14 L6,14 L6,12.08 C6.38984808,12.08 6.70588235,11.7934622 6.70588235,11.44 L6.70588235,10.3072 C7.14276939,10.0792686 7.4119765,9.65700825 7.41176473,9.19999998 C7.41176473,8.4930755 6.77969611,7.91999999 6,7.91999999 L6,6 L10.5882353,6 C11.3679314,6 12,6.57307552 12,7.27999999 L12,12.72 C12,13.4269245 11.3679314,14 10.5882353,14 Z' id='Shape'%3E%3C/path%3E %3C/g%3E %3C/g%3E %3C/svg%3E"
        },
        "93fe": function(t, e, i) {
            "use strict";
            i("f47e")
        },
        "98fc": function(t, e) {
            t.exports = "data:image/svg+xml,%3Csvg viewBox='0 0 18 12' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E %3Cg id='Widget-Copy' stroke='none' stroke-width='1' fill='none' fill-rule='evenodd'%3E %3Cg id='Group-6' transform='translate(0.000000, -13.000000)' fill-rule='nonzero'%3E %3Cg id='dollars' transform='translate(0.000000, 13.000000)'%3E %3Cpath d='M13.5001483,0 C14.0743355,0 14.5384615,0.428884615 14.5384615,0.9585 L14.5374232,2.07692308 L3.11493962,2.07692308 C2.58272994,2.07692308 2.1436294,2.44672665 2.08361611,2.92359545 L2.07662642,3.03542308 L2.0755881,8.30769231 L1.03831321,8.30769231 C0.465164317,8.30769231 0,7.87880769 0,7.34919231 L0,0.9585 C0,0.428884615 0.465164317,0 1.03831321,0 L13.5001483,0 Z' id='Combined-Shape' fill='%23D4A6FF'%3E%3C/path%3E %3Cpath d='M16.9615385,11.7692308 L4.5,11.7692308 C3.92676923,11.7692308 3.46153846,11.3403462 3.46153846,10.8107308 L3.46153846,4.42003846 C3.46153846,3.89042308 3.92676923,3.46153846 4.5,3.46153846 L16.9615385,3.46153846 C17.5347692,3.46153846 18,3.89042308 18,4.42003846 L18,10.8107308 C18,11.3403462 17.5347692,11.7692308 16.9615385,11.7692308 Z M10.737,5.53845686 C9.99387383,5.5373485 9.30660313,5.93277312 8.93407613,6.57578276 C8.56154914,7.21879239 8.56036156,8.01169858 8.93096075,8.65582123 C9.30155993,9.29994389 9.98764306,9.69742545 10.7307669,9.69854323 C11.8795427,9.70025903 12.8122024,8.77038889 12.8139278,7.62161538 C12.8156436,6.47284188 11.8857735,5.54018213 10.737,5.53845686 Z' id='Shape' fill='%236874FF' opacity='0.868047805'%3E%3C/path%3E %3C/g%3E %3C/g%3E %3C/g%3E %3C/svg%3E"
        },
        a77a: function(t, e, i) {},
        c904: function(t, e, i) {},
        cd0e: function(t, e, i) {
            "use strict";
            i("639b")
        },
        d4c2: function(t, e, i) {
            "use strict";
            i("1585")
        },
        d919: function(t, e) {
            t.exports = "data:image/svg+xml,%3Csvg viewBox='0 0 23 21' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E %3Cg id='Widget-Copy' stroke='none' stroke-width='1' fill='none' fill-rule='evenodd'%3E %3Cg id='Group-2' transform='translate(0.000000, -30.000000)' fill-rule='nonzero'%3E %3Cg id='Group' transform='translate(0.000000, 30.000000)'%3E %3Cg id='fastForwardIconArrow-link'%3E %3Cpath d='M1.79605263,0.210249307 L14.0719298,9.058241 C14.3751392,9.27704087 14.55552,9.63321529 14.55552,10.0131233 C14.55552,10.3930312 14.3751392,10.7492057 14.0719298,10.9680055 L1.79605263,19.8159972 C1.44754188,20.0668823 0.99157165,20.0978899 0.613739483,19.8963989 C0.235907316,19.6949078 -0.000787109173,19.2945146 -1.95703558e-06,18.8581948 L-1.95703558e-06,1.16805171 C-0.000787109173,0.731731925 0.235907316,0.331338739 0.613739483,0.129847675 C0.99157165,-0.0716433893 1.44754188,-0.0406357408 1.79605263,0.210249307 Z' id='fastForwardIconArrow' fill='%239A2CFF' opacity='0.422688802'%3E%3C/path%3E %3Cpath d='M9.77850877,0.210249307 L22.054386,9.058241 C22.3575953,9.27704087 22.5379762,9.63321529 22.5379762,10.0131233 C22.5379762,10.3930312 22.3575953,10.7492057 22.054386,10.9680055 L9.77850877,19.8159972 C9.42999802,20.0668823 8.97402779,20.0978899 8.59619562,19.8963989 C8.21836346,19.6949078 7.98166903,19.2945146 7.98245418,18.8581948 L7.98245418,1.16805171 C7.98166903,0.731731925 8.21836346,0.331338739 8.59619562,0.129847675 C8.97402779,-0.0716433893 9.42999802,-0.0406357408 9.77850877,0.210249307 Z' id='fastForwardIconArrow' fill='%236874FF' opacity='0.614560082'%3E%3C/path%3E %3Cpath d='M7.99774145,4.68019392 L14.0719298,9.058241 C14.3751392,9.27704087 14.55552,9.63321529 14.55552,10.0131233 C14.55552,10.3930312 14.3751392,10.7492057 14.0719298,10.9680055 L7.9919353,15.3502375 L7.99774145,4.68019392 Z' id='fastForwardIconArrow' fill='%236874FF' opacity='0.980422247'%3E%3C/path%3E %3C/g%3E %3C/g%3E %3C/g%3E %3C/g%3E %3C/svg%3E"
        },
        e4af: function(t, e, i) {
            "use strict";
            i("12e5")
        },
        edb6: function(t, e, i) {
            "use strict";
            i("72a2")
        },
        f04d: function(t, e, i) {},
        f47e: function(t, e, i) {},
        f4c6: function(t, e, i) {}
    }
]);
//# sourceMappingURL=widget-ui.js.map?9c5947c3