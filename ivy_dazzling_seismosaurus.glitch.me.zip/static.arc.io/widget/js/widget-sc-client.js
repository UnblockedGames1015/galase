(window["arcWidgetJsonp"] = window["arcWidgetJsonp"] || []).push([
    ["widget-sc-client"], {
        b07c: function(t, s, e) {
            "use strict";
            e.r(s);
            var i = e("ade3"),
                o = e("faa1"),
                r = e.n(o),
                n = e("517b");
            const a = e("7812"),
                c = (console.log, 30),
                h = "overmind",
                u = {
                    STATUS_REPORT: h + ".statusReport",
                    GET_SWARM_CONFIG: h + ".getSwarmConfig",
                    UPDATE_SWARM_CONFIG: h + ".updateSwarmConfig",
                    TASK_RESULT: h + ".taskResult",
                    DISCONNECT: h + ".disconnect"
                },
                d = t => `${h}.task.${t}`;

            function p(t = {}) {
                const s = a.create({
                    hostname: "socket.arc.io",
                    port: Number("443"),
                    batchOnHandshake: !0,
                    ...t
                });
                return s
            }

            function T(t, s, e) {
                (async () => {
                    for await (const i of t.listener(s)) e(i)
                })()
            }

            function l(t, s, e, i = {}) {
                (async () => {
                    for await (const o of t.subscribe(s, i)) e(o)
                })()
            }
            const k = (t, s) => `${t}/${s}`;

            function f(t, s = c) {
                const e = m(0, s),
                    i = k(t, e);
                return i
            }

            function m(t, s) {
                return Math.floor(Math.random() * (s - t + 1) + t)
            }
            var g = e("a5a5"),
                y = e("8c32");
            const R = e("34eb")("arc:p2p-client");
            class S extends r.a {
                constructor(t) {
                    super(), Object(i["a"])(this, "sendStatusReport", Object(n["a"])(async () => {
                        if (this.isDestroyed) return;
                        const t = await this.p2pClient.getStatusReport();
                        t.config = this.config, t.tasks = this.tasks, R("statusReport", t);
                        const s = f(u.STATUS_REPORT);
                        this.socket.transmitPublish(s, t);
                        const e = this.socket.state === this.socket.OPEN;
                        !e && this.isFirstStatusReport && (this.isFirstStatusReport = !1, await this.sendStatusReportViaHTTP(t)), this._trackMessageHistory(s, "send"), clearTimeout(this.reportTimeoutId), this.reportTimeoutId = setTimeout(this.sendStatusReport, g["h"])
                    }, 1e4)), this.p2pClient = t, this.tasks = [], this.msgHistory = [], this.config = {
                        isAcceptingTasks: !0,
                        maxFilesSeeding: g["f"]
                    }, this.isFirstStatusReport = !0, this.isDestroyed = !1, this.reportTimeoutId = null
                }
                async _queueTask(t) {
                    const {
                        length: s
                    } = this.tasks;
                    this.tasks.push(t), 0 === s && this._performTasks(this.tasks)
                }
                async _performTasks(t) {
                    while (t.length > 0) {
                        const s = t[0],
                            e = await this._performTask(s);
                        s.returnResult && this._sendTaskResult(s.id, e), t.shift()
                    }
                    this.sendStatusReport()
                }
                async _performTask(t) {
                    R("Task", t);
                    const {
                        timeout: s = 5e3
                    } = t;
                    let e;
                    try {
                        const i = this.p2pClient.performTask(t);
                        e = await Object(y["h"])(i, s)
                    } catch (i) {
                        R("task err", i), e = i instanceof Error ? Object(y["d"])(i) : "Error: " + i
                    }
                    return e
                }
                async _sendTaskResult(t, s) {
                    const e = f(u.TASK_RESULT);
                    this.socket.transmitPublish(e, {
                        taskId: t,
                        result: s
                    })
                }
                async sendStatusReportViaHTTP(t) {
                    const s = "https://warden.arc.io/mailbox/statusReport";
                    await fetch(s, {
                        method: "POST",
                        headers: {
                            "Content-Type": "text/plain;charset=UTF-8"
                        },
                        body: JSON.stringify({
                            statusReport: t
                        })
                    })
                }
                _registerEvents(t) {
                    T(t, "connect", t => R("socket connect", t)), T(t, "close", t => R("socket close", t)), T(t, "error", ({
                        error: t
                    }) => R("socket err", t)), T(t, "message", ({
                        message: t
                    }) => {
                        this._trackMessageHistory(t, "receive")
                    });
                    const {
                        nodeId: s
                    } = this.p2pClient;
                    l(t, d(s), t => {
                        t.forEach(t => this._queueTask(t))
                    })
                }
                _trackMessageHistory(t, s) {
                    const e = 100;
                    this.msgHistory.push({
                        [s]: t,
                        at: new Date
                    }), this.msgHistory.length > e && this.msgHistory.shift()
                }
                async connect() {
                    const {
                        nodeId: t
                    } = this.p2pClient, s = p({
                        secure: !0,
                        query: {
                            nodeId: t
                        }
                    });
                    this.socket = s, this._registerEvents(s)
                }
                disconnect() {
                    this.socket.disconnect()
                }
                destroy() {
                    this.isDestroyed = !0, this.disconnect(), this.removeAllListeners(), clearTimeout(this.reportTimeoutId)
                }
            }
            s["default"] = S
        }
    }
]);
//# sourceMappingURL=widget-sc-client.js.map?197dbd2e