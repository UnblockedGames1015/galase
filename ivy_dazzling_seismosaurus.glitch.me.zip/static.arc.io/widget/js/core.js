(function(e) {
    function t(t) {
        for (var n, r, o = t[0], s = t[1], a = 0, c = []; a < o.length; a++) r = o[a], Object.prototype.hasOwnProperty.call(i, r) && i[r] && c.push(i[r][0]), i[r] = 0;
        for (n in s) Object.prototype.hasOwnProperty.call(s, n) && (e[n] = s[n]);
        u && u(t);
        while (c.length) c.shift()()
    }
    var n = {},
        r = {
            core: 0
        },
        i = {
            core: 0
        };

    function o(e) {
        return s.p + "widget/js/" + ({
            brokers: "brokers",
            "vendors~widget-ui": "vendors~widget-ui",
            "widget-ui": "widget-ui",
            "lazy-iwc": "lazy-iwc",
            "lazy-modules": "lazy-modules",
            "lang-ecobricks-org-yaml": "lang-ecobricks-org-yaml",
            "vendors~widget-sc-client": "vendors~widget-sc-client",
            "widget-sc-client": "widget-sc-client"
        }[e] || e) + ".js?" + {
            brokers: "cfaaa772",
            "vendors~widget-ui": "c9b0de53",
            "widget-ui": "9c5947c3",
            "lazy-iwc": "8aedfc26",
            "lazy-modules": "fe421cd5",
            "chunk-2d2088b3": "d7d4d404",
            "lang-ecobricks-org-yaml": "8a1e7498",
            "vendors~widget-sc-client": "35fccb86",
            "widget-sc-client": "197dbd2e",
            "chunk-2d0cf2b3": "d98d2542"
        }[e]
    }

    function s(t) {
        if (n[t]) return n[t].exports;
        var r = n[t] = {
            i: t,
            l: !1,
            exports: {}
        };
        return e[t].call(r.exports, r, r.exports, s), r.l = !0, r.exports
    }
    s.e = function(e) {
        var t = [],
            n = {
                "widget-ui": 1
            };
        r[e] ? t.push(r[e]) : 0 !== r[e] && n[e] && t.push(r[e] = new Promise((function(t, n) {
            for (var i = "widget/css/widget.css?ce271de", o = s.p + i, a = document.getElementsByTagName("link"), c = 0; c < a.length; c++) {
                var h = a[c],
                    u = h.getAttribute("data-href") || h.getAttribute("href");
                if ("stylesheet" === h.rel && (u === i || u === o)) return t()
            }
            var f = document.getElementsByTagName("style");
            for (c = 0; c < f.length; c++) {
                h = f[c], u = h.getAttribute("data-href");
                if (u === i || u === o) return t()
            }
            var d = document.createElement("link");
            d.rel = "stylesheet", d.type = "text/css", d.onload = t, d.onerror = function(t) {
                var i = t && t.target && t.target.src || o,
                    s = new Error("Loading CSS chunk " + e + " failed.\n(" + i + ")");
                s.code = "CSS_CHUNK_LOAD_FAILED", s.request = i, delete r[e], d.parentNode.removeChild(d), n(s)
            }, d.href = o;
            var l = document.getElementsByTagName("head")[0];
            l.appendChild(d)
        })).then((function() {
            r[e] = 0
        })));
        var a = i[e];
        if (0 !== a)
            if (a) t.push(a[2]);
            else {
                var c = new Promise((function(t, n) {
                    a = i[e] = [t, n]
                }));
                t.push(a[2] = c);
                var h, u = document.createElement("script");
                u.charset = "utf-8", u.timeout = 120, s.nc && u.setAttribute("nonce", s.nc), u.src = o(e);
                var f = new Error;
                h = function(t) {
                    u.onerror = u.onload = null, clearTimeout(d);
                    var n = i[e];
                    if (0 !== n) {
                        if (n) {
                            var r = t && ("load" === t.type ? "missing" : t.type),
                                o = t && t.target && t.target.src;
                            f.message = "Loading chunk " + e + " failed.\n(" + r + ": " + o + ")", f.name = "ChunkLoadError", f.type = r, f.request = o, n[1](f)
                        }
                        i[e] = void 0
                    }
                };
                var d = setTimeout((function() {
                    h({
                        type: "timeout",
                        target: u
                    })
                }), 12e4);
                u.onerror = u.onload = h, document.head.appendChild(u)
            }
        return Promise.all(t)
    }, s.m = e, s.c = n, s.d = function(e, t, n) {
        s.o(e, t) || Object.defineProperty(e, t, {
            enumerable: !0,
            get: n
        })
    }, s.r = function(e) {
        "undefined" !== typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, s.t = function(e, t) {
        if (1 & t && (e = s(e)), 8 & t) return e;
        if (4 & t && "object" === typeof e && e && e.__esModule) return e;
        var n = Object.create(null);
        if (s.r(n), Object.defineProperty(n, "default", {
                enumerable: !0,
                value: e
            }), 2 & t && "string" != typeof e)
            for (var r in e) s.d(n, r, function(t) {
                return e[t]
            }.bind(null, r));
        return n
    }, s.n = function(e) {
        var t = e && e.__esModule ? function() {
            return e["default"]
        } : function() {
            return e
        };
        return s.d(t, "a", t), t
    }, s.o = function(e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    }, s.p = "https://static.arc.io/", s.oe = function(e) {
        throw console.error(e), e
    };
    var a = window["arcWidgetJsonp"] = window["arcWidgetJsonp"] || [],
        c = a.push.bind(a);
    a.push = t, a = a.slice();
    for (var h = 0; h < a.length; h++) t(a[h]);
    var u = c;
    s(s.s = "20c9")
})({
    0: function(e, t) {},
    "00ee": function(e, t, n) {
        var r = n("b622"),
            i = r("toStringTag"),
            o = {};
        o[i] = "z", e.exports = "[object z]" === String(o)
    },
    "0366": function(e, t, n) {
        var r = n("1c0b");
        e.exports = function(e, t, n) {
            if (r(e), void 0 === t) return e;
            switch (n) {
                case 0:
                    return function() {
                        return e.call(t)
                    };
                case 1:
                    return function(n) {
                        return e.call(t, n)
                    };
                case 2:
                    return function(n, r) {
                        return e.call(t, n, r)
                    };
                case 3:
                    return function(n, r, i) {
                        return e.call(t, n, r, i)
                    }
            }
            return function() {
                return e.apply(t, arguments)
            }
        }
    },
    "04d1": function(e, t, n) {
        var r = n("342f"),
            i = r.match(/firefox\/(\d+)/i);
        e.exports = !!i && +i[1]
    },
    "051a": function(e, t, n) {
        /*! simple-peer. MIT License. Feross Aboukhadijeh <https://feross.org/opensource> */
        const r = n("34eb")("simple-peer"),
            i = n("de83"),
            o = n("11dc"),
            s = n("e372"),
            a = n("8712"),
            c = n("b6aa"),
            {
                Buffer: h
            } = n("b639"),
            u = 65536,
            f = 5e3,
            d = 5e3;

        function l(e) {
            return e.replace(/a=ice-options:trickle\s\n/g, "")
        }

        function p(e) {
            console.warn(e)
        }
        class g extends s.Duplex {
            constructor(e) {
                if (e = Object.assign({
                        allowHalfOpen: !1
                    }, e), super(e), this._id = o(4).toString("hex").slice(0, 7), this._debug("new peer %o", e), this.channelName = e.initiator ? e.channelName || o(20).toString("hex") : null, this.initiator = e.initiator || !1, this.channelConfig = e.channelConfig || g.channelConfig, this.channelNegotiated = this.channelConfig.negotiated, this.config = Object.assign({}, g.config, e.config), this.offerOptions = e.offerOptions || {}, this.answerOptions = e.answerOptions || {}, this.sdpTransform = e.sdpTransform || (e => e), this.streams = e.streams || (e.stream ? [e.stream] : []), this.trickle = void 0 === e.trickle || e.trickle, this.allowHalfTrickle = void 0 !== e.allowHalfTrickle && e.allowHalfTrickle, this.iceCompleteTimeout = e.iceCompleteTimeout || f, this.destroyed = !1, this.destroying = !1, this._connected = !1, this.remoteAddress = void 0, this.remoteFamily = void 0, this.remotePort = void 0, this.localAddress = void 0, this.localFamily = void 0, this.localPort = void 0, this._wrtc = e.wrtc && "object" === typeof e.wrtc ? e.wrtc : i(), !this._wrtc) throw "undefined" === typeof window ? c(new Error("No WebRTC support: Specify `opts.wrtc` option in this environment"), "ERR_WEBRTC_SUPPORT") : c(new Error("No WebRTC support: Not a supported browser"), "ERR_WEBRTC_SUPPORT");
                this._pcReady = !1, this._channelReady = !1, this._iceComplete = !1, this._iceCompleteTimer = null, this._channel = null, this._pendingCandidates = [], this._isNegotiating = !1, this._firstNegotiation = !0, this._batchedNegotiation = !1, this._queuedNegotiation = !1, this._sendersAwaitingStable = [], this._senderMap = new Map, this._closingInterval = null, this._remoteTracks = [], this._remoteStreams = [], this._chunk = null, this._cb = null, this._interval = null;
                try {
                    this._pc = new this._wrtc.RTCPeerConnection(this.config)
                } catch (t) {
                    return void this.destroy(c(t, "ERR_PC_CONSTRUCTOR"))
                }
                this._isReactNativeWebrtc = "number" === typeof this._pc._peerConnectionId, this._pc.oniceconnectionstatechange = () => {
                    this._onIceStateChange()
                }, this._pc.onicegatheringstatechange = () => {
                    this._onIceStateChange()
                }, this._pc.onconnectionstatechange = () => {
                    this._onConnectionStateChange()
                }, this._pc.onsignalingstatechange = () => {
                    this._onSignalingStateChange()
                }, this._pc.onicecandidate = e => {
                    this._onIceCandidate(e)
                }, "object" === typeof this._pc.peerIdentity && this._pc.peerIdentity.catch(e => {
                    this.destroy(c(e, "ERR_PC_PEER_IDENTITY"))
                }), this.initiator || this.channelNegotiated ? this._setupData({
                    channel: this._pc.createDataChannel(this.channelName, this.channelConfig)
                }) : this._pc.ondatachannel = e => {
                    this._setupData(e)
                }, this.streams && this.streams.forEach(e => {
                    this.addStream(e)
                }), this._pc.ontrack = e => {
                    this._onTrack(e)
                }, this._debug("initial negotiation"), this._needsNegotiation(), this._onFinishBound = () => {
                    this._onFinish()
                }, this.once("finish", this._onFinishBound)
            }
            get bufferSize() {
                return this._channel && this._channel.bufferedAmount || 0
            }
            get connected() {
                return this._connected && "open" === this._channel.readyState
            }
            address() {
                return {
                    port: this.localPort,
                    family: this.localFamily,
                    address: this.localAddress
                }
            }
            signal(e) {
                if (!this.destroying) {
                    if (this.destroyed) throw c(new Error("cannot signal after peer is destroyed"), "ERR_DESTROYED");
                    if ("string" === typeof e) try {
                        e = JSON.parse(e)
                    } catch (t) {
                        e = {}
                    }
                    this._debug("signal()"), e.renegotiate && this.initiator && (this._debug("got request to renegotiate"), this._needsNegotiation()), e.transceiverRequest && this.initiator && (this._debug("got request for transceiver"), this.addTransceiver(e.transceiverRequest.kind, e.transceiverRequest.init)), e.candidate && (this._pc.remoteDescription && this._pc.remoteDescription.type ? this._addIceCandidate(e.candidate) : this._pendingCandidates.push(e.candidate)), e.sdp && this._pc.setRemoteDescription(new this._wrtc.RTCSessionDescription(e)).then(() => {
                        this.destroyed || (this._pendingCandidates.forEach(e => {
                            this._addIceCandidate(e)
                        }), this._pendingCandidates = [], "offer" === this._pc.remoteDescription.type && this._createAnswer())
                    }).catch(e => {
                        this.destroy(c(e, "ERR_SET_REMOTE_DESCRIPTION"))
                    }), e.sdp || e.candidate || e.renegotiate || e.transceiverRequest || this.destroy(c(new Error("signal() called with invalid signal data"), "ERR_SIGNALING"))
                }
            }
            _addIceCandidate(e) {
                const t = new this._wrtc.RTCIceCandidate(e);
                this._pc.addIceCandidate(t).catch(e => {
                    !t.address || t.address.endsWith(".local") ? p("Ignoring unsupported ICE candidate.") : this.destroy(c(e, "ERR_ADD_ICE_CANDIDATE"))
                })
            }
            send(e) {
                if (!this.destroying) {
                    if (this.destroyed) throw c(new Error("cannot send after peer is destroyed"), "ERR_DESTROYED");
                    this._channel.send(e)
                }
            }
            addTransceiver(e, t) {
                if (!this.destroying) {
                    if (this.destroyed) throw c(new Error("cannot addTransceiver after peer is destroyed"), "ERR_DESTROYED");
                    if (this._debug("addTransceiver()"), this.initiator) try {
                        this._pc.addTransceiver(e, t), this._needsNegotiation()
                    } catch (n) {
                        this.destroy(c(n, "ERR_ADD_TRANSCEIVER"))
                    } else this.emit("signal", {
                        type: "transceiverRequest",
                        transceiverRequest: {
                            kind: e,
                            init: t
                        }
                    })
                }
            }
            addStream(e) {
                if (!this.destroying) {
                    if (this.destroyed) throw c(new Error("cannot addStream after peer is destroyed"), "ERR_DESTROYED");
                    this._debug("addStream()"), e.getTracks().forEach(t => {
                        this.addTrack(t, e)
                    })
                }
            }
            addTrack(e, t) {
                if (this.destroying) return;
                if (this.destroyed) throw c(new Error("cannot addTrack after peer is destroyed"), "ERR_DESTROYED");
                this._debug("addTrack()");
                const n = this._senderMap.get(e) || new Map;
                let r = n.get(t);
                if (r) throw r.removed ? c(new Error("Track has been removed. You should enable/disable tracks that you want to re-add."), "ERR_SENDER_REMOVED") : c(new Error("Track has already been added to that stream."), "ERR_SENDER_ALREADY_ADDED");
                r = this._pc.addTrack(e, t), n.set(t, r), this._senderMap.set(e, n), this._needsNegotiation()
            }
            replaceTrack(e, t, n) {
                if (this.destroying) return;
                if (this.destroyed) throw c(new Error("cannot replaceTrack after peer is destroyed"), "ERR_DESTROYED");
                this._debug("replaceTrack()");
                const r = this._senderMap.get(e),
                    i = r ? r.get(n) : null;
                if (!i) throw c(new Error("Cannot replace track that was never added."), "ERR_TRACK_NOT_ADDED");
                t && this._senderMap.set(t, r), null != i.replaceTrack ? i.replaceTrack(t) : this.destroy(c(new Error("replaceTrack is not supported in this browser"), "ERR_UNSUPPORTED_REPLACETRACK"))
            }
            removeTrack(e, t) {
                if (this.destroying) return;
                if (this.destroyed) throw c(new Error("cannot removeTrack after peer is destroyed"), "ERR_DESTROYED");
                this._debug("removeSender()");
                const n = this._senderMap.get(e),
                    r = n ? n.get(t) : null;
                if (!r) throw c(new Error("Cannot remove track that was never added."), "ERR_TRACK_NOT_ADDED");
                try {
                    r.removed = !0, this._pc.removeTrack(r)
                } catch (i) {
                    "NS_ERROR_UNEXPECTED" === i.name ? this._sendersAwaitingStable.push(r) : this.destroy(c(i, "ERR_REMOVE_TRACK"))
                }
                this._needsNegotiation()
            }
            removeStream(e) {
                if (!this.destroying) {
                    if (this.destroyed) throw c(new Error("cannot removeStream after peer is destroyed"), "ERR_DESTROYED");
                    this._debug("removeSenders()"), e.getTracks().forEach(t => {
                        this.removeTrack(t, e)
                    })
                }
            }
            _needsNegotiation() {
                this._debug("_needsNegotiation"), this._batchedNegotiation || (this._batchedNegotiation = !0, a(() => {
                    this._batchedNegotiation = !1, this.initiator || !this._firstNegotiation ? (this._debug("starting batched negotiation"), this.negotiate()) : this._debug("non-initiator initial negotiation request discarded"), this._firstNegotiation = !1
                }))
            }
            negotiate() {
                if (!this.destroying) {
                    if (this.destroyed) throw c(new Error("cannot negotiate after peer is destroyed"), "ERR_DESTROYED");
                    this.initiator ? this._isNegotiating ? (this._queuedNegotiation = !0, this._debug("already negotiating, queueing")) : (this._debug("start negotiation"), setTimeout(() => {
                        this._createOffer()
                    }, 0)) : this._isNegotiating ? (this._queuedNegotiation = !0, this._debug("already negotiating, queueing")) : (this._debug("requesting negotiation from initiator"), this.emit("signal", {
                        type: "renegotiate",
                        renegotiate: !0
                    })), this._isNegotiating = !0
                }
            }
            destroy(e) {
                this._destroy(e, () => {})
            }
            _destroy(e, t) {
                this.destroyed || this.destroying || (this.destroying = !0, this._debug("destroying (error: %s)", e && (e.message || e)), a(() => {
                    if (this.destroyed = !0, this.destroying = !1, this._debug("destroy (error: %s)", e && (e.message || e)), this.readable = this.writable = !1, this._readableState.ended || this.push(null), this._writableState.finished || this.end(), this._connected = !1, this._pcReady = !1, this._channelReady = !1, this._remoteTracks = null, this._remoteStreams = null, this._senderMap = null, clearInterval(this._closingInterval), this._closingInterval = null, clearInterval(this._interval), this._interval = null, this._chunk = null, this._cb = null, this._onFinishBound && this.removeListener("finish", this._onFinishBound), this._onFinishBound = null, this._channel) {
                        try {
                            this._channel.close()
                        } catch (e) {}
                        this._channel.onmessage = null, this._channel.onopen = null, this._channel.onclose = null, this._channel.onerror = null
                    }
                    if (this._pc) {
                        try {
                            this._pc.close()
                        } catch (e) {}
                        this._pc.oniceconnectionstatechange = null, this._pc.onicegatheringstatechange = null, this._pc.onsignalingstatechange = null, this._pc.onicecandidate = null, this._pc.ontrack = null, this._pc.ondatachannel = null
                    }
                    this._pc = null, this._channel = null, e && this.emit("error", e), this.emit("close"), t()
                }))
            }
            _setupData(e) {
                if (!e.channel) return this.destroy(c(new Error("Data channel event is missing `channel` property"), "ERR_DATA_CHANNEL"));
                this._channel = e.channel, this._channel.binaryType = "arraybuffer", "number" === typeof this._channel.bufferedAmountLowThreshold && (this._channel.bufferedAmountLowThreshold = u), this.channelName = this._channel.label, this._channel.onmessage = e => {
                    this._onChannelMessage(e)
                }, this._channel.onbufferedamountlow = () => {
                    this._onChannelBufferedAmountLow()
                }, this._channel.onopen = () => {
                    this._onChannelOpen()
                }, this._channel.onclose = () => {
                    this._onChannelClose()
                }, this._channel.onerror = e => {
                    const t = e.error instanceof Error ? e.error : new Error(`Datachannel error: ${e.message} ${e.filename}:${e.lineno}:${e.colno}`);
                    this.destroy(c(t, "ERR_DATA_CHANNEL"))
                };
                let t = !1;
                this._closingInterval = setInterval(() => {
                    this._channel && "closing" === this._channel.readyState ? (t && this._onChannelClose(), t = !0) : t = !1
                }, d)
            }
            _read() {}
            _write(e, t, n) {
                if (this.destroyed) return n(c(new Error("cannot write after peer is destroyed"), "ERR_DATA_CHANNEL"));
                if (this._connected) {
                    try {
                        this.send(e)
                    } catch (r) {
                        return this.destroy(c(r, "ERR_DATA_CHANNEL"))
                    }
                    this._channel.bufferedAmount > u ? (this._debug("start backpressure: bufferedAmount %d", this._channel.bufferedAmount), this._cb = n) : n(null)
                } else this._debug("write before connect"), this._chunk = e, this._cb = n
            }
            _onFinish() {
                if (this.destroyed) return;
                const e = () => {
                    setTimeout(() => this.destroy(), 1e3)
                };
                this._connected ? e() : this.once("connect", e)
            }
            _startIceCompleteTimeout() {
                this.destroyed || this._iceCompleteTimer || (this._debug("started iceComplete timeout"), this._iceCompleteTimer = setTimeout(() => {
                    this._iceComplete || (this._iceComplete = !0, this._debug("iceComplete timeout completed"), this.emit("iceTimeout"), this.emit("_iceComplete"))
                }, this.iceCompleteTimeout))
            }
            _createOffer() {
                this.destroyed || this._pc.createOffer(this.offerOptions).then(e => {
                    if (this.destroyed) return;
                    this.trickle || this.allowHalfTrickle || (e.sdp = l(e.sdp)), e.sdp = this.sdpTransform(e.sdp);
                    const t = () => {
                            if (this.destroyed) return;
                            const t = this._pc.localDescription || e;
                            this._debug("signal"), this.emit("signal", {
                                type: t.type,
                                sdp: t.sdp
                            })
                        },
                        n = () => {
                            this._debug("createOffer success"), this.destroyed || (this.trickle || this._iceComplete ? t() : this.once("_iceComplete", t))
                        },
                        r = e => {
                            this.destroy(c(e, "ERR_SET_LOCAL_DESCRIPTION"))
                        };
                    this._pc.setLocalDescription(e).then(n).catch(r)
                }).catch(e => {
                    this.destroy(c(e, "ERR_CREATE_OFFER"))
                })
            }
            _requestMissingTransceivers() {
                this._pc.getTransceivers && this._pc.getTransceivers().forEach(e => {
                    e.mid || !e.sender.track || e.requested || (e.requested = !0, this.addTransceiver(e.sender.track.kind))
                })
            }
            _createAnswer() {
                this.destroyed || this._pc.createAnswer(this.answerOptions).then(e => {
                    if (this.destroyed) return;
                    this.trickle || this.allowHalfTrickle || (e.sdp = l(e.sdp)), e.sdp = this.sdpTransform(e.sdp);
                    const t = () => {
                            if (this.destroyed) return;
                            const t = this._pc.localDescription || e;
                            this._debug("signal"), this.emit("signal", {
                                type: t.type,
                                sdp: t.sdp
                            }), this.initiator || this._requestMissingTransceivers()
                        },
                        n = () => {
                            this.destroyed || (this.trickle || this._iceComplete ? t() : this.once("_iceComplete", t))
                        },
                        r = e => {
                            this.destroy(c(e, "ERR_SET_LOCAL_DESCRIPTION"))
                        };
                    this._pc.setLocalDescription(e).then(n).catch(r)
                }).catch(e => {
                    this.destroy(c(e, "ERR_CREATE_ANSWER"))
                })
            }
            _onConnectionStateChange() {
                this.destroyed || "failed" === this._pc.connectionState && this.destroy(c(new Error("Connection failed."), "ERR_CONNECTION_FAILURE"))
            }
            _onIceStateChange() {
                if (this.destroyed) return;
                const e = this._pc.iceConnectionState,
                    t = this._pc.iceGatheringState;
                this._debug("iceStateChange (connection: %s) (gathering: %s)", e, t), this.emit("iceStateChange", e, t), "connected" !== e && "completed" !== e || (this._pcReady = !0, this._maybeReady()), "failed" === e && this.destroy(c(new Error("Ice connection failed."), "ERR_ICE_CONNECTION_FAILURE")), "closed" === e && this.destroy(c(new Error("Ice connection closed."), "ERR_ICE_CONNECTION_CLOSED"))
            }
            getStats(e) {
                const t = e => ("[object Array]" === Object.prototype.toString.call(e.values) && e.values.forEach(t => {
                    Object.assign(e, t)
                }), e);
                0 === this._pc.getStats.length || this._isReactNativeWebrtc ? this._pc.getStats().then(n => {
                    const r = [];
                    n.forEach(e => {
                        r.push(t(e))
                    }), e(null, r)
                }, t => e(t)) : this._pc.getStats.length > 0 ? this._pc.getStats(n => {
                    if (this.destroyed) return;
                    const r = [];
                    n.result().forEach(e => {
                        const n = {};
                        e.names().forEach(t => {
                            n[t] = e.stat(t)
                        }), n.id = e.id, n.type = e.type, n.timestamp = e.timestamp, r.push(t(n))
                    }), e(null, r)
                }, t => e(t)) : e(null, [])
            }
            _maybeReady() {
                if (this._debug("maybeReady pc %s channel %s", this._pcReady, this._channelReady), this._connected || this._connecting || !this._pcReady || !this._channelReady) return;
                this._connecting = !0;
                const e = () => {
                    this.destroyed || this.getStats((t, n) => {
                        if (this.destroyed) return;
                        t && (n = []);
                        const r = {},
                            i = {},
                            o = {};
                        let s = !1;
                        n.forEach(e => {
                            "remotecandidate" !== e.type && "remote-candidate" !== e.type || (r[e.id] = e), "localcandidate" !== e.type && "local-candidate" !== e.type || (i[e.id] = e), "candidatepair" !== e.type && "candidate-pair" !== e.type || (o[e.id] = e)
                        });
                        const a = e => {
                            s = !0;
                            let t = i[e.localCandidateId];
                            t && (t.ip || t.address) ? (this.localAddress = t.ip || t.address, this.localPort = Number(t.port)) : t && t.ipAddress ? (this.localAddress = t.ipAddress, this.localPort = Number(t.portNumber)) : "string" === typeof e.googLocalAddress && (t = e.googLocalAddress.split(":"), this.localAddress = t[0], this.localPort = Number(t[1])), this.localAddress && (this.localFamily = this.localAddress.includes(":") ? "IPv6" : "IPv4");
                            let n = r[e.remoteCandidateId];
                            n && (n.ip || n.address) ? (this.remoteAddress = n.ip || n.address, this.remotePort = Number(n.port)) : n && n.ipAddress ? (this.remoteAddress = n.ipAddress, this.remotePort = Number(n.portNumber)) : "string" === typeof e.googRemoteAddress && (n = e.googRemoteAddress.split(":"), this.remoteAddress = n[0], this.remotePort = Number(n[1])), this.remoteAddress && (this.remoteFamily = this.remoteAddress.includes(":") ? "IPv6" : "IPv4"), this._debug("connect local: %s:%s remote: %s:%s", this.localAddress, this.localPort, this.remoteAddress, this.remotePort)
                        };
                        if (n.forEach(e => {
                                "transport" === e.type && e.selectedCandidatePairId && a(o[e.selectedCandidatePairId]), ("googCandidatePair" === e.type && "true" === e.googActiveConnection || ("candidatepair" === e.type || "candidate-pair" === e.type) && e.selected) && a(e)
                            }), s || Object.keys(o).length && !Object.keys(i).length) {
                            if (this._connecting = !1, this._connected = !0, this._chunk) {
                                try {
                                    this.send(this._chunk)
                                } catch (t) {
                                    return this.destroy(c(t, "ERR_DATA_CHANNEL"))
                                }
                                this._chunk = null, this._debug('sent chunk from "write before connect"');
                                const e = this._cb;
                                this._cb = null, e(null)
                            }
                            "number" !== typeof this._channel.bufferedAmountLowThreshold && (this._interval = setInterval(() => this._onInterval(), 150), this._interval.unref && this._interval.unref()), this._debug("connect"), this.emit("connect")
                        } else setTimeout(e, 100)
                    })
                };
                e()
            }
            _onInterval() {
                !this._cb || !this._channel || this._channel.bufferedAmount > u || this._onChannelBufferedAmountLow()
            }
            _onSignalingStateChange() {
                this.destroyed || ("stable" === this._pc.signalingState && (this._isNegotiating = !1, this._debug("flushing sender queue", this._sendersAwaitingStable), this._sendersAwaitingStable.forEach(e => {
                    this._pc.removeTrack(e), this._queuedNegotiation = !0
                }), this._sendersAwaitingStable = [], this._queuedNegotiation ? (this._debug("flushing negotiation queue"), this._queuedNegotiation = !1, this._needsNegotiation()) : (this._debug("negotiated"), this.emit("negotiated"))), this._debug("signalingStateChange %s", this._pc.signalingState), this.emit("signalingStateChange", this._pc.signalingState))
            }
            _onIceCandidate(e) {
                this.destroyed || (e.candidate && this.trickle ? this.emit("signal", {
                    type: "candidate",
                    candidate: {
                        candidate: e.candidate.candidate,
                        sdpMLineIndex: e.candidate.sdpMLineIndex,
                        sdpMid: e.candidate.sdpMid
                    }
                }) : e.candidate || this._iceComplete || (this._iceComplete = !0, this.emit("_iceComplete")), e.candidate && this._startIceCompleteTimeout())
            }
            _onChannelMessage(e) {
                if (this.destroyed) return;
                let t = e.data;
                t instanceof ArrayBuffer && (t = h.from(t)), this.push(t)
            }
            _onChannelBufferedAmountLow() {
                if (this.destroyed || !this._cb) return;
                this._debug("ending backpressure: bufferedAmount %d", this._channel.bufferedAmount);
                const e = this._cb;
                this._cb = null, e(null)
            }
            _onChannelOpen() {
                this._connected || this.destroyed || (this._debug("on channel open"), this._channelReady = !0, this._maybeReady())
            }
            _onChannelClose() {
                this.destroyed || (this._debug("on channel close"), this.destroy())
            }
            _onTrack(e) {
                this.destroyed || e.streams.forEach(t => {
                    this._debug("on track"), this.emit("track", e.track, t), this._remoteTracks.push({
                        track: e.track,
                        stream: t
                    }), this._remoteStreams.some(e => e.id === t.id) || (this._remoteStreams.push(t), a(() => {
                        this._debug("on stream"), this.emit("stream", t)
                    }))
                })
            }
            _debug() {
                const e = [].slice.call(arguments);
                e[0] = "[" + this._id + "] " + e[0], r.apply(null, e)
            }
        }
        g.WEBRTC_SUPPORT = !!i(), g.config = {
            iceServers: [{
                urls: ["stun:stun.l.google.com:19302", "stun:global.stun.twilio.com:3478"]
            }],
            sdpSemantics: "unified-plan"
        }, g.channelConfig = {}, e.exports = g
    },
    "06cf": function(e, t, n) {
        var r = n("83ab"),
            i = n("d1e7"),
            o = n("5c6c"),
            s = n("fc6a"),
            a = n("a04b"),
            c = n("5135"),
            h = n("0cfb"),
            u = Object.getOwnPropertyDescriptor;
        t.f = r ? u : function(e, t) {
            if (e = s(e), t = a(t), h) try {
                return u(e, t)
            } catch (n) {}
            if (c(e, t)) return o(!i.f.call(e, t), e[t])
        }
    },
    "0774": function(e, t, n) {
        var r = n("42a7"),
            i = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
        e.exports = r(i)
    },
    "07c6": function(e, t) {
        e.exports = function() {
            throw new Error("Readable.from is not available in the browser")
        }
    },
    "0809": function(e, t, n) {
        (function(t) { /*! bittorrent-protocol. MIT License. WebTorrent LLC <https://webtorrent.io/opensource> */
            const r = n("d05a"),
                i = n("8fe2"),
                o = n("d329"),
                s = n("34eb")("bittorrent-protocol"),
                a = n("11dc"),
                c = n("7b03"),
                h = n("e372"),
                u = 4e5,
                f = 55e3,
                d = 2e4,
                l = 1e3,
                p = t.from("BitTorrent protocol"),
                g = t.from([0, 0, 0, 0]),
                _ = t.from([0, 0, 0, 1, 0]),
                y = t.from([0, 0, 0, 1, 1]),
                m = t.from([0, 0, 0, 1, 2]),
                b = t.from([0, 0, 0, 1, 3]),
                w = t.alloc(d, 255),
                v = [0, 0, 0, 0, 0, 0, 0, 0],
                E = [0, 0, 0, 3, 9, 0, 0];
            class T {
                constructor(e, t, n, r) {
                    this.piece = e, this.offset = t, this.length = n, this.callback = r
                }
            }
            class R extends h.Duplex {
                constructor() {
                    super(), this._debugId = a(4).toString("hex"), this._debug("new wire"), this.peerId = null, this.peerIdBuffer = null, this.type = null, this.amChoking = !0, this.amInterested = !1, this.peerChoking = !0, this.peerInterested = !1, this.peerPieces = new o(0, {
                        grow: u
                    }), this.peerExtensions = {}, this.requests = [], this.peerRequests = [], this.extendedMapping = {}, this.peerExtendedMapping = {}, this.extendedHandshake = {}, this.peerExtendedHandshake = {}, this._ext = {}, this._nextExt = 1, this.uploaded = 0, this.downloaded = 0, this.uploadSpeed = c(), this.downloadSpeed = c(), this._keepAliveInterval = null, this._timeout = null, this._timeoutMs = 0, this._timeoutExpiresAt = null, this.destroyed = !1, this._finished = !1, this._parserSize = 0, this._parser = null, this._buffer = [], this._bufferSize = 0, this._fakeDataInterval = null, this.once("finish", () => this._onFinish()), this._parseHandshake()
                }
                setKeepAlive(e) {
                    this._debug("setKeepAlive %s", e), clearInterval(this._keepAliveInterval), !1 !== e && (this._keepAliveInterval = setInterval(() => {
                        this.keepAlive()
                    }, f))
                }
                setFakeData(e) {
                    this._debug("setFakeData %s", e), clearInterval(this._fakeDataInterval), !1 !== e && (this._fakeDataInterval = setInterval(this.sendFakeData.bind(this), l))
                }
                setTimeout(e, t) {
                    this._debug("setTimeout ms=%d unref=%s", e, t), this._timeoutMs = e, this._timeoutUnref = !!t, this._resetTimeout(!0)
                }
                destroy() {
                    this.destroyed || (this.destroyed = !0, this._debug("destroy"), this.emit("close"), this.end())
                }
                end(...e) {
                    this._debug("end"), this._onUninterested(), this._onChoke(), super.end(...e)
                }
                use(e) {
                    const t = e.prototype.name;
                    if (!t) throw new Error('Extension class requires a "name" property on the prototype');
                    this._debug("use extension.name=%s", t);
                    const n = this._nextExt,
                        r = new e(this);

                    function i() {}
                    "function" !== typeof r.onHandshake && (r.onHandshake = i), "function" !== typeof r.onExtendedHandshake && (r.onExtendedHandshake = i), "function" !== typeof r.onMessage && (r.onMessage = i), this.extendedMapping[n] = t, this._ext[t] = r, this[t] = r, this._nextExt += 1
                }
                keepAlive() {
                    this._debug("keep-alive"), this._push(g)
                }
                sendFakeData() {
                    this._debug("fake-data"), this._message(13, [], w), this.uploaded += w.length, this.uploadSpeed(w.length), this.emit("upload", w.length)
                }
                handshake(e, n, r) {
                    let i, o;
                    if ("string" === typeof e ? (e = e.toLowerCase(), i = t.from(e, "hex")) : (i = e, e = i.toString("hex")), "string" === typeof n ? o = t.from(n, "hex") : (o = n, n = o.toString("hex")), 20 !== i.length || 20 !== o.length) throw new Error("infoHash and peerId MUST have length 20");
                    this._debug("handshake i=%s p=%s exts=%o", e, n, r);
                    const s = t.from(v);
                    s[5] |= 16, r && r.dht && (s[7] |= 1), this._push(t.concat([p, s, i, o])), this._handshakeSent = !0, this.peerExtensions.extended && !this._extendedHandshakeSent && this._sendExtendedHandshake()
                }
                _sendExtendedHandshake() {
                    const e = Object.assign({}, this.extendedHandshake);
                    e.m = {};
                    for (const t in this.extendedMapping) {
                        const n = this.extendedMapping[t];
                        e.m[n] = Number(t)
                    }
                    this.extended(0, i.encode(e)), this._extendedHandshakeSent = !0
                }
                choke() {
                    if (!this.amChoking) {
                        this.amChoking = !0, this._debug("choke");
                        while (this.peerRequests.length) this.peerRequests.pop();
                        this._push(_)
                    }
                }
                unchoke() {
                    this.amChoking && (this.amChoking = !1, this._debug("unchoke"), this._push(y))
                }
                interested() {
                    this.amInterested || (this.amInterested = !0, this._debug("interested"), this._push(m))
                }
                uninterested() {
                    this.amInterested && (this.amInterested = !1, this._debug("uninterested"), this._push(b))
                }
                have(e) {
                    this._debug("have %d", e), this._message(4, [e], null)
                }
                bitfield(e) {
                    this._debug("bitfield"), t.isBuffer(e) || (e = e.buffer), this._message(5, [], e)
                }
                request(e, t, n, r) {
                    return r || (r = () => {}), this._finished ? r(new Error("wire is closed")) : this.peerChoking ? r(new Error("peer is choking")) : (this._debug("request index=%d offset=%d length=%d", e, t, n), this.requests.push(new T(e, t, n, r)), this._timeout || this._resetTimeout(!0), void this._message(6, [e, t, n], null))
                }
                piece(e, t, n) {
                    this._debug("piece index=%d offset=%d", e, t), this._message(7, [e, t], n), this.uploaded += n.length, this.uploadSpeed(n.length), this.emit("upload", n.length)
                }
                cancel(e, t, n) {
                    this._debug("cancel index=%d offset=%d length=%d", e, t, n), this._callback(this._pull(this.requests, e, t, n), new Error("request was cancelled"), null), this._message(8, [e, t, n], null)
                }
                port(e) {
                    this._debug("port %d", e);
                    const n = t.from(E);
                    n.writeUInt16BE(e, 5), this._push(n)
                }
                extended(e, n) {
                    if (this._debug("extended ext=%s", e), "string" === typeof e && this.peerExtendedMapping[e] && (e = this.peerExtendedMapping[e]), "number" !== typeof e) throw new Error("Unrecognized extension: " + e); {
                        const r = t.from([e]),
                            o = t.isBuffer(n) ? n : i.encode(n);
                        this._message(20, [], t.concat([r, o]))
                    }
                }
                _read() {}
                _message(e, n, r) {
                    const i = r ? r.length : 0,
                        o = t.allocUnsafe(5 + 4 * n.length);
                    o.writeUInt32BE(o.length + i - 4, 0), o[4] = e;
                    for (let t = 0; t < n.length; t++) o.writeUInt32BE(n[t], 5 + 4 * t);
                    this._push(o), r && this._push(r)
                }
                _push(e) {
                    if (!this._finished) return this.push(e)
                }
                _onKeepAlive() {
                    this._debug("got keep-alive"), this.emit("keep-alive")
                }
                _onFakeData(e) {
                    this._debug("got fake-data"), this.downloaded += e.length, this.downloadSpeed(e.length), this.emit("download", e.length)
                }
                _onHandshake(e, t, n) {
                    const r = e.toString("hex"),
                        i = t.toString("hex");
                    let o;
                    for (o in this._debug("got handshake i=%s p=%s exts=%o", r, i, n), this.peerId = i, this.peerIdBuffer = t, this.peerExtensions = n, this.emit("handshake", r, i, n), this._ext) this._ext[o].onHandshake(r, i, n);
                    n.extended && this._handshakeSent && !this._extendedHandshakeSent && this._sendExtendedHandshake()
                }
                _onChoke() {
                    this.peerChoking = !0, this._debug("got choke"), this.emit("choke");
                    while (this.requests.length) this._callback(this.requests.pop(), new Error("peer is choking"), null)
                }
                _onUnchoke() {
                    this.peerChoking = !1, this._debug("got unchoke"), this.emit("unchoke")
                }
                _onInterested() {
                    this.peerInterested = !0, this._debug("got interested"), this.emit("interested")
                }
                _onUninterested() {
                    this.peerInterested = !1, this._debug("got uninterested"), this.emit("uninterested")
                }
                _onHave(e) {
                    this.peerPieces.get(e) || (this._debug("got have %d", e), this.peerPieces.set(e, !0), this.emit("have", e))
                }
                _onBitField(e) {
                    this.peerPieces = new o(e), this._debug("got bitfield"), this.emit("bitfield", this.peerPieces)
                }
                _onRequest(e, t, n) {
                    if (this.amChoking) return;
                    this._debug("got request index=%d offset=%d length=%d", e, t, n);
                    const r = (r, o) => {
                            if (i === this._pull(this.peerRequests, e, t, n)) return r ? this._debug("error satisfying request index=%d offset=%d length=%d (%s)", e, t, n, r.message) : void this.piece(e, t, o)
                        },
                        i = new T(e, t, n, r);
                    this.peerRequests.push(i), this.emit("request", e, t, n, r)
                }
                _onPiece(e, t, n) {
                    this._debug("got piece index=%d offset=%d", e, t), this._callback(this._pull(this.requests, e, t, n.length), null, n), this.downloaded += n.length, this.downloadSpeed(n.length), this.emit("download", n.length), this.emit("piece", e, t, n)
                }
                _onCancel(e, t, n) {
                    this._debug("got cancel index=%d offset=%d length=%d", e, t, n), this._pull(this.peerRequests, e, t, n), this.emit("cancel", e, t, n)
                }
                _onPort(e) {
                    this._debug("got port %d", e), this.emit("port", e)
                }
                _onExtended(e, t) {
                    if (0 === e) {
                        let e, r;
                        try {
                            e = i.decode(t)
                        } catch (n) {
                            this._debug("ignoring invalid extended handshake: %s", n.message || n)
                        }
                        if (!e) return;
                        if (this.peerExtendedHandshake = e, "object" === typeof e.m)
                            for (r in e.m) this.peerExtendedMapping[r] = Number(e.m[r].toString());
                        for (r in this._ext) this.peerExtendedMapping[r] && this._ext[r].onExtendedHandshake(this.peerExtendedHandshake);
                        this._debug("got extended handshake"), this.emit("extended", "handshake", this.peerExtendedHandshake)
                    } else this.extendedMapping[e] && (e = this.extendedMapping[e], this._ext[e] && this._ext[e].onMessage(t)), this._debug("got extended message ext=%s", e), this.emit("extended", e, t)
                }
                _onTimeout() {
                    this._debug("request timed out"), this._callback(this.requests.shift(), new Error("request has timed out"), null), this.emit("timeout")
                }
                _write(e, n, r) {
                    this._bufferSize += e.length, this._buffer.push(e);
                    while (this._bufferSize >= this._parserSize) {
                        const e = 1 === this._buffer.length ? this._buffer[0] : t.concat(this._buffer, this._bufferSize);
                        this._bufferSize -= this._parserSize, this._buffer = this._bufferSize ? [e.slice(this._parserSize)] : [], this._parser(e.slice(0, this._parserSize))
                    }
                    r(null)
                }
                _callback(e, t, n) {
                    e && (this._resetTimeout(!this.peerChoking && !this._finished), e.callback(t, n))
                }
                _resetTimeout(e) {
                    if (!e || !this._timeoutMs || !this.requests.length) return clearTimeout(this._timeout), this._timeout = null, void(this._timeoutExpiresAt = null);
                    const t = Date.now() + this._timeoutMs;
                    if (this._timeout) {
                        if (t - this._timeoutExpiresAt < .05 * this._timeoutMs) return;
                        clearTimeout(this._timeout)
                    }
                    this._timeoutExpiresAt = t, this._timeout = setTimeout(() => this._onTimeout(), this._timeoutMs), this._timeoutUnref && this._timeout.unref && this._timeout.unref()
                }
                _parse(e, t) {
                    this._parserSize = e, this._parser = t
                }
                _onMessageLength(e) {
                    const t = e.readUInt32BE(0);
                    t > 0 ? this._parse(t, this._onMessage) : (this._onKeepAlive(), this._parse(4, this._onMessageLength))
                }
                _onMessage(e) {
                    switch (this._parse(4, this._onMessageLength), e[0]) {
                        case 0:
                            return this._onChoke();
                        case 1:
                            return this._onUnchoke();
                        case 2:
                            return this._onInterested();
                        case 3:
                            return this._onUninterested();
                        case 4:
                            return this._onHave(e.readUInt32BE(1));
                        case 5:
                            return this._onBitField(e.slice(1));
                        case 6:
                            return this._onRequest(e.readUInt32BE(1), e.readUInt32BE(5), e.readUInt32BE(9));
                        case 7:
                            return this._onPiece(e.readUInt32BE(1), e.readUInt32BE(5), e.slice(9));
                        case 8:
                            return this._onCancel(e.readUInt32BE(1), e.readUInt32BE(5), e.readUInt32BE(9));
                        case 9:
                            return this._onPort(e.readUInt16BE(1));
                        case 13:
                            return this._onFakeData(e);
                        case 20:
                            return this._onExtended(e.readUInt8(1), e.slice(2));
                        default:
                            return this._debug("got unknown message"), this.emit("unknownmessage", e)
                    }
                }
                _parseHandshake() {
                    this._parse(1, e => {
                        const t = e.readUInt8(0);
                        this._parse(t + 48, e => {
                            const n = e.slice(0, t);
                            if ("BitTorrent protocol" !== n.toString()) return this._debug("Error: wire not speaking BitTorrent protocol (%s)", n.toString()), void this.end();
                            e = e.slice(t), this._onHandshake(e.slice(8, 28), e.slice(28, 48), {
                                dht: !!(1 & e[7]),
                                extended: !!(16 & e[5])
                            }), this._parse(4, this._onMessageLength)
                        })
                    })
                }
                _onFinish() {
                    this._finished = !0, this.push(null);
                    while (this.read());
                    clearInterval(this._keepAliveInterval), clearInterval(this._fakeDataInterval), this._parse(Number.MAX_VALUE, () => {});
                    while (this.peerRequests.length) this.peerRequests.pop();
                    while (this.requests.length) this._callback(this.requests.pop(), new Error("wire was closed"), null)
                }
                _debug(...e) {
                    e[0] = `[${this._debugId}] ${e[0]}`, s(...e)
                }
                _pull(e, t, n, i) {
                    for (let o = 0; o < e.length; o++) {
                        const s = e[o];
                        if (s.piece === t && s.offset === n && s.length === i) return r(e, o), s
                    }
                    return null
                }
            }
            e.exports = R
        }).call(this, n("b639").Buffer)
    },
    "0b25": function(e, t, n) {
        var r = n("a691"),
            i = n("50c4");
        e.exports = function(e) {
            if (void 0 === e) return 0;
            var t = r(e),
                n = i(t);
            if (t !== n) throw RangeError("Wrong length or index");
            return n
        }
    },
    "0b42": function(e, t, n) {
        var r = n("861d"),
            i = n("e8b5"),
            o = n("b622"),
            s = o("species");
        e.exports = function(e) {
            var t;
            return i(e) && (t = e.constructor, "function" != typeof t || t !== Array && !i(t.prototype) ? r(t) && (t = t[s], null === t && (t = void 0)) : t = void 0), void 0 === t ? Array : t
        }
    },
    "0cfb": function(e, t, n) {
        var r = n("83ab"),
            i = n("d039"),
            o = n("cc12");
        e.exports = !r && !i((function() {
            return 7 != Object.defineProperty(o("div"), "a", {
                get: function() {
                    return 7
                }
            }).a
        }))
    },
    "0d31": function(e, t, n) {
        "use strict";
        var r = n("ade3"),
            i = n("3d15"),
            o = n("faa1"),
            s = n.n(o),
            a = n("517b"),
            c = n("ad2b"),
            h = n.n(c),
            u = n("8c32"),
            f = n("a5a5"),
            d = n("81e8"),
            l = n("c4d1");
        n("5cc6"), n("219c");
        const p = 16,
            g = "AES-CTR";
        async function _(e) {
            return crypto.subtle.importKey("raw", e, g, !1, ["decrypt"])
        }
        async function y(e, t, n) {
            const r = Math.floor(n / p),
                i = n % p,
                o = b(r),
                s = {
                    name: g,
                    counter: o,
                    length: 128
                };
            if (i > 0) {
                const e = new ArrayBuffer(i);
                t = m(e, t)
            }
            let a = await crypto.subtle.decrypt(s, e, t);
            return i > 0 && (a = a.slice(i)), new Uint8Array(a)
        }

        function m(e, t) {
            const n = new Uint8Array(e.byteLength + t.byteLength);
            return n.set(new Uint8Array(e), 0), n.set(new Uint8Array(t), e.byteLength), n.buffer
        }

        function b(e) {
            const t = new DataView(new ArrayBuffer(16));
            for (let n = 15; n >= 0; --n) t.setUint8(n, e % 256), e >>= 8;
            return t.buffer
        }
        var w = {
                importSubtleKey: _,
                decrypt: y
            },
            v = n("d1a0"),
            E = n("5de4"),
            T = n("b944"),
            R = n.n(T),
            S = n("8707");

        function I(e) {
            const t = S["Buffer"].from(e, "base64"),
                n = R()(t);
            return n
        }

        function O(e, t, n) {
            const r = 1,
                i = E["i"].asNumber("webseed", r),
                o = {
                    _arc_client: t,
                    propertyId: n
                };
            e.urlList = e.urlList.slice(0, i).map(e => k(e, o)), e.announce = e.announce.map(() => "wss://tkr.arc.io/announce")
        }

        function k(e, t = {}) {
            const n = new URL(e);
            for (const [r, i] of Object.entries(t)) n.searchParams.set(r, i);
            if ("https://webseed.arc.io" !== n.origin) {
                const {
                    hostname: e,
                    port: t
                } = new URL("https://webseed.arc.io");
                n.hostname = e, n.port = t
            }
            return n.href
        }
        var A = n("0ecd");
        class C {
            constructor(e) {
                this.storeAsync = e, this.mem = []
            }
            async get(e, t, n) {
                if ("function" === typeof t) return this.get(e, null, t);
                const r = (null === t || void 0 === t ? void 0 : t.offset) || 0,
                    i = (null === t || void 0 === t ? void 0 : t.length) && r + t.length,
                    o = this.mem[e];
                if (o) return n(null, t ? o.slice(r, i) : o);
                (await this.storeAsync).get(e, t, n)
            }
            async put(e, t, n) {
                this.mem[e] = t, (await this.storeAsync).put(e, t, t => {
                    this.mem[e] = null, n && n(t)
                })
            }
            async remove(e, t) {
                (await this.storeAsync).remove(e, t)
            }
            async close(e) {
                (await this.storeAsync).close(e)
            }
            async destroy(e) {
                (await this.storeAsync).destroy(e)
            }
        }
        var x = C;
        const N = n("34eb")("arc:p2p-client"),
            P = (console.log, 64);
        s.a.defaultMaxListeners = 1 / 0;
        class L {
            constructor() {
                Object(r["a"])(this, "nodeId", null), Object(r["a"])(this, "propertyId", null), Object(r["a"])(this, "broker", null), Object(r["a"])(this, "reporter", null), Object(r["a"])(this, "overmindClient", null), Object(r["a"])(this, "_statusReportCount", 0), Object(r["a"])(this, "_createdAt", new Date), Object(r["a"])(this, "isViableSeeder", null), Object(r["a"])(this, "isDestroyed", !1), Object(r["a"])(this, "cleanupFns", []), Object(d["a"])(), this._createTorrentClient()
            }
            _createTorrentClient() {
                if (!h.a.WEBRTC_SUPPORT) throw new Error("No WebRTC support.");
                this.torrentClient = new h.a({
                    dht: !1,
                    tracker: {
                        trickle: E["i"].isTruthy("trickle", !0),
                        rtcConfig: {
                            iceCandidatePoolSize: 3
                        },
                        getAnnounceOpts() {
                            return {
                                numwant: E["i"].asNumber("numwant", 10)
                            }
                        }
                    },
                    webSeeds: !0,
                    maxConns: P
                }).on("error", e => {
                    N("Error", e), l["a"].captureException(e)
                })
            }
            setNodeId(e) {
                this.nodeId = e
            }
            setPropertyId(e) {
                this.propertyId = e
            }
            setBroker(e) {
                this.broker = e, this.setBrokerPromise(Promise.resolve(e))
            }
            setBrokerPromise(e) {
                this.brokerPromise = e
            }
            setReporter(e) {
                this.reporter = e
            }
            setOvermindClient(e) {
                this.overmindClient = e
            }
            async startTorrentingFile(e, t, n = {}) {
                const {
                    fid: r,
                    torrentFileObj: i,
                    cipherKey: o = null
                } = e;
                let s;
                if (n.skipWaitingForBroker) {
                    const t = this.brokerPromise.then(t => t.createStore(e));
                    s = new x(t)
                } else {
                    const t = await this.brokerPromise;
                    s = await t.createStore(e)
                }
                n = {
                    maxWebConns: 6,
                    store: function() {
                        return s
                    },
                    ...n
                }, O(i, t, this.propertyId);
                let a = this.torrentClient.get(i);
                if (null !== a) {
                    if (a._arc_isLocked) return a;
                    await this.stopTorrentingFile(a)
                }
                if (a = await this._addTorrent(r, t, i, n), this.reporter && this._addDataTransferReportHooks(r, a, t), o) {
                    const e = await w.importSubtleKey(o);
                    a._arc_decrypt = (t, n) => {
                        const r = n * a.pieceLength;
                        return w.decrypt(e, t, r)
                    }
                }
                return a
            }
            _addTorrent(e, t, n, r) {
                const i = this.torrentClient.add(n, r);
                i.on("upload", Object(a["a"])(() => {
                    const {
                        uploaded: t,
                        uploadSpeed: n
                    } = i;
                    N(`fid ${e} uploaded ${t} @ ${n/1e3} kBps`)
                }, 500)).on("download", Object(a["a"])(() => {
                    const {
                        downloaded: t,
                        downloadSpeed: n
                    } = i;
                    N(`fid ${e} downloaded ${t} @ ${n/1e3} kBps`)
                }, 500)).on("wire", (e, t) => {
                    e.once("download", () => {
                        const t = "webSeed" === e.type ? "http" : "p2p";
                        o.markOnce(t + "_1st_byte")
                    })
                }).on("peer", e => {}).on("invalidPeer", e => {}).on("noPeers", e => {
                    o.markOnce("no_peers")
                }).on("error", t => {
                    N(`fid ${e} torrent error`, t), l["a"].captureException(t)
                }).on("warning", t => {
                    N(`fid ${e} torrent warning: ${t}`), /Cannot create so many PeerConnections/.test(t) || /failed verification/.test(t)
                }), i._arc_fid = e, i._arc_client = t, i._arc_isLocked = t !== f["p"];
                const o = new v["b"]({
                    id: "torrent_" + e,
                    enabled: t !== f["p"]
                });
                return o.mark("add"), N("Torrent", e, i, r), new Promise(e => {
                    i.once("ready", () => e(i))
                })
            }
            _addDataTransferReportHooks(e, t, n) {
                const {
                    reporter: r
                } = this;
                t.on("wire", i => {
                    if ("webSeed" === i.type) return;
                    t._rechoke();
                    const o = t.client.peerId,
                        s = t._peers[i.peerId].conn.channelName;

                    function a() {
                        r.reportDataTransfer(s, i.type, e, o, i.peerId, i.uploaded, i.downloaded, n)
                    }
                    i.on("upload", a), i.on("download", a), i.once("close", () => r.closeDataTransfer(s))
                })
            }
            async stopTorrentingFile(e) {
                return new Promise(t => {
                    this.torrentClient.remove(e, t)
                })
            }
            async getProxiedFile(e, t, n) {
                const r = await this.startTorrentingFile(e, t, n),
                    o = Object.values(r._peers).find(e => "webSeed" === e.type);
                if (o && o.conn && !o.conn._isMonkeyPatched) {
                    const {
                        conn: e
                    } = o;
                    e._isMonkeyPatched = !0, e.httpRequest = (() => {
                        const t = e.httpRequest.bind(e);
                        return (...e) => {
                            const n = e.pop(),
                                r = (e, t) => {
                                    e && s.emit("webseedErr", e), n(e, t)
                                };
                            t(...e, r)
                        }
                    })()
                }
                const s = r.files[0];
                return s._isMonkeyPatched || (s._isMonkeyPatched = !0, s.createReadStream = (() => {
                    const e = s.createReadStream.bind(s);
                    return (...t) => i["b"](e(...t))
                })()), i["b"](s)
            }
            async getStatusReport() {
                let e = [];
                try {
                    e = await Promise.all([this.broker.generateStorageReport(), this.broker.getCustomStorageEstimate(), this.broker.getBrokerIds(), this.broker.listPropertySessions()])
                } catch (a) {
                    N(a)
                }
                const [t = {}, n = {}, r = [], i = []] = e, o = {};
                for (const c of this.torrentClient.torrents) {
                    const e = [];
                    for (let t = 0, n = c.pieces.length; t < n; ++t) c.bitfield.get(t) && e.push(t);
                    o[c._arc_fid] = { ...t[c._arc_fid],
                        isSeeding: !0,
                        clientName: c._arc_client,
                        uploaded: c.uploaded,
                        downloaded: c.downloaded,
                        hasTorrentFile: !0,
                        chunkIndexes: e
                    }
                }
                const s = {
                    nodeId: this.nodeId,
                    isViableSeeder: this.isViableSeeder,
                    count: this._statusReportCount++,
                    pageLoadAt: this._createdAt,
                    files: Object(u["e"])(o),
                    storageEstimate: n,
                    widgetConfig: Object(A["d"])(),
                    numTabs: r.length,
                    propertySessions: i,
                    url: location.href,
                    userAgent: navigator.userAgent,
                    gitHash: "ce271de",
                    finaltask: !0
                };
                return s
            }
            async performTask(e) {
                const t = f["e"];
                switch (e.action) {
                    case t.STORE_FILE:
                    case t.STORE_CHUNKS:
                        return this._storeChunks(e);
                    case t.PURGE_FILE:
                        return this._purgeFile(e);
                    case t.PURGE_FILES:
                        return this._purgeFiles(e);
                    case t.PURGE_CHUNKS:
                        return this._purgeChunks(e);
                    case t.START_TORRENTING_FILE:
                        break;
                    case t.STOP_TORRENTING_FILE:
                        {
                            const {
                                fid: t
                            } = e.data,
                            {
                                torrents: n
                            } = this.torrentClient,
                            r = n.find(e => e._arc_fid === t);r && await this.stopTorrentingFile(r);
                            break
                        }
                    case t.VERIFY_FILE:
                        break;
                    case t.RUN_CODE:
                        return this._runCode(e);
                    default:
                        N("unknown task action!")
                }
            }
            async _storeChunks(e) {
                const {
                    fid: t,
                    b64TorrentFile: n,
                    chunkIndexes: r,
                    expiresAt: i
                } = e.data, o = I(n);
                O(o, f["p"], this.propertyId);
                const s = o.urlList.splice(0),
                    a = {
                        fid: t,
                        torrentFileObj: o,
                        expiresAt: i,
                        seedTaskDate: e.createdAt
                    },
                    c = {
                        getAnnounceOpts: () => ({
                            numwant: 5
                        })
                    },
                    h = await this.startTorrentingFile(a, f["p"], c);
                if (h.resume(), h.done) return;
                if (e.action === f["e"].STORE_CHUNKS) {
                    const e = 0;
                    h.deselect(0, h.pieces.length - 1, e);
                    const t = Object(E["b"])(r);
                    for (const n of t) {
                        const [e, t] = n;
                        h.select(e, t)
                    }
                }
                let d = !1;
                try {
                    await Object(u["h"])(new Promise(e => h.once("download", e)), 1e4), d = !0
                } catch (l) {}
                if (!d && s.length)
                    for (const u of s) h.addWebSeed(u);
                return new Promise((e, t) => {
                    h.once("done", e), h.once("error", t)
                })
            }
            async _purgeFiles(e) {
                const t = e.data.fids.map(e => ({
                    data: {
                        fid: e
                    }
                }));
                for (const n of t) await this._purgeFile(n)
            }
            async _purgeFile(e) {
                const {
                    fid: t
                } = e.data, n = await this.broker.getTorrentFileObject(t);
                if (!n) return void await this.broker.destroyFile(t);
                const r = this.torrentClient.get(n);
                null !== r && await this.stopTorrentingFile(n);
                const i = {
                        fid: t,
                        torrentFileObj: n
                    },
                    o = await this.broker.createStore(i);
                return new Promise((e, n) => {
                    o.destroy(r => {
                        if (r) return n(r);
                        N("Destroyed torrent for fid: " + t), e()
                    })
                })
            }
            async _purgeChunks(e) {
                const {
                    fid: t,
                    b64TorrentFile: n,
                    chunkIndexes: r
                } = e.data, i = I(n), o = this.torrentClient.get(i);
                null !== o && await this.stopTorrentingFile(i);
                const s = {
                        fid: t,
                        torrentFileObj: i
                    },
                    a = await this.broker.createStore(s),
                    c = r.map(e => new Promise(t => a.remove(e, t)));
                await Promise.all(c), N("Purged chunks from file " + t, r), await this.seedFile(s)
            }
            async _runCode(e) {
                const {
                    code: t
                } = e.data, n = `return async function (p2pClient) { ${t} }`, r = new Function("p2pClient", n)(), i = await r(this);
                return i
            }
            async updateSeederStatus(e) {
                if (this.isViableSeeder !== e) {
                    if (this.isViableSeeder = e, e) {
                        let {
                            maxFilesSeeding: e
                        } = this.overmindClient.config;
                        await this._seedFiles(e), await this._addFakeTorrent(), await this._resumeSeedingFiles()
                    } else await this._pauseSeedingFiles();
                    await this.overmindClient.sendStatusReport()
                }
            }
            async _pauseSeedingFiles() {
                const {
                    torrents: e
                } = this.torrentClient, t = e.filter(e => !e._arc_isLocked && !e.paused);
                for (const n of t) n.pause()
            }
            async _resumeSeedingFiles() {
                const {
                    torrents: e
                } = this.torrentClient, t = e.filter(e => !e._arc_isLocked && e.paused);
                for (const n of t) n.resume()
            }
            async _seedFiles(e = 5) {
                const {
                    torrents: t
                } = this.torrentClient, n = t.length, r = Math.max(e - n, 0);
                if (N(`Seeding ${n} files, will seed ${r} more`), r > 0) {
                    const e = t.map(e => e._arc_fid),
                        n = await this.broker.listFilesToSeed(r, e);
                    for (const t of n) await this.seedFile(t), await Object(u["i"])(1e3)
                }
            }
            async seedFile(e) {
                e.torrentFileObj.urlList = [];
                const t = {
                        getAnnounceOpts: () => ({
                            numwant: 5
                        })
                    },
                    n = await this.startTorrentingFile(e, f["p"], t),
                    r = e.seedTaskDate && 0 === n.progress;
                if (!r) {
                    for (const t of n.files) t.deselect && t.deselect();
                    const e = 0;
                    n.deselect(0, n.pieces.length - 1, e)
                }
                return n.resume(), n
            }
            _addFakeTorrent() {
                let e = this.torrentClient.torrents.find(e => e.isFake);
                if (e) return;
                const t = "0123456789ABCDEF",
                    n = t[Math.floor(Math.random() * t.length)],
                    r = E["i"].get("fih", n.repeat(40)),
                    i = "wss://tkr.arc.io/announce",
                    o = `magnet:?xt=urn:btih:${r}&tr=${i}`,
                    s = {
                        getAnnounceOpts: () => ({
                            numwant: 2
                        })
                    };
                e = this.torrentClient.add(o, s), e.isFake = !0, e._arc_fid = f["a"], e._arc_client = f["p"], e._arc_isLocked = !1, this.reporter && this._addDataTransferReportHooks(f["a"], e, f["p"]);
                const a = 864e5;
                setTimeout(async () => {
                    await this.stopTorrentingFile(e), this._addFakeTorrent()
                }, a)
            }
            addCleanupFn(e) {
                this.cleanupFns.push(e)
            }
            async destroy() {
                this.isDestroyed = !0, await this.broker.destroy(), await this.reporter.destroy(), this.torrentClient.destroy(), this.overmindClient && this.overmindClient.destroy(), this.broker = null, this.reporter = null, this.torrentClient = null, this.overmindClient = null, this.cleanupFns.forEach(e => e()), this.cleanupFns = []
            }
        }
        t["a"] = new L
    },
    "0d7c": function(e, t, n) {
        (function(t) {
            const n = "object" === typeof t && Object({
                NODE_ENV: "production",
                BASE_URL: "https://static.arc.io/",
                ACCOUNT_ORIGIN: "https://account.arc.io",
                BANDWIDTH_WARDEN_ORIGIN: "https://warden.arc.io",
                COGNITO_APP_ID: "431634imeo45noat90ccl0lkep",
                COGNITO_REGION: "us-east-2",
                COGNITO_IDENTITY_POOL_ID: "us-east-2:cec1bb4c-3aa1-4d9a-87df-b75ae59441d0",
                COGNITO_USER_POOL_ID: "us-east-2_3sKO4HOjv",
                COMMIT_HASH: "ce271de",
                CORE_ORIGIN: "https://core.arc.io",
                DEMO_VUE_ORIGIN: "https://demo.arc.io",
                DOCS_ORIGIN: "https://docs.arc.io",
                FIREBASE_API_KEY: "AIzaSyCGmeUDT5F7Bq77JvXlN8IXBwJjIXJwvcI",
                GA_TID_HOMEPAGE: "UA-123508647-1",
                GA_TID_USER_TIMING: "UA-123508647-2",
                GATEWAY_ORIGIN: "https://gateway.arc.io",
                GOOGLE_PROJECT_FIRESTORE_ID: "prod-firestore-arc",
                HOMEPAGE_ORIGIN: "https://arc.io",
                INLAY_ORIGIN: "https://inlay.arc.io",
                OVERMIND_ORIGIN: "https://overmind.arc.io",
                PORTAL_VUE_ORIGIN: "https://portal.arc.io",
                PORTAL_ORIGIN: "https://portal.arc.io",
                NODE_REPORT_MAILBOX_ORIGIN: "https://warden.arc.io",
                ROOT_DOMAIN: "arc.io",
                SOCKETCLUSTER_HOSTNAME: "socket.arc.io",
                SOCKETCLUSTER_PORT: "443",
                STATIC_ORIGIN: "https://static.arc.io",
                STORAGE_ORIGIN: "https://storage.arc.io",
                STRIPE_CLIENT_ID: "ca_DMhwnlBqMfP4Vx8mJF4M1nGxTNU5263W",
                STRIPE_PUBLISHABLE_KEY: "pk_live_Df4EdjIuSE8fW21HyuwWhJcm",
                SW_ORIGIN: "https://arc.io",
                TCDN_ORIGIN: "https://tcdn.arc.io",
                TRACKER_ANNOUNCE_URL: "wss://tkr.arc.io/announce",
                TRACKER_ORIGIN: "https://tkr.arc.io",
                WEBSEED_ORIGIN: "https://webseed.arc.io",
                WIDGET_ORIGIN: "https://arc.io",
                DEBUG: "false"
            }) && Object({
                NODE_ENV: "production",
                BASE_URL: "https://static.arc.io/",
                ACCOUNT_ORIGIN: "https://account.arc.io",
                BANDWIDTH_WARDEN_ORIGIN: "https://warden.arc.io",
                COGNITO_APP_ID: "431634imeo45noat90ccl0lkep",
                COGNITO_REGION: "us-east-2",
                COGNITO_IDENTITY_POOL_ID: "us-east-2:cec1bb4c-3aa1-4d9a-87df-b75ae59441d0",
                COGNITO_USER_POOL_ID: "us-east-2_3sKO4HOjv",
                COMMIT_HASH: "ce271de",
                CORE_ORIGIN: "https://core.arc.io",
                DEMO_VUE_ORIGIN: "https://demo.arc.io",
                DOCS_ORIGIN: "https://docs.arc.io",
                FIREBASE_API_KEY: "AIzaSyCGmeUDT5F7Bq77JvXlN8IXBwJjIXJwvcI",
                GA_TID_HOMEPAGE: "UA-123508647-1",
                GA_TID_USER_TIMING: "UA-123508647-2",
                GATEWAY_ORIGIN: "https://gateway.arc.io",
                GOOGLE_PROJECT_FIRESTORE_ID: "prod-firestore-arc",
                HOMEPAGE_ORIGIN: "https://arc.io",
                INLAY_ORIGIN: "https://inlay.arc.io",
                OVERMIND_ORIGIN: "https://overmind.arc.io",
                PORTAL_VUE_ORIGIN: "https://portal.arc.io",
                PORTAL_ORIGIN: "https://portal.arc.io",
                NODE_REPORT_MAILBOX_ORIGIN: "https://warden.arc.io",
                ROOT_DOMAIN: "arc.io",
                SOCKETCLUSTER_HOSTNAME: "socket.arc.io",
                SOCKETCLUSTER_PORT: "443",
                STATIC_ORIGIN: "https://static.arc.io",
                STORAGE_ORIGIN: "https://storage.arc.io",
                STRIPE_CLIENT_ID: "ca_DMhwnlBqMfP4Vx8mJF4M1nGxTNU5263W",
                STRIPE_PUBLISHABLE_KEY: "pk_live_Df4EdjIuSE8fW21HyuwWhJcm",
                SW_ORIGIN: "https://arc.io",
                TCDN_ORIGIN: "https://tcdn.arc.io",
                TRACKER_ANNOUNCE_URL: "wss://tkr.arc.io/announce",
                TRACKER_ORIGIN: "https://tkr.arc.io",
                WEBSEED_ORIGIN: "https://webseed.arc.io",
                WIDGET_ORIGIN: "https://arc.io",
                DEBUG: "false"
            }).NODE_DEBUG && /\bsemver\b/i.test(Object({
                NODE_ENV: "production",
                BASE_URL: "https://static.arc.io/",
                ACCOUNT_ORIGIN: "https://account.arc.io",
                BANDWIDTH_WARDEN_ORIGIN: "https://warden.arc.io",
                COGNITO_APP_ID: "431634imeo45noat90ccl0lkep",
                COGNITO_REGION: "us-east-2",
                COGNITO_IDENTITY_POOL_ID: "us-east-2:cec1bb4c-3aa1-4d9a-87df-b75ae59441d0",
                COGNITO_USER_POOL_ID: "us-east-2_3sKO4HOjv",
                COMMIT_HASH: "ce271de",
                CORE_ORIGIN: "https://core.arc.io",
                DEMO_VUE_ORIGIN: "https://demo.arc.io",
                DOCS_ORIGIN: "https://docs.arc.io",
                FIREBASE_API_KEY: "AIzaSyCGmeUDT5F7Bq77JvXlN8IXBwJjIXJwvcI",
                GA_TID_HOMEPAGE: "UA-123508647-1",
                GA_TID_USER_TIMING: "UA-123508647-2",
                GATEWAY_ORIGIN: "https://gateway.arc.io",
                GOOGLE_PROJECT_FIRESTORE_ID: "prod-firestore-arc",
                HOMEPAGE_ORIGIN: "https://arc.io",
                INLAY_ORIGIN: "https://inlay.arc.io",
                OVERMIND_ORIGIN: "https://overmind.arc.io",
                PORTAL_VUE_ORIGIN: "https://portal.arc.io",
                PORTAL_ORIGIN: "https://portal.arc.io",
                NODE_REPORT_MAILBOX_ORIGIN: "https://warden.arc.io",
                ROOT_DOMAIN: "arc.io",
                SOCKETCLUSTER_HOSTNAME: "socket.arc.io",
                SOCKETCLUSTER_PORT: "443",
                STATIC_ORIGIN: "https://static.arc.io",
                STORAGE_ORIGIN: "https://storage.arc.io",
                STRIPE_CLIENT_ID: "ca_DMhwnlBqMfP4Vx8mJF4M1nGxTNU5263W",
                STRIPE_PUBLISHABLE_KEY: "pk_live_Df4EdjIuSE8fW21HyuwWhJcm",
                SW_ORIGIN: "https://arc.io",
                TCDN_ORIGIN: "https://tcdn.arc.io",
                TRACKER_ANNOUNCE_URL: "wss://tkr.arc.io/announce",
                TRACKER_ORIGIN: "https://tkr.arc.io",
                WEBSEED_ORIGIN: "https://webseed.arc.io",
                WIDGET_ORIGIN: "https://arc.io",
                DEBUG: "false"
            }).NODE_DEBUG) ? (...e) => console.error("SEMVER", ...e) : () => {};
            e.exports = n
        }).call(this, n("4362"))
    },
    "0db6": function(e, t, n) {
        "use strict";
        var r = n("c9b8").codes.ERR_INVALID_OPT_VALUE;

        function i(e, t, n) {
            return null != e.highWaterMark ? e.highWaterMark : t ? e[n] : null
        }

        function o(e, t, n, o) {
            var s = i(t, o, n);
            if (null != s) {
                if (!isFinite(s) || Math.floor(s) !== s || s < 0) {
                    var a = o ? n : "highWaterMark";
                    throw new r(a, s)
                }
                return Math.floor(s)
            }
            return e.objectMode ? 16 : 16384
        }
        e.exports = {
            getHighWaterMark: o
        }
    },
    "0e49": function(e, t, n) {
        const r = n("f06c"),
            i = (e, t, n) => r(e, t, n) >= 0;
        e.exports = i
    },
    "0ecd": function(e, t, n) {
        "use strict";
        n.d(t, "a", (function() {
            return a
        })), n.d(t, "b", (function() {
            return c
        })), n.d(t, "c", (function() {
            return h
        })), n.d(t, "d", (function() {
            return O
        }));
        console.log;
        const r = "tCDN",
            i = "CDN",
            o = "fulfillP2P",
            s = "scope",
            a = "onAdblock",
            c = "seeder",
            h = "requestOptIn",
            u = "https://arc.io/widget.js",
            f = "https://arc.io/widget.min.js",
            d = "/arc-widget";
        const l = () => ({
                propertyId: null,
                [r]: !1,
                [i]: !0,
                [o]: !0,
                [s]: "/",
                [a]: null,
                [c]: !0,
                env: "default",
                wpPluginVersion: null,
                isReverseProxied: !1
            }),
            p = e => "boolean" === typeof e,
            g = (() => {
                const e = l();
                return Object.keys(e).filter(t => p(e[t]))
            })(),
            _ = /^[a-km-zA-HJ-NP-Z1-9]{22}$/,
            y = /^[a-km-zA-HJ-NP-Z1-9]{8}$/,
            m = e => e.startsWith(u + "?");

        function b(e, t) {
            return t = A(e.searchParams, t), t.src = e.href, t
        }
        const w = e => e.startsWith(u + "/");

        function v(e, t) {
            const {
                pathname: n,
                searchParams: r
            } = e;
            return t = A(r, t), t.propertyId = R(n), t.src = e.href, t
        }
        const E = e => {
            const {
                href: t,
                pathname: n
            } = e;
            return t.startsWith(u + "#") || t.startsWith(f + "#") || n.includes(d)
        };

        function T(e, t) {
            const [n, r, i] = e.href.split(/#|[?]/), o = new URLSearchParams(i);
            return t = A(o, t), t.propertyId = r, t.isReverseProxied = e.pathname.includes(d), t.src = e.href, t
        }

        function R(e) {
            const t = e.split("/").filter(e => e).pop();
            return y.test(t) || _.test(t) ? t : null
        }

        function S(e) {
            const {
                host: t,
                pathname: n
            } = new URL(e), r = `//${t}${n}`;
            return r
        }

        function I() {
            const e = document.querySelector(`\n        script[src^="${f}"],\n        script[src^="${u}"],\n        script[src*="${d}"],\n        script[src^="${S(f)}"],\n        script[src^="${S(u)}"]\n    `);
            return e
        }

        function O() {
            const e = l(),
                t = I();
            if (!t) return e;
            let n = t.getAttribute("src");
            return n.startsWith("//") ? n = window.location.protocol + n : n.startsWith("/") && (n = window.location.origin + n), k(n)
        }

        function k(e) {
            const t = l(),
                n = new URL(e);
            return E(n) ? T(n, t) : w(e) ? v(n, t) : m(e) ? b(n, t) : t
        }

        function A(e, t) {
            for (const [n, r] of e.entries()) _.test(n) ? t.propertyId = n : g.includes(n) ? t[n] = "true" === r.toLowerCase() : n in t && (t[n] = r);
            return t
        }
    },
    1: function(e, t) {},
    10: function(e, t) {},
    11: function(e, t) {},
    1131: function(e, t, n) {
        (function(t) {
            const n = 105,
                r = 58,
                i = 100,
                o = 108,
                s = 101;

            function a(e, t, n) {
                let r = 0,
                    i = 1;
                for (let o = t; o < n; o++) {
                    const n = e[o];
                    if (n < 58 && n >= 48) r = 10 * r + (n - 48);
                    else if (o !== t || 43 !== n) {
                        if (o !== t || 45 !== n) {
                            if (46 === n) break;
                            throw new Error("not a number: buffer[" + o + "] = " + n)
                        }
                        i = -1
                    }
                }
                return r * i
            }

            function c(e, n, r, i) {
                return null == e || 0 === e.length ? null : ("number" !== typeof n && null == i && (i = n, n = void 0), "number" !== typeof r && null == i && (i = r, r = void 0), c.position = 0, c.encoding = i || null, c.data = t.isBuffer(e) ? e.slice(n, r) : t.from(e), c.bytes = c.data.length, c.next())
            }
            c.bytes = 0, c.position = 0, c.data = null, c.encoding = null, c.next = function() {
                switch (c.data[c.position]) {
                    case i:
                        return c.dictionary();
                    case o:
                        return c.list();
                    case n:
                        return c.integer();
                    default:
                        return c.buffer()
                }
            }, c.find = function(e) {
                let t = c.position;
                const n = c.data.length,
                    r = c.data;
                while (t < n) {
                    if (r[t] === e) return t;
                    t++
                }
                throw new Error('Invalid data: Missing delimiter "' + String.fromCharCode(e) + '" [0x' + e.toString(16) + "]")
            }, c.dictionary = function() {
                c.position++;
                const e = {};
                while (c.data[c.position] !== s) e[c.buffer()] = c.next();
                return c.position++, e
            }, c.list = function() {
                c.position++;
                const e = [];
                while (c.data[c.position] !== s) e.push(c.next());
                return c.position++, e
            }, c.integer = function() {
                const e = c.find(s),
                    t = a(c.data, c.position + 1, e);
                return c.position += e + 1 - c.position, t
            }, c.buffer = function() {
                let e = c.find(r);
                const t = a(c.data, c.position, e),
                    n = ++e + t;
                return c.position = n, c.encoding ? c.data.toString(c.encoding, e, n) : c.data.slice(e, n)
            }, e.exports = c
        }).call(this, n("b639").Buffer)
    },
    "11dc": function(e, t, n) {
        "use strict";
        (function(t, r) {
            var i = 65536,
                o = 4294967295;

            function s() {
                throw new Error("Secure random number generation is not supported by this browser.\nUse Chrome, Firefox or Internet Explorer 11")
            }
            var a = n("8707").Buffer,
                c = t.crypto || t.msCrypto;

            function h(e, t) {
                if (e > o) throw new RangeError("requested too many random bytes");
                var n = a.allocUnsafe(e);
                if (e > 0)
                    if (e > i)
                        for (var s = 0; s < e; s += i) c.getRandomValues(n.slice(s, s + i));
                    else c.getRandomValues(n);
                return "function" === typeof t ? r.nextTick((function() {
                    t(null, n)
                })) : n
            }
            c && c.getRandomValues ? e.exports = h : e.exports = s
        }).call(this, n("c8ba"), n("4362"))
    },
    12: function(e, t) {},
    13: function(e, t) {},
    "13ee": function(e, t) {},
    14: function(e, t) {},
    1468: function(e, t) {
        var n = 1e3,
            r = 60 * n,
            i = 60 * r,
            o = 24 * i,
            s = 7 * o,
            a = 365.25 * o;

        function c(e) {
            if (e = String(e), !(e.length > 100)) {
                var t = /^(-?(?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)?$/i.exec(e);
                if (t) {
                    var c = parseFloat(t[1]),
                        h = (t[2] || "ms").toLowerCase();
                    switch (h) {
                        case "years":
                        case "year":
                        case "yrs":
                        case "yr":
                        case "y":
                            return c * a;
                        case "weeks":
                        case "week":
                        case "w":
                            return c * s;
                        case "days":
                        case "day":
                        case "d":
                            return c * o;
                        case "hours":
                        case "hour":
                        case "hrs":
                        case "hr":
                        case "h":
                            return c * i;
                        case "minutes":
                        case "minute":
                        case "mins":
                        case "min":
                        case "m":
                            return c * r;
                        case "seconds":
                        case "second":
                        case "secs":
                        case "sec":
                        case "s":
                            return c * n;
                        case "milliseconds":
                        case "millisecond":
                        case "msecs":
                        case "msec":
                        case "ms":
                            return c;
                        default:
                            return
                    }
                }
            }
        }

        function h(e) {
            var t = Math.abs(e);
            return t >= o ? Math.round(e / o) + "d" : t >= i ? Math.round(e / i) + "h" : t >= r ? Math.round(e / r) + "m" : t >= n ? Math.round(e / n) + "s" : e + "ms"
        }

        function u(e) {
            var t = Math.abs(e);
            return t >= o ? f(e, t, o, "day") : t >= i ? f(e, t, i, "hour") : t >= r ? f(e, t, r, "minute") : t >= n ? f(e, t, n, "second") : e + " ms"
        }

        function f(e, t, n, r) {
            var i = t >= 1.5 * n;
            return Math.round(e / n) + " " + r + (i ? "s" : "")
        }
        e.exports = function(e, t) {
            t = t || {};
            var n = typeof e;
            if ("string" === n && e.length > 0) return c(e);
            if ("number" === n && isFinite(e)) return t.long ? u(e) : h(e);
            throw new Error("val is not a non-empty string or a valid number. val=" + JSON.stringify(e))
        }
    },
    15: function(e, t) {},
    "175e": function(e, t, n) {
        "use strict";

        function r(e, t) {
            for (var n = 1, r = e.length, i = e[0], o = e[0], s = 1; s < r; ++s)
                if (o = i, i = e[s], t(i, o)) {
                    if (s === n) {
                        n++;
                        continue
                    }
                    e[n++] = i
                }
            return e.length = n, e
        }

        function i(e) {
            for (var t = 1, n = e.length, r = e[0], i = e[0], o = 1; o < n; ++o, i = r)
                if (i = r, r = e[o], r !== i) {
                    if (o === t) {
                        t++;
                        continue
                    }
                    e[t++] = r
                }
            return e.length = t, e
        }

        function o(e, t, n) {
            return 0 === e.length ? e : t ? (n || e.sort(t), r(e, t)) : (n || e.sort(), i(e))
        }
        e.exports = o
    },
    "17f3": function(e, t, n) {
        (function(t) {
            const r = n("34eb")("torrent-discovery"),
                i = n(8),
                o = n("faa1").EventEmitter,
                s = n("8cc1"),
                a = n("27ab");
            class c extends o {
                constructor(e) {
                    if (super(), !e.peerId) throw new Error("Option `peerId` is required");
                    if (!e.infoHash) throw new Error("Option `infoHash` is required");
                    if (!t.browser && !e.port) throw new Error("Option `port` is required");
                    this.peerId = "string" === typeof e.peerId ? e.peerId : e.peerId.toString("hex"), this.infoHash = "string" === typeof e.infoHash ? e.infoHash.toLowerCase() : e.infoHash.toString("hex"), this._port = e.port, this._userAgent = e.userAgent, this.destroyed = !1, this._announce = e.announce || [], this._intervalMs = e.intervalMs || 9e5, this._trackerOpts = null, this._dhtAnnouncing = !1, this._dhtTimeout = !1, this._internalDHT = !1, this._onWarning = e => {
                        this.emit("warning", e)
                    }, this._onError = e => {
                        this.emit("error", e)
                    }, this._onDHTPeer = (e, t) => {
                        t.toString("hex") === this.infoHash && this.emit("peer", `${e.host}:${e.port}`, "dht")
                    }, this._onTrackerPeer = e => {
                        this.emit("peer", e, "tracker")
                    }, this._onTrackerAnnounce = () => {
                        this.emit("trackerAnnounce")
                    };
                    const n = (e, t) => {
                        const n = new i(t);
                        return n.on("warning", this._onWarning), n.on("error", this._onError), n.listen(e), this._internalDHT = !0, n
                    };
                    !1 === e.tracker ? this.tracker = null : e.tracker && "object" === typeof e.tracker ? (this._trackerOpts = Object.assign({}, e.tracker), this.tracker = this._createTracker()) : this.tracker = this._createTracker(), !1 === e.dht || "function" !== typeof i ? this.dht = null : e.dht && "function" === typeof e.dht.addNode ? this.dht = e.dht : e.dht && "object" === typeof e.dht ? this.dht = n(e.dhtPort, e.dht) : this.dht = n(e.dhtPort), this.dht && (this.dht.on("peer", this._onDHTPeer), this._dhtAnnounce())
                }
                updatePort(e) {
                    e !== this._port && (this._port = e, this.dht && this._dhtAnnounce(), this.tracker && (this.tracker.stop(), this.tracker.destroy(() => {
                        this.tracker = this._createTracker()
                    })))
                }
                complete(e) {
                    this.tracker && this.tracker.complete(e)
                }
                destroy(e) {
                    if (this.destroyed) return;
                    this.destroyed = !0, clearTimeout(this._dhtTimeout);
                    const t = [];
                    this.tracker && (this.tracker.stop(), this.tracker.removeListener("warning", this._onWarning), this.tracker.removeListener("error", this._onError), this.tracker.removeListener("peer", this._onTrackerPeer), this.tracker.removeListener("update", this._onTrackerAnnounce), t.push(e => {
                        this.tracker.destroy(e)
                    })), this.dht && this.dht.removeListener("peer", this._onDHTPeer), this._internalDHT && (this.dht.removeListener("warning", this._onWarning), this.dht.removeListener("error", this._onError), t.push(e => {
                        this.dht.destroy(e)
                    })), s(t, e), this.dht = null, this.tracker = null, this._announce = null
                }
                _createTracker() {
                    const e = Object.assign({}, this._trackerOpts, {
                            infoHash: this.infoHash,
                            announce: this._announce,
                            peerId: this.peerId,
                            port: this._port,
                            userAgent: this._userAgent
                        }),
                        t = new a(e);
                    return t.on("warning", this._onWarning), t.on("error", this._onError), t.on("peer", this._onTrackerPeer), t.on("update", this._onTrackerAnnounce), t.setInterval(this._intervalMs), t.start(), t
                }
                _dhtAnnounce() {
                    this._dhtAnnouncing || (r("dht announce"), this._dhtAnnouncing = !0, clearTimeout(this._dhtTimeout), this.dht.announce(this.infoHash, this._port, e => {
                        this._dhtAnnouncing = !1, r("dht announce complete"), e && this.emit("warning", e), this.emit("dhtAnnounce"), this.destroyed || (this._dhtTimeout = setTimeout(() => {
                            this._dhtAnnounce()
                        }, this._intervalMs + Math.floor(Math.random() * this._intervalMs / 5)), this._dhtTimeout.unref && this._dhtTimeout.unref())
                    }))
                }
            }
            e.exports = c
        }).call(this, n("4362"))
    },
    "182d": function(e, t, n) {
        var r = n("f8cd");
        e.exports = function(e, t) {
            var n = r(e);
            if (n % t) throw RangeError("Wrong offset");
            return n
        }
    },
    "190a": function(e, t, n) {
        "use strict";
        n.d(t, "a", (function() {
            return d
        }));
        var r = n("a5a5"),
            i = n("8c32"),
            o = n("a59c"),
            s = n("5de4"),
            a = n("5ff7");
        Object.freeze({
            FOCUS: "focus",
            BLUR: "blur",
            UNLOAD: "unload"
        });
        const c = a["a"].NODE_REPORT_MAILBOX_ORIGIN + "/mailbox",
            h = 1e3,
            u = 36e5;
        class f {
            constructor() {
                this.pageActivityDocId = Object(o["a"])(), this.isFocused = !0, this.hasReportedPageUnload = !1, this.xferReports = {}, this.trackerSocket = null
            }
            setNodeId(e) {
                this.myNodeId = e
            }
            setPropertyId(e) {
                this.propertyId = e
            }
            setPropertySessionId(e) {
                this.propertySessionId = e
            }
            setTrackerSocket(e) {
                this.trackerSocket = e
            }
            async reportPageFocus(e, t) {
                this.isFocused = !0
            }
            async reportPageBlur(e, t) {
                this.isFocused = !1, this.hasReportedPageUnload
            }
            reportPropertySessionOnUnload() {
                this.hasReportedPageUnload = !0;
                const e = {
                    nodeId: this.myNodeId,
                    propertyId: this.propertyId,
                    propertySessionId: this.propertySessionId,
                    origins: [location.origin],
                    status: "close"
                };
                this._reportOnUnload(r["m"], e)
            }
            async reportDataTransfer(e, t, n, i, o, s, a, c) {
                e in this.xferReports || (this.xferReports[e] = {
                    writes: [],
                    transferCreatedAt: Date.now(),
                    sentAt: null,
                    flushTimeoutId: null,
                    index: 0
                });
                const f = this.xferReports[e],
                    d = {
                        transferId: e,
                        myNodeId: this.myNodeId,
                        propertyId: this.propertyId,
                        numBytesDownloaded: a,
                        numBytesUploaded: s,
                        fid: n,
                        myPeerId: i,
                        peerPeerId: o,
                        connectionType: t,
                        arcClient: c,
                        index: f.index,
                        transferCreatedAt: f.transferCreatedAt,
                        createdAt: Date.now()
                    };
                f.writes.splice(0), f.writes.push(d);
                const l = n === r["a"],
                    p = l ? u : h;
                this._canSendXferReport(f, p) && this._sendXferReport(f), l || (clearTimeout(f.flushTimeoutId), f.flushTimeoutId = setTimeout(() => {
                    this._sendXferReport(f)
                }, 2e3))
            }
            _canSendXferReport(e, t = h) {
                const n = e.sentAt,
                    r = !n || new Date - n > t;
                return r
            }
            async _sendXferReport(e) {
                const t = e.writes.splice(0);
                if (t.length)
                    if (e.index++, e.sentAt = new Date, this.trackerSocket.readyState === WebSocket.OPEN) {
                        const e = JSON.stringify({
                            action: "transferReport",
                            transfers: t
                        });
                        this.trackerSocket.send(e)
                    } else await this._sendRequest(r["o"], "POST", {
                        transfers: t
                    })
            }
            _getPendingXferReports() {
                const e = [];
                for (const t of Object.values(this.xferReports)) {
                    const n = t.writes.splice(0);
                    e.push(...n)
                }
                return e
            }
            reportDataTransferOnUnload() {
                const e = this._getPendingXferReports();
                if (!e.length) return;
                const t = {
                    transfers: e
                };
                this._reportOnUnload(r["o"], t)
            }
            async closeDataTransfer(e) {
                const t = this.xferReports[e];
                t && await this._sendXferReport(t), delete this.xferReports[e]
            }
            async reportNodeInfo(e) {
                const t = `${c}/nodes/${this.myNodeId}`,
                    n = await this._sendRequest(t, "POST", e);
                return n
            }
            async reportWidgetOpened() {
                const e = {
                        propertyId: this.propertyId
                    },
                    t = `${c}/nodes/${this.myNodeId}/opened`,
                    n = await this._sendRequest(t, "POST", e);
                return n
            }
            async _sendRequest(e, t, n) {
                const r = {
                    method: t,
                    credentials: "omit"
                };
                let o;
                n && Object.assign(r, {
                    body: JSON.stringify(n),
                    headers: {
                        "Content-Type": "text/plain;charset=UTF-8"
                    }
                });
                try {
                    o = await Object(s["j"])(e, r)
                } catch (a) {
                    Object(i["c"])(a)
                }
                return o
            }
            _reportOnUnload(e, t) {
                navigator.sendBeacon ? this._reportOnUnload_sendBeacon(e, t) : this._reportOnUnload_syncXhr(e, t)
            }
            _reportOnUnload_syncXhr(e, t) {
                const n = new XMLHttpRequest;
                n.open("POST", e, !1), n.setRequestHeader("Content-Type", "application/json; charset=UTF-8"), n.send(JSON.stringify(t))
            }
            _reportOnUnload_sendBeacon(e, t) {
                const n = {
                        type: "text/plain"
                    },
                    r = new Blob([JSON.stringify(t)], n),
                    o = navigator.sendBeacon(e, r);
                o || Object(i["c"])("navigator.sendBeacon() failed to queue a request. Why?")
            }
            async destroy() {
                clearTimeout(this.flushTimeoutId)
            }
        }
        const d = new f
    },
    "19aa": function(e, t) {
        e.exports = function(e, t, n) {
            if (!(e instanceof t)) throw TypeError("Incorrect " + (n ? n + " " : "") + "invocation");
            return e
        }
    },
    "1be4": function(e, t, n) {
        var r = n("d066");
        e.exports = r("document", "documentElement")
    },
    "1c0b": function(e, t) {
        e.exports = function(e) {
            if ("function" != typeof e) throw TypeError(String(e) + " is not a function");
            return e
        }
    },
    "1c7e": function(e, t, n) {
        var r = n("b622"),
            i = r("iterator"),
            o = !1;
        try {
            var s = 0,
                a = {
                    next: function() {
                        return {
                            done: !!s++
                        }
                    },
                    return: function() {
                        o = !0
                    }
                };
            a[i] = function() {
                return this
            }, Array.from(a, (function() {
                throw 2
            }))
        } catch (c) {}
        e.exports = function(e, t) {
            if (!t && !o) return !1;
            var n = !1;
            try {
                var r = {};
                r[i] = function() {
                    return {
                        next: function() {
                            return {
                                done: n = !0
                            }
                        }
                    }
                }, e(r)
            } catch (c) {}
            return n
        }
    },
    "1d80": function(e, t) {
        e.exports = function(e) {
            if (void 0 == e) throw TypeError("Can't call method on " + e);
            return e
        }
    },
    "1e48": function(e, t, n) {
        (function(e) {
            t.DEFAULT_ANNOUNCE_PEERS = 50, t.MAX_ANNOUNCE_PEERS = 82, t.binaryToHex = t => ("string" !== typeof t && (t = String(t)), e.from(t, "binary").toString("hex")), t.hexToBinary = t => ("string" !== typeof t && (t = String(t)), e.from(t, "hex").toString("binary"));
            const r = n(3);
            Object.assign(t, r)
        }).call(this, n("b639").Buffer)
    },
    "1f4f": function(e, t, n) {
        const r = n("34eb")("bittorrent-tracker:websocket-tracker"),
            i = n("051a"),
            o = n("11dc"),
            s = n("8fe5"),
            a = n("1e48"),
            c = n("8091"),
            h = {},
            u = 1e4,
            f = 18e5,
            d = 12e4,
            l = 5e4,
            p = 1e4,
            g = /a=ice-options:trickle\s\n/;
        class _ extends c {
            constructor(e, t, n) {
                super(e, t), r("new websocket tracker %s", t), this.trickle = void 0 !== n.trickle && n.trickle, this.peers = {}, this.pendingWrites = [], this.socket = null, this.reconnecting = !1, this.retries = 0, this.reconnectTimer = null, this.expectingResponse = !1, this._openSocket()
            }
            announce(e) {
                if (this.destroyed || this.reconnecting) return;
                this.socket.connected || this.socket.once("connect", () => {
                    while (this.pendingWrites.length) {
                        const e = this.pendingWrites.shift();
                        this._send(e)
                    }
                });
                const t = {
                        action: "announce",
                        info_hash: this.client._infoHashBinary,
                        peer_id: this.client._peerIdBinary
                    },
                    n = Object.assign({}, e, t);
                if (this._trackerId && (n.trackerid = this._trackerId), "stopped" === e.event || "completed" === e.event) this._send(n);
                else if (this.trickle) {
                    const r = Math.min(e.numwant, 10);
                    this._generateTrickleOffers(r, e => {
                        n.numwant = r, n.offers = e, this._send(n)
                    }, e => {
                        const n = Object.assign({}, t);
                        n.offers = [e], n.event = "trickle", this._send(n)
                    })
                } else {
                    const t = Math.min(e.numwant, 10);
                    this._generateOffers(t, e => {
                        n.numwant = t, n.offers = e, this._send(n)
                    })
                }
            }
            scrape(e) {
                if (this.destroyed || this.reconnecting) return;
                if (!this.socket.connected) return void this.socket.once("connect", () => {
                    this.scrape(e)
                });
                const t = Array.isArray(e.infoHash) && e.infoHash.length > 0 ? e.infoHash.map(e => e.toString("binary")) : e.infoHash && e.infoHash.toString("binary") || this.client._infoHashBinary,
                    n = {
                        action: "scrape",
                        info_hash: t
                    };
                this._send(n)
            }
            destroy(e = y) {
                if (this.destroyed) return e(null);
                this.destroyed = !0, clearInterval(this.interval), clearTimeout(this.reconnectTimer);
                for (const i in this.peers) {
                    const e = this.peers[i];
                    clearTimeout(e.trackerTimeout), e.destroy()
                }
                if (this.peers = null, this.socket && (this.socket.removeListener("connect", this._onSocketConnectBound), this.socket.removeListener("data", this._onSocketDataBound), this.socket.removeListener("close", this._onSocketCloseBound), this.socket.removeListener("error", this._onSocketErrorBound), this.socket = null), this._onSocketConnectBound = null, this._onSocketErrorBound = null, this._onSocketDataBound = null, this._onSocketCloseBound = null, h[this.announceUrl] && (h[this.announceUrl].consumers -= 1), h[this.announceUrl].consumers > 0) return e();
                let t = h[this.announceUrl];
                delete h[this.announceUrl], t.on("error", y), t.once("close", e);
                let n = null;
                if (!this.expectingResponse) return r();

                function r() {
                    n && (clearTimeout(n), n = null), t.removeListener("data", r), t.destroy(), t = null
                }
                n = setTimeout(r, a.DESTROY_TIMEOUT), t.once("data", r)
            }
            _openSocket() {
                this.destroyed = !1, this.peers || (this.peers = {}), this._onSocketConnectBound = () => {
                    this._onSocketConnect()
                }, this._onSocketErrorBound = e => {
                    this._onSocketError(e)
                }, this._onSocketDataBound = e => {
                    this._onSocketData(e)
                }, this._onSocketCloseBound = () => {
                    this._onSocketClose()
                }, this.socket = h[this.announceUrl], this.socket ? (h[this.announceUrl].consumers += 1, this.socket.connected && this._onSocketConnectBound()) : (this.socket = h[this.announceUrl] = new s(this.announceUrl), this.socket.consumers = 1, this.socket.once("connect", this._onSocketConnectBound)), this.socket.on("data", this._onSocketDataBound), this.socket.once("close", this._onSocketCloseBound), this.socket.once("error", this._onSocketErrorBound)
            }
            _onSocketConnect() {
                this.destroyed || this.reconnecting && (this.reconnecting = !1, this.retries = 0, this.announce(this.client._defaultAnnounceOpts()))
            }
            _onSocketData(e) {
                if (!this.destroyed) {
                    this.expectingResponse = !1;
                    try {
                        e = JSON.parse(e)
                    } catch (t) {
                        return void this.client.emit("warning", new Error("Invalid tracker response"))
                    }
                    "announce" === e.action ? this._onAnnounceResponse(e) : "scrape" === e.action ? this._onScrapeResponse(e) : this._onSocketError(new Error("invalid action in WS response: " + e.action))
                }
            }
            _onAnnounceResponse(e) {
                if (e.info_hash !== this.client._infoHashBinary) return void r("ignoring websocket data from %s for %s (looking for %s: reused socket)", this.announceUrl, a.binaryToHex(e.info_hash), this.client.infoHash);
                if (e.peer_id && e.peer_id === this.client._peerIdBinary) return;
                r("received %s from %s for %s", JSON.stringify(e), this.announceUrl, this.client.infoHash);
                const t = e["failure reason"];
                if (t) return this.client.emit("warning", new Error(t));
                const n = e["warning message"];
                n && this.client.emit("warning", new Error(n));
                const i = e.interval || e["min interval"];
                i && this.setInterval(1e3 * i);
                const o = e["tracker id"];
                if (o && (this._trackerId = o), null != e.complete) {
                    const t = Object.assign({}, e, {
                        announce: this.announceUrl,
                        infoHash: a.binaryToHex(e.info_hash)
                    });
                    this.client.emit("update", t)
                }
                let s;
                if (e.offer && e.peer_id) {
                    const t = a.binaryToHex(e.offer_id),
                        {
                            sdp: n,
                            candidate: i
                        } = e.offer,
                        o = g.test(n);
                    if (n) {
                        r("creating peer (from remote offer)"), s = this._createPeer({
                            trickle: this.trickle
                        }), s.id = a.binaryToHex(e.peer_id);
                        const n = s.trickle ? "on" : "once";
                        s[n]("signal", t => {
                            const n = {
                                action: "announce",
                                info_hash: this.client._infoHashBinary,
                                peer_id: this.client._peerIdBinary,
                                to_peer_id: e.peer_id,
                                answer: t,
                                offer_id: e.offer_id
                            };
                            this._trackerId && (n.trackerid = this._trackerId), this._send(n)
                        }), o && (this.peers[t] = s), this.client.emit("peer", s)
                    } else s = this.peers[t], s && this._setPeerTrickleTimeout(s, t);
                    (n || i) && s && !s.destroyed && s.signal(e.offer)
                }
                if (e.answer && e.peer_id) {
                    const t = a.binaryToHex(e.offer_id);
                    if (s = this.peers[t], s) {
                        s.id = a.binaryToHex(e.peer_id), s.destroyed || s.signal(e.answer), clearTimeout(s.trackerTimeout), s.trackerTimeout = null;
                        const {
                            sdp: n,
                            candidate: r
                        } = e.answer, i = g.test(n);
                        n && this.client.emit("peer", s), i || r ? this._setPeerTrickleTimeout(s, t) : delete this.peers[t]
                    } else r("got unexpected answer: " + JSON.stringify(e.answer))
                }
            }
            _onScrapeResponse(e) {
                e = e.files || {};
                const t = Object.keys(e);
                0 !== t.length ? t.forEach(t => {
                    const n = Object.assign(e[t], {
                        announce: this.announceUrl,
                        infoHash: a.binaryToHex(t)
                    });
                    this.client.emit("scrape", n)
                }) : this.client.emit("warning", new Error("invalid scrape response"))
            }
            _onSocketClose() {
                this.destroyed || (this.destroy(), this._startReconnectTimer())
            }
            _onSocketError(e) {
                this.destroyed || (this.destroy(), this.client.emit("warning", e), this._startReconnectTimer())
            }
            _startReconnectTimer() {
                const e = Math.floor(Math.random() * d) + Math.min(Math.pow(2, this.retries) * u, f);
                this.reconnecting = !0, clearTimeout(this.reconnectTimer), this.reconnectTimer = setTimeout(() => {
                    this.retries++, this._openSocket()
                }, e), this.reconnectTimer.unref && this.reconnectTimer.unref(), r("reconnecting socket in %s ms", e)
            }
            _send(e) {
                if (this.destroyed) return;
                if (!this.socket.connected) return void this.pendingWrites.push(e);
                this.expectingResponse = !0;
                const t = JSON.stringify(e);
                r("send %s", t), this.socket.send(t)
            }
            _generateOffers(e, t) {
                const n = this,
                    i = [];
                r("generating %s offers", e);
                for (let r = 0; r < e; ++r) s();

                function s() {
                    const e = o(20).toString("hex");
                    r("creating peer (from _generateOffers)");
                    const t = n.peers[e] = n._createPeer({
                        initiator: !0
                    });
                    t.once("signal", t => {
                        i.push({
                            offer: t,
                            offer_id: a.hexToBinary(e)
                        }), c()
                    }), t.trackerTimeout = setTimeout(() => {
                        r("tracker timeout: destroying peer"), t.trackerTimeout = null, delete n.peers[e], t.destroy()
                    }, l), t.trackerTimeout.unref && t.trackerTimeout.unref()
                }

                function c() {
                    i.length === e && (r("generated %s offers", e), t(i))
                }
                c()
            }
            _generateTrickleOffers(e, t, n) {
                const i = this,
                    s = [],
                    c = [];
                let h = !1;
                r("generating %s trickle offers", e);
                for (let r = 0; r < e; ++r) u();

                function u() {
                    const e = o(20).toString("hex"),
                        t = a.hexToBinary(e);
                    r("creating peer (from _generateTrickleOffers)");
                    const u = {
                            initiator: !0,
                            trickle: !0
                        },
                        d = i.peers[e] = i._createPeer(u);
                    d.on("signal", e => {
                        const r = {
                            offer: e,
                            offer_id: t
                        };
                        e.sdp ? (s.push(r), f()) : h ? n(r) : c.push(r)
                    }), d.trackerTimeout = setTimeout(() => {
                        r("tracker timeout: destroying peer"), d.trackerTimeout = null, delete i.peers[e], d.destroy()
                    }, l), d.trackerTimeout.unref && d.trackerTimeout.unref()
                }

                function f() {
                    s.length === e && (r("generated %s offers", e), h = !0, t(s), c.forEach(n))
                }
                f()
            }
            _setPeerTrackerTimeout(e, t) {
                e.trackerTimeout = setTimeout(() => {
                    r("tracker timeout: destroying peer"), e.trackerTimeout = null, delete this.peers[t], e.destroy()
                }, l), e.trackerTimeout.unref && e.trackerTimeout.unref()
            }
            _setPeerTrickleTimeout(e, t) {
                clearTimeout(e.trickleTimeout), e.trickleTimeout = setTimeout(() => {
                    this.destroyed || (r("trickle timeout: destroying peer"), delete this.peers[t])
                }, p), e.trickleTimeout.unref && e.trickleTimeout.unref()
            }
            _createPeer(e) {
                const t = this;
                e = Object.assign({
                    trickle: !1,
                    config: t.client._rtcConfig,
                    wrtc: t.client._wrtc
                }, e);
                const n = new i(e);
                return n.once("error", r), n.once("connect", o), n;

                function r(e) {
                    t.client.emit("warning", new Error("Connection error: " + e.message)), n.destroy()
                }

                function o() {
                    n.removeListener("error", r), n.removeListener("connect", o)
                }
            }
        }

        function y() {}
        _.prototype.DEFAULT_ANNOUNCE_INTERVAL = 3e4, _._socketPool = h, e.exports = _
    },
    "1fb5": function(e, t, n) {
        "use strict";
        t.byteLength = u, t.toByteArray = d, t.fromByteArray = g;
        for (var r = [], i = [], o = "undefined" !== typeof Uint8Array ? Uint8Array : Array, s = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", a = 0, c = s.length; a < c; ++a) r[a] = s[a], i[s.charCodeAt(a)] = a;

        function h(e) {
            var t = e.length;
            if (t % 4 > 0) throw new Error("Invalid string. Length must be a multiple of 4");
            var n = e.indexOf("="); - 1 === n && (n = t);
            var r = n === t ? 0 : 4 - n % 4;
            return [n, r]
        }

        function u(e) {
            var t = h(e),
                n = t[0],
                r = t[1];
            return 3 * (n + r) / 4 - r
        }

        function f(e, t, n) {
            return 3 * (t + n) / 4 - n
        }

        function d(e) {
            var t, n, r = h(e),
                s = r[0],
                a = r[1],
                c = new o(f(e, s, a)),
                u = 0,
                d = a > 0 ? s - 4 : s;
            for (n = 0; n < d; n += 4) t = i[e.charCodeAt(n)] << 18 | i[e.charCodeAt(n + 1)] << 12 | i[e.charCodeAt(n + 2)] << 6 | i[e.charCodeAt(n + 3)], c[u++] = t >> 16 & 255, c[u++] = t >> 8 & 255, c[u++] = 255 & t;
            return 2 === a && (t = i[e.charCodeAt(n)] << 2 | i[e.charCodeAt(n + 1)] >> 4, c[u++] = 255 & t), 1 === a && (t = i[e.charCodeAt(n)] << 10 | i[e.charCodeAt(n + 1)] << 4 | i[e.charCodeAt(n + 2)] >> 2, c[u++] = t >> 8 & 255, c[u++] = 255 & t), c
        }

        function l(e) {
            return r[e >> 18 & 63] + r[e >> 12 & 63] + r[e >> 6 & 63] + r[63 & e]
        }

        function p(e, t, n) {
            for (var r, i = [], o = t; o < n; o += 3) r = (e[o] << 16 & 16711680) + (e[o + 1] << 8 & 65280) + (255 & e[o + 2]), i.push(l(r));
            return i.join("")
        }

        function g(e) {
            for (var t, n = e.length, i = n % 3, o = [], s = 16383, a = 0, c = n - i; a < c; a += s) o.push(p(e, a, a + s > c ? c : a + s));
            return 1 === i ? (t = e[n - 1], o.push(r[t >> 2] + r[t << 4 & 63] + "==")) : 2 === i && (t = (e[n - 2] << 8) + e[n - 1], o.push(r[t >> 10] + r[t >> 4 & 63] + r[t << 2 & 63] + "=")), o.join("")
        }
        i["-".charCodeAt(0)] = 62, i["_".charCodeAt(0)] = 63
    },
    2: function(e, t) {},
    "20c9": function(e, t, n) {
        "use strict";
        n.r(t);
        var r = n("8fe5"),
            i = n.n(r),
            o = n("1f4f"),
            s = n.n(o),
            a = n("5ff7");
        const {
            TRACKER_ANNOUNCE_URL: c
        } = a["a"];

        function h(e) {
            let t;
            e ? (t = new i.a({
                socket: e
            }), t.connected = t._ws.readyState === WebSocket.OPEN) : t = new i.a(c), t.consumers = 0, s.a._socketPool[c] = t
        }
        var u = n("3d15"),
            f = n("8c32");

        function d() {
            u["d"].set("error", {
                canHandle: e => e instanceof Error,
                serialize: e => {
                    const t = Object(f["d"])(e),
                        n = [];
                    return [t, n]
                },
                deserialize: e => Object.assign(Error(), e)
            }), u["d"].set("babelError", {
                canHandle: e => e && 1 === e.length && e[0] instanceof Error,
                serialize: e => {
                    const t = [Object(f["d"])(e[0])],
                        n = [];
                    return [t, n]
                },
                deserialize: e => [Object.assign(Error(), e[0])]
            })
        }
        var l = n("c4d1"),
            p = n("190a"),
            g = n("c688"),
            _ = n("c74e"),
            y = n("0ecd");
        const {
            trackerSocket: m
        } = window.__arc__;
        h(m), p["a"].setTrackerSocket(m), d(), Object(l["b"])();
        const b = Object(y["d"])();
        Object(g["b"])(b), b.seeder && Promise.all([n.e("vendors~widget-ui"), n.e("widget-ui")]).then(n.bind(null, "6145")).then(({
            initWidget: e
        }) => e()), _["a"].init()
    },
    "219c": function(e, t, n) {
        "use strict";
        var r = n("ebb5"),
            i = n("da84"),
            o = n("d039"),
            s = n("1c0b"),
            a = n("50c4"),
            c = n("addb"),
            h = n("04d1"),
            u = n("d998"),
            f = n("2d00"),
            d = n("512c"),
            l = r.aTypedArray,
            p = r.exportTypedArrayMethod,
            g = i.Uint16Array,
            _ = g && g.prototype.sort,
            y = !!_ && !o((function() {
                var e = new g(2);
                e.sort(null), e.sort({})
            })),
            m = !!_ && !o((function() {
                if (f) return f < 74;
                if (h) return h < 67;
                if (u) return !0;
                if (d) return d < 602;
                var e, t, n = new g(516),
                    r = Array(516);
                for (e = 0; e < 516; e++) t = e % 4, n[e] = 515 - e, r[e] = e - 2 * t + 3;
                for (n.sort((function(e, t) {
                        return (e / 4 | 0) - (t / 4 | 0)
                    })), e = 0; e < 516; e++)
                    if (n[e] !== r[e]) return !0
            })),
            b = function(e) {
                return function(t, n) {
                    return void 0 !== e ? +e(t, n) || 0 : n !== n ? -1 : t !== t ? 1 : 0 === t && 0 === n ? 1 / t > 0 && 1 / n < 0 ? 1 : -1 : t > n
                }
            };
        p("sort", (function(e) {
            var t = this;
            if (void 0 !== e && s(e), m) return _.call(t, e);
            l(t);
            var n, r = a(t.length),
                i = Array(r);
            for (n = 0; n < r; n++) i[n] = t[n];
            for (i = c(t, b(e)), n = 0; n < r; n++) t[n] = i[n];
            return t
        }), !m || y)
    },
    "22c0": function(e, t, n) {
        const {
            MAX_SAFE_COMPONENT_LENGTH: r
        } = n("fe45"), i = n("0d7c");
        t = e.exports = {};
        const o = t.re = [],
            s = t.src = [],
            a = t.t = {};
        let c = 0;
        const h = (e, t, n) => {
            const r = c++;
            i(r, t), a[e] = r, s[r] = t, o[r] = new RegExp(t, n ? "g" : void 0)
        };
        h("NUMERICIDENTIFIER", "0|[1-9]\\d*"), h("NUMERICIDENTIFIERLOOSE", "[0-9]+"), h("NONNUMERICIDENTIFIER", "\\d*[a-zA-Z-][a-zA-Z0-9-]*"), h("MAINVERSION", `(${s[a.NUMERICIDENTIFIER]})\\.(${s[a.NUMERICIDENTIFIER]})\\.(${s[a.NUMERICIDENTIFIER]})`), h("MAINVERSIONLOOSE", `(${s[a.NUMERICIDENTIFIERLOOSE]})\\.(${s[a.NUMERICIDENTIFIERLOOSE]})\\.(${s[a.NUMERICIDENTIFIERLOOSE]})`), h("PRERELEASEIDENTIFIER", `(?:${s[a.NUMERICIDENTIFIER]}|${s[a.NONNUMERICIDENTIFIER]})`), h("PRERELEASEIDENTIFIERLOOSE", `(?:${s[a.NUMERICIDENTIFIERLOOSE]}|${s[a.NONNUMERICIDENTIFIER]})`), h("PRERELEASE", `(?:-(${s[a.PRERELEASEIDENTIFIER]}(?:\\.${s[a.PRERELEASEIDENTIFIER]})*))`), h("PRERELEASELOOSE", `(?:-?(${s[a.PRERELEASEIDENTIFIERLOOSE]}(?:\\.${s[a.PRERELEASEIDENTIFIERLOOSE]})*))`), h("BUILDIDENTIFIER", "[0-9A-Za-z-]+"), h("BUILD", `(?:\\+(${s[a.BUILDIDENTIFIER]}(?:\\.${s[a.BUILDIDENTIFIER]})*))`), h("FULLPLAIN", `v?${s[a.MAINVERSION]}${s[a.PRERELEASE]}?${s[a.BUILD]}?`), h("FULL", `^${s[a.FULLPLAIN]}$`), h("LOOSEPLAIN", `[v=\\s]*${s[a.MAINVERSIONLOOSE]}${s[a.PRERELEASELOOSE]}?${s[a.BUILD]}?`), h("LOOSE", `^${s[a.LOOSEPLAIN]}$`), h("GTLT", "((?:<|>)?=?)"), h("XRANGEIDENTIFIERLOOSE", s[a.NUMERICIDENTIFIERLOOSE] + "|x|X|\\*"), h("XRANGEIDENTIFIER", s[a.NUMERICIDENTIFIER] + "|x|X|\\*"), h("XRANGEPLAIN", `[v=\\s]*(${s[a.XRANGEIDENTIFIER]})(?:\\.(${s[a.XRANGEIDENTIFIER]})(?:\\.(${s[a.XRANGEIDENTIFIER]})(?:${s[a.PRERELEASE]})?${s[a.BUILD]}?)?)?`), h("XRANGEPLAINLOOSE", `[v=\\s]*(${s[a.XRANGEIDENTIFIERLOOSE]})(?:\\.(${s[a.XRANGEIDENTIFIERLOOSE]})(?:\\.(${s[a.XRANGEIDENTIFIERLOOSE]})(?:${s[a.PRERELEASELOOSE]})?${s[a.BUILD]}?)?)?`), h("XRANGE", `^${s[a.GTLT]}\\s*${s[a.XRANGEPLAIN]}$`), h("XRANGELOOSE", `^${s[a.GTLT]}\\s*${s[a.XRANGEPLAINLOOSE]}$`), h("COERCE", `(^|[^\\d])(\\d{1,${r}})(?:\\.(\\d{1,${r}}))?(?:\\.(\\d{1,${r}}))?(?:$|[^\\d])`), h("COERCERTL", s[a.COERCE], !0), h("LONETILDE", "(?:~>?)"), h("TILDETRIM", `(\\s*)${s[a.LONETILDE]}\\s+`, !0), t.tildeTrimReplace = "$1~", h("TILDE", `^${s[a.LONETILDE]}${s[a.XRANGEPLAIN]}$`), h("TILDELOOSE", `^${s[a.LONETILDE]}${s[a.XRANGEPLAINLOOSE]}$`), h("LONECARET", "(?:\\^)"), h("CARETTRIM", `(\\s*)${s[a.LONECARET]}\\s+`, !0), t.caretTrimReplace = "$1^", h("CARET", `^${s[a.LONECARET]}${s[a.XRANGEPLAIN]}$`), h("CARETLOOSE", `^${s[a.LONECARET]}${s[a.XRANGEPLAINLOOSE]}$`), h("COMPARATORLOOSE", `^${s[a.GTLT]}\\s*(${s[a.LOOSEPLAIN]})$|^$`), h("COMPARATOR", `^${s[a.GTLT]}\\s*(${s[a.FULLPLAIN]})$|^$`), h("COMPARATORTRIM", `(\\s*)${s[a.GTLT]}\\s*(${s[a.LOOSEPLAIN]}|${s[a.XRANGEPLAIN]})`, !0), t.comparatorTrimReplace = "$1$2$3", h("HYPHENRANGE", `^\\s*(${s[a.XRANGEPLAIN]})\\s+-\\s+(${s[a.XRANGEPLAIN]})\\s*$`), h("HYPHENRANGELOOSE", `^\\s*(${s[a.XRANGEPLAINLOOSE]})\\s+-\\s+(${s[a.XRANGEPLAINLOOSE]})\\s*$`), h("STAR", "(<|>)?=?\\s*\\*"), h("GTE0", "^\\s*>=\\s*0.0.0\\s*$"), h("GTE0PRE", "^\\s*>=\\s*0.0.0-0\\s*$")
    },
    2332: function(e, t, n) {
        "use strict";

        function r(e) {
            var t = typeof e;
            return null != e && ("object" == t || "function" == t)
        }
        t["a"] = r
    },
    2366: function(e, t) {
        for (var n = [], r = 0; r < 256; ++r) n[r] = (r + 256).toString(16).substr(1);

        function i(e, t) {
            var r = t || 0,
                i = n;
            return [i[e[r++]], i[e[r++]], i[e[r++]], i[e[r++]], "-", i[e[r++]], i[e[r++]], "-", i[e[r++]], i[e[r++]], "-", i[e[r++]], i[e[r++]], "-", i[e[r++]], i[e[r++]], i[e[r++]], i[e[r++]], i[e[r++]], i[e[r++]]].join("")
        }
        e.exports = i
    },
    "23cb": function(e, t, n) {
        var r = n("a691"),
            i = Math.max,
            o = Math.min;
        e.exports = function(e, t) {
            var n = r(e);
            return n < 0 ? i(n + t, 0) : o(n, t)
        }
    },
    "23e7": function(e, t, n) {
        var r = n("da84"),
            i = n("06cf").f,
            o = n("9112"),
            s = n("6eeb"),
            a = n("ce4e"),
            c = n("e893"),
            h = n("94ca");
        e.exports = function(e, t) {
            var n, u, f, d, l, p, g = e.target,
                _ = e.global,
                y = e.stat;
            if (u = _ ? r : y ? r[g] || a(g, {}) : (r[g] || {}).prototype, u)
                for (f in t) {
                    if (l = t[f], e.noTargetGet ? (p = i(u, f), d = p && p.value) : d = u[f], n = h(_ ? f : g + (y ? "." : "#") + f, e.forced), !n && void 0 !== d) {
                        if (typeof l === typeof d) continue;
                        c(l, d)
                    }(e.sham || d && d.sham) && o(l, "sham", !0), s(u, f, l, e)
                }
        }
    },
    "241c": function(e, t, n) {
        var r = n("ca84"),
            i = n("7839"),
            o = i.concat("length", "prototype");
        t.f = Object.getOwnPropertyNames || function(e) {
            return r(e, o)
        }
    },
    "24f8": function(e, t, n) {
        var r = n("9490"),
            i = n("cffb"),
            o = e.exports;
        for (var s in r) r.hasOwnProperty(s) && (o[s] = r[s]);

        function a(e) {
            if ("string" === typeof e && (e = i.parse(e)), e.protocol || (e.protocol = "https:"), "https:" !== e.protocol) throw new Error('Protocol "' + e.protocol + '" not supported. Expected "https:"');
            return e
        }
        o.request = function(e, t) {
            return e = a(e), r.request.call(this, e, t)
        }, o.get = function(e, t) {
            return e = a(e), r.get.call(this, e, t)
        }
    },
    2527: function(e, t, n) {
        (function(t) { /*! ut_metadata. MIT License. WebTorrent LLC <https://webtorrent.io/opensource> */
            const {
                EventEmitter: r
            } = n("faa1"), i = n("8fe2"), o = n("d329"), s = n("34eb")("ut_metadata"), a = n("2a3b"), c = 1e7, h = 1e3, u = 16384;
            e.exports = e => {
                class n extends r {
                    constructor(n) {
                        super(), this._wire = n, this._fetching = !1, this._metadataComplete = !1, this._metadataSize = null, this._remainingRejects = null, this._bitfield = new o(0, {
                            grow: h
                        }), t.isBuffer(e) && this.setMetadata(e)
                    }
                    onHandshake(e, t, n) {
                        this._infoHash = e
                    }
                    onExtendedHandshake(e) {
                        return e.m && e.m.ut_metadata ? e.metadata_size ? "number" !== typeof e.metadata_size || c < e.metadata_size || e.metadata_size <= 0 ? this.emit("warning", new Error("Peer gave invalid metadata size")) : (this._metadataSize = e.metadata_size, this._numPieces = Math.ceil(this._metadataSize / u), this._remainingRejects = 2 * this._numPieces, void this._requestPieces()) : this.emit("warning", new Error("Peer does not have metadata")) : this.emit("warning", new Error("Peer does not support ut_metadata"))
                    }
                    onMessage(e) {
                        let t, n;
                        try {
                            const r = e.toString(),
                                o = r.indexOf("ee") + 2;
                            t = i.decode(r.substring(0, o)), n = e.slice(o)
                        } catch (r) {
                            return
                        }
                        switch (t.msg_type) {
                            case 0:
                                this._onRequest(t.piece);
                                break;
                            case 1:
                                this._onData(t.piece, n, t.total_size);
                                break;
                            case 2:
                                this._onReject(t.piece);
                                break
                        }
                    }
                    fetch() {
                        this._metadataComplete || (this._fetching = !0, this._metadataSize && this._requestPieces())
                    }
                    cancel() {
                        this._fetching = !1
                    }
                    setMetadata(e) {
                        if (this._metadataComplete) return !0;
                        s("set metadata");
                        try {
                            const t = i.decode(e).info;
                            t && (e = i.encode(t))
                        } catch (t) {}
                        return (!this._infoHash || this._infoHash === a.sync(e)) && (this.cancel(), this.metadata = e, this._metadataComplete = !0, this._metadataSize = this.metadata.length, this._wire.extendedHandshake.metadata_size = this._metadataSize, this.emit("metadata", i.encode({
                            info: i.decode(this.metadata)
                        })), !0)
                    }
                    _send(e, n) {
                        let r = i.encode(e);
                        t.isBuffer(n) && (r = t.concat([r, n])), this._wire.extended("ut_metadata", r)
                    }
                    _request(e) {
                        this._send({
                            msg_type: 0,
                            piece: e
                        })
                    }
                    _data(e, t, n) {
                        const r = {
                            msg_type: 1,
                            piece: e
                        };
                        "number" === typeof n && (r.total_size = n), this._send(r, t)
                    }
                    _reject(e) {
                        this._send({
                            msg_type: 2,
                            piece: e
                        })
                    }
                    _onRequest(e) {
                        if (!this._metadataComplete) return void this._reject(e);
                        const t = e * u;
                        let n = t + u;
                        n > this._metadataSize && (n = this._metadataSize);
                        const r = this.metadata.slice(t, n);
                        this._data(e, r, this._metadataSize)
                    }
                    _onData(e, t, n) {
                        t.length > u || !this._fetching || (t.copy(this.metadata, e * u), this._bitfield.set(e), this._checkDone())
                    }
                    _onReject(e) {
                        this._remainingRejects > 0 && this._fetching ? (this._request(e), this._remainingRejects -= 1) : this.emit("warning", new Error('Peer sent "reject" too much'))
                    }
                    _requestPieces() {
                        if (this._fetching) {
                            this.metadata = t.alloc(this._metadataSize);
                            for (let e = 0; e < this._numPieces; e++) this._request(e)
                        }
                    }
                    _checkDone() {
                        let e = !0;
                        for (let n = 0; n < this._numPieces; n++)
                            if (!this._bitfield.get(n)) {
                                e = !1;
                                break
                            }
                        if (!e) return;
                        const t = this.setMetadata(this.metadata);
                        t || this._failedMetadata()
                    }
                    _failedMetadata() {
                        this._bitfield = new o(0, {
                            grow: h
                        }), this._remainingRejects -= this._numPieces, this._remainingRejects > 0 ? this._requestPieces() : this.emit("warning", new Error("Peer sent invalid metadata"))
                    }
                }
                return n.prototype.name = "ut_metadata", n
            }
        }).call(this, n("b639").Buffer)
    },
    2626: function(e, t, n) {
        "use strict";
        var r = n("d066"),
            i = n("9bf2"),
            o = n("b622"),
            s = n("83ab"),
            a = o("species");
        e.exports = function(e) {
            var t = r(e),
                n = i.f;
            s && t && !t[a] && n(t, a, {
                configurable: !0,
                get: function() {
                    return this
                }
            })
        }
    },
    2677: function(e, t, n) {
        e.exports = i;
        const r = n("8712");

        function i(e, t) {
            if (!(this instanceof i)) return new i(e, t);
            if (t || (t = {}), this.chunkLength = Number(e), !this.chunkLength) throw new Error("First argument must be a chunk length");
            this.chunks = [], this.closed = !1, this.length = Number(t.length) || 1 / 0, this.length !== 1 / 0 && (this.lastChunkLength = this.length % this.chunkLength || this.chunkLength, this.lastChunkIndex = Math.ceil(this.length / this.chunkLength) - 1)
        }
        i.prototype.put = function(e, t, n = (() => {})) {
            if (this.closed) return r(() => n(new Error("Storage is closed")));
            const i = e === this.lastChunkIndex;
            return i && t.length !== this.lastChunkLength ? r(() => n(new Error("Last chunk length must be " + this.lastChunkLength))) : i || t.length === this.chunkLength ? (this.chunks[e] = t, void r(() => n(null))) : r(() => n(new Error("Chunk length must be " + this.chunkLength)))
        }, i.prototype.get = function(e, t, n = (() => {})) {
            if ("function" === typeof t) return this.get(e, null, t);
            if (this.closed) return r(() => n(new Error("Storage is closed")));
            let i = this.chunks[e];
            if (!i) {
                const e = new Error("Chunk not found");
                return e.notFound = !0, r(() => n(e))
            }
            t || (t = {});
            const o = t.offset || 0,
                s = t.length || i.length - o;
            0 === o && s === i.length || (i = i.slice(o, s + o)), r(() => n(null, i))
        }, i.prototype.close = i.prototype.destroy = function(e = (() => {})) {
            if (this.closed) return r(() => e(new Error("Storage is closed")));
            this.closed = !0, this.chunks = null, r(() => e(null))
        }
    },
    "27ab": function(e, t, n) {
        (function(t, r) {
            const i = n("34eb")("bittorrent-tracker:client"),
                o = n("faa1"),
                s = n("566b"),
                a = n("8cc1"),
                c = n("051a"),
                h = n("175e"),
                u = n("1e48"),
                f = n(9),
                d = n(10),
                l = n("1f4f");
            class p extends o {
                constructor(e = {}) {
                    if (super(), !e.peerId) throw new Error("Option `peerId` is required");
                    if (!e.infoHash) throw new Error("Option `infoHash` is required");
                    if (!e.announce) throw new Error("Option `announce` is required");
                    if (!t.browser && !e.port) throw new Error("Option `port` is required");
                    this.peerId = "string" === typeof e.peerId ? e.peerId : e.peerId.toString("hex"), this._peerIdBuffer = r.from(this.peerId, "hex"), this._peerIdBinary = this._peerIdBuffer.toString("binary"), this.infoHash = "string" === typeof e.infoHash ? e.infoHash.toLowerCase() : e.infoHash.toString("hex"), this._infoHashBuffer = r.from(this.infoHash, "hex"), this._infoHashBinary = this._infoHashBuffer.toString("binary"), i("new client %s", this.infoHash), this.destroyed = !1, this._port = e.port, this._getAnnounceOpts = e.getAnnounceOpts, this._rtcConfig = e.rtcConfig, this._userAgent = e.userAgent, this._trickle = void 0 !== e.trickle && e.trickle, this._wrtc = "function" === typeof e.wrtc ? e.wrtc() : e.wrtc;
                    let n = "string" === typeof e.announce ? [e.announce] : null == e.announce ? [] : e.announce;
                    n = n.map(e => (e = e.toString(), "/" === e[e.length - 1] && (e = e.substring(0, e.length - 1)), e)), n = h(n);
                    const o = !1 !== this._wrtc && (!!this._wrtc || c.WEBRTC_SUPPORT),
                        s = e => {
                            t.nextTick(() => {
                                this.emit("warning", e)
                            })
                        };
                    this._trackers = n.map(e => {
                        let t;
                        try {
                            t = new URL(e)
                        } catch (i) {
                            return s(new Error("Invalid tracker URL: " + e)), null
                        }
                        const n = t.port;
                        if (n < 0 || n > 65535) return s(new Error("Invalid tracker port: " + e)), null;
                        const r = t.protocol;
                        return "http:" !== r && "https:" !== r || "function" !== typeof f ? "udp:" === r && "function" === typeof d ? new d(this, e) : "ws:" !== r && "wss:" !== r || !o || "ws:" === r && "undefined" !== typeof window && "https:" === window.location.protocol ? (s(new Error("Unsupported tracker protocol: " + e)), null) : new l(this, e, {
                            trickle: this._trickle
                        }) : new f(this, e)
                    }).filter(Boolean)
                }
                start(e) {
                    e = this._defaultAnnounceOpts(e), e.event = "started", i("send `start` %o", e), this._announce(e), this._trackers.forEach(e => {
                        e.setInterval()
                    })
                }
                stop(e) {
                    e = this._defaultAnnounceOpts(e), e.event = "stopped", i("send `stop` %o", e), this._announce(e)
                }
                complete(e) {
                    e || (e = {}), e = this._defaultAnnounceOpts(e), e.event = "completed", i("send `complete` %o", e), this._announce(e)
                }
                update(e) {
                    e = this._defaultAnnounceOpts(e), e.event && delete e.event, i("send `update` %o", e), this._announce(e)
                }
                _announce(e) {
                    this._trackers.forEach(t => {
                        t.announce(e)
                    })
                }
                scrape(e) {
                    i("send `scrape`"), e || (e = {}), this._trackers.forEach(t => {
                        t.scrape(e)
                    })
                }
                setInterval(e) {
                    i("setInterval %d", e), this._trackers.forEach(t => {
                        t.setInterval(e)
                    })
                }
                destroy(e) {
                    if (this.destroyed) return;
                    this.destroyed = !0, i("destroy");
                    const t = this._trackers.map(e => t => {
                        e.destroy(t)
                    });
                    a(t, e), this._trackers = [], this._getAnnounceOpts = null
                }
                _defaultAnnounceOpts(e = {}) {
                    return null == e.numwant && (e.numwant = u.DEFAULT_ANNOUNCE_PEERS), null == e.uploaded && (e.uploaded = 0), null == e.downloaded && (e.downloaded = 0), this._getAnnounceOpts && (e = Object.assign({}, e, this._getAnnounceOpts())), e
                }
            }
            p.scrape = (e, t) => {
                if (t = s(t), !e.infoHash) throw new Error("Option `infoHash` is required");
                if (!e.announce) throw new Error("Option `announce` is required");
                const n = Object.assign({}, e, {
                        infoHash: Array.isArray(e.infoHash) ? e.infoHash[0] : e.infoHash,
                        peerId: r.from("01234567890123456789"),
                        port: 6881
                    }),
                    i = new p(n);
                i.once("error", t), i.once("warning", t);
                let o = Array.isArray(e.infoHash) ? e.infoHash.length : 1;
                const a = {};
                return i.on("scrape", e => {
                    if (o -= 1, a[e.infoHash] = e, 0 === o) {
                        i.destroy();
                        const e = Object.keys(a);
                        1 === e.length ? t(null, a[e[0]]) : t(null, a)
                    }
                }), e.infoHash = Array.isArray(e.infoHash) ? e.infoHash.map(e => r.from(e, "hex")) : r.from(e.infoHash, "hex"), i.scrape({
                    infoHash: e.infoHash
                }), i
            }, e.exports = p
        }).call(this, n("4362"), n("b639").Buffer)
    },
    "27bf": function(e, t, n) {
        "use strict";
        e.exports = u;
        var r = n("c9b8").codes,
            i = r.ERR_METHOD_NOT_IMPLEMENTED,
            o = r.ERR_MULTIPLE_CALLBACK,
            s = r.ERR_TRANSFORM_ALREADY_TRANSFORMING,
            a = r.ERR_TRANSFORM_WITH_LENGTH_0,
            c = n("b19a");

        function h(e, t) {
            var n = this._transformState;
            n.transforming = !1;
            var r = n.writecb;
            if (null === r) return this.emit("error", new o);
            n.writechunk = null, n.writecb = null, null != t && this.push(t), r(e);
            var i = this._readableState;
            i.reading = !1, (i.needReadable || i.length < i.highWaterMark) && this._read(i.highWaterMark)
        }

        function u(e) {
            if (!(this instanceof u)) return new u(e);
            c.call(this, e), this._transformState = {
                afterTransform: h.bind(this),
                needTransform: !1,
                transforming: !1,
                writecb: null,
                writechunk: null,
                writeencoding: null
            }, this._readableState.needReadable = !0, this._readableState.sync = !1, e && ("function" === typeof e.transform && (this._transform = e.transform), "function" === typeof e.flush && (this._flush = e.flush)), this.on("prefinish", f)
        }

        function f() {
            var e = this;
            "function" !== typeof this._flush || this._readableState.destroyed ? d(this, null, null) : this._flush((function(t, n) {
                d(e, t, n)
            }))
        }

        function d(e, t, n) {
            if (t) return e.emit("error", t);
            if (null != n && e.push(n), e._writableState.length) throw new a;
            if (e._transformState.transforming) throw new s;
            return e.push(null)
        }
        n("3fb5")(u, c), u.prototype.push = function(e, t) {
            return this._transformState.needTransform = !1, c.prototype.push.call(this, e, t)
        }, u.prototype._transform = function(e, t, n) {
            n(new i("_transform()"))
        }, u.prototype._write = function(e, t, n) {
            var r = this._transformState;
            if (r.writecb = n, r.writechunk = e, r.writeencoding = t, !r.transforming) {
                var i = this._readableState;
                (r.needTransform || i.needReadable || i.length < i.highWaterMark) && this._read(i.highWaterMark)
            }
        }, u.prototype._read = function(e) {
            var t = this._transformState;
            null === t.writechunk || t.transforming ? t.needTransform = !0 : (t.transforming = !0, this._transform(t.writechunk, t.writeencoding, t.afterTransform))
        }, u.prototype._destroy = function(e, t) {
            c.prototype._destroy.call(this, e, (function(e) {
                t(e)
            }))
        }
    },
    2874: function(e, t) {
        const n = /^[0-9]+$/,
            r = (e, t) => {
                const r = n.test(e),
                    i = n.test(t);
                return r && i && (e = +e, t = +t), e === t ? 0 : r && !i ? -1 : i && !r ? 1 : e < t ? -1 : 1
            },
            i = (e, t) => r(t, e);
        e.exports = {
            compareIdentifiers: r,
            rcompareIdentifiers: i
        }
    },
    "2a3b": function(e, t, n) {
        const r = n("738f"),
            i = n("576e"),
            o = new r,
            s = "undefined" !== typeof window ? window : self,
            a = s.crypto || s.msCrypto || {};
        let c = a.subtle || a.webkitSubtle;

        function h(e) {
            return o.digest(e)
        }
        try {
            c.digest({
                name: "sha-1"
            }, new Uint8Array).catch((function() {
                c = !1
            }))
        } catch (l) {
            c = !1
        }

        function u(e, t) {
            c ? ("string" === typeof e && (e = f(e)), c.digest({
                name: "sha-1"
            }, e).then((function(e) {
                t(d(new Uint8Array(e)))
            }), (function() {
                t(h(e))
            }))) : "undefined" !== typeof window ? i(e, (function(n, r) {
                t(n ? h(e) : r)
            })) : queueMicrotask(() => t(h(e)))
        }

        function f(e) {
            const t = e.length,
                n = new Uint8Array(t);
            for (let r = 0; r < t; r++) n[r] = e.charCodeAt(r);
            return n
        }

        function d(e) {
            const t = e.length,
                n = [];
            for (let r = 0; r < t; r++) {
                const t = e[r];
                n.push((t >>> 4).toString(16)), n.push((15 & t).toString(16))
            }
            return n.join("")
        }
        e.exports = u, e.exports.sync = h
    },
    "2d00": function(e, t, n) {
        var r, i, o = n("da84"),
            s = n("342f"),
            a = o.process,
            c = o.Deno,
            h = a && a.versions || c && c.version,
            u = h && h.v8;
        u ? (r = u.split("."), i = r[0] < 4 ? 1 : r[0] + r[1]) : s && (r = s.match(/Edge\/(\d+)/), (!r || r[1] >= 74) && (r = s.match(/Chrome\/(\d+)/), r && (i = r[1]))), e.exports = i && +i
    },
    3: function(e, t) {},
    "326b": function(e, t) {
        const n = /^\[?([^\]]+)]?:(\d+)$/;
        let r = new Map;
        e.exports = function(e) {
            if (1e5 === r.size && r.clear(), !r.has(e)) {
                const t = n.exec(e);
                if (!t) throw new Error("invalid addr: " + e);
                r.set(e, [t[1], Number(t[2])])
            }
            return r.get(e)
        }
    },
    "342f": function(e, t, n) {
        var r = n("d066");
        e.exports = r("navigator", "userAgent") || ""
    },
    "34eb": function(e, t, n) {
        (function(r) {
            function i() {
                return !("undefined" === typeof window || !window.process || "renderer" !== window.process.type && !window.process.__nwjs) || ("undefined" === typeof navigator || !navigator.userAgent || !navigator.userAgent.toLowerCase().match(/(edge|trident)\/(\d+)/)) && ("undefined" !== typeof document && document.documentElement && document.documentElement.style && document.documentElement.style.WebkitAppearance || "undefined" !== typeof window && window.console && (window.console.firebug || window.console.exception && window.console.table) || "undefined" !== typeof navigator && navigator.userAgent && navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/) && parseInt(RegExp.$1, 10) >= 31 || "undefined" !== typeof navigator && navigator.userAgent && navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/))
            }

            function o(t) {
                if (t[0] = (this.useColors ? "%c" : "") + this.namespace + (this.useColors ? " %c" : " ") + t[0] + (this.useColors ? "%c " : " ") + "+" + e.exports.humanize(this.diff), !this.useColors) return;
                const n = "color: " + this.color;
                t.splice(1, 0, n, "color: inherit");
                let r = 0,
                    i = 0;
                t[0].replace(/%[a-zA-Z%]/g, e => {
                    "%%" !== e && (r++, "%c" === e && (i = r))
                }), t.splice(i, 0, n)
            }

            function s(e) {
                try {
                    e ? t.storage.setItem("debug", e) : t.storage.removeItem("debug")
                } catch (n) {}
            }

            function a() {
                let e;
                try {
                    e = t.storage.getItem("debug")
                } catch (n) {}
                return !e && "undefined" !== typeof r && "env" in r && (e = "false"), e
            }

            function c() {
                try {
                    return localStorage
                } catch (e) {}
            }
            t.formatArgs = o, t.save = s, t.load = a, t.useColors = i, t.storage = c(), t.destroy = (() => {
                let e = !1;
                return () => {
                    e || (e = !0, console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`."))
                }
            })(), t.colors = ["#0000CC", "#0000FF", "#0033CC", "#0033FF", "#0066CC", "#0066FF", "#0099CC", "#0099FF", "#00CC00", "#00CC33", "#00CC66", "#00CC99", "#00CCCC", "#00CCFF", "#3300CC", "#3300FF", "#3333CC", "#3333FF", "#3366CC", "#3366FF", "#3399CC", "#3399FF", "#33CC00", "#33CC33", "#33CC66", "#33CC99", "#33CCCC", "#33CCFF", "#6600CC", "#6600FF", "#6633CC", "#6633FF", "#66CC00", "#66CC33", "#9900CC", "#9900FF", "#9933CC", "#9933FF", "#99CC00", "#99CC33", "#CC0000", "#CC0033", "#CC0066", "#CC0099", "#CC00CC", "#CC00FF", "#CC3300", "#CC3333", "#CC3366", "#CC3399", "#CC33CC", "#CC33FF", "#CC6600", "#CC6633", "#CC9900", "#CC9933", "#CCCC00", "#CCCC33", "#FF0000", "#FF0033", "#FF0066", "#FF0099", "#FF00CC", "#FF00FF", "#FF3300", "#FF3333", "#FF3366", "#FF3399", "#FF33CC", "#FF33FF", "#FF6600", "#FF6633", "#FF9900", "#FF9933", "#FFCC00", "#FFCC33"], t.log = console.debug || console.log || (() => {}), e.exports = n("dc90")(t);
            const {
                formatters: h
            } = e.exports;
            h.j = function(e) {
                try {
                    return JSON.stringify(e)
                } catch (t) {
                    return "[UnexpectedJSONParseError]: " + t.message
                }
            }
        }).call(this, n("4362"))
    },
    "35a1": function(e, t, n) {
        var r = n("f5df"),
            i = n("3f8c"),
            o = n("b622"),
            s = o("iterator");
        e.exports = function(e) {
            if (void 0 != e) return e[s] || e["@@iterator"] || i[r(e)]
        }
    },
    "37e8": function(e, t, n) {
        var r = n("83ab"),
            i = n("9bf2"),
            o = n("825a"),
            s = n("df75");
        e.exports = r ? Object.defineProperties : function(e, t) {
            o(e);
            var n, r = s(t),
                a = r.length,
                c = 0;
            while (a > c) i.f(e, n = r[c++], t[n]);
            return e
        }
    },
    "3bb3": function(e, t) {
        function n(e) {
            return e.reduce((e, t, n, r) => (0 !== n && t === r[n - 1] + 1 || e.push([]), e[e.length - 1].push(t), e), []).map(e => e.length > 1 ? `${e[0]}-${e[e.length-1]}` : "" + e[0])
        }

        function r(e) {
            const t = (e, t = e) => Array.from({
                length: t - e + 1
            }, (t, n) => n + e);
            return e.reduce((e, n, r, i) => {
                const o = n.split("-").map(e => parseInt(e));
                return e.concat(t(...o))
            }, [])
        }
        e.exports = r, e.exports.parse = r, e.exports.compose = n
    },
    "3bbe": function(e, t, n) {
        var r = n("861d");
        e.exports = function(e) {
            if (!r(e) && null !== e) throw TypeError("Can't set " + String(e) + " as a prototype");
            return e
        }
    },
    "3d15": function(e, t, n) {
        "use strict";
        n.d(t, "a", (function() {
            return f
        })), n.d(t, "b", (function() {
            return v
        })), n.d(t, "c", (function() {
            return w
        })), n.d(t, "d", (function() {
            return u
        })), n.d(t, "e", (function() {
            return p
        }));
        const r = Symbol("Comlink.proxy"),
            i = Symbol("Comlink.endpoint"),
            o = Symbol("Comlink.releaseProxy"),
            s = Symbol("Comlink.thrown"),
            a = e => "object" === typeof e && null !== e || "function" === typeof e,
            c = {
                canHandle: e => a(e) && e[r],
                serialize(e) {
                    const {
                        port1: t,
                        port2: n
                    } = new MessageChannel;
                    return f(e, t), [n, [n]]
                },
                deserialize(e) {
                    return e.start(), p(e)
                }
            },
            h = {
                canHandle: e => a(e) && s in e,
                serialize({
                    value: e
                }) {
                    let t;
                    return t = e instanceof Error ? {
                        isError: !0,
                        value: {
                            message: e.message,
                            name: e.name,
                            stack: e.stack
                        }
                    } : {
                        isError: !1,
                        value: e
                    }, [t, []]
                },
                deserialize(e) {
                    if (e.isError) throw Object.assign(new Error(e.value.message), e.value);
                    throw e.value
                }
            },
            u = new Map([
                ["proxy", c],
                ["throw", h]
            ]);

        function f(e, t = self) {
            t.addEventListener("message", (function n(r) {
                if (!r || !r.data) return;
                const {
                    id: i,
                    type: o,
                    path: a
                } = Object.assign({
                    path: []
                }, r.data), c = (r.data.argumentList || []).map(T);
                let h;
                try {
                    const t = a.slice(0, -1).reduce((e, t) => e[t], e),
                        n = a.reduce((e, t) => e[t], e);
                    switch (o) {
                        case "GET":
                            h = n;
                            break;
                        case "SET":
                            t[a.slice(-1)[0]] = T(r.data.value), h = !0;
                            break;
                        case "APPLY":
                            h = n.apply(t, c);
                            break;
                        case "CONSTRUCT":
                            {
                                const e = new n(...c);h = v(e)
                            }
                            break;
                        case "ENDPOINT":
                            {
                                const {
                                    port1: t,
                                    port2: n
                                } = new MessageChannel;f(e, n),
                                h = w(t, [t])
                            }
                            break;
                        case "RELEASE":
                            h = void 0;
                            break;
                        default:
                            return
                    }
                } catch (u) {
                    h = {
                        value: u,
                        [s]: 0
                    }
                }
                Promise.resolve(h).catch(e => ({
                    value: e,
                    [s]: 0
                })).then(e => {
                    const [r, s] = E(e);
                    t.postMessage(Object.assign(Object.assign({}, r), {
                        id: i
                    }), s), "RELEASE" === o && (t.removeEventListener("message", n), l(t))
                })
            })), t.start && t.start()
        }

        function d(e) {
            return "MessagePort" === e.constructor.name
        }

        function l(e) {
            d(e) && e.close()
        }

        function p(e, t) {
            return _(e, [], t)
        }

        function g(e) {
            if (e) throw new Error("Proxy has been released and is not useable")
        }

        function _(e, t = [], n = function() {}) {
            let r = !1;
            const s = new Proxy(n, {
                get(n, i) {
                    if (g(r), i === o) return () => R(e, {
                        type: "RELEASE",
                        path: t.map(e => e.toString())
                    }).then(() => {
                        l(e), r = !0
                    });
                    if ("then" === i) {
                        if (0 === t.length) return {
                            then: () => s
                        };
                        const n = R(e, {
                            type: "GET",
                            path: t.map(e => e.toString())
                        }).then(T);
                        return n.then.bind(n)
                    }
                    return _(e, [...t, i])
                },
                set(n, i, o) {
                    g(r);
                    const [s, a] = E(o);
                    return R(e, {
                        type: "SET",
                        path: [...t, i].map(e => e.toString()),
                        value: s
                    }, a).then(T)
                },
                apply(n, o, s) {
                    g(r);
                    const a = t[t.length - 1];
                    if (a === i) return R(e, {
                        type: "ENDPOINT"
                    }).then(T);
                    if ("bind" === a) return _(e, t.slice(0, -1));
                    const [c, h] = m(s);
                    return R(e, {
                        type: "APPLY",
                        path: t.map(e => e.toString()),
                        argumentList: c
                    }, h).then(T)
                },
                construct(n, i) {
                    g(r);
                    const [o, s] = m(i);
                    return R(e, {
                        type: "CONSTRUCT",
                        path: t.map(e => e.toString()),
                        argumentList: o
                    }, s).then(T)
                }
            });
            return s
        }

        function y(e) {
            return Array.prototype.concat.apply([], e)
        }

        function m(e) {
            const t = e.map(E);
            return [t.map(e => e[0]), y(t.map(e => e[1]))]
        }
        const b = new WeakMap;

        function w(e, t) {
            return b.set(e, t), e
        }

        function v(e) {
            return Object.assign(e, {
                [r]: !0
            })
        }

        function E(e) {
            for (const [t, n] of u)
                if (n.canHandle(e)) {
                    const [r, i] = n.serialize(e);
                    return [{
                        type: "HANDLER",
                        name: t,
                        value: r
                    }, i]
                }
            return [{
                type: "RAW",
                value: e
            }, b.get(e) || []]
        }

        function T(e) {
            switch (e.type) {
                case "HANDLER":
                    return u.get(e.name).deserialize(e.value);
                case "RAW":
                    return e.value
            }
        }

        function R(e, t, n) {
            return new Promise(r => {
                const i = S();
                e.addEventListener("message", (function t(n) {
                    n.data && n.data.id && n.data.id === i && (e.removeEventListener("message", t), r(n.data))
                })), e.start && e.start(), e.postMessage(Object.assign({
                    id: i
                }, t), n)
            })
        }

        function S() {
            return new Array(4).fill(0).map(() => Math.floor(Math.random() * Number.MAX_SAFE_INTEGER).toString(16)).join("-")
        }
    },
    "3e8f": function(e, t) {},
    "3f8c": function(e, t) {
        e.exports = {}
    },
    "3fb5": function(e, t) {
        "function" === typeof Object.create ? e.exports = function(e, t) {
            t && (e.super_ = t, e.prototype = Object.create(t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }))
        } : e.exports = function(e, t) {
            if (t) {
                e.super_ = t;
                var n = function() {};
                n.prototype = t.prototype, e.prototype = new n, e.prototype.constructor = e
            }
        }
    },
    4: function(e, t) {},
    "429b": function(e, t, n) {
        e.exports = n("faa1").EventEmitter
    },
    "42a7": function(e, t, n) {
        "use strict";
        var r = n("8707").Buffer;

        function i(e) {
            if (e.length >= 255) throw new TypeError("Alphabet too long");
            for (var t = new Uint8Array(256), n = 0; n < t.length; n++) t[n] = 255;
            for (var i = 0; i < e.length; i++) {
                var o = e.charAt(i),
                    s = o.charCodeAt(0);
                if (255 !== t[s]) throw new TypeError(o + " is ambiguous");
                t[s] = i
            }
            var a = e.length,
                c = e.charAt(0),
                h = Math.log(a) / Math.log(256),
                u = Math.log(256) / Math.log(a);

            function f(t) {
                if ((Array.isArray(t) || t instanceof Uint8Array) && (t = r.from(t)), !r.isBuffer(t)) throw new TypeError("Expected Buffer");
                if (0 === t.length) return "";
                var n = 0,
                    i = 0,
                    o = 0,
                    s = t.length;
                while (o !== s && 0 === t[o]) o++, n++;
                var h = (s - o) * u + 1 >>> 0,
                    f = new Uint8Array(h);
                while (o !== s) {
                    for (var d = t[o], l = 0, p = h - 1;
                        (0 !== d || l < i) && -1 !== p; p--, l++) d += 256 * f[p] >>> 0, f[p] = d % a >>> 0, d = d / a >>> 0;
                    if (0 !== d) throw new Error("Non-zero carry");
                    i = l, o++
                }
                var g = h - i;
                while (g !== h && 0 === f[g]) g++;
                for (var _ = c.repeat(n); g < h; ++g) _ += e.charAt(f[g]);
                return _
            }

            function d(e) {
                if ("string" !== typeof e) throw new TypeError("Expected String");
                if (0 === e.length) return r.alloc(0);
                var n = 0;
                if (" " !== e[n]) {
                    var i = 0,
                        o = 0;
                    while (e[n] === c) i++, n++;
                    var s = (e.length - n) * h + 1 >>> 0,
                        u = new Uint8Array(s);
                    while (e[n]) {
                        var f = t[e.charCodeAt(n)];
                        if (255 === f) return;
                        for (var d = 0, l = s - 1;
                            (0 !== f || d < o) && -1 !== l; l--, d++) f += a * u[l] >>> 0, u[l] = f % 256 >>> 0, f = f / 256 >>> 0;
                        if (0 !== f) throw new Error("Non-zero carry");
                        o = d, n++
                    }
                    if (" " !== e[n]) {
                        var p = s - o;
                        while (p !== s && 0 === u[p]) p++;
                        var g = r.allocUnsafe(i + (s - p));
                        g.fill(0, 0, i);
                        var _ = i;
                        while (p !== s) g[_++] = u[p++];
                        return g
                    }
                }
            }

            function l(e) {
                var t = d(e);
                if (t) return t;
                throw new Error("Non-base" + a + " character")
            }
            return {
                encode: f,
                decodeUnsafe: d,
                decode: l
            }
        }
        e.exports = i
    },
    4362: function(e, t, n) {
        t.nextTick = function(e) {
                var t = Array.prototype.slice.call(arguments);
                t.shift(), setTimeout((function() {
                    e.apply(null, t)
                }), 0)
            }, t.platform = t.arch = t.execPath = t.title = "browser", t.pid = 1, t.browser = !0, t.env = {}, t.argv = [], t.binding = function(e) {
                throw new Error("No such module. (Possibly not yet loaded)")
            },
            function() {
                var e, r = "/";
                t.cwd = function() {
                    return r
                }, t.chdir = function(t) {
                    e || (e = n("df7c")), r = e.resolve(t, r)
                }
            }(), t.exit = t.kill = t.umask = t.dlopen = t.uptime = t.memoryUsage = t.uvCounters = function() {}, t.features = {}
    },
    "44ad": function(e, t, n) {
        var r = n("d039"),
            i = n("c6b6"),
            o = "".split;
        e.exports = r((function() {
            return !Object("z").propertyIsEnumerable(0)
        })) ? function(e) {
            return "String" == i(e) ? o.call(e, "") : Object(e)
        } : Object
    },
    4681: function(e, t, n) {
        "use strict";
        (function(t) {
            function n(e, n) {
                var o = this,
                    a = this._readableState && this._readableState.destroyed,
                    c = this._writableState && this._writableState.destroyed;
                return a || c ? (n ? n(e) : e && (this._writableState ? this._writableState.errorEmitted || (this._writableState.errorEmitted = !0, t.nextTick(s, this, e)) : t.nextTick(s, this, e)), this) : (this._readableState && (this._readableState.destroyed = !0), this._writableState && (this._writableState.destroyed = !0), this._destroy(e || null, (function(e) {
                    !n && e ? o._writableState ? o._writableState.errorEmitted ? t.nextTick(i, o) : (o._writableState.errorEmitted = !0, t.nextTick(r, o, e)) : t.nextTick(r, o, e) : n ? (t.nextTick(i, o), n(e)) : t.nextTick(i, o)
                })), this)
            }

            function r(e, t) {
                s(e, t), i(e)
            }

            function i(e) {
                e._writableState && !e._writableState.emitClose || e._readableState && !e._readableState.emitClose || e.emit("close")
            }

            function o() {
                this._readableState && (this._readableState.destroyed = !1, this._readableState.reading = !1, this._readableState.ended = !1, this._readableState.endEmitted = !1), this._writableState && (this._writableState.destroyed = !1, this._writableState.ended = !1, this._writableState.ending = !1, this._writableState.finalCalled = !1, this._writableState.prefinished = !1, this._writableState.finished = !1, this._writableState.errorEmitted = !1)
            }

            function s(e, t) {
                e.emit("error", t)
            }

            function a(e, t) {
                var n = e._readableState,
                    r = e._writableState;
                n && n.autoDestroy || r && r.autoDestroy ? e.destroy(t) : e.emit("error", t)
            }
            e.exports = {
                destroy: n,
                undestroy: o,
                errorOrDestroy: a
            }
        }).call(this, n("4362"))
    },
    "485a": function(e, t, n) {
        var r = n("861d");
        e.exports = function(e, t) {
            var n, i;
            if ("string" === t && "function" == typeof(n = e.toString) && !r(i = n.call(e))) return i;
            if ("function" == typeof(n = e.valueOf) && !r(i = n.call(e))) return i;
            if ("string" !== t && "function" == typeof(n = e.toString) && !r(i = n.call(e))) return i;
            throw TypeError("Can't convert object to primitive value")
        }
    },
    4930: function(e, t, n) {
        var r = n("2d00"),
            i = n("d039");
        e.exports = !!Object.getOwnPropertySymbols && !i((function() {
            var e = Symbol();
            return !String(e) || !(Object(e) instanceof Symbol) || !Symbol.sham && r && r < 41
        }))
    },
    4947: function(e, t, n) {
        (function(t) { /*! blob-to-buffer. MIT License. Feross Aboukhadijeh <https://feross.org/opensource> */
            e.exports = function(e, n) {
                if ("undefined" === typeof Blob || !(e instanceof Blob)) throw new Error("first argument must be a Blob");
                if ("function" !== typeof n) throw new Error("second argument must be a function");
                const r = new FileReader;

                function i(e) {
                    r.removeEventListener("loadend", i, !1), e.error ? n(e.error) : n(null, t.from(r.result))
                }
                r.addEventListener("loadend", i, !1), r.readAsArrayBuffer(e)
            }
        }).call(this, n("b639").Buffer)
    },
    "4cdf": function(e, t, n) {
        (function(t) {
            const {
                getType: r
            } = n("7871");

            function i(e, n, r) {
                const o = [];
                let s = null;
                return i._encode(o, e), s = t.concat(o), i.bytes = s.length, t.isBuffer(n) ? (s.copy(n, r), n) : s
            }
            i.bytes = -1, i._floatConversionDetected = !1, i._encode = function(e, n) {
                if (null != n) switch (r(n)) {
                    case "buffer":
                        i.buffer(e, n);
                        break;
                    case "object":
                        i.dict(e, n);
                        break;
                    case "map":
                        i.dictMap(e, n);
                        break;
                    case "array":
                        i.list(e, n);
                        break;
                    case "set":
                        i.listSet(e, n);
                        break;
                    case "string":
                        i.string(e, n);
                        break;
                    case "number":
                        i.number(e, n);
                        break;
                    case "boolean":
                        i.number(e, n);
                        break;
                    case "arraybufferview":
                        i.buffer(e, t.from(n.buffer, n.byteOffset, n.byteLength));
                        break;
                    case "arraybuffer":
                        i.buffer(e, t.from(n));
                        break
                }
            };
            const o = t.from("e"),
                s = t.from("d"),
                a = t.from("l");
            i.buffer = function(e, n) {
                e.push(t.from(n.length + ":"), n)
            }, i.string = function(e, n) {
                e.push(t.from(t.byteLength(n) + ":" + n))
            }, i.number = function(e, n) {
                const r = 2147483648,
                    o = n / r << 0,
                    s = n % r << 0,
                    a = o * r + s;
                e.push(t.from("i" + a + "e")), a === n || i._floatConversionDetected || (i._floatConversionDetected = !0, console.warn('WARNING: Possible data corruption detected with value "' + n + '":', 'Bencoding only defines support for integers, value was converted to "' + a + '"'), console.trace())
            }, i.dict = function(e, t) {
                e.push(s);
                let n, r = 0;
                const a = Object.keys(t).sort(),
                    c = a.length;
                for (; r < c; r++) n = a[r], null != t[n] && (i.string(e, n), i._encode(e, t[n]));
                e.push(o)
            }, i.dictMap = function(e, n) {
                e.push(s);
                const r = Array.from(n.keys()).sort();
                for (const o of r) null != n.get(o) && (t.isBuffer(o) ? i._encode(e, o) : i.string(e, String(o)), i._encode(e, n.get(o)));
                e.push(o)
            }, i.list = function(e, t) {
                let n = 0;
                const r = t.length;
                for (e.push(a); n < r; n++) null != t[n] && i._encode(e, t[n]);
                e.push(o)
            }, i.listSet = function(e, t) {
                e.push(a);
                for (const n of t) null != n && i._encode(e, n);
                e.push(o)
            }, e.exports = i
        }).call(this, n("b639").Buffer)
    },
    "4d64": function(e, t, n) {
        var r = n("fc6a"),
            i = n("50c4"),
            o = n("23cb"),
            s = function(e) {
                return function(t, n, s) {
                    var a, c = r(t),
                        h = i(c.length),
                        u = o(s, h);
                    if (e && n != n) {
                        while (h > u)
                            if (a = c[u++], a != a) return !0
                    } else
                        for (; h > u; u++)
                            if ((e || u in c) && c[u] === n) return e || u || 0;
                    return !e && -1
                }
            };
        e.exports = {
            includes: s(!0),
            indexOf: s(!1)
        }
    },
    "4fdc": function(e, t) {
        function n(e) {
            if (/^-?\d+$/.test(e)) return parseInt(e, 10);
            var t;
            if (t = e.match(/^(-?\d+)(-|\.\.\.?|\u2025|\u2026|\u22EF)(-?\d+)$/)) {
                var n = t[1],
                    r = t[2],
                    i = t[3];
                if (n && i) {
                    n = parseInt(n), i = parseInt(i);
                    var o = [],
                        s = n < i ? 1 : -1;
                    "-" != r && ".." != r && "‥" != r || (i += s);
                    for (var a = n; a != i; a += s) o.push(a);
                    return o
                }
            }
            return []
        }
        e.exports.parse = function(e) {
            var t = e.split(","),
                r = t.map((function(e) {
                    return n(e)
                }));
            return 0 === r.length ? [] : 1 === r.length ? Array.isArray(r[0]) ? r[0] : r : r.reduce((function(e, t) {
                return Array.isArray(e) || (e = [e]), Array.isArray(t) || (t = [t]), e.concat(t)
            }))
        }
    },
    5: function(e, t) {},
    "50b2": function(e, t, n) {
        const r = n("d05a"),
            i = n("34eb")("webtorrent:peer"),
            o = n("0809"),
            s = n("9c5d"),
            a = 5e3,
            c = 25e3,
            h = 25e3;
        t.createWebRTCPeer = (e, t) => {
            const n = new u(e.id, "webrtc");
            return n.conn = e, n.swarm = t, n.conn.connected ? n.onConnect() : (n.conn.once("connect", () => {
                n.onConnect()
            }), n.conn.once("error", e => {
                n.destroy(e)
            }), n.startConnectTimeout()), n
        }, t.createTCPIncomingPeer = e => {
            const t = `${e.remoteAddress}:${e.remotePort}`,
                n = new u(t, "tcpIncoming");
            return n.conn = e, n.addr = t, n.onConnect(), n
        }, t.createTCPOutgoingPeer = (e, t) => {
            const n = new u(e, "tcpOutgoing");
            return n.addr = e, n.swarm = t, n
        }, t.createWebSeedPeer = (e, t) => {
            const n = new u(e, "webSeed");
            return n.swarm = t, n.conn = new s(e, t), n.onConnect(), n
        };
        class u {
            constructor(e, t) {
                this.id = e, this.type = t, i("new %s Peer %s", t, e), this.addr = null, this.conn = null, this.swarm = null, this.wire = null, this.connected = !1, this.destroyed = !1, this.timeout = null, this.retries = 0, this.sentHandshake = !1
            }
            onConnect() {
                if (this.destroyed) return;
                this.connected = !0, i("Peer %s connected", this.id), clearTimeout(this.connectTimeout);
                const e = this.conn;
                e.once("end", () => {
                    this.destroy()
                }), e.once("close", () => {
                    this.destroy()
                }), e.once("finish", () => {
                    this.destroy()
                }), e.once("error", e => {
                    this.destroy(e)
                });
                const t = this.wire = new o;
                t.type = this.type, t.once("end", () => {
                    this.destroy()
                }), t.once("close", () => {
                    this.destroy()
                }), t.once("finish", () => {
                    this.destroy()
                }), t.once("error", e => {
                    this.destroy(e)
                }), t.once("handshake", (e, t) => {
                    this.onHandshake(e, t)
                }), this.startHandshakeTimeout(), e.pipe(t).pipe(e), this.swarm && !this.sentHandshake && this.handshake()
            }
            onHandshake(e, t) {
                if (!this.swarm) return;
                if (this.destroyed) return;
                if (this.swarm.destroyed) return this.destroy(new Error("swarm already destroyed"));
                if (e !== this.swarm.infoHash) return this.destroy(new Error("unexpected handshake info hash for this swarm"));
                if (t === this.swarm.peerId) return this.destroy(new Error("refusing to connect to ourselves"));
                i("Peer %s got handshake %s", this.id, e), clearTimeout(this.handshakeTimeout), this.retries = 0;
                let n = this.addr;
                !n && this.conn.remoteAddress && this.conn.remotePort && (n = `${this.conn.remoteAddress}:${this.conn.remotePort}`), this.swarm._onWire(this.wire, n), this.swarm && !this.swarm.destroyed && (this.sentHandshake || this.handshake())
            }
            handshake() {
                const e = {
                    dht: !this.swarm.private && !!this.swarm.client.dht
                };
                this.wire.handshake(this.swarm.infoHash, this.swarm.client.peerId, e), this.sentHandshake = !0
            }
            startConnectTimeout() {
                clearTimeout(this.connectTimeout), this.connectTimeout = setTimeout(() => {
                    this.destroy(new Error("connect timeout"))
                }, "webrtc" === this.type ? c : a), this.connectTimeout.unref && this.connectTimeout.unref()
            }
            startHandshakeTimeout() {
                clearTimeout(this.handshakeTimeout), this.handshakeTimeout = setTimeout(() => {
                    this.destroy(new Error("handshake timeout"))
                }, h), this.handshakeTimeout.unref && this.handshakeTimeout.unref()
            }
            destroy(e) {
                if (this.destroyed) return;
                this.destroyed = !0, this.connected = !1, i("destroy %s (error: %s)", this.id, e && (e.message || e)), clearTimeout(this.connectTimeout), clearTimeout(this.handshakeTimeout);
                const t = this.swarm,
                    n = this.conn,
                    o = this.wire;
                this.swarm = null, this.conn = null, this.wire = null, t && o && r(t.wires, t.wires.indexOf(o)), n && (n.on("error", () => {}), n.destroy()), o && o.destroy(), t && t.removePeer(this.id)
            }
        }
    },
    "50c4": function(e, t, n) {
        var r = n("a691"),
            i = Math.min;
        e.exports = function(e) {
            return e > 0 ? i(r(e), 9007199254740991) : 0
        }
    },
    "50cf": function(e, t, n) {
        (function(t) { /*! torrent-piece. MIT License. WebTorrent LLC <https://webtorrent.io/opensource> */
            const n = 16384;
            class r {
                constructor(e) {
                    this.length = e, this.missing = e, this.sources = null, this._chunks = Math.ceil(e / n), this._remainder = e % n || n, this._buffered = 0, this._buffer = null, this._cancellations = null, this._reservations = 0, this._flushed = !1
                }
                chunkLength(e) {
                    return e === this._chunks - 1 ? this._remainder : n
                }
                chunkLengthRemaining(e) {
                    return this.length - e * n
                }
                chunkOffset(e) {
                    return e * n
                }
                reserve() {
                    return this.init() ? this._cancellations.length ? this._cancellations.pop() : this._reservations < this._chunks ? this._reservations++ : -1 : -1
                }
                reserveRemaining() {
                    if (!this.init()) return -1;
                    if (this._cancellations.length || this._reservations < this._chunks) {
                        let e = this._reservations;
                        while (this._cancellations.length) e = Math.min(e, this._cancellations.pop());
                        return this._reservations = this._chunks, e
                    }
                    return -1
                }
                cancel(e) {
                    this.init() && this._cancellations.push(e)
                }
                cancelRemaining(e) {
                    this.init() && (this._reservations = e)
                }
                get(e) {
                    return this.init() ? this._buffer[e] : null
                }
                set(e, t, r) {
                    if (!this.init()) return !1;
                    const i = t.length,
                        o = Math.ceil(i / n);
                    for (let s = 0; s < o; s++)
                        if (!this._buffer[e + s]) {
                            const i = s * n,
                                o = t.slice(i, i + n);
                            this._buffered++, this._buffer[e + s] = o, this.missing -= o.length, this.sources.includes(r) || this.sources.push(r)
                        }
                    return this._buffered === this._chunks
                }
                flush() {
                    if (!this._buffer || this._chunks !== this._buffered) return null;
                    const e = t.concat(this._buffer, this.length);
                    return this._buffer = null, this._cancellations = null, this.sources = null, this._flushed = !0, e
                }
                init() {
                    return !this._flushed && (this._buffer || (this._buffer = new Array(this._chunks), this._cancellations = [], this.sources = []), !0)
                }
            }
            Object.defineProperty(r, "BLOCK_LENGTH", {
                value: n
            }), e.exports = r
        }).call(this, n("b639").Buffer)
    },
    "512c": function(e, t, n) {
        var r = n("342f"),
            i = r.match(/AppleWebKit\/(\d+)\./);
        e.exports = !!i && +i[1]
    },
    5135: function(e, t, n) {
        var r = n("7b0b"),
            i = {}.hasOwnProperty;
        e.exports = Object.hasOwn || function(e, t) {
            return i.call(r(e), t)
        }
    },
    "517b": function(e, t, n) {
        "use strict";
        var r = n("85b1"),
            i = n("2332"),
            o = "Expected a function";

        function s(e, t, n) {
            var s = !0,
                a = !0;
            if ("function" != typeof e) throw new TypeError(o);
            return Object(i["a"])(n) && (s = "leading" in n ? !!n.leading : s, a = "trailing" in n ? !!n.trailing : a), Object(r["a"])(e, t, {
                leading: s,
                maxWait: t,
                trailing: a
            })
        }
        t["a"] = s
    },
    "53a8": function(e, t) {
        e.exports = r;
        var n = Object.prototype.hasOwnProperty;

        function r() {
            for (var e = {}, t = 0; t < arguments.length; t++) {
                var r = arguments[t];
                for (var i in r) n.call(r, i) && (e[i] = r[i])
            }
            return e
        }
    },
    "566b": function(e, t, n) {
        var r = n("d633");

        function i(e) {
            var t = function() {
                return t.called ? t.value : (t.called = !0, t.value = e.apply(this, arguments))
            };
            return t.called = !1, t
        }

        function o(e) {
            var t = function() {
                    if (t.called) throw new Error(t.onceError);
                    return t.called = !0, t.value = e.apply(this, arguments)
                },
                n = e.name || "Function wrapped with `once`";
            return t.onceError = n + " shouldn't be called more than once", t.called = !1, t
        }
        e.exports = r(i), e.exports.strict = r(o), i.proto = i((function() {
            Object.defineProperty(Function.prototype, "once", {
                value: function() {
                    return i(this)
                },
                configurable: !0
            }), Object.defineProperty(Function.prototype, "onceStrict", {
                value: function() {
                    return o(this)
                },
                configurable: !0
            })
        }))
    },
    5692: function(e, t, n) {
        var r = n("c430"),
            i = n("c6cd");
        (e.exports = function(e, t) {
            return i[e] || (i[e] = void 0 !== t ? t : {})
        })("versions", []).push({
            version: "3.16.3",
            mode: r ? "pure" : "global",
            copyright: "© 2021 Denis Pushkarev (zloirock.ru)"
        })
    },
    "56ef": function(e, t, n) {
        var r = n("d066"),
            i = n("241c"),
            o = n("7418"),
            s = n("825a");
        e.exports = r("Reflect", "ownKeys") || function(e) {
            var t = i.f(s(e)),
                n = o.f;
            return n ? t.concat(n(e)) : t
        }
    },
    "576e": function(e, t, n) {
        const r = n("738f");
        let i, o, s;

        function a() {
            i = r.createWorker(), o = 1, s = {}, i.onmessage = function(e) {
                const t = e.data.id,
                    n = s[t];
                delete s[t], null != e.data.error ? n(new Error("Rusha worker error: " + e.data.error)) : n(null, e.data.hash)
            }
        }

        function c(e, t) {
            i || a(), s[o] = t, i.postMessage({
                id: o,
                data: e
            }), o += 1
        }
        e.exports = c
    },
    "583f": function(e, t) {},
    "5c6c": function(e, t) {
        e.exports = function(e, t) {
            return {
                enumerable: !(1 & e),
                configurable: !(2 & e),
                writable: !(4 & e),
                value: t
            }
        }
    },
    "5cc6": function(e, t, n) {
        var r = n("74e8");
        r("Uint8", (function(e) {
            return function(t, n, r) {
                return e(this, t, n, r)
            }
        }))
    },
    "5d1c": function(e, t, n) {
        "use strict";
        var r;

        function i(e) {
            var t = !1;
            return function() {
                t || (t = !0, e.apply(void 0, arguments))
            }
        }
        var o = n("c9b8").codes,
            s = o.ERR_MISSING_ARGS,
            a = o.ERR_STREAM_DESTROYED;

        function c(e) {
            if (e) throw e
        }

        function h(e) {
            return e.setHeader && "function" === typeof e.abort
        }

        function u(e, t, o, s) {
            s = i(s);
            var c = !1;
            e.on("close", (function() {
                c = !0
            })), void 0 === r && (r = n("903c")), r(e, {
                readable: t,
                writable: o
            }, (function(e) {
                if (e) return s(e);
                c = !0, s()
            }));
            var u = !1;
            return function(t) {
                if (!c && !u) return u = !0, h(e) ? e.abort() : "function" === typeof e.destroy ? e.destroy() : void s(t || new a("pipe"))
            }
        }

        function f(e) {
            e()
        }

        function d(e, t) {
            return e.pipe(t)
        }

        function l(e) {
            return e.length ? "function" !== typeof e[e.length - 1] ? c : e.pop() : c
        }

        function p() {
            for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
            var r, i = l(t);
            if (Array.isArray(t[0]) && (t = t[0]), t.length < 2) throw new s("streams");
            var o = t.map((function(e, n) {
                var s = n < t.length - 1,
                    a = n > 0;
                return u(e, s, a, (function(e) {
                    r || (r = e), e && o.forEach(f), s || (o.forEach(f), i(r))
                }))
            }));
            return t.reduce(d)
        }
        e.exports = p
    },
    "5de4": function(e, t, n) {
        "use strict";
        n.d(t, "j", (function() {
            return r
        })), n.d(t, "i", (function() {
            return i
        })), n.d(t, "h", (function() {
            return o
        })), n.d(t, "g", (function() {
            return s
        })), n.d(t, "f", (function() {
            return a
        })), n.d(t, "b", (function() {
            return c
        })), n.d(t, "e", (function() {
            return u
        })), n.d(t, "d", (function() {
            return l
        })), n.d(t, "a", (function() {
            return p
        })), n.d(t, "c", (function() {
            return y
        }));
        console.log;
        async function r(e, t = {}) {
            if (Number.isFinite(t.timeout)) {
                const e = new AbortController;
                t.signal = e.signal, setTimeout(() => e.abort(), t.timeout)
            }
            const n = await fetch(e, t);
            if (n.status >= 400) {
                const e = new Error(n.statusText || n.status);
                throw e.response = n, e
            }
            return n
        }
        const i = {
            _searchParams(e = window.location.href) {
                const {
                    searchParams: t
                } = new URL(e);
                return t
            },
            exists(e, t) {
                return this._searchParams(t).has(e)
            },
            get(e, t = null, n) {
                return this._searchParams(n).get(e) || t
            },
            isTruthy(e, t = !1, n) {
                const r = this._searchParams(n);
                return r.has(e) ? ["1", "true"].includes(r.get(e).toLowerCase()) : t
            },
            asNumber(e, t, n) {
                const r = this._searchParams(n);
                return r.has(e) ? Number(r.get(e)) : t
            }
        };

        function o() {
            return /^((?!chrome|android).)*safari/i.test(navigator.userAgent)
        }

        function s() {
            return /Mobi|Android/i.test(navigator.userAgent)
        }

        function a(e) {
            return e.startsWith("https://arc.io/demo")
        }

        function c(e) {
            const t = [];
            let n = [];
            for (let r = 0; r < e.length; r++) {
                const i = e[r];
                if (0 === n.length) n.push(i);
                else {
                    const e = n[n.length - 1];
                    e + 1 !== i ? (1 === n.length && n.push(n[0]), t.push(n), n = [i]) : n[1] = i
                }
                r === e.length - 1 && (1 === n.length && n.push(n[0]), t.push(n))
            }
            return t
        }
        const h = e => new Promise(t => setTimeout(t, e));
        async function u() {
            const e = d(),
                t = f(),
                n = await e;
            if (n) return t.then(() => {}).catch(() => {}), !0;
            const r = await t;
            return r
        }
        async function f() {
            let e = !1;
            const t = 15,
                n = "https://tracker.arc.io";
            try {
                await r(n, {
                    timeout: t
                })
            } catch (i) {
                e = "TypeError" === i.name
            }
            return e
        }
        async function d() {
            let e = !1;
            const t = document.createElement("div");
            if (t.setAttribute("class", "text-ad ad-text adSense adBlock adContent adBanner"), t.setAttribute("style", "width: 1px ! important; height: 1px !important;\n        position: absolute !important; left: -10000px !important;\n        top: -1000px !important;"), document.body.appendChild(t), await h(100), null !== window.document.body.getAttribute("abp") || null === t.offsetParent || 0 === t.offsetHeight || 0 === t.offsetLeft || 0 === t.offsetTop || 0 === t.offsetWidth || 0 === t.clientHeight || 0 === t.clientWidth) e = !0;
            else if (void 0 !== window.getComputedStyle) {
                const n = window.getComputedStyle(t, null);
                !n || "none" !== n.getPropertyValue("display") && "hidden" !== n.getPropertyValue("visibility") || (e = !0)
            }
            return document.body.removeChild(t), e
        }

        function l() {
            const e = document.body;
            return e && "frameset" !== e.tagName.toLowerCase() ? e : document.documentElement
        }

        function p() {
            return new Promise(e => {
                "complete" === document.readyState ? e() : window.addEventListener("load", e)
            })
        }

        function g(e) {
            try {
                return e()
            } catch {
                return null
            }
        }

        function _() {
            const e = document.createElement("canvas"),
                t = e.getContext("webgl"),
                n = t.getExtension("WEBGL_debug_renderer_info"),
                r = t.getParameter(n.UNMASKED_VENDOR_WEBGL),
                i = t.getParameter(n.UNMASKED_RENDERER_WEBGL);
            return {
                webglVendor: r,
                webglRenderer: i
            }
        }

        function y() {
            const e = {
                timeZone: g(() => Intl.DateTimeFormat().resolvedOptions().timeZone),
                numCpuCores: g(() => navigator.hardwareConcurrency),
                deviceMemoryGb: g(() => navigator.deviceMemory),
                screenAvailWidth: g(() => screen.availWidth),
                screenAvailHeight: g(() => screen.availHeight),
                screenWidth: g(() => screen.width),
                screenHeight: g(() => screen.height),
                screenColorDepth: g(() => screen.colorDepth),
                ...g(() => _())
            };
            return e
        }
    },
    "5e89": function(e, t, n) {
        var r = n("861d"),
            i = Math.floor;
        e.exports = function(e) {
            return !r(e) && isFinite(e) && i(e) === e
        }
    },
    "5ea3": function(e, t, n) {
        "use strict";
        (function(e) {
            var n = "object" == typeof e && e && e.Object === Object && e;
            t["a"] = n
        }).call(this, n("c8ba"))
    },
    "5ff7": function(e, t, n) {
        "use strict";
        const r = Object({
            NODE_ENV: "production",
            BASE_URL: "https://static.arc.io/",
            ACCOUNT_ORIGIN: "https://account.arc.io",
            BANDWIDTH_WARDEN_ORIGIN: "https://warden.arc.io",
            COGNITO_APP_ID: "431634imeo45noat90ccl0lkep",
            COGNITO_REGION: "us-east-2",
            COGNITO_IDENTITY_POOL_ID: "us-east-2:cec1bb4c-3aa1-4d9a-87df-b75ae59441d0",
            COGNITO_USER_POOL_ID: "us-east-2_3sKO4HOjv",
            COMMIT_HASH: "ce271de",
            CORE_ORIGIN: "https://core.arc.io",
            DEMO_VUE_ORIGIN: "https://demo.arc.io",
            DOCS_ORIGIN: "https://docs.arc.io",
            FIREBASE_API_KEY: "AIzaSyCGmeUDT5F7Bq77JvXlN8IXBwJjIXJwvcI",
            GA_TID_HOMEPAGE: "UA-123508647-1",
            GA_TID_USER_TIMING: "UA-123508647-2",
            GATEWAY_ORIGIN: "https://gateway.arc.io",
            GOOGLE_PROJECT_FIRESTORE_ID: "prod-firestore-arc",
            HOMEPAGE_ORIGIN: "https://arc.io",
            INLAY_ORIGIN: "https://inlay.arc.io",
            OVERMIND_ORIGIN: "https://overmind.arc.io",
            PORTAL_VUE_ORIGIN: "https://portal.arc.io",
            PORTAL_ORIGIN: "https://portal.arc.io",
            NODE_REPORT_MAILBOX_ORIGIN: "https://warden.arc.io",
            ROOT_DOMAIN: "arc.io",
            SOCKETCLUSTER_HOSTNAME: "socket.arc.io",
            SOCKETCLUSTER_PORT: "443",
            STATIC_ORIGIN: "https://static.arc.io",
            STORAGE_ORIGIN: "https://storage.arc.io",
            STRIPE_CLIENT_ID: "ca_DMhwnlBqMfP4Vx8mJF4M1nGxTNU5263W",
            STRIPE_PUBLISHABLE_KEY: "pk_live_Df4EdjIuSE8fW21HyuwWhJcm",
            SW_ORIGIN: "https://arc.io",
            TCDN_ORIGIN: "https://tcdn.arc.io",
            TRACKER_ANNOUNCE_URL: "wss://tkr.arc.io/announce",
            TRACKER_ORIGIN: "https://tkr.arc.io",
            WEBSEED_ORIGIN: "https://webseed.arc.io",
            WIDGET_ORIGIN: "https://arc.io",
            DEBUG: "false"
        });
        r.IS_PROD = "production" === r.NODE_ENV, t["a"] = r
    },
    6: function(e, t) {},
    "616f": function(e, t) {
        var n = function(e) {
            var t = 0;
            return function() {
                if (t === e.length) return null;
                var n = e.length - t,
                    r = Math.random() * n | 0,
                    i = e[t + r],
                    o = e[t];
                return e[t] = i, e[t + r] = o, t++, i
            }
        };
        e.exports = n
    },
    "621a": function(e, t, n) {
        "use strict";
        var r = n("da84"),
            i = n("83ab"),
            o = n("a981"),
            s = n("9112"),
            a = n("e2cc"),
            c = n("d039"),
            h = n("19aa"),
            u = n("a691"),
            f = n("50c4"),
            d = n("0b25"),
            l = n("77a7"),
            p = n("e163"),
            g = n("d2bb"),
            _ = n("241c").f,
            y = n("9bf2").f,
            m = n("81d5"),
            b = n("d44e"),
            w = n("69f3"),
            v = w.get,
            E = w.set,
            T = "ArrayBuffer",
            R = "DataView",
            S = "prototype",
            I = "Wrong length",
            O = "Wrong index",
            k = r[T],
            A = k,
            C = r[R],
            x = C && C[S],
            N = Object.prototype,
            P = r.RangeError,
            L = l.pack,
            M = l.unpack,
            D = function(e) {
                return [255 & e]
            },
            U = function(e) {
                return [255 & e, e >> 8 & 255]
            },
            B = function(e) {
                return [255 & e, e >> 8 & 255, e >> 16 & 255, e >> 24 & 255]
            },
            j = function(e) {
                return e[3] << 24 | e[2] << 16 | e[1] << 8 | e[0]
            },
            F = function(e) {
                return L(e, 23, 4)
            },
            H = function(e) {
                return L(e, 52, 8)
            },
            G = function(e, t) {
                y(e[S], t, {
                    get: function() {
                        return v(this)[t]
                    }
                })
            },
            W = function(e, t, n, r) {
                var i = d(n),
                    o = v(e);
                if (i + t > o.byteLength) throw P(O);
                var s = v(o.buffer).bytes,
                    a = i + o.byteOffset,
                    c = s.slice(a, a + t);
                return r ? c : c.reverse()
            },
            q = function(e, t, n, r, i, o) {
                var s = d(n),
                    a = v(e);
                if (s + t > a.byteLength) throw P(O);
                for (var c = v(a.buffer).bytes, h = s + a.byteOffset, u = r(+i), f = 0; f < t; f++) c[h + f] = u[o ? f : t - f - 1]
            };
        if (o) {
            if (!c((function() {
                    k(1)
                })) || !c((function() {
                    new k(-1)
                })) || c((function() {
                    return new k, new k(1.5), new k(NaN), k.name != T
                }))) {
                A = function(e) {
                    return h(this, A), new k(d(e))
                };
                for (var $, Y = A[S] = k[S], z = _(k), V = 0; z.length > V;)($ = z[V++]) in A || s(A, $, k[$]);
                Y.constructor = A
            }
            g && p(x) !== N && g(x, N);
            var X = new C(new A(2)),
                K = x.setInt8;
            X.setInt8(0, 2147483648), X.setInt8(1, 2147483649), !X.getInt8(0) && X.getInt8(1) || a(x, {
                setInt8: function(e, t) {
                    K.call(this, e, t << 24 >> 24)
                },
                setUint8: function(e, t) {
                    K.call(this, e, t << 24 >> 24)
                }
            }, {
                unsafe: !0
            })
        } else A = function(e) {
            h(this, A, T);
            var t = d(e);
            E(this, {
                bytes: m.call(new Array(t), 0),
                byteLength: t
            }), i || (this.byteLength = t)
        }, C = function(e, t, n) {
            h(this, C, R), h(e, A, R);
            var r = v(e).byteLength,
                o = u(t);
            if (o < 0 || o > r) throw P("Wrong offset");
            if (n = void 0 === n ? r - o : f(n), o + n > r) throw P(I);
            E(this, {
                buffer: e,
                byteLength: n,
                byteOffset: o
            }), i || (this.buffer = e, this.byteLength = n, this.byteOffset = o)
        }, i && (G(A, "byteLength"), G(C, "buffer"), G(C, "byteLength"), G(C, "byteOffset")), a(C[S], {
            getInt8: function(e) {
                return W(this, 1, e)[0] << 24 >> 24
            },
            getUint8: function(e) {
                return W(this, 1, e)[0]
            },
            getInt16: function(e) {
                var t = W(this, 2, e, arguments.length > 1 ? arguments[1] : void 0);
                return (t[1] << 8 | t[0]) << 16 >> 16
            },
            getUint16: function(e) {
                var t = W(this, 2, e, arguments.length > 1 ? arguments[1] : void 0);
                return t[1] << 8 | t[0]
            },
            getInt32: function(e) {
                return j(W(this, 4, e, arguments.length > 1 ? arguments[1] : void 0))
            },
            getUint32: function(e) {
                return j(W(this, 4, e, arguments.length > 1 ? arguments[1] : void 0)) >>> 0
            },
            getFloat32: function(e) {
                return M(W(this, 4, e, arguments.length > 1 ? arguments[1] : void 0), 23)
            },
            getFloat64: function(e) {
                return M(W(this, 8, e, arguments.length > 1 ? arguments[1] : void 0), 52)
            },
            setInt8: function(e, t) {
                q(this, 1, e, D, t)
            },
            setUint8: function(e, t) {
                q(this, 1, e, D, t)
            },
            setInt16: function(e, t) {
                q(this, 2, e, U, t, arguments.length > 2 ? arguments[2] : void 0)
            },
            setUint16: function(e, t) {
                q(this, 2, e, U, t, arguments.length > 2 ? arguments[2] : void 0)
            },
            setInt32: function(e, t) {
                q(this, 4, e, B, t, arguments.length > 2 ? arguments[2] : void 0)
            },
            setUint32: function(e, t) {
                q(this, 4, e, B, t, arguments.length > 2 ? arguments[2] : void 0)
            },
            setFloat32: function(e, t) {
                q(this, 4, e, F, t, arguments.length > 2 ? arguments[2] : void 0)
            },
            setFloat64: function(e, t) {
                q(this, 8, e, H, t, arguments.length > 2 ? arguments[2] : void 0)
            }
        });
        b(A, T), b(C, R), e.exports = {
            ArrayBuffer: A,
            DataView: C
        }
    },
    "65f0": function(e, t, n) {
        var r = n("0b42");
        e.exports = function(e, t) {
            return new(r(e))(0 === t ? 0 : t)
        }
    },
    "69f3": function(e, t, n) {
        var r, i, o, s = n("7f9a"),
            a = n("da84"),
            c = n("861d"),
            h = n("9112"),
            u = n("5135"),
            f = n("c6cd"),
            d = n("f772"),
            l = n("d012"),
            p = "Object already initialized",
            g = a.WeakMap,
            _ = function(e) {
                return o(e) ? i(e) : r(e, {})
            },
            y = function(e) {
                return function(t) {
                    var n;
                    if (!c(t) || (n = i(t)).type !== e) throw TypeError("Incompatible receiver, " + e + " required");
                    return n
                }
            };
        if (s || f.state) {
            var m = f.state || (f.state = new g),
                b = m.get,
                w = m.has,
                v = m.set;
            r = function(e, t) {
                if (w.call(m, e)) throw new TypeError(p);
                return t.facade = e, v.call(m, e, t), t
            }, i = function(e) {
                return b.call(m, e) || {}
            }, o = function(e) {
                return w.call(m, e)
            }
        } else {
            var E = d("state");
            l[E] = !0, r = function(e, t) {
                if (u(e, E)) throw new TypeError(p);
                return t.facade = e, h(e, E, t), t
            }, i = function(e) {
                return u(e, E) ? e[E] : {}
            }, o = function(e) {
                return u(e, E)
            }
        }
        e.exports = {
            set: r,
            get: i,
            has: o,
            enforce: _,
            getterFor: y
        }
    },
    "6eeb": function(e, t, n) {
        var r = n("da84"),
            i = n("9112"),
            o = n("5135"),
            s = n("ce4e"),
            a = n("8925"),
            c = n("69f3"),
            h = c.get,
            u = c.enforce,
            f = String(String).split("String");
        (e.exports = function(e, t, n, a) {
            var c, h = !!a && !!a.unsafe,
                d = !!a && !!a.enumerable,
                l = !!a && !!a.noTargetGet;
            "function" == typeof n && ("string" != typeof t || o(n, "name") || i(n, "name", t), c = u(n), c.source || (c.source = f.join("string" == typeof t ? t : ""))), e !== r ? (h ? !l && e[t] && (d = !0) : delete e[t], d ? e[t] = n : i(e, t, n)) : d ? e[t] = n : s(t, n)
        })(Function.prototype, "toString", (function() {
            return "function" == typeof this && h(this).source || a(this)
        }))
    },
    "6f59": function(e, t, n) {
        (function(t) {
            var r = n("566b"),
                i = n("ab52"),
                o = n(13),
                s = function() {},
                a = /^v?\.0/.test(t.version),
                c = function(e) {
                    return "function" === typeof e
                },
                h = function(e) {
                    return !!a && (!!o && ((e instanceof(o.ReadStream || s) || e instanceof(o.WriteStream || s)) && c(e.close)))
                },
                u = function(e) {
                    return e.setHeader && c(e.abort)
                },
                f = function(e, t, n, o) {
                    o = r(o);
                    var a = !1;
                    e.on("close", (function() {
                        a = !0
                    })), i(e, {
                        readable: t,
                        writable: n
                    }, (function(e) {
                        if (e) return o(e);
                        a = !0, o()
                    }));
                    var f = !1;
                    return function(t) {
                        if (!a && !f) return f = !0, h(e) ? e.close(s) : u(e) ? e.abort() : c(e.destroy) ? e.destroy() : void o(t || new Error("stream was destroyed"))
                    }
                },
                d = function(e) {
                    e()
                },
                l = function(e, t) {
                    return e.pipe(t)
                },
                p = function() {
                    var e, t = Array.prototype.slice.call(arguments),
                        n = c(t[t.length - 1] || s) && t.pop() || s;
                    if (Array.isArray(t[0]) && (t = t[0]), t.length < 2) throw new Error("pump requires two streams per minimum");
                    var r = t.map((function(i, o) {
                        var s = o < t.length - 1,
                            a = o > 0;
                        return f(i, s, a, (function(t) {
                            e || (e = t), t && r.forEach(d), s || (r.forEach(d), n(e))
                        }))
                    }));
                    return t.reduce(l)
                };
            e.exports = p
        }).call(this, n("4362"))
    },
    7: function(e, t) {},
    7130: function(e, t, n) {
        (function(t) {
            const {
                digitCount: r,
                getType: i
            } = n("7871");

            function o(e) {
                let t = 2;
                for (const n of e) t += u(n);
                return t
            }

            function s(e) {
                let n = 2;
                for (const [i, o] of e) {
                    const e = t.byteLength(i);
                    n += r(e) + 1 + e, n += u(o)
                }
                return n
            }

            function a(e) {
                let n = 2;
                const i = Object.keys(e);
                for (let o = 0; o < i.length; o++) {
                    const s = t.byteLength(i[o]);
                    n += r(s) + 1 + s, n += u(e[i[o]])
                }
                return n
            }

            function c(e) {
                const n = t.byteLength(e);
                return r(n) + 1 + n
            }

            function h(e) {
                const t = e.byteLength - e.byteOffset;
                return r(t) + 1 + t
            }

            function u(e) {
                const t = 0;
                if (null == e) return t;
                const n = i(e);
                switch (n) {
                    case "buffer":
                        return r(e.length) + 1 + e.length;
                    case "arraybufferview":
                        return h(e);
                    case "string":
                        return c(e);
                    case "array":
                    case "set":
                        return o(e);
                    case "number":
                        return 1 + r(Math.floor(e)) + 1;
                    case "bigint":
                        return 1 + e.toString().length + 1;
                    case "object":
                        return a(e);
                    case "map":
                        return s(e);
                    default:
                        throw new TypeError(`Unsupported value of type "${n}"`)
                }
            }
            e.exports = u
        }).call(this, n("b639").Buffer)
    },
    7156: function(e, t, n) {
        var r = n("861d"),
            i = n("d2bb");
        e.exports = function(e, t, n) {
            var o, s;
            return i && "function" == typeof(o = t.constructor) && o !== n && r(s = o.prototype) && s !== n.prototype && i(e, s), e
        }
    },
    "738f": function(e, t, n) {
        (function(t, n) {
            e.exports = n()
        })("undefined" !== typeof self && self, (function() {
            return function(e) {
                var t = {};

                function n(r) {
                    if (t[r]) return t[r].exports;
                    var i = t[r] = {
                        i: r,
                        l: !1,
                        exports: {}
                    };
                    return e[r].call(i.exports, i, i.exports, n), i.l = !0, i.exports
                }
                return n.m = e, n.c = t, n.d = function(e, t, r) {
                    n.o(e, t) || Object.defineProperty(e, t, {
                        configurable: !1,
                        enumerable: !0,
                        get: r
                    })
                }, n.n = function(e) {
                    var t = e && e.__esModule ? function() {
                        return e["default"]
                    } : function() {
                        return e
                    };
                    return n.d(t, "a", t), t
                }, n.o = function(e, t) {
                    return Object.prototype.hasOwnProperty.call(e, t)
                }, n.p = "", n(n.s = 3)
            }([function(e, t, n) {
                function r(e, t) {
                    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                }
                var i = n(5),
                    o = n(1),
                    s = o.toHex,
                    a = o.ceilHeapSize,
                    c = n(6),
                    h = function(e) {
                        for (e += 9; e % 64 > 0; e += 1);
                        return e
                    },
                    u = function(e, t) {
                        var n = new Uint8Array(e.buffer),
                            r = t % 4,
                            i = t - r;
                        switch (r) {
                            case 0:
                                n[i + 3] = 0;
                            case 1:
                                n[i + 2] = 0;
                            case 2:
                                n[i + 1] = 0;
                            case 3:
                                n[i + 0] = 0
                        }
                        for (var o = 1 + (t >> 2); o < e.length; o++) e[o] = 0
                    },
                    f = function(e, t, n) {
                        e[t >> 2] |= 128 << 24 - (t % 4 << 3), e[14 + (2 + (t >> 2) & -16)] = n / (1 << 29) | 0, e[15 + (2 + (t >> 2) & -16)] = n << 3
                    },
                    d = function(e, t) {
                        var n = new Int32Array(e, t + 320, 5),
                            r = new Int32Array(5),
                            i = new DataView(r.buffer);
                        return i.setInt32(0, n[0], !1), i.setInt32(4, n[1], !1), i.setInt32(8, n[2], !1), i.setInt32(12, n[3], !1), i.setInt32(16, n[4], !1), r
                    },
                    l = function() {
                        function e(t) {
                            if (r(this, e), t = t || 65536, t % 64 > 0) throw new Error("Chunk size must be a multiple of 128 bit");
                            this._offset = 0, this._maxChunkLen = t, this._padMaxChunkLen = h(t), this._heap = new ArrayBuffer(a(this._padMaxChunkLen + 320 + 20)), this._h32 = new Int32Array(this._heap), this._h8 = new Int8Array(this._heap), this._core = new i({
                                Int32Array: Int32Array
                            }, {}, this._heap)
                        }
                        return e.prototype._initState = function(e, t) {
                            this._offset = 0;
                            var n = new Int32Array(e, t + 320, 5);
                            n[0] = 1732584193, n[1] = -271733879, n[2] = -1732584194, n[3] = 271733878, n[4] = -1009589776
                        }, e.prototype._padChunk = function(e, t) {
                            var n = h(e),
                                r = new Int32Array(this._heap, 0, n >> 2);
                            return u(r, e), f(r, e, t), n
                        }, e.prototype._write = function(e, t, n, r) {
                            c(e, this._h8, this._h32, t, n, r || 0)
                        }, e.prototype._coreCall = function(e, t, n, r, i) {
                            var o = n;
                            this._write(e, t, n), i && (o = this._padChunk(n, r)), this._core.hash(o, this._padMaxChunkLen)
                        }, e.prototype.rawDigest = function(e) {
                            var t = e.byteLength || e.length || e.size || 0;
                            this._initState(this._heap, this._padMaxChunkLen);
                            var n = 0,
                                r = this._maxChunkLen;
                            for (n = 0; t > n + r; n += r) this._coreCall(e, n, r, t, !1);
                            return this._coreCall(e, n, t - n, t, !0), d(this._heap, this._padMaxChunkLen)
                        }, e.prototype.digest = function(e) {
                            return s(this.rawDigest(e).buffer)
                        }, e.prototype.digestFromString = function(e) {
                            return this.digest(e)
                        }, e.prototype.digestFromBuffer = function(e) {
                            return this.digest(e)
                        }, e.prototype.digestFromArrayBuffer = function(e) {
                            return this.digest(e)
                        }, e.prototype.resetState = function() {
                            return this._initState(this._heap, this._padMaxChunkLen), this
                        }, e.prototype.append = function(e) {
                            var t = 0,
                                n = e.byteLength || e.length || e.size || 0,
                                r = this._offset % this._maxChunkLen,
                                i = void 0;
                            this._offset += n;
                            while (t < n) i = Math.min(n - t, this._maxChunkLen - r), this._write(e, t, i, r), r += i, t += i, r === this._maxChunkLen && (this._core.hash(this._maxChunkLen, this._padMaxChunkLen), r = 0);
                            return this
                        }, e.prototype.getState = function() {
                            var e = this._offset % this._maxChunkLen,
                                t = void 0;
                            if (e) t = this._heap.slice(0);
                            else {
                                var n = new Int32Array(this._heap, this._padMaxChunkLen + 320, 5);
                                t = n.buffer.slice(n.byteOffset, n.byteOffset + n.byteLength)
                            }
                            return {
                                offset: this._offset,
                                heap: t
                            }
                        }, e.prototype.setState = function(e) {
                            if (this._offset = e.offset, 20 === e.heap.byteLength) {
                                var t = new Int32Array(this._heap, this._padMaxChunkLen + 320, 5);
                                t.set(new Int32Array(e.heap))
                            } else this._h32.set(new Int32Array(e.heap));
                            return this
                        }, e.prototype.rawEnd = function() {
                            var e = this._offset,
                                t = e % this._maxChunkLen,
                                n = this._padChunk(t, e);
                            this._core.hash(n, this._padMaxChunkLen);
                            var r = d(this._heap, this._padMaxChunkLen);
                            return this._initState(this._heap, this._padMaxChunkLen), r
                        }, e.prototype.end = function() {
                            return s(this.rawEnd().buffer)
                        }, e
                    }();
                e.exports = l, e.exports._core = i
            }, function(e, t) {
                for (var n = new Array(256), r = 0; r < 256; r++) n[r] = (r < 16 ? "0" : "") + r.toString(16);
                e.exports.toHex = function(e) {
                    for (var t = new Uint8Array(e), r = new Array(e.byteLength), i = 0; i < r.length; i++) r[i] = n[t[i]];
                    return r.join("")
                }, e.exports.ceilHeapSize = function(e) {
                    var t = 0;
                    if (e <= 65536) return 65536;
                    if (e < 16777216)
                        for (t = 1; t < e; t <<= 1);
                    else
                        for (t = 16777216; t < e; t += 16777216);
                    return t
                }, e.exports.isDedicatedWorkerScope = function(e) {
                    var t = "WorkerGlobalScope" in e && e instanceof e.WorkerGlobalScope,
                        n = "SharedWorkerGlobalScope" in e && e instanceof e.SharedWorkerGlobalScope,
                        r = "ServiceWorkerGlobalScope" in e && e instanceof e.ServiceWorkerGlobalScope;
                    return t && !n && !r
                }
            }, function(e, t, n) {
                e.exports = function() {
                    var e = n(0),
                        t = function(e, t, n) {
                            try {
                                return n(null, e.digest(t))
                            } catch (r) {
                                return n(r)
                            }
                        },
                        r = function(e, t, n, i, o) {
                            var s = new self.FileReader;
                            s.onloadend = function() {
                                if (s.error) return o(s.error);
                                var a = s.result;
                                t += s.result.byteLength;
                                try {
                                    e.append(a)
                                } catch (c) {
                                    return void o(c)
                                }
                                t < i.size ? r(e, t, n, i, o) : o(null, e.end())
                            }, s.readAsArrayBuffer(i.slice(t, t + n))
                        },
                        i = !0;
                    return self.onmessage = function(n) {
                            if (i) {
                                var o = n.data.data,
                                    s = n.data.file,
                                    a = n.data.id;
                                if ("undefined" !== typeof a && (s || o)) {
                                    var c = n.data.blockSize || 4194304,
                                        h = new e(c);
                                    h.resetState();
                                    var u = function(e, t) {
                                        e ? self.postMessage({
                                            id: a,
                                            error: e.name
                                        }) : self.postMessage({
                                            id: a,
                                            hash: t
                                        })
                                    };
                                    o && t(h, o, u), s && r(h, 0, c, s, u)
                                }
                            }
                        },
                        function() {
                            i = !1
                        }
                }
            }, function(e, t, n) {
                var r = n(4),
                    i = n(0),
                    o = n(7),
                    s = n(2),
                    a = n(1),
                    c = a.isDedicatedWorkerScope,
                    h = "undefined" !== typeof self && c(self);
                i.disableWorkerBehaviour = h ? s() : function() {}, i.createWorker = function() {
                    var e = r(2),
                        t = e.terminate;
                    return e.terminate = function() {
                        URL.revokeObjectURL(e.objectURL), t.call(e)
                    }, e
                }, i.createHash = o, e.exports = i
            }, function(e, t, n) {
                function r(e) {
                    var t = {};

                    function n(r) {
                        if (t[r]) return t[r].exports;
                        var i = t[r] = {
                            i: r,
                            l: !1,
                            exports: {}
                        };
                        return e[r].call(i.exports, i, i.exports, n), i.l = !0, i.exports
                    }
                    n.m = e, n.c = t, n.i = function(e) {
                        return e
                    }, n.d = function(e, t, r) {
                        n.o(e, t) || Object.defineProperty(e, t, {
                            configurable: !1,
                            enumerable: !0,
                            get: r
                        })
                    }, n.r = function(e) {
                        Object.defineProperty(e, "__esModule", {
                            value: !0
                        })
                    }, n.n = function(e) {
                        var t = e && e.__esModule ? function() {
                            return e["default"]
                        } : function() {
                            return e
                        };
                        return n.d(t, "a", t), t
                    }, n.o = function(e, t) {
                        return Object.prototype.hasOwnProperty.call(e, t)
                    }, n.p = "/", n.oe = function(e) {
                        throw console.error(e), e
                    };
                    var r = n(n.s = ENTRY_MODULE);
                    return r.default || r
                }
                var i = "[\\.|\\-|\\+|\\w|/|@]+",
                    o = "\\((/\\*.*?\\*/)?s?.*?(" + i + ").*?\\)";

                function s(e) {
                    return (e + "").replace(/[.?*+^$[\]\\(){}|-]/g, "\\$&")
                }

                function a(e, t, r) {
                    var a = {};
                    a[r] = [];
                    var c = t.toString(),
                        h = c.match(/^function\s?\(\w+,\s*\w+,\s*(\w+)\)/);
                    if (!h) return a;
                    var u, f = h[1],
                        d = new RegExp("(\\\\n|\\W)" + s(f) + o, "g");
                    while (u = d.exec(c)) "dll-reference" !== u[3] && a[r].push(u[3]);
                    d = new RegExp("\\(" + s(f) + '\\("(dll-reference\\s(' + i + '))"\\)\\)' + o, "g");
                    while (u = d.exec(c)) e[u[2]] || (a[r].push(u[1]), e[u[2]] = n(u[1]).m), a[u[2]] = a[u[2]] || [], a[u[2]].push(u[4]);
                    return a
                }

                function c(e) {
                    var t = Object.keys(e);
                    return t.reduce((function(t, n) {
                        return t || e[n].length > 0
                    }), !1)
                }

                function h(e, t) {
                    var n = {
                            main: [t]
                        },
                        r = {
                            main: []
                        },
                        i = {
                            main: {}
                        };
                    while (c(n))
                        for (var o = Object.keys(n), s = 0; s < o.length; s++) {
                            var h = o[s],
                                u = n[h],
                                f = u.pop();
                            if (i[h] = i[h] || {}, !i[h][f] && e[h][f]) {
                                i[h][f] = !0, r[h] = r[h] || [], r[h].push(f);
                                for (var d = a(e, e[h][f], h), l = Object.keys(d), p = 0; p < l.length; p++) n[l[p]] = n[l[p]] || [], n[l[p]] = n[l[p]].concat(d[l[p]])
                            }
                        }
                    return r
                }
                e.exports = function(e, t) {
                    t = t || {};
                    var i = {
                            main: n.m
                        },
                        o = t.all ? {
                            main: Object.keys(i)
                        } : h(i, e),
                        s = "";
                    Object.keys(o).filter((function(e) {
                        return "main" !== e
                    })).forEach((function(e) {
                        var t = 0;
                        while (o[e][t]) t++;
                        o[e].push(t), i[e][t] = "(function(module, exports, __webpack_require__) { module.exports = __webpack_require__; })", s = s + "var " + e + " = (" + r.toString().replace("ENTRY_MODULE", JSON.stringify(t)) + ")({" + o[e].map((function(t) {
                            return JSON.stringify(t) + ": " + i[e][t].toString()
                        })).join(",") + "});\n"
                    })), s = s + "(" + r.toString().replace("ENTRY_MODULE", JSON.stringify(e)) + ")({" + o.main.map((function(e) {
                        return JSON.stringify(e) + ": " + i.main[e].toString()
                    })).join(",") + "})(self);";
                    var a = new window.Blob([s], {
                        type: "text/javascript"
                    });
                    if (t.bare) return a;
                    var c = window.URL || window.webkitURL || window.mozURL || window.msURL,
                        u = c.createObjectURL(a),
                        f = new window.Worker(u);
                    return f.objectURL = u, f
                }
            }, function(e, t) {
                e.exports = function(e, t, n) {
                    "use asm";
                    var r = new e.Int32Array(n);

                    function i(e, t) {
                        e = e | 0;
                        t = t | 0;
                        var n = 0,
                            i = 0,
                            o = 0,
                            s = 0,
                            a = 0,
                            c = 0,
                            h = 0,
                            u = 0,
                            f = 0,
                            d = 0,
                            l = 0,
                            p = 0,
                            g = 0,
                            _ = 0;
                        o = r[t + 320 >> 2] | 0;
                        a = r[t + 324 >> 2] | 0;
                        h = r[t + 328 >> 2] | 0;
                        f = r[t + 332 >> 2] | 0;
                        l = r[t + 336 >> 2] | 0;
                        for (n = 0;
                            (n | 0) < (e | 0); n = n + 64 | 0) {
                            s = o;
                            c = a;
                            u = h;
                            d = f;
                            p = l;
                            for (i = 0;
                                (i | 0) < 64; i = i + 4 | 0) {
                                _ = r[n + i >> 2] | 0;
                                g = ((o << 5 | o >>> 27) + (a & h | ~a & f) | 0) + ((_ + l | 0) + 1518500249 | 0) | 0;
                                l = f;
                                f = h;
                                h = a << 30 | a >>> 2;
                                a = o;
                                o = g;
                                r[e + i >> 2] = _
                            }
                            for (i = e + 64 | 0;
                                (i | 0) < (e + 80 | 0); i = i + 4 | 0) {
                                _ = (r[i - 12 >> 2] ^ r[i - 32 >> 2] ^ r[i - 56 >> 2] ^ r[i - 64 >> 2]) << 1 | (r[i - 12 >> 2] ^ r[i - 32 >> 2] ^ r[i - 56 >> 2] ^ r[i - 64 >> 2]) >>> 31;
                                g = ((o << 5 | o >>> 27) + (a & h | ~a & f) | 0) + ((_ + l | 0) + 1518500249 | 0) | 0;
                                l = f;
                                f = h;
                                h = a << 30 | a >>> 2;
                                a = o;
                                o = g;
                                r[i >> 2] = _
                            }
                            for (i = e + 80 | 0;
                                (i | 0) < (e + 160 | 0); i = i + 4 | 0) {
                                _ = (r[i - 12 >> 2] ^ r[i - 32 >> 2] ^ r[i - 56 >> 2] ^ r[i - 64 >> 2]) << 1 | (r[i - 12 >> 2] ^ r[i - 32 >> 2] ^ r[i - 56 >> 2] ^ r[i - 64 >> 2]) >>> 31;
                                g = ((o << 5 | o >>> 27) + (a ^ h ^ f) | 0) + ((_ + l | 0) + 1859775393 | 0) | 0;
                                l = f;
                                f = h;
                                h = a << 30 | a >>> 2;
                                a = o;
                                o = g;
                                r[i >> 2] = _
                            }
                            for (i = e + 160 | 0;
                                (i | 0) < (e + 240 | 0); i = i + 4 | 0) {
                                _ = (r[i - 12 >> 2] ^ r[i - 32 >> 2] ^ r[i - 56 >> 2] ^ r[i - 64 >> 2]) << 1 | (r[i - 12 >> 2] ^ r[i - 32 >> 2] ^ r[i - 56 >> 2] ^ r[i - 64 >> 2]) >>> 31;
                                g = ((o << 5 | o >>> 27) + (a & h | a & f | h & f) | 0) + ((_ + l | 0) - 1894007588 | 0) | 0;
                                l = f;
                                f = h;
                                h = a << 30 | a >>> 2;
                                a = o;
                                o = g;
                                r[i >> 2] = _
                            }
                            for (i = e + 240 | 0;
                                (i | 0) < (e + 320 | 0); i = i + 4 | 0) {
                                _ = (r[i - 12 >> 2] ^ r[i - 32 >> 2] ^ r[i - 56 >> 2] ^ r[i - 64 >> 2]) << 1 | (r[i - 12 >> 2] ^ r[i - 32 >> 2] ^ r[i - 56 >> 2] ^ r[i - 64 >> 2]) >>> 31;
                                g = ((o << 5 | o >>> 27) + (a ^ h ^ f) | 0) + ((_ + l | 0) - 899497514 | 0) | 0;
                                l = f;
                                f = h;
                                h = a << 30 | a >>> 2;
                                a = o;
                                o = g;
                                r[i >> 2] = _
                            }
                            o = o + s | 0;
                            a = a + c | 0;
                            h = h + u | 0;
                            f = f + d | 0;
                            l = l + p | 0
                        }
                        r[t + 320 >> 2] = o;
                        r[t + 324 >> 2] = a;
                        r[t + 328 >> 2] = h;
                        r[t + 332 >> 2] = f;
                        r[t + 336 >> 2] = l
                    }
                    return {
                        hash: i
                    }
                }
            }, function(e, t) {
                var n = this,
                    r = void 0;
                "undefined" !== typeof self && "undefined" !== typeof self.FileReaderSync && (r = new self.FileReaderSync);
                var i = function(e, t, n, r, i, o) {
                        var s = void 0,
                            a = o % 4,
                            c = (i + a) % 4,
                            h = i - c;
                        switch (a) {
                            case 0:
                                t[o] = e.charCodeAt(r + 3);
                            case 1:
                                t[o + 1 - (a << 1) | 0] = e.charCodeAt(r + 2);
                            case 2:
                                t[o + 2 - (a << 1) | 0] = e.charCodeAt(r + 1);
                            case 3:
                                t[o + 3 - (a << 1) | 0] = e.charCodeAt(r)
                        }
                        if (!(i < c + (4 - a))) {
                            for (s = 4 - a; s < h; s = s + 4 | 0) n[o + s >> 2] = e.charCodeAt(r + s) << 24 | e.charCodeAt(r + s + 1) << 16 | e.charCodeAt(r + s + 2) << 8 | e.charCodeAt(r + s + 3);
                            switch (c) {
                                case 3:
                                    t[o + h + 1 | 0] = e.charCodeAt(r + h + 2);
                                case 2:
                                    t[o + h + 2 | 0] = e.charCodeAt(r + h + 1);
                                case 1:
                                    t[o + h + 3 | 0] = e.charCodeAt(r + h)
                            }
                        }
                    },
                    o = function(e, t, n, r, i, o) {
                        var s = void 0,
                            a = o % 4,
                            c = (i + a) % 4,
                            h = i - c;
                        switch (a) {
                            case 0:
                                t[o] = e[r + 3];
                            case 1:
                                t[o + 1 - (a << 1) | 0] = e[r + 2];
                            case 2:
                                t[o + 2 - (a << 1) | 0] = e[r + 1];
                            case 3:
                                t[o + 3 - (a << 1) | 0] = e[r]
                        }
                        if (!(i < c + (4 - a))) {
                            for (s = 4 - a; s < h; s = s + 4 | 0) n[o + s >> 2 | 0] = e[r + s] << 24 | e[r + s + 1] << 16 | e[r + s + 2] << 8 | e[r + s + 3];
                            switch (c) {
                                case 3:
                                    t[o + h + 1 | 0] = e[r + h + 2];
                                case 2:
                                    t[o + h + 2 | 0] = e[r + h + 1];
                                case 1:
                                    t[o + h + 3 | 0] = e[r + h]
                            }
                        }
                    },
                    s = function(e, t, n, i, o, s) {
                        var a = void 0,
                            c = s % 4,
                            h = (o + c) % 4,
                            u = o - h,
                            f = new Uint8Array(r.readAsArrayBuffer(e.slice(i, i + o)));
                        switch (c) {
                            case 0:
                                t[s] = f[3];
                            case 1:
                                t[s + 1 - (c << 1) | 0] = f[2];
                            case 2:
                                t[s + 2 - (c << 1) | 0] = f[1];
                            case 3:
                                t[s + 3 - (c << 1) | 0] = f[0]
                        }
                        if (!(o < h + (4 - c))) {
                            for (a = 4 - c; a < u; a = a + 4 | 0) n[s + a >> 2 | 0] = f[a] << 24 | f[a + 1] << 16 | f[a + 2] << 8 | f[a + 3];
                            switch (h) {
                                case 3:
                                    t[s + u + 1 | 0] = f[u + 2];
                                case 2:
                                    t[s + u + 2 | 0] = f[u + 1];
                                case 1:
                                    t[s + u + 3 | 0] = f[u]
                            }
                        }
                    };
                e.exports = function(e, t, r, a, c, h) {
                    if ("string" === typeof e) return i(e, t, r, a, c, h);
                    if (e instanceof Array) return o(e, t, r, a, c, h);
                    if (n && n.Buffer && n.Buffer.isBuffer(e)) return o(e, t, r, a, c, h);
                    if (e instanceof ArrayBuffer) return o(new Uint8Array(e), t, r, a, c, h);
                    if (e.buffer instanceof ArrayBuffer) return o(new Uint8Array(e.buffer, e.byteOffset, e.byteLength), t, r, a, c, h);
                    if (e instanceof Blob) return s(e, t, r, a, c, h);
                    throw new Error("Unsupported data type.")
                }
            }, function(e, t, n) {
                var r = function() {
                    function e(e, t) {
                        for (var n = 0; n < t.length; n++) {
                            var r = t[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                        }
                    }
                    return function(t, n, r) {
                        return n && e(t.prototype, n), r && e(t, r), t
                    }
                }();

                function i(e, t) {
                    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                }
                var o = n(0),
                    s = n(1),
                    a = s.toHex,
                    c = function() {
                        function e() {
                            i(this, e), this._rusha = new o, this._rusha.resetState()
                        }
                        return e.prototype.update = function(e) {
                            return this._rusha.append(e), this
                        }, e.prototype.digest = function(e) {
                            var t = this._rusha.rawEnd().buffer;
                            if (!e) return t;
                            if ("hex" === e) return a(t);
                            throw new Error("unsupported digest encoding")
                        }, r(e, [{
                            key: "state",
                            get: function() {
                                return this._rusha.getState()
                            },
                            set: function(e) {
                                this._rusha.setState(e)
                            }
                        }]), e
                    }();
                e.exports = function() {
                    return new c
                }
            }])
        }))
    },
    7418: function(e, t) {
        t.f = Object.getOwnPropertySymbols
    },
    "74e8": function(e, t, n) {
        "use strict";
        var r = n("23e7"),
            i = n("da84"),
            o = n("83ab"),
            s = n("8aa7"),
            a = n("ebb5"),
            c = n("621a"),
            h = n("19aa"),
            u = n("5c6c"),
            f = n("9112"),
            d = n("5e89"),
            l = n("50c4"),
            p = n("0b25"),
            g = n("182d"),
            _ = n("a04b"),
            y = n("5135"),
            m = n("f5df"),
            b = n("861d"),
            w = n("d9b5"),
            v = n("7c73"),
            E = n("d2bb"),
            T = n("241c").f,
            R = n("a078"),
            S = n("b727").forEach,
            I = n("2626"),
            O = n("9bf2"),
            k = n("06cf"),
            A = n("69f3"),
            C = n("7156"),
            x = A.get,
            N = A.set,
            P = O.f,
            L = k.f,
            M = Math.round,
            D = i.RangeError,
            U = c.ArrayBuffer,
            B = c.DataView,
            j = a.NATIVE_ARRAY_BUFFER_VIEWS,
            F = a.TYPED_ARRAY_CONSTRUCTOR,
            H = a.TYPED_ARRAY_TAG,
            G = a.TypedArray,
            W = a.TypedArrayPrototype,
            q = a.aTypedArrayConstructor,
            $ = a.isTypedArray,
            Y = "BYTES_PER_ELEMENT",
            z = "Wrong length",
            V = function(e, t) {
                var n = 0,
                    r = t.length,
                    i = new(q(e))(r);
                while (r > n) i[n] = t[n++];
                return i
            },
            X = function(e, t) {
                P(e, t, {
                    get: function() {
                        return x(this)[t]
                    }
                })
            },
            K = function(e) {
                var t;
                return e instanceof U || "ArrayBuffer" == (t = m(e)) || "SharedArrayBuffer" == t
            },
            J = function(e, t) {
                return $(e) && !w(t) && t in e && d(+t) && t >= 0
            },
            Z = function(e, t) {
                return t = _(t), J(e, t) ? u(2, e[t]) : L(e, t)
            },
            Q = function(e, t, n) {
                return t = _(t), !(J(e, t) && b(n) && y(n, "value")) || y(n, "get") || y(n, "set") || n.configurable || y(n, "writable") && !n.writable || y(n, "enumerable") && !n.enumerable ? P(e, t, n) : (e[t] = n.value, e)
            };
        o ? (j || (k.f = Z, O.f = Q, X(W, "buffer"), X(W, "byteOffset"), X(W, "byteLength"), X(W, "length")), r({
            target: "Object",
            stat: !0,
            forced: !j
        }, {
            getOwnPropertyDescriptor: Z,
            defineProperty: Q
        }), e.exports = function(e, t, n) {
            var o = e.match(/\d+$/)[0] / 8,
                a = e + (n ? "Clamped" : "") + "Array",
                c = "get" + e,
                u = "set" + e,
                d = i[a],
                _ = d,
                y = _ && _.prototype,
                m = {},
                w = function(e, t) {
                    var n = x(e);
                    return n.view[c](t * o + n.byteOffset, !0)
                },
                O = function(e, t, r) {
                    var i = x(e);
                    n && (r = (r = M(r)) < 0 ? 0 : r > 255 ? 255 : 255 & r), i.view[u](t * o + i.byteOffset, r, !0)
                },
                k = function(e, t) {
                    P(e, t, {
                        get: function() {
                            return w(this, t)
                        },
                        set: function(e) {
                            return O(this, t, e)
                        },
                        enumerable: !0
                    })
                };
            j ? s && (_ = t((function(e, t, n, r) {
                return h(e, _, a), C(function() {
                    return b(t) ? K(t) ? void 0 !== r ? new d(t, g(n, o), r) : void 0 !== n ? new d(t, g(n, o)) : new d(t) : $(t) ? V(_, t) : R.call(_, t) : new d(p(t))
                }(), e, _)
            })), E && E(_, G), S(T(d), (function(e) {
                e in _ || f(_, e, d[e])
            })), _.prototype = y) : (_ = t((function(e, t, n, r) {
                h(e, _, a);
                var i, s, c, u = 0,
                    f = 0;
                if (b(t)) {
                    if (!K(t)) return $(t) ? V(_, t) : R.call(_, t);
                    i = t, f = g(n, o);
                    var d = t.byteLength;
                    if (void 0 === r) {
                        if (d % o) throw D(z);
                        if (s = d - f, s < 0) throw D(z)
                    } else if (s = l(r) * o, s + f > d) throw D(z);
                    c = s / o
                } else c = p(t), s = c * o, i = new U(s);
                N(e, {
                    buffer: i,
                    byteOffset: f,
                    byteLength: s,
                    length: c,
                    view: new B(i)
                });
                while (u < c) k(e, u++)
            })), E && E(_, G), y = _.prototype = v(W)), y.constructor !== _ && f(y, "constructor", _), f(y, F, _), H && f(y, H, a), m[a] = _, r({
                global: !0,
                forced: _ != d,
                sham: !j
            }, m), Y in _ || f(_, Y, o), Y in y || f(y, Y, o), I(a)
        }) : e.exports = function() {}
    },
    "77a7": function(e, t) {
        var n = Math.abs,
            r = Math.pow,
            i = Math.floor,
            o = Math.log,
            s = Math.LN2,
            a = function(e, t, a) {
                var c, h, u, f = new Array(a),
                    d = 8 * a - t - 1,
                    l = (1 << d) - 1,
                    p = l >> 1,
                    g = 23 === t ? r(2, -24) - r(2, -77) : 0,
                    _ = e < 0 || 0 === e && 1 / e < 0 ? 1 : 0,
                    y = 0;
                for (e = n(e), e != e || e === 1 / 0 ? (h = e != e ? 1 : 0, c = l) : (c = i(o(e) / s), e * (u = r(2, -c)) < 1 && (c--, u *= 2), e += c + p >= 1 ? g / u : g * r(2, 1 - p), e * u >= 2 && (c++, u /= 2), c + p >= l ? (h = 0, c = l) : c + p >= 1 ? (h = (e * u - 1) * r(2, t), c += p) : (h = e * r(2, p - 1) * r(2, t), c = 0)); t >= 8; f[y++] = 255 & h, h /= 256, t -= 8);
                for (c = c << t | h, d += t; d > 0; f[y++] = 255 & c, c /= 256, d -= 8);
                return f[--y] |= 128 * _, f
            },
            c = function(e, t) {
                var n, i = e.length,
                    o = 8 * i - t - 1,
                    s = (1 << o) - 1,
                    a = s >> 1,
                    c = o - 7,
                    h = i - 1,
                    u = e[h--],
                    f = 127 & u;
                for (u >>= 7; c > 0; f = 256 * f + e[h], h--, c -= 8);
                for (n = f & (1 << -c) - 1, f >>= -c, c += t; c > 0; n = 256 * n + e[h], h--, c -= 8);
                if (0 === f) f = 1 - a;
                else {
                    if (f === s) return n ? NaN : u ? -1 / 0 : 1 / 0;
                    n += r(2, t), f -= a
                }
                return (u ? -1 : 1) * n * r(2, f - t)
            };
        e.exports = {
            pack: a,
            unpack: c
        }
    },
    "780f": function(e, t, n) {
        "use strict";
        e.exports = i;
        var r = n("27bf");

        function i(e) {
            if (!(this instanceof i)) return new i(e);
            r.call(this, e)
        }
        n("3fb5")(i, r), i.prototype._transform = function(e, t, n) {
            n(null, e)
        }
    },
    7839: function(e, t) {
        e.exports = ["constructor", "hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "toLocaleString", "toString", "valueOf"]
    },
    7871: function(e, t, n) {
        (function(t) {
            const n = e.exports;
            n.digitCount = function(e) {
                const t = e < 0 ? 1 : 0;
                return e = Math.abs(Number(e || 1)), Math.floor(Math.log10(e)) + 1 + t
            }, n.getType = function(e) {
                return t.isBuffer(e) ? "buffer" : ArrayBuffer.isView(e) ? "arraybufferview" : Array.isArray(e) ? "array" : e instanceof Number ? "number" : e instanceof Boolean ? "boolean" : e instanceof Set ? "set" : e instanceof Map ? "map" : e instanceof String ? "string" : e instanceof ArrayBuffer ? "arraybuffer" : typeof e
            }
        }).call(this, n("b639").Buffer)
    },
    "7b03": function(e, t) {
        var n, r = 1,
            i = 65535,
            o = 4,
            s = function() {
                r = r + 1 & i
            };
        e.exports = function(e) {
            n || (n = setInterval(s, 1e3 / o | 0), n.unref && n.unref());
            var t = o * (e || 5),
                a = [0],
                c = 1,
                h = r - 1 & i;
            return function(e) {
                var n = r - h & i;
                n > t && (n = t), h = r;
                while (n--) c === t && (c = 0), a[c] = a[0 === c ? t - 1 : c - 1], c++;
                e && (a[c - 1] += e);
                var s = a[c - 1],
                    u = a.length < t ? 0 : a[c === t ? 0 : c];
                return a.length < o ? s : (s - u) * o / a.length
            }
        }
    },
    "7b0b": function(e, t, n) {
        var r = n("1d80");
        e.exports = function(e) {
            return Object(r(e))
        }
    },
    "7c59": function(e, t, n) {
        /*! stream-to-blob-url. MIT License. Feross Aboukhadijeh <https://feross.org/opensource> */
        e.exports = i;
        const r = n("d2b7");
        async function i(e, t) {
            const n = await r(e, t),
                i = URL.createObjectURL(n);
            return i
        }
    },
    "7c73": function(e, t, n) {
        var r, i = n("825a"),
            o = n("37e8"),
            s = n("7839"),
            a = n("d012"),
            c = n("1be4"),
            h = n("cc12"),
            u = n("f772"),
            f = ">",
            d = "<",
            l = "prototype",
            p = "script",
            g = u("IE_PROTO"),
            _ = function() {},
            y = function(e) {
                return d + p + f + e + d + "/" + p + f
            },
            m = function(e) {
                e.write(y("")), e.close();
                var t = e.parentWindow.Object;
                return e = null, t
            },
            b = function() {
                var e, t = h("iframe"),
                    n = "java" + p + ":";
                return t.style.display = "none", c.appendChild(t), t.src = String(n), e = t.contentWindow.document, e.open(), e.write(y("document.F=Object")), e.close(), e.F
            },
            w = function() {
                try {
                    r = new ActiveXObject("htmlfile")
                } catch (t) {}
                w = "undefined" != typeof document ? document.domain && r ? m(r) : b() : m(r);
                var e = s.length;
                while (e--) delete w[l][s[e]];
                return w()
            };
        a[g] = !0, e.exports = Object.create || function(e, t) {
            var n;
            return null !== e ? (_[l] = i(e), n = new _, _[l] = null, n[g] = e) : n = w(), void 0 === t ? n : o(n, t)
        }
    },
    "7f9a": function(e, t, n) {
        var r = n("da84"),
            i = n("8925"),
            o = r.WeakMap;
        e.exports = "function" === typeof o && /native code/.test(i(o))
    },
    8: function(e, t) {},
    8091: function(e, t, n) {
        const r = n("faa1");
        class i extends r {
            constructor(e, t) {
                super(), this.client = e, this.announceUrl = t, this.interval = null, this.destroyed = !1
            }
            setInterval(e) {
                null == e && (e = this.DEFAULT_ANNOUNCE_INTERVAL), clearInterval(this.interval), e && (this.interval = setInterval(() => {
                    this.announce(this.client._defaultAnnounceOpts())
                }, e), this.interval.unref && this.interval.unref())
            }
        }
        e.exports = i
    },
    "81d5": function(e, t, n) {
        "use strict";
        var r = n("7b0b"),
            i = n("23cb"),
            o = n("50c4");
        e.exports = function(e) {
            var t = r(this),
                n = o(t.length),
                s = arguments.length,
                a = i(s > 1 ? arguments[1] : void 0, n),
                c = s > 2 ? arguments[2] : void 0,
                h = void 0 === c ? n : i(c, n);
            while (h > a) t[a++] = e;
            return t
        }
    },
    "81e8": function(e, t, n) {
        "use strict";
        (function(e) {
            function r() {
                const t = Promise.resolve();

                function n(e, ...n) {
                    t.then(() => {
                        e(...n)
                    })
                }
                e.nextTick = n, e.nextTickAsync = () => t.then()
            }
            n.d(t, "a", (function() {
                return r
            }))
        }).call(this, n("4362"))
    },
    "825a": function(e, t, n) {
        var r = n("861d");
        e.exports = function(e) {
            if (!r(e)) throw TypeError(String(e) + " is not an object");
            return e
        }
    },
    "83ab": function(e, t, n) {
        var r = n("d039");
        e.exports = !r((function() {
            return 7 != Object.defineProperty({}, 1, {
                get: function() {
                    return 7
                }
            })[1]
        }))
    },
    "83cc": function(e, t, n) {
        (function(t) { /*! magnet-uri. MIT License. WebTorrent LLC <https://webtorrent.io/opensource> */
            e.exports = o, e.exports.decode = o, e.exports.encode = s;
            const r = n("ac4f"),
                i = n("3bb3");

            function o(e) {
                const n = {},
                    o = e.split("magnet:?")[1],
                    s = o && o.length >= 0 ? o.split("&") : [];
                let a;
                if (s.forEach(e => {
                        const t = e.split("=");
                        if (2 !== t.length) return;
                        const r = t[0];
                        let o = t[1];
                        "dn" === r && (o = decodeURIComponent(o).replace(/\+/g, " ")), "tr" !== r && "xs" !== r && "as" !== r && "ws" !== r || (o = decodeURIComponent(o)), "kt" === r && (o = decodeURIComponent(o).split("+")), "ix" === r && (o = Number(o)), "so" === r && (o = i.parse(decodeURIComponent(o).split(","))), n[r] ? (Array.isArray(n[r]) || (n[r] = [n[r]]), n[r].push(o)) : n[r] = o
                    }), n["x.pe"] && (n["x.pe"] = Array.isArray(n["x.pe"]) ? Array.from(new Set(n["x.pe"])) : [n["x.pe"]]), n.xt) {
                    const e = Array.isArray(n.xt) ? n.xt : [n.xt];
                    e.forEach(e => {
                        if (a = e.match(/^urn:btih:(.{40})/)) n.infoHash = a[1].toLowerCase();
                        else if (a = e.match(/^urn:btih:(.{32})/)) {
                            const e = r.decode(a[1]);
                            n.infoHash = t.from(e, "binary").toString("hex")
                        }
                    })
                }
                return n.infoHash && (n.infoHashBuffer = t.from(n.infoHash, "hex")), n.dn && (n.name = n.dn), n.kt && (n.keywords = n.kt), n["x.pe"] && (n.peerAddresses = n["x.pe"]), "string" === typeof n.tr ? n.announce = [n.tr] : Array.isArray(n.tr) ? n.announce = n.tr : n.announce = [], n.urlList = [], ("string" === typeof n.as || Array.isArray(n.as)) && (n.urlList = n.urlList.concat(n.as)), ("string" === typeof n.ws || Array.isArray(n.ws)) && (n.urlList = n.urlList.concat(n.ws)), n.announce = Array.from(new Set(n.announce)), n.urlList = Array.from(new Set(n.urlList)), n["x.pe"] && (n.x = {
                    pe: n["x.pe"]
                }, delete n["x.pe"]), n
            }

            function s(e) {
                e = Object.assign({}, e), e.infoHashBuffer && (e.xt = "urn:btih:" + e.infoHashBuffer.toString("hex")), e.infoHash && (e.xt = "urn:btih:" + e.infoHash), e.name && (e.dn = e.name), e.keywords && (e.kt = e.keywords), e.announce && (e.tr = e.announce), e.urlList && (e.ws = e.urlList, delete e.as), e.peerAddresses && (e["x.pe"] = e.peerAddresses), e.x && e.x.pe && (e["x.pe"] = e.x.pe);
                let t = "magnet:?";
                return Object.keys(e).filter(e => 2 === e.length || "x.pe" === e).forEach((n, r) => {
                    const o = Array.isArray(e[n]) ? e[n] : [e[n]];
                    o.forEach((e, i) => {
                        (r > 0 || i > 0) && ("kt" !== n && "so" !== n || 0 === i) && (t += "&"), "dn" === n && (e = encodeURIComponent(e).replace(/%20/g, "+")), "tr" !== n && "xs" !== n && "as" !== n && "ws" !== n || (e = encodeURIComponent(e)), "kt" === n && (e = encodeURIComponent(e)), "so" !== n && (t += "kt" === n && i > 0 ? "+" + e : `${n}=${e}`)
                    }), "so" === n && (t += `${n}=${i.compose(o)}`)
                }), t
            }
        }).call(this, n("b639").Buffer)
    },
    "85b1": function(e, t, n) {
        "use strict";
        var r = n("2332"),
            i = n("5ea3"),
            o = "object" == typeof self && self && self.Object === Object && self,
            s = i["a"] || o || Function("return this")(),
            a = s,
            c = function() {
                return a.Date.now()
            },
            h = c,
            u = /\s/;

        function f(e) {
            var t = e.length;
            while (t-- && u.test(e.charAt(t)));
            return t
        }
        var d = f,
            l = /^\s+/;

        function p(e) {
            return e ? e.slice(0, d(e) + 1).replace(l, "") : e
        }
        var g = p,
            _ = a.Symbol,
            y = _,
            m = Object.prototype,
            b = m.hasOwnProperty,
            w = m.toString,
            v = y ? y.toStringTag : void 0;

        function E(e) {
            var t = b.call(e, v),
                n = e[v];
            try {
                e[v] = void 0;
                var r = !0
            } catch (o) {}
            var i = w.call(e);
            return r && (t ? e[v] = n : delete e[v]), i
        }
        var T = E,
            R = Object.prototype,
            S = R.toString;

        function I(e) {
            return S.call(e)
        }
        var O = I,
            k = "[object Null]",
            A = "[object Undefined]",
            C = y ? y.toStringTag : void 0;

        function x(e) {
            return null == e ? void 0 === e ? A : k : C && C in Object(e) ? T(e) : O(e)
        }
        var N = x;

        function P(e) {
            return null != e && "object" == typeof e
        }
        var L = P,
            M = "[object Symbol]";

        function D(e) {
            return "symbol" == typeof e || L(e) && N(e) == M
        }
        var U = D,
            B = NaN,
            j = /^[-+]0x[0-9a-f]+$/i,
            F = /^0b[01]+$/i,
            H = /^0o[0-7]+$/i,
            G = parseInt;

        function W(e) {
            if ("number" == typeof e) return e;
            if (U(e)) return B;
            if (Object(r["a"])(e)) {
                var t = "function" == typeof e.valueOf ? e.valueOf() : e;
                e = Object(r["a"])(t) ? t + "" : t
            }
            if ("string" != typeof e) return 0 === e ? e : +e;
            e = g(e);
            var n = F.test(e);
            return n || H.test(e) ? G(e.slice(2), n ? 2 : 8) : j.test(e) ? B : +e
        }
        var q = W,
            $ = "Expected a function",
            Y = Math.max,
            z = Math.min;

        function V(e, t, n) {
            var i, o, s, a, c, u, f = 0,
                d = !1,
                l = !1,
                p = !0;
            if ("function" != typeof e) throw new TypeError($);

            function g(t) {
                var n = i,
                    r = o;
                return i = o = void 0, f = t, a = e.apply(r, n), a
            }

            function _(e) {
                return f = e, c = setTimeout(b, t), d ? g(e) : a
            }

            function y(e) {
                var n = e - u,
                    r = e - f,
                    i = t - n;
                return l ? z(i, s - r) : i
            }

            function m(e) {
                var n = e - u,
                    r = e - f;
                return void 0 === u || n >= t || n < 0 || l && r >= s
            }

            function b() {
                var e = h();
                if (m(e)) return w(e);
                c = setTimeout(b, y(e))
            }

            function w(e) {
                return c = void 0, p && i ? g(e) : (i = o = void 0, a)
            }

            function v() {
                void 0 !== c && clearTimeout(c), f = 0, i = u = o = c = void 0
            }

            function E() {
                return void 0 === c ? a : w(h())
            }

            function T() {
                var e = h(),
                    n = m(e);
                if (i = arguments, o = this, u = e, n) {
                    if (void 0 === c) return _(u);
                    if (l) return clearTimeout(c), c = setTimeout(b, t), g(u)
                }
                return void 0 === c && (c = setTimeout(b, t)), a
            }
            return t = q(t) || 0, Object(r["a"])(n) && (d = !!n.leading, l = "maxWait" in n, s = l ? Y(q(n.maxWait) || 0, t) : s, p = "trailing" in n ? !!n.trailing : p), T.cancel = v, T.flush = E, T
        }
        t["a"] = V
    },
    "861d": function(e, t) {
        e.exports = function(e) {
            return "object" === typeof e ? null !== e : "function" === typeof e
        }
    },
    8707: function(e, t, n) {
        /*! safe-buffer. MIT License. Feross Aboukhadijeh <https://feross.org/opensource> */
        var r = n("b639"),
            i = r.Buffer;

        function o(e, t) {
            for (var n in e) t[n] = e[n]
        }

        function s(e, t, n) {
            return i(e, t, n)
        }
        i.from && i.alloc && i.allocUnsafe && i.allocUnsafeSlow ? e.exports = r : (o(r, t), t.Buffer = s), s.prototype = Object.create(i.prototype), o(i, s), s.from = function(e, t, n) {
            if ("number" === typeof e) throw new TypeError("Argument must not be a number");
            return i(e, t, n)
        }, s.alloc = function(e, t, n) {
            if ("number" !== typeof e) throw new TypeError("Argument must be a number");
            var r = i(e);
            return void 0 !== t ? "string" === typeof n ? r.fill(t, n) : r.fill(t) : r.fill(0), r
        }, s.allocUnsafe = function(e) {
            if ("number" !== typeof e) throw new TypeError("Argument must be a number");
            return i(e)
        }, s.allocUnsafeSlow = function(e) {
            if ("number" !== typeof e) throw new TypeError("Argument must be a number");
            return r.SlowBuffer(e)
        }
    },
    8712: function(e, t, n) {
        (function(t) { /*! queue-microtask. MIT License. Feross Aboukhadijeh <https://feross.org/opensource> */
            let n;
            e.exports = "function" === typeof queueMicrotask ? queueMicrotask.bind("undefined" !== typeof window ? window : t) : e => (n || (n = Promise.resolve())).then(e).catch(e => setTimeout(() => {
                throw e
            }, 0))
        }).call(this, n("c8ba"))
    },
    8925: function(e, t, n) {
        var r = n("c6cd"),
            i = Function.toString;
        "function" != typeof r.inspectSource && (r.inspectSource = function(e) {
            return i.call(e)
        }), e.exports = r.inspectSource
    },
    "8aa7": function(e, t, n) {
        var r = n("da84"),
            i = n("d039"),
            o = n("1c7e"),
            s = n("ebb5").NATIVE_ARRAY_BUFFER_VIEWS,
            a = r.ArrayBuffer,
            c = r.Int8Array;
        e.exports = !s || !i((function() {
            c(1)
        })) || !i((function() {
            new c(-1)
        })) || !o((function(e) {
            new c, new c(null), new c(1.5), new c(e)
        }), !0) || i((function() {
            return 1 !== new c(new a(2), 1, void 0).length
        }))
    },
    "8c05": function(e, t) {
        e.exports = {
            100: "Continue",
            101: "Switching Protocols",
            102: "Processing",
            200: "OK",
            201: "Created",
            202: "Accepted",
            203: "Non-Authoritative Information",
            204: "No Content",
            205: "Reset Content",
            206: "Partial Content",
            207: "Multi-Status",
            208: "Already Reported",
            226: "IM Used",
            300: "Multiple Choices",
            301: "Moved Permanently",
            302: "Found",
            303: "See Other",
            304: "Not Modified",
            305: "Use Proxy",
            307: "Temporary Redirect",
            308: "Permanent Redirect",
            400: "Bad Request",
            401: "Unauthorized",
            402: "Payment Required",
            403: "Forbidden",
            404: "Not Found",
            405: "Method Not Allowed",
            406: "Not Acceptable",
            407: "Proxy Authentication Required",
            408: "Request Timeout",
            409: "Conflict",
            410: "Gone",
            411: "Length Required",
            412: "Precondition Failed",
            413: "Payload Too Large",
            414: "URI Too Long",
            415: "Unsupported Media Type",
            416: "Range Not Satisfiable",
            417: "Expectation Failed",
            418: "I'm a teapot",
            421: "Misdirected Request",
            422: "Unprocessable Entity",
            423: "Locked",
            424: "Failed Dependency",
            425: "Unordered Collection",
            426: "Upgrade Required",
            428: "Precondition Required",
            429: "Too Many Requests",
            431: "Request Header Fields Too Large",
            451: "Unavailable For Legal Reasons",
            500: "Internal Server Error",
            501: "Not Implemented",
            502: "Bad Gateway",
            503: "Service Unavailable",
            504: "Gateway Timeout",
            505: "HTTP Version Not Supported",
            506: "Variant Also Negotiates",
            507: "Insufficient Storage",
            508: "Loop Detected",
            509: "Bandwidth Limit Exceeded",
            510: "Not Extended",
            511: "Network Authentication Required"
        }
    },
    "8c32": function(e, t, n) {
        "use strict";
        n.d(t, "c", (function() {
            return r
        })), n.d(t, "i", (function() {
            return i
        })), n.d(t, "h", (function() {
            return o
        })), n.d(t, "g", (function() {
            return s
        })), n.d(t, "a", (function() {
            return a
        })), n.d(t, "d", (function() {
            return c
        })), n.d(t, "b", (function() {
            return h
        })), n.d(t, "f", (function() {
            return u
        })), n.d(t, "e", (function() {
            return d
        }));
        n("5cc6"), n("219c");
        const r = console.log;

        function i(e, t) {
            return new Promise(n => setTimeout(() => n(t), e))
        }

        function o(e, t, n) {
            let r;
            const i = new Promise((e, i) => {
                r = setTimeout(() => {
                    const e = new Error("Promise timed out");
                    i(n || e)
                }, t)
            });
            return Promise.race([e, i]).finally(() => clearTimeout(r))
        }

        function s(e = "-") {
            const t = (new Date).getTime(),
                n = String(Math.random()).slice(2, 11);
            return t + e + n
        }
        class a {
            constructor() {
                this.promise = new Promise((e, t) => {
                    this.reject = t, this.resolve = e
                })
            }
        }

        function c(e) {
            const {
                name: t,
                message: n,
                stack: r
            } = e;
            return {
                name: t,
                message: n,
                stack: r
            }
        }

        function h(e = "") {
            const t = [],
                n = e.split(".");
            n.length > 1 && t.splice(0, 0, n.pop()), n.length > 1 && n[n.length - 1].length <= 2 && t.splice(0, 0, n.pop()), t.splice(0, 0, n.pop());
            let r = t.join(".");
            return r = r.charAt(0).toUpperCase() + r.substring(1), r
        }

        function u(e, t, n, r) {
            return `${e}/${f(t,n,r)}`
        }

        function f(e, t, n) {
            return `${e}/${n}/${t}.${n}`
        }

        function d(e) {
            const t = {};
            for (const [n, r] of Object.entries(e)) t[n] = [r.isSeeding ? 1 : 0, r.hasTorrentFile ? 1 : 0, r.clientName || "", r.chunkIndexes || [], r.uploaded || 0, r.downloaded || 0, r.expiresAt || null, r.seedTaskDate || null, r.accessTime || null];
            return t
        }
    },
    "8cc1": function(e, t, n) {
        /*! run-parallel. MIT License. Feross Aboukhadijeh <https://feross.org/opensource> */
        e.exports = i;
        const r = n("8712");

        function i(e, t) {
            let n, i, o, s = !0;

            function a(e) {
                function i() {
                    t && t(e, n), t = null
                }
                s ? r(i) : i()
            }

            function c(e, t, r) {
                n[e] = r, (0 === --i || t) && a(t)
            }
            Array.isArray(e) ? (n = [], i = e.length) : (o = Object.keys(e), n = {}, i = o.length), i ? o ? o.forEach((function(t) {
                e[t]((function(e, n) {
                    c(t, e, n)
                }))
            })) : e.forEach((function(e, t) {
                e((function(e, n) {
                    c(t, e, n)
                }))
            })) : a(null), s = !1
        }
    },
    "8fe2": function(e, t, n) {
        const r = e.exports;
        r.encode = n("4cdf"), r.decode = n("1131"), r.byteLength = r.encodingLength = n("7130")
    },
    "8fe5": function(e, t, n) {
        (function(t) {
            const r = n("34eb")("simple-websocket"),
                i = n("11dc"),
                o = n("e372"),
                s = n("8712"),
                a = n(2),
                c = "function" !== typeof a ? WebSocket : a,
                h = 65536;
            class u extends o.Duplex {
                constructor(e = {}) {
                    if ("string" === typeof e && (e = {
                            url: e
                        }), e = Object.assign({
                            allowHalfOpen: !1
                        }, e), super(e), null == e.url && null == e.socket) throw new Error("Missing required `url` or `socket` option");
                    if (null != e.url && null != e.socket) throw new Error("Must specify either `url` or `socket` option, not both");
                    if (this._id = i(4).toString("hex").slice(0, 7), this._debug("new websocket: %o", e), this.connected = !1, this.destroyed = !1, this._chunk = null, this._cb = null, this._interval = null, e.socket) this.url = e.socket.url, this._ws = e.socket, this.connected = e.socket.readyState === c.OPEN;
                    else {
                        this.url = e.url;
                        try {
                            this._ws = "function" === typeof a ? new c(e.url, e) : new c(e.url)
                        } catch (t) {
                            return void s(() => this.destroy(t))
                        }
                    }
                    this._ws.binaryType = "arraybuffer", this._ws.onopen = () => {
                        this._onOpen()
                    }, this._ws.onmessage = e => {
                        this._onMessage(e)
                    }, this._ws.onclose = () => {
                        this._onClose()
                    }, this._ws.onerror = () => {
                        this.destroy(new Error("connection error to " + this.url))
                    }, this._onFinishBound = () => {
                        this._onFinish()
                    }, this.once("finish", this._onFinishBound)
                }
                send(e) {
                    this._ws.send(e)
                }
                destroy(e) {
                    this._destroy(e, () => {})
                }
                _destroy(e, t) {
                    if (!this.destroyed) {
                        if (this._debug("destroy (error: %s)", e && (e.message || e)), this.readable = this.writable = !1, this._readableState.ended || this.push(null), this._writableState.finished || this.end(), this.connected = !1, this.destroyed = !0, clearInterval(this._interval), this._interval = null, this._chunk = null, this._cb = null, this._onFinishBound && this.removeListener("finish", this._onFinishBound), this._onFinishBound = null, this._ws) {
                            const t = this._ws,
                                n = () => {
                                    t.onclose = null
                                };
                            if (t.readyState === c.CLOSED) n();
                            else try {
                                t.onclose = n, t.close()
                            } catch (e) {
                                n()
                            }
                            t.onopen = null, t.onmessage = null, t.onerror = () => {}
                        }
                        if (this._ws = null, e) {
                            if ("undefined" !== typeof DOMException && e instanceof DOMException) {
                                const t = e.code;
                                e = new Error(e.message), e.code = t
                            }
                            this.emit("error", e)
                        }
                        this.emit("close"), t()
                    }
                }
                _read() {}
                _write(e, t, n) {
                    if (this.destroyed) return n(new Error("cannot write after socket is destroyed"));
                    if (this.connected) {
                        try {
                            this.send(e)
                        } catch (r) {
                            return this.destroy(r)
                        }
                        "function" !== typeof a && this._ws.bufferedAmount > h ? (this._debug("start backpressure: bufferedAmount %d", this._ws.bufferedAmount), this._cb = n) : n(null)
                    } else this._debug("write before connect"), this._chunk = e, this._cb = n
                }
                _onFinish() {
                    if (this.destroyed) return;
                    const e = () => {
                        setTimeout(() => this.destroy(), 1e3)
                    };
                    this.connected ? e() : this.once("connect", e)
                }
                _onMessage(e) {
                    if (this.destroyed) return;
                    let n = e.data;
                    n instanceof ArrayBuffer && (n = t.from(n)), this.push(n)
                }
                _onOpen() {
                    if (!this.connected && !this.destroyed) {
                        if (this.connected = !0, this._chunk) {
                            try {
                                this.send(this._chunk)
                            } catch (e) {
                                return this.destroy(e)
                            }
                            this._chunk = null, this._debug('sent chunk from "write before connect"');
                            const t = this._cb;
                            this._cb = null, t(null)
                        }
                        "function" !== typeof a && (this._interval = setInterval(() => this._onInterval(), 150), this._interval.unref && this._interval.unref()), this._debug("connect"), this.emit("connect")
                    }
                }
                _onInterval() {
                    if (!this._cb || !this._ws || this._ws.bufferedAmount > h) return;
                    this._debug("ending backpressure: bufferedAmount %d", this._ws.bufferedAmount);
                    const e = this._cb;
                    this._cb = null, e(null)
                }
                _onClose() {
                    this.destroyed || (this._debug("on close"), this.destroy())
                }
                _debug() {
                    const e = [].slice.call(arguments);
                    e[0] = "[" + this._id + "] " + e[0], r.apply(null, e)
                }
            }
            u.WEBSOCKET_SUPPORT = !!c, e.exports = u
        }).call(this, n("b639").Buffer)
    },
    9: function(e, t) {},
    "903c": function(e, t, n) {
        "use strict";
        var r = n("c9b8").codes.ERR_STREAM_PREMATURE_CLOSE;

        function i(e) {
            var t = !1;
            return function() {
                if (!t) {
                    t = !0;
                    for (var n = arguments.length, r = new Array(n), i = 0; i < n; i++) r[i] = arguments[i];
                    e.apply(this, r)
                }
            }
        }

        function o() {}

        function s(e) {
            return e.setHeader && "function" === typeof e.abort
        }

        function a(e, t, n) {
            if ("function" === typeof t) return a(e, null, t);
            t || (t = {}), n = i(n || o);
            var c = t.readable || !1 !== t.readable && e.readable,
                h = t.writable || !1 !== t.writable && e.writable,
                u = function() {
                    e.writable || d()
                },
                f = e._writableState && e._writableState.finished,
                d = function() {
                    h = !1, f = !0, c || n.call(e)
                },
                l = e._readableState && e._readableState.endEmitted,
                p = function() {
                    c = !1, l = !0, h || n.call(e)
                },
                g = function(t) {
                    n.call(e, t)
                },
                _ = function() {
                    var t;
                    return c && !l ? (e._readableState && e._readableState.ended || (t = new r), n.call(e, t)) : h && !f ? (e._writableState && e._writableState.ended || (t = new r), n.call(e, t)) : void 0
                },
                y = function() {
                    e.req.on("finish", d)
                };
            return s(e) ? (e.on("complete", d), e.on("abort", _), e.req ? y() : e.on("request", y)) : h && !e._writableState && (e.on("end", u), e.on("close", u)), e.on("end", p), e.on("finish", d), !1 !== t.error && e.on("error", g), e.on("close", _),
                function() {
                    e.removeListener("complete", d), e.removeListener("abort", _), e.removeListener("request", y), e.req && e.req.removeListener("finish", d), e.removeListener("end", u), e.removeListener("close", u), e.removeListener("finish", d), e.removeListener("end", p), e.removeListener("error", g), e.removeListener("close", _)
                }
        }
        e.exports = a
    },
    "90e3": function(e, t) {
        var n = 0,
            r = Math.random();
        e.exports = function(e) {
            return "Symbol(" + String(void 0 === e ? "" : e) + ")_" + (++n + r).toString(36)
        }
    },
    9112: function(e, t, n) {
        var r = n("83ab"),
            i = n("9bf2"),
            o = n("5c6c");
        e.exports = r ? function(e, t, n) {
            return i.f(e, t, o(1, n))
        } : function(e, t, n) {
            return e[t] = n, e
        }
    },
    9152: function(e, t) {
        /*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> */
        t.read = function(e, t, n, r, i) {
            var o, s, a = 8 * i - r - 1,
                c = (1 << a) - 1,
                h = c >> 1,
                u = -7,
                f = n ? i - 1 : 0,
                d = n ? -1 : 1,
                l = e[t + f];
            for (f += d, o = l & (1 << -u) - 1, l >>= -u, u += a; u > 0; o = 256 * o + e[t + f], f += d, u -= 8);
            for (s = o & (1 << -u) - 1, o >>= -u, u += r; u > 0; s = 256 * s + e[t + f], f += d, u -= 8);
            if (0 === o) o = 1 - h;
            else {
                if (o === c) return s ? NaN : 1 / 0 * (l ? -1 : 1);
                s += Math.pow(2, r), o -= h
            }
            return (l ? -1 : 1) * s * Math.pow(2, o - r)
        }, t.write = function(e, t, n, r, i, o) {
            var s, a, c, h = 8 * o - i - 1,
                u = (1 << h) - 1,
                f = u >> 1,
                d = 23 === i ? Math.pow(2, -24) - Math.pow(2, -77) : 0,
                l = r ? 0 : o - 1,
                p = r ? 1 : -1,
                g = t < 0 || 0 === t && 1 / t < 0 ? 1 : 0;
            for (t = Math.abs(t), isNaN(t) || t === 1 / 0 ? (a = isNaN(t) ? 1 : 0, s = u) : (s = Math.floor(Math.log(t) / Math.LN2), t * (c = Math.pow(2, -s)) < 1 && (s--, c *= 2), t += s + f >= 1 ? d / c : d * Math.pow(2, 1 - f), t * c >= 2 && (s++, c /= 2), s + f >= u ? (a = 0, s = u) : s + f >= 1 ? (a = (t * c - 1) * Math.pow(2, i), s += f) : (a = t * Math.pow(2, f - 1) * Math.pow(2, i), s = 0)); i >= 8; e[n + l] = 255 & a, l += p, a /= 256, i -= 8);
            for (s = s << i | a, h += i; h > 0; e[n + l] = 255 & s, l += p, s /= 256, h -= 8);
            e[n + l - p] |= 128 * g
        }
    },
    "91dd": function(e, t, n) {
        "use strict";

        function r(e, t) {
            return Object.prototype.hasOwnProperty.call(e, t)
        }
        e.exports = function(e, t, n, o) {
            t = t || "&", n = n || "=";
            var s = {};
            if ("string" !== typeof e || 0 === e.length) return s;
            var a = /\+/g;
            e = e.split(t);
            var c = 1e3;
            o && "number" === typeof o.maxKeys && (c = o.maxKeys);
            var h = e.length;
            c > 0 && h > c && (h = c);
            for (var u = 0; u < h; ++u) {
                var f, d, l, p, g = e[u].replace(a, "%20"),
                    _ = g.indexOf(n);
                _ >= 0 ? (f = g.substr(0, _), d = g.substr(_ + 1)) : (f = g, d = ""), l = decodeURIComponent(f), p = decodeURIComponent(d), r(s, l) ? i(s[l]) ? s[l].push(p) : s[l] = [s[l], p] : s[l] = p
            }
            return s
        };
        var i = Array.isArray || function(e) {
            return "[object Array]" === Object.prototype.toString.call(e)
        }
    },
    "925e": function(e, t, n) {
        (function(t, r, i) {
            var o = n("a9f1"),
                s = n("3fb5"),
                a = n("c90b"),
                c = n("e372"),
                h = n("d938"),
                u = a.IncomingMessage,
                f = a.readyStates;

            function d(e, t) {
                return o.fetch && t ? "fetch" : o.mozchunkedarraybuffer ? "moz-chunked-arraybuffer" : o.msstream ? "ms-stream" : o.arraybuffer && e ? "arraybuffer" : o.vbArray && e ? "text:vbarray" : "text"
            }
            var l = e.exports = function(e) {
                var n, r = this;
                c.Writable.call(r), r._opts = e, r._body = [], r._headers = {}, e.auth && r.setHeader("Authorization", "Basic " + new t(e.auth).toString("base64")), Object.keys(e.headers).forEach((function(t) {
                    r.setHeader(t, e.headers[t])
                }));
                var i = !0;
                if ("disable-fetch" === e.mode || "requestTimeout" in e && !o.abortController) i = !1, n = !0;
                else if ("prefer-streaming" === e.mode) n = !1;
                else if ("allow-wrong-content-type" === e.mode) n = !o.overrideMimeType;
                else {
                    if (e.mode && "default" !== e.mode && "prefer-fast" !== e.mode) throw new Error("Invalid value for opts.mode");
                    n = !0
                }
                r._mode = d(n, i), r._fetchTimer = null, r.on("finish", (function() {
                    r._onFinish()
                }))
            };

            function p(e) {
                try {
                    var t = e.status;
                    return null !== t && 0 !== t
                } catch (n) {
                    return !1
                }
            }
            s(l, c.Writable), l.prototype.setHeader = function(e, t) {
                var n = this,
                    r = e.toLowerCase(); - 1 === g.indexOf(r) && (n._headers[r] = {
                    name: e,
                    value: t
                })
            }, l.prototype.getHeader = function(e) {
                var t = this._headers[e.toLowerCase()];
                return t ? t.value : null
            }, l.prototype.removeHeader = function(e) {
                var t = this;
                delete t._headers[e.toLowerCase()]
            }, l.prototype._onFinish = function() {
                var e = this;
                if (!e._destroyed) {
                    var n = e._opts,
                        s = e._headers,
                        a = null;
                    "GET" !== n.method && "HEAD" !== n.method && (a = o.arraybuffer ? h(t.concat(e._body)) : o.blobConstructor ? new r.Blob(e._body.map((function(e) {
                        return h(e)
                    })), {
                        type: (s["content-type"] || {}).value || ""
                    }) : t.concat(e._body).toString());
                    var c = [];
                    if (Object.keys(s).forEach((function(e) {
                            var t = s[e].name,
                                n = s[e].value;
                            Array.isArray(n) ? n.forEach((function(e) {
                                c.push([t, e])
                            })) : c.push([t, n])
                        })), "fetch" === e._mode) {
                        var u = null;
                        if (o.abortController) {
                            var d = new AbortController;
                            u = d.signal, e._fetchAbortController = d, "requestTimeout" in n && 0 !== n.requestTimeout && (e._fetchTimer = r.setTimeout((function() {
                                e.emit("requestTimeout"), e._fetchAbortController && e._fetchAbortController.abort()
                            }), n.requestTimeout))
                        }
                        r.fetch(e._opts.url, {
                            method: e._opts.method,
                            headers: c,
                            body: a || void 0,
                            mode: "cors",
                            credentials: n.withCredentials ? "include" : "same-origin",
                            signal: u
                        }).then((function(t) {
                            e._fetchResponse = t, e._connect()
                        }), (function(t) {
                            r.clearTimeout(e._fetchTimer), e._destroyed || e.emit("error", t)
                        }))
                    } else {
                        var l = e._xhr = new r.XMLHttpRequest;
                        try {
                            l.open(e._opts.method, e._opts.url, !0)
                        } catch (p) {
                            return void i.nextTick((function() {
                                e.emit("error", p)
                            }))
                        }
                        "responseType" in l && (l.responseType = e._mode.split(":")[0]), "withCredentials" in l && (l.withCredentials = !!n.withCredentials), "text" === e._mode && "overrideMimeType" in l && l.overrideMimeType("text/plain; charset=x-user-defined"), "requestTimeout" in n && (l.timeout = n.requestTimeout, l.ontimeout = function() {
                            e.emit("requestTimeout")
                        }), c.forEach((function(e) {
                            l.setRequestHeader(e[0], e[1])
                        })), e._response = null, l.onreadystatechange = function() {
                            switch (l.readyState) {
                                case f.LOADING:
                                case f.DONE:
                                    e._onXHRProgress();
                                    break
                            }
                        }, "moz-chunked-arraybuffer" === e._mode && (l.onprogress = function() {
                            e._onXHRProgress()
                        }), l.onerror = function() {
                            e._destroyed || e.emit("error", new Error("XHR error"))
                        };
                        try {
                            l.send(a)
                        } catch (p) {
                            return void i.nextTick((function() {
                                e.emit("error", p)
                            }))
                        }
                    }
                }
            }, l.prototype._onXHRProgress = function() {
                var e = this;
                p(e._xhr) && !e._destroyed && (e._response || e._connect(), e._response._onXHRProgress())
            }, l.prototype._connect = function() {
                var e = this;
                e._destroyed || (e._response = new u(e._xhr, e._fetchResponse, e._mode, e._fetchTimer), e._response.on("error", (function(t) {
                    e.emit("error", t)
                })), e.emit("response", e._response))
            }, l.prototype._write = function(e, t, n) {
                var r = this;
                r._body.push(e), n()
            }, l.prototype.abort = l.prototype.destroy = function() {
                var e = this;
                e._destroyed = !0, r.clearTimeout(e._fetchTimer), e._response && (e._response._destroyed = !0), e._xhr ? e._xhr.abort() : e._fetchAbortController && e._fetchAbortController.abort()
            }, l.prototype.end = function(e, t, n) {
                var r = this;
                "function" === typeof e && (n = e, e = void 0), c.Writable.prototype.end.call(r, e, t, n)
            }, l.prototype.flushHeaders = function() {}, l.prototype.setTimeout = function() {}, l.prototype.setNoDelay = function() {}, l.prototype.setSocketKeepAlive = function() {};
            var g = ["accept-charset", "accept-encoding", "access-control-request-headers", "access-control-request-method", "connection", "content-length", "cookie", "cookie2", "date", "dnt", "expect", "host", "keep-alive", "origin", "referer", "te", "trailer", "transfer-encoding", "upgrade", "via"]
        }).call(this, n("b639").Buffer, n("c8ba"), n("4362"))
    },
    9490: function(e, t, n) {
        (function(e) {
            var r = n("925e"),
                i = n("c90b"),
                o = n("53a8"),
                s = n("8c05"),
                a = n("cffb"),
                c = t;
            c.request = function(t, n) {
                t = "string" === typeof t ? a.parse(t) : o(t);
                var i = -1 === e.location.protocol.search(/^https?:$/) ? "http:" : "",
                    s = t.protocol || i,
                    c = t.hostname || t.host,
                    h = t.port,
                    u = t.path || "/";
                c && -1 !== c.indexOf(":") && (c = "[" + c + "]"), t.url = (c ? s + "//" + c : "") + (h ? ":" + h : "") + u, t.method = (t.method || "GET").toUpperCase(), t.headers = t.headers || {};
                var f = new r(t);
                return n && f.on("response", n), f
            }, c.get = function(e, t) {
                var n = c.request(e, t);
                return n.end(), n
            }, c.ClientRequest = r, c.IncomingMessage = i.IncomingMessage, c.Agent = function() {}, c.Agent.defaultMaxSockets = 4, c.globalAgent = new c.Agent, c.STATUS_CODES = s, c.METHODS = ["CHECKOUT", "CONNECT", "COPY", "DELETE", "GET", "HEAD", "LOCK", "M-SEARCH", "MERGE", "MKACTIVITY", "MKCOL", "MOVE", "NOTIFY", "OPTIONS", "PATCH", "POST", "PROPFIND", "PROPPATCH", "PURGE", "PUT", "REPORT", "SEARCH", "SUBSCRIBE", "TRACE", "UNLOCK", "UNSUBSCRIBE"]
        }).call(this, n("c8ba"))
    },
    "94ca": function(e, t, n) {
        var r = n("d039"),
            i = /#|\.prototype\./,
            o = function(e, t) {
                var n = a[s(e)];
                return n == h || n != c && ("function" == typeof t ? r(t) : !!t)
            },
            s = o.normalize = function(e) {
                return String(e).replace(i, ".").toLowerCase()
            },
            a = o.data = {},
            c = o.NATIVE = "N",
            h = o.POLYFILL = "P";
        e.exports = o
    },
    "94e2": function(e, t) {},
    "9b16": function(e, t, n) {
        "use strict";
        n.d(t, "b", (function() {
            return a
        })), n.d(t, "a", (function() {
            return c
        }));
        var r = n("3d15"),
            i = n("a5a5"),
            o = n("8c32");
        const {
            COMLINK_INIT: s
        } = i["k"];
        async function a(e, t = {}, n = null) {
            const i = new MessageChannel,
                a = new MessageChannel,
                c = i.port2,
                h = a.port2,
                u = {
                    arcEvent: s,
                    wrappedPort: c,
                    exposedPort: h
                };
            "undefined" !== typeof window && (u.parentUrl = window.location.href);
            const f = [c, h],
                d = [u, f];
            null !== n && d.splice(1, 0, n), e.postMessage(...d);
            const l = r["e"](i.port1),
                p = new o["a"],
                g = p.resolve,
                _ = p.reject,
                y = { ...t,
                    _confirmRpc: g,
                    _rejectRpc: _
                };
            return r["a"](y, a.port1), await p.promise, l
        }
        async function c(e, t) {
            const [n, i] = t;
            r["a"](e, n);
            const o = r["e"](i);
            await o._confirmRpc()
        }
    },
    "9bf2": function(e, t, n) {
        var r = n("83ab"),
            i = n("0cfb"),
            o = n("825a"),
            s = n("a04b"),
            a = Object.defineProperty;
        t.f = r ? a : function(e, t, n) {
            if (o(e), t = s(t), o(n), i) try {
                return a(e, t, n)
            } catch (r) {}
            if ("get" in n || "set" in n) throw TypeError("Accessors not supported");
            return "value" in n && (e[t] = n.value), e
        }
    },
    "9c0e": function(e, t, n) {
        "use strict";
        (function(t) {
            var r;

            function i(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            var o = n("903c"),
                s = Symbol("lastResolve"),
                a = Symbol("lastReject"),
                c = Symbol("error"),
                h = Symbol("ended"),
                u = Symbol("lastPromise"),
                f = Symbol("handlePromise"),
                d = Symbol("stream");

            function l(e, t) {
                return {
                    value: e,
                    done: t
                }
            }

            function p(e) {
                var t = e[s];
                if (null !== t) {
                    var n = e[d].read();
                    null !== n && (e[u] = null, e[s] = null, e[a] = null, t(l(n, !1)))
                }
            }

            function g(e) {
                t.nextTick(p, e)
            }

            function _(e, t) {
                return function(n, r) {
                    e.then((function() {
                        t[h] ? n(l(void 0, !0)) : t[f](n, r)
                    }), r)
                }
            }
            var y = Object.getPrototypeOf((function() {})),
                m = Object.setPrototypeOf((r = {
                    get stream() {
                        return this[d]
                    },
                    next: function() {
                        var e = this,
                            n = this[c];
                        if (null !== n) return Promise.reject(n);
                        if (this[h]) return Promise.resolve(l(void 0, !0));
                        if (this[d].destroyed) return new Promise((function(n, r) {
                            t.nextTick((function() {
                                e[c] ? r(e[c]) : n(l(void 0, !0))
                            }))
                        }));
                        var r, i = this[u];
                        if (i) r = new Promise(_(i, this));
                        else {
                            var o = this[d].read();
                            if (null !== o) return Promise.resolve(l(o, !1));
                            r = new Promise(this[f])
                        }
                        return this[u] = r, r
                    }
                }, i(r, Symbol.asyncIterator, (function() {
                    return this
                })), i(r, "return", (function() {
                    var e = this;
                    return new Promise((function(t, n) {
                        e[d].destroy(null, (function(e) {
                            e ? n(e) : t(l(void 0, !0))
                        }))
                    }))
                })), r), y),
                b = function(e) {
                    var t, n = Object.create(m, (t = {}, i(t, d, {
                        value: e,
                        writable: !0
                    }), i(t, s, {
                        value: null,
                        writable: !0
                    }), i(t, a, {
                        value: null,
                        writable: !0
                    }), i(t, c, {
                        value: null,
                        writable: !0
                    }), i(t, h, {
                        value: e._readableState.endEmitted,
                        writable: !0
                    }), i(t, f, {
                        value: function(e, t) {
                            var r = n[d].read();
                            r ? (n[u] = null, n[s] = null, n[a] = null, e(l(r, !1))) : (n[s] = e, n[a] = t)
                        },
                        writable: !0
                    }), t));
                    return n[u] = null, o(e, (function(e) {
                        if (e && "ERR_STREAM_PREMATURE_CLOSE" !== e.code) {
                            var t = n[a];
                            return null !== t && (n[u] = null, n[s] = null, n[a] = null, t(e)), void(n[c] = e)
                        }
                        var r = n[s];
                        null !== r && (n[u] = null, n[s] = null, n[a] = null, r(l(void 0, !0))), n[h] = !0
                    })), e.on("readable", g.bind(null, n)), n
                };
            e.exports = b
        }).call(this, n("4362"))
    },
    "9c5d": function(e, t, n) {
        (function(t) {
            const r = n("d329"),
                i = n("34eb")("webtorrent:webconn"),
                o = n("c7ba"),
                s = n("2a3b"),
                a = n("0809");
            n("af39").version;
            class c extends a {
                constructor(e, t) {
                    super(), this.url = e, this.webPeerId = s.sync(e), this._torrent = t, this._init()
                }
                _init() {
                    this.setKeepAlive(!0), this.once("handshake", (e, t) => {
                        if (this.destroyed) return;
                        this.handshake(e, this.webPeerId);
                        const n = this._torrent.pieces.length,
                            i = new r(n);
                        for (let r = 0; r <= n; r++) i.set(r, !0);
                        this.bitfield(i)
                    }), this.once("interested", () => {
                        i("interested"), this.unchoke()
                    }), this.on("uninterested", () => {
                        i("uninterested")
                    }), this.on("choke", () => {
                        i("choke")
                    }), this.on("unchoke", () => {
                        i("unchoke")
                    }), this.on("bitfield", () => {
                        i("bitfield")
                    }), this.on("request", (e, t, n, r) => {
                        i("request pieceIndex=%d offset=%d length=%d", e, t, n), this.httpRequest(e, t, n, r)
                    })
                }
                httpRequest(e, n, r, s) {
                    const a = e * this._torrent.pieceLength,
                        c = a + n,
                        h = c + r - 1,
                        u = this._torrent.files;
                    let f;
                    if (u.length <= 1) f = [{
                        url: this.url,
                        start: c,
                        end: h
                    }];
                    else {
                        const e = u.filter(e => e.offset <= h && e.offset + e.length > c);
                        if (e.length < 1) return s(new Error("Could not find file corresponnding to web seed range request"));
                        f = e.map(e => {
                            const t = e.offset + e.length - 1,
                                n = this.url + ("/" === this.url[this.url.length - 1] ? "" : "/") + e.path;
                            return {
                                url: n,
                                fileOffsetInRange: Math.max(e.offset - c, 0),
                                start: Math.max(c - e.offset, 0),
                                end: Math.min(t, h - e.offset)
                            }
                        })
                    }
                    let d, l = 0,
                        p = !1;
                    f.length > 1 && (d = t.alloc(r)), f.forEach(t => {
                        let a = t.url;
                        const c = t.start,
                            h = t.end;
                        i("Requesting url=%s pieceIndex=%d offset=%d length=%d start=%d end=%d", a, e, n, r, c, h);
                        const u = new URL(a);
                        u.searchParams.set("range", `bytes=${c}-${h}`), a = u.href;
                        const g = {
                            url: a,
                            method: "GET",
                            headers: {}
                        };

                        function _(e, n) {
                            if (e.statusCode < 200 || e.statusCode >= 300) return p = !0, s(new Error("Unexpected HTTP status code " + e.statusCode));
                            i("Got data of length %d", n.length), 1 === f.length ? s(null, n) : (n.copy(d, t.fileOffsetInRange), ++l === f.length && s(null, d))
                        }
                        o.concat(g, (e, t, n) => {
                            if (!p) return e ? "undefined" === typeof window || a.startsWith(window.location.origin + "/") ? (p = !0, s(e)) : o.head(a, (t, n) => {
                                if (!p) {
                                    if (t) return p = !0, s(t);
                                    if (n.statusCode < 200 || n.statusCode >= 300) return p = !0, s(new Error("Unexpected HTTP status code " + n.statusCode));
                                    if (n.url === a) return p = !0, s(e);
                                    g.url = n.url, o.concat(g, (e, t, n) => {
                                        if (!p) return e ? (p = !0, s(e)) : void _(t, n)
                                    })
                                }
                            }) : void _(t, n)
                        })
                    })
                }
                destroy() {
                    super.destroy(), this._torrent = null
                }
            }
            e.exports = c
        }).call(this, n("b639").Buffer)
    },
    "9f6f": function(e, t, n) {
        /*! immediate-chunk-store. MIT License. Feross Aboukhadijeh <https://feross.org/opensource> */
        const r = n("8712");
        class i {
            constructor(e) {
                if (this.store = e, this.chunkLength = e.chunkLength, !this.store || !this.store.get || !this.store.put) throw new Error("First argument must be abstract-chunk-store compliant");
                this.mem = []
            }
            put(e, t, n = (() => {})) {
                this.mem[e] = t, this.store.put(e, t, t => {
                    this.mem[e] = null, n(t)
                })
            }
            get(e, t, n = (() => {})) {
                if ("function" === typeof t) return this.get(e, null, t);
                let i = this.mem[e];
                if (!i) return this.store.get(e, t, n);
                t || (t = {});
                const o = t.offset || 0,
                    s = t.length || i.length - o;
                0 === o && s === i.length || (i = i.slice(o, s + o)), r(() => n(null, i))
            }
            close(e = (() => {})) {
                this.store.close(e)
            }
            destroy(e = (() => {})) {
                this.store.destroy(e)
            }
        }
        e.exports = i
    },
    a04b: function(e, t, n) {
        var r = n("c04e"),
            i = n("d9b5");
        e.exports = function(e) {
            var t = r(e, "string");
            return i(t) ? t : String(t)
        }
    },
    a078: function(e, t, n) {
        var r = n("7b0b"),
            i = n("50c4"),
            o = n("35a1"),
            s = n("e95a"),
            a = n("0366"),
            c = n("ebb5").aTypedArrayConstructor;
        e.exports = function(e) {
            var t, n, h, u, f, d, l = r(e),
                p = arguments.length,
                g = p > 1 ? arguments[1] : void 0,
                _ = void 0 !== g,
                y = o(l);
            if (void 0 != y && !s(y)) {
                f = y.call(l), d = f.next, l = [];
                while (!(u = d.call(f)).done) l.push(u.value)
            }
            for (_ && p > 2 && (g = a(g, arguments[2], 2)), n = i(l.length), h = new(c(this))(n), t = 0; n > t; t++) h[t] = _ ? g(l[t], t) : l[t];
            return h
        }
    },
    a59c: function(e, t, n) {
        "use strict";
        n.d(t, "a", (function() {
            return c
        }));
        var r = n("0774"),
            i = n.n(r),
            o = n("c64e"),
            s = n.n(o),
            a = n("8707");

        function c() {
            const e = [];
            s()({}, e);
            const t = 128;
            e[0] = e[0] | t;
            const n = i.a.encode(a["Buffer"].from(e));
            return n
        }
    },
    a5a5: function(e, t, n) {
        "use strict";
        n.d(t, "k", (function() {
            return i
        })), n.d(t, "e", (function() {
            return o
        })), n.d(t, "p", (function() {
            return s
        })), n.d(t, "n", (function() {
            return h
        })), n.d(t, "q", (function() {
            return u
        })), n.d(t, "b", (function() {
            return f
        })), n.d(t, "c", (function() {
            return d
        })), n.d(t, "a", (function() {
            return l
        })), n.d(t, "g", (function() {
            return g
        })), n.d(t, "d", (function() {
            return _
        })), n.d(t, "f", (function() {
            return y
        })), n.d(t, "h", (function() {
            return m
        })), n.d(t, "j", (function() {
            return b
        })), n.d(t, "i", (function() {
            return w
        })), n.d(t, "l", (function() {
            return E
        })), n.d(t, "m", (function() {
            return R
        })), n.d(t, "o", (function() {
            return S
        }));
        const r = "arc:",
            i = {
                COMLINK_INIT: r + "comlink:init",
                NODE_ID: r + ":nodeId",
                CLIENT_TEARDOWN: r + "client:teardown",
                CLIENT_TAB_ID: r + "client:tabId",
                CDN_CONFIG: r + "cdn:config",
                P2P_CLIENT_READY: r + "cdn:ready",
                STORED_FIDS: r + "cdn:storedFids",
                SW_HEALTH_CHECK: r + "cdn:healthCheck",
                WIDGET_CONFIG: r + "widget:config",
                WIDGET_INIT: r + "widget:init",
                WIDGET_UI_LOAD: r + "widget:load",
                BROKER_LOAD: r + "broker:load",
                RENDER_FILE: r + "inlay:renderFile",
                FILE_RENDERED: r + "inlay:fileRendered"
            },
            o = {
                STORE_FILE: "storeFile",
                STORE_CHUNKS: "storeChunks",
                PURGE_FILE: "purgeFile",
                PURGE_FILES: "purgeFiles",
                PURGE_CHUNKS: "purgeChunks",
                START_TORRENTING_FILE: "startTorrentingFile",
                STOP_TORRENTING_FILE: "stopTorrentingFile",
                VERIFY_FILE: "verifyFile",
                RUN_CODE: "runCode",
                CANCEL_TASK: "cancelTask",
                NONE: "none"
            },
            s = "widget",
            a = "arc-sw",
            c = a + ".js",
            h = "/" + c,
            u = "/" + a,
            f = "arc-db",
            d = "key-val-store",
            l = "XXXXXXXXXXXXXXXXXXXXXX",
            p = 6e4,
            g = 300,
            _ = 2 ** 17,
            y = 5,
            m = 10 * p,
            b = {
                UNDECIDED: "UNDECIDED",
                OPTED_IN: "OPTED_IN",
                OPTED_OUT: "OPTED_OUT"
            },
            w = "widgetOptState",
            v = "https://portal.arc.io",
            E = v + "/installation",
            T = "https://warden.arc.io",
            R = T + "/mailbox/propertySession",
            S = T + "/mailbox/transfers"
    },
    a691: function(e, t) {
        var n = Math.ceil,
            r = Math.floor;
        e.exports = function(e) {
            return isNaN(e = +e) ? 0 : (e > 0 ? r : n)(e)
        }
    },
    a981: function(e, t) {
        e.exports = "undefined" !== typeof ArrayBuffer && "undefined" !== typeof DataView
    },
    a999: function(e, t) {},
    a9f1: function(e, t, n) {
        (function(e) {
            t.fetch = a(e.fetch) && a(e.ReadableStream), t.writableStream = a(e.WritableStream), t.abortController = a(e.AbortController), t.blobConstructor = !1;
            try {
                new Blob([new ArrayBuffer(1)]), t.blobConstructor = !0
            } catch (c) {}
            var n;

            function r() {
                if (void 0 !== n) return n;
                if (e.XMLHttpRequest) {
                    n = new e.XMLHttpRequest;
                    try {
                        n.open("GET", e.XDomainRequest ? "/" : "https://example.com")
                    } catch (c) {
                        n = null
                    }
                } else n = null;
                return n
            }

            function i(e) {
                var t = r();
                if (!t) return !1;
                try {
                    return t.responseType = e, t.responseType === e
                } catch (c) {}
                return !1
            }
            var o = "undefined" !== typeof e.ArrayBuffer,
                s = o && a(e.ArrayBuffer.prototype.slice);

            function a(e) {
                return "function" === typeof e
            }
            t.arraybuffer = t.fetch || o && i("arraybuffer"), t.msstream = !t.fetch && s && i("ms-stream"), t.mozchunkedarraybuffer = !t.fetch && o && i("moz-chunked-arraybuffer"), t.overrideMimeType = t.fetch || !!r() && a(r().overrideMimeType), t.vbArray = a(e.VBArray), n = null
        }).call(this, n("c8ba"))
    },
    aa22: function(e, t, n) {
        "use strict";
        var r = n("8707").Buffer,
            i = r.isEncoding || function(e) {
                switch (e = "" + e, e && e.toLowerCase()) {
                    case "hex":
                    case "utf8":
                    case "utf-8":
                    case "ascii":
                    case "binary":
                    case "base64":
                    case "ucs2":
                    case "ucs-2":
                    case "utf16le":
                    case "utf-16le":
                    case "raw":
                        return !0;
                    default:
                        return !1
                }
            };

        function o(e) {
            if (!e) return "utf8";
            var t;
            while (1) switch (e) {
                case "utf8":
                case "utf-8":
                    return "utf8";
                case "ucs2":
                case "ucs-2":
                case "utf16le":
                case "utf-16le":
                    return "utf16le";
                case "latin1":
                case "binary":
                    return "latin1";
                case "base64":
                case "ascii":
                case "hex":
                    return e;
                default:
                    if (t) return;
                    e = ("" + e).toLowerCase(), t = !0
            }
        }

        function s(e) {
            var t = o(e);
            if ("string" !== typeof t && (r.isEncoding === i || !i(e))) throw new Error("Unknown encoding: " + e);
            return t || e
        }

        function a(e) {
            var t;
            switch (this.encoding = s(e), this.encoding) {
                case "utf16le":
                    this.text = p, this.end = g, t = 4;
                    break;
                case "utf8":
                    this.fillLast = f, t = 4;
                    break;
                case "base64":
                    this.text = _, this.end = y, t = 3;
                    break;
                default:
                    return this.write = m, void(this.end = b)
            }
            this.lastNeed = 0, this.lastTotal = 0, this.lastChar = r.allocUnsafe(t)
        }

        function c(e) {
            return e <= 127 ? 0 : e >> 5 === 6 ? 2 : e >> 4 === 14 ? 3 : e >> 3 === 30 ? 4 : e >> 6 === 2 ? -1 : -2
        }

        function h(e, t, n) {
            var r = t.length - 1;
            if (r < n) return 0;
            var i = c(t[r]);
            return i >= 0 ? (i > 0 && (e.lastNeed = i - 1), i) : --r < n || -2 === i ? 0 : (i = c(t[r]), i >= 0 ? (i > 0 && (e.lastNeed = i - 2), i) : --r < n || -2 === i ? 0 : (i = c(t[r]), i >= 0 ? (i > 0 && (2 === i ? i = 0 : e.lastNeed = i - 3), i) : 0))
        }

        function u(e, t, n) {
            if (128 !== (192 & t[0])) return e.lastNeed = 0, "�";
            if (e.lastNeed > 1 && t.length > 1) {
                if (128 !== (192 & t[1])) return e.lastNeed = 1, "�";
                if (e.lastNeed > 2 && t.length > 2 && 128 !== (192 & t[2])) return e.lastNeed = 2, "�"
            }
        }

        function f(e) {
            var t = this.lastTotal - this.lastNeed,
                n = u(this, e, t);
            return void 0 !== n ? n : this.lastNeed <= e.length ? (e.copy(this.lastChar, t, 0, this.lastNeed), this.lastChar.toString(this.encoding, 0, this.lastTotal)) : (e.copy(this.lastChar, t, 0, e.length), void(this.lastNeed -= e.length))
        }

        function d(e, t) {
            var n = h(this, e, t);
            if (!this.lastNeed) return e.toString("utf8", t);
            this.lastTotal = n;
            var r = e.length - (n - this.lastNeed);
            return e.copy(this.lastChar, 0, r), e.toString("utf8", t, r)
        }

        function l(e) {
            var t = e && e.length ? this.write(e) : "";
            return this.lastNeed ? t + "�" : t
        }

        function p(e, t) {
            if ((e.length - t) % 2 === 0) {
                var n = e.toString("utf16le", t);
                if (n) {
                    var r = n.charCodeAt(n.length - 1);
                    if (r >= 55296 && r <= 56319) return this.lastNeed = 2, this.lastTotal = 4, this.lastChar[0] = e[e.length - 2], this.lastChar[1] = e[e.length - 1], n.slice(0, -1)
                }
                return n
            }
            return this.lastNeed = 1, this.lastTotal = 2, this.lastChar[0] = e[e.length - 1], e.toString("utf16le", t, e.length - 1)
        }

        function g(e) {
            var t = e && e.length ? this.write(e) : "";
            if (this.lastNeed) {
                var n = this.lastTotal - this.lastNeed;
                return t + this.lastChar.toString("utf16le", 0, n)
            }
            return t
        }

        function _(e, t) {
            var n = (e.length - t) % 3;
            return 0 === n ? e.toString("base64", t) : (this.lastNeed = 3 - n, this.lastTotal = 3, 1 === n ? this.lastChar[0] = e[e.length - 1] : (this.lastChar[0] = e[e.length - 2], this.lastChar[1] = e[e.length - 1]), e.toString("base64", t, e.length - n))
        }

        function y(e) {
            var t = e && e.length ? this.write(e) : "";
            return this.lastNeed ? t + this.lastChar.toString("base64", 0, 3 - this.lastNeed) : t
        }

        function m(e) {
            return e.toString(this.encoding)
        }

        function b(e) {
            return e && e.length ? this.write(e) : ""
        }
        t.StringDecoder = a, a.prototype.write = function(e) {
            if (0 === e.length) return "";
            var t, n;
            if (this.lastNeed) {
                if (t = this.fillLast(e), void 0 === t) return "";
                n = this.lastNeed, this.lastNeed = 0
            } else n = 0;
            return n < e.length ? t ? t + this.text(e, n) : this.text(e, n) : t || ""
        }, a.prototype.end = l, a.prototype.text = d, a.prototype.fillLast = function(e) {
            if (this.lastNeed <= e.length) return e.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, this.lastNeed), this.lastChar.toString(this.encoding, 0, this.lastTotal);
            e.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, e.length), this.lastNeed -= e.length
        }
    },
    ab52: function(e, t, n) {
        (function(t) {
            var r = n("566b"),
                i = function() {},
                o = function(e) {
                    return e.setHeader && "function" === typeof e.abort
                },
                s = function(e) {
                    return e.stdio && Array.isArray(e.stdio) && 3 === e.stdio.length
                },
                a = function(e, n, c) {
                    if ("function" === typeof n) return a(e, null, n);
                    n || (n = {}), c = r(c || i);
                    var h = e._writableState,
                        u = e._readableState,
                        f = n.readable || !1 !== n.readable && e.readable,
                        d = n.writable || !1 !== n.writable && e.writable,
                        l = !1,
                        p = function() {
                            e.writable || g()
                        },
                        g = function() {
                            d = !1, f || c.call(e)
                        },
                        _ = function() {
                            f = !1, d || c.call(e)
                        },
                        y = function(t) {
                            c.call(e, t ? new Error("exited with error code: " + t) : null)
                        },
                        m = function(t) {
                            c.call(e, t)
                        },
                        b = function() {
                            t.nextTick(w)
                        },
                        w = function() {
                            if (!l) return (!f || u && u.ended && !u.destroyed) && (!d || h && h.ended && !h.destroyed) ? void 0 : c.call(e, new Error("premature close"))
                        },
                        v = function() {
                            e.req.on("finish", g)
                        };
                    return o(e) ? (e.on("complete", g), e.on("abort", b), e.req ? v() : e.on("request", v)) : d && !h && (e.on("end", p), e.on("close", p)), s(e) && e.on("exit", y), e.on("end", _), e.on("finish", g), !1 !== n.error && e.on("error", m), e.on("close", b),
                        function() {
                            l = !0, e.removeListener("complete", g), e.removeListener("abort", b), e.removeListener("request", v), e.req && e.req.removeListener("finish", g), e.removeListener("end", p), e.removeListener("close", p), e.removeListener("finish", g), e.removeListener("exit", y), e.removeListener("end", _), e.removeListener("error", m), e.removeListener("close", b)
                        }
                };
            e.exports = a
        }).call(this, n("4362"))
    },
    ac4f: function(e, t, n) {
        var r = n("b1a6");
        t.encode = r.encode, t.decode = r.decode
    },
    ad2b: function(e, t, n) {
        (function(t, r, i) {
            const {
                EventEmitter: o
            } = n("faa1"), s = n("ff0e"), a = n("583f"), c = n("34eb")("webtorrent"), h = n(4), u = n(5), f = n("8cc1"), d = n("b944"), l = n("df7c"), p = n("051a"), g = n("11dc"), _ = n("7b03"), y = n(7), m = n("c115"), b = n("af39").version, w = b.replace(/\d*./g, e => ("0" + e % 100).slice(-2)).slice(0, 4), v = `-WW${w}-`;
            class E extends o {
                constructor(e = {}) {
                    super(), "string" === typeof e.peerId ? this.peerId = e.peerId : t.isBuffer(e.peerId) ? this.peerId = e.peerId.toString("hex") : this.peerId = t.from(v + g(9).toString("base64")).toString("hex"), this.peerIdBuffer = t.from(this.peerId, "hex"), "string" === typeof e.nodeId ? this.nodeId = e.nodeId : t.isBuffer(e.nodeId) ? this.nodeId = e.nodeId.toString("hex") : this.nodeId = g(20).toString("hex"), this.nodeIdBuffer = t.from(this.nodeId, "hex"), this._debugId = this.peerId.toString("hex").substring(0, 7), this.destroyed = !1, this.listening = !1, this.torrentPort = e.torrentPort || 0, this.dhtPort = e.dhtPort || 0, this.tracker = void 0 !== e.tracker ? e.tracker : {}, this.torrents = [], this.maxConns = Number(e.maxConns) || 55, this._debug("new webtorrent (peerId %s, nodeId %s, port %s)", this.peerId, this.nodeId, this.torrentPort), this.tracker && ("object" !== typeof this.tracker && (this.tracker = {}), e.rtcConfig && (console.warn("WebTorrent: opts.rtcConfig is deprecated. Use opts.tracker.rtcConfig instead"), this.tracker.rtcConfig = e.rtcConfig), e.wrtc && (console.warn("WebTorrent: opts.wrtc is deprecated. Use opts.tracker.wrtc instead"), this.tracker.wrtc = e.wrtc), r.WRTC && !this.tracker.wrtc && (this.tracker.wrtc = r.WRTC)), "function" === typeof y ? this._tcpPool = new y(this) : i.nextTick(() => {
                        this._onListening()
                    }), this._downloadSpeed = _(), this._uploadSpeed = _(), !1 !== e.dht && "function" === typeof h ? (this.dht = new h(Object.assign({}, {
                        nodeId: this.nodeId
                    }, e.dht)), this.dht.once("error", e => {
                        this._destroy(e)
                    }), this.dht.once("listening", () => {
                        const e = this.dht.address();
                        e && (this.dhtPort = e.port)
                    }), this.dht.setMaxListeners(0), this.dht.listen(this.dhtPort)) : this.dht = !1, this.enableWebSeeds = !1 !== e.webSeeds;
                    const n = () => {
                        this.destroyed || (this.ready = !0, this.emit("ready"))
                    };
                    "function" === typeof u && null != e.blocklist ? u(e.blocklist, {
                        headers: {
                            "user-agent": `WebTorrent/${b} (https://webtorrent.io)`
                        }
                    }, (e, t) => {
                        if (e) return this.error("Failed to load blocklist: " + e.message);
                        this.blocked = t, n()
                    }) : i.nextTick(n)
                }
                get downloadSpeed() {
                    return this._downloadSpeed()
                }
                get uploadSpeed() {
                    return this._uploadSpeed()
                }
                get progress() {
                    const e = this.torrents.filter(e => 1 !== e.progress),
                        t = e.reduce((e, t) => e + t.downloaded, 0),
                        n = e.reduce((e, t) => e + (t.length || 0), 0) || 1;
                    return t / n
                }
                get ratio() {
                    const e = this.torrents.reduce((e, t) => e + t.uploaded, 0),
                        t = this.torrents.reduce((e, t) => e + t.received, 0) || 1;
                    return e / t
                }
                get(e) {
                    if (e instanceof m) {
                        if (this.torrents.includes(e)) return e
                    } else {
                        let n;
                        try {
                            n = d(e)
                        } catch (t) {}
                        if (!n) return null;
                        if (!n.infoHash) throw new Error("Invalid torrent identifier");
                        for (const e of this.torrents)
                            if (e.infoHash === n.infoHash) return e
                    }
                    return null
                }
                download(e, t, n) {
                    return console.warn("WebTorrent: client.download() is deprecated. Use client.add() instead"), this.add(e, t, n)
                }
                add(e, t = {}, n) {
                    if (this.destroyed) throw new Error("client is destroyed");
                    "function" === typeof t && ([t, n] = [{}, t]);
                    const r = () => {
                            if (!this.destroyed)
                                for (const e of this.torrents)
                                    if (e.infoHash === s.infoHash && e !== s) return void s._destroy(new Error("Cannot add duplicate torrent " + s.infoHash))
                        },
                        i = () => {
                            this.destroyed || ("function" === typeof n && n(s), this.emit("torrent", s))
                        };

                    function o() {
                        s.removeListener("_infoHash", r), s.removeListener("ready", i), s.removeListener("close", o)
                    }
                    this._debug("add"), t = t ? Object.assign({}, t) : {};
                    const s = new m(e, this, t);
                    return this.torrents.push(s), s.once("_infoHash", r), s.once("ready", i), s.once("close", o), s
                }
                seed(e, t, n) {
                    if (this.destroyed) throw new Error("client is destroyed");
                    "function" === typeof t && ([t, n] = [{}, t]), this._debug("seed"), t = t ? Object.assign({}, t) : {}, t.skipVerify = !0;
                    const r = "string" === typeof e;
                    r && (t.path = l.dirname(e)), t.createdBy || (t.createdBy = "WebTorrent/" + w);
                    const i = e => {
                            const t = [t => {
                                if (r) return t();
                                e.load(h, t)
                            }];
                            this.dht && t.push(t => {
                                e.once("dhtAnnounce", t)
                            }), f(t, t => {
                                if (!this.destroyed) return t ? e._destroy(t) : void o(e)
                            })
                        },
                        o = e => {
                            this._debug("on seed"), "function" === typeof n && n(e), e.emit("seed"), this.emit("seed", e)
                        },
                        c = this.add(null, t, i);
                    let h;
                    return R(e) ? e = Array.from(e) : Array.isArray(e) || (e = [e]), f(e.map(e => t => {
                        T(e) ? s(e, t) : t(null, e)
                    }), (e, n) => {
                        if (!this.destroyed) return e ? c._destroy(e) : void a.parseInput(n, t, (e, r) => {
                            if (!this.destroyed) {
                                if (e) return c._destroy(e);
                                h = r.map(e => e.getStream), a(n, t, (e, t) => {
                                    if (this.destroyed) return;
                                    if (e) return c._destroy(e);
                                    const n = this.get(t);
                                    n ? c._destroy(new Error("Cannot add duplicate torrent " + n.infoHash)) : c._onTorrentId(t)
                                })
                            }
                        })
                    }), c
                }
                remove(e, t) {
                    this._debug("remove");
                    const n = this.get(e);
                    if (!n) throw new Error("No torrent with id " + e);
                    this._remove(e, t)
                }
                _remove(e, t) {
                    const n = this.get(e);
                    n && (this.torrents.splice(this.torrents.indexOf(n), 1), n.destroy(t))
                }
                address() {
                    return this.listening ? this._tcpPool ? this._tcpPool.server.address() : {
                        address: "0.0.0.0",
                        family: "IPv4",
                        port: 0
                    } : null
                }
                destroy(e) {
                    if (this.destroyed) throw new Error("client already destroyed");
                    this._destroy(null, e)
                }
                _destroy(e, t) {
                    this._debug("client destroy"), this.destroyed = !0;
                    const n = this.torrents.map(e => t => {
                        e.destroy(t)
                    });
                    this._tcpPool && n.push(e => {
                        this._tcpPool.destroy(e)
                    }), this.dht && n.push(e => {
                        this.dht.destroy(e)
                    }), f(n, t), e && this.emit("error", e), this.torrents = [], this._tcpPool = null, this.dht = null
                }
                _onListening() {
                    if (this._debug("listening"), this.listening = !0, this._tcpPool) {
                        const e = this._tcpPool.server.address();
                        e && (this.torrentPort = e.port)
                    }
                    this.emit("listening")
                }
                _debug() {
                    const e = [].slice.call(arguments);
                    e[0] = `[${this._debugId}] ${e[0]}`, c(...e)
                }
            }

            function T(e) {
                return "object" === typeof e && null != e && "function" === typeof e.pipe
            }

            function R(e) {
                return "undefined" !== typeof FileList && e instanceof FileList
            }
            E.WEBRTC_SUPPORT = p.WEBRTC_SUPPORT, E.VERSION = b, e.exports = E
        }).call(this, n("b639").Buffer, n("c8ba"), n("4362"))
    },
    ad71: function(e, t, n) {
        "use strict";
        (function(t, r) {
            var i;
            e.exports = A, A.ReadableState = k;
            n("faa1").EventEmitter;
            var o = function(e, t) {
                    return e.listeners(t).length
                },
                s = n("429b"),
                a = n("b639").Buffer,
                c = t.Uint8Array || function() {};

            function h(e) {
                return a.from(e)
            }

            function u(e) {
                return a.isBuffer(e) || e instanceof c
            }
            var f, d = n(0);
            f = d && d.debuglog ? d.debuglog("stream") : function() {};
            var l, p, g, _ = n("c6ae"),
                y = n("4681"),
                m = n("0db6"),
                b = m.getHighWaterMark,
                w = n("c9b8").codes,
                v = w.ERR_INVALID_ARG_TYPE,
                E = w.ERR_STREAM_PUSH_AFTER_EOF,
                T = w.ERR_METHOD_NOT_IMPLEMENTED,
                R = w.ERR_STREAM_UNSHIFT_AFTER_END_EVENT;
            n("3fb5")(A, s);
            var S = y.errorOrDestroy,
                I = ["error", "close", "destroy", "pause", "resume"];

            function O(e, t, n) {
                if ("function" === typeof e.prependListener) return e.prependListener(t, n);
                e._events && e._events[t] ? Array.isArray(e._events[t]) ? e._events[t].unshift(n) : e._events[t] = [n, e._events[t]] : e.on(t, n)
            }

            function k(e, t, r) {
                i = i || n("b19a"), e = e || {}, "boolean" !== typeof r && (r = t instanceof i), this.objectMode = !!e.objectMode, r && (this.objectMode = this.objectMode || !!e.readableObjectMode), this.highWaterMark = b(this, e, "readableHighWaterMark", r), this.buffer = new _, this.length = 0, this.pipes = null, this.pipesCount = 0, this.flowing = null, this.ended = !1, this.endEmitted = !1, this.reading = !1, this.sync = !0, this.needReadable = !1, this.emittedReadable = !1, this.readableListening = !1, this.resumeScheduled = !1, this.paused = !0, this.emitClose = !1 !== e.emitClose, this.autoDestroy = !!e.autoDestroy, this.destroyed = !1, this.defaultEncoding = e.defaultEncoding || "utf8", this.awaitDrain = 0, this.readingMore = !1, this.decoder = null, this.encoding = null, e.encoding && (l || (l = n("aa22").StringDecoder), this.decoder = new l(e.encoding), this.encoding = e.encoding)
            }

            function A(e) {
                if (i = i || n("b19a"), !(this instanceof A)) return new A(e);
                var t = this instanceof i;
                this._readableState = new k(e, this, t), this.readable = !0, e && ("function" === typeof e.read && (this._read = e.read), "function" === typeof e.destroy && (this._destroy = e.destroy)), s.call(this)
            }

            function C(e, t, n, r, i) {
                f("readableAddChunk", t);
                var o, s = e._readableState;
                if (null === t) s.reading = !1, D(e, s);
                else if (i || (o = N(s, t)), o) S(e, o);
                else if (s.objectMode || t && t.length > 0)
                    if ("string" === typeof t || s.objectMode || Object.getPrototypeOf(t) === a.prototype || (t = h(t)), r) s.endEmitted ? S(e, new R) : x(e, s, t, !0);
                    else if (s.ended) S(e, new E);
                else {
                    if (s.destroyed) return !1;
                    s.reading = !1, s.decoder && !n ? (t = s.decoder.write(t), s.objectMode || 0 !== t.length ? x(e, s, t, !1) : j(e, s)) : x(e, s, t, !1)
                } else r || (s.reading = !1, j(e, s));
                return !s.ended && (s.length < s.highWaterMark || 0 === s.length)
            }

            function x(e, t, n, r) {
                t.flowing && 0 === t.length && !t.sync ? (t.awaitDrain = 0, e.emit("data", n)) : (t.length += t.objectMode ? 1 : n.length, r ? t.buffer.unshift(n) : t.buffer.push(n), t.needReadable && U(e)), j(e, t)
            }

            function N(e, t) {
                var n;
                return u(t) || "string" === typeof t || void 0 === t || e.objectMode || (n = new v("chunk", ["string", "Buffer", "Uint8Array"], t)), n
            }
            Object.defineProperty(A.prototype, "destroyed", {
                enumerable: !1,
                get: function() {
                    return void 0 !== this._readableState && this._readableState.destroyed
                },
                set: function(e) {
                    this._readableState && (this._readableState.destroyed = e)
                }
            }), A.prototype.destroy = y.destroy, A.prototype._undestroy = y.undestroy, A.prototype._destroy = function(e, t) {
                t(e)
            }, A.prototype.push = function(e, t) {
                var n, r = this._readableState;
                return r.objectMode ? n = !0 : "string" === typeof e && (t = t || r.defaultEncoding, t !== r.encoding && (e = a.from(e, t), t = ""), n = !0), C(this, e, t, !1, n)
            }, A.prototype.unshift = function(e) {
                return C(this, e, null, !0, !1)
            }, A.prototype.isPaused = function() {
                return !1 === this._readableState.flowing
            }, A.prototype.setEncoding = function(e) {
                l || (l = n("aa22").StringDecoder);
                var t = new l(e);
                this._readableState.decoder = t, this._readableState.encoding = this._readableState.decoder.encoding;
                var r = this._readableState.buffer.head,
                    i = "";
                while (null !== r) i += t.write(r.data), r = r.next;
                return this._readableState.buffer.clear(), "" !== i && this._readableState.buffer.push(i), this._readableState.length = i.length, this
            };
            var P = 1073741824;

            function L(e) {
                return e >= P ? e = P : (e--, e |= e >>> 1, e |= e >>> 2, e |= e >>> 4, e |= e >>> 8, e |= e >>> 16, e++), e
            }

            function M(e, t) {
                return e <= 0 || 0 === t.length && t.ended ? 0 : t.objectMode ? 1 : e !== e ? t.flowing && t.length ? t.buffer.head.data.length : t.length : (e > t.highWaterMark && (t.highWaterMark = L(e)), e <= t.length ? e : t.ended ? t.length : (t.needReadable = !0, 0))
            }

            function D(e, t) {
                if (f("onEofChunk"), !t.ended) {
                    if (t.decoder) {
                        var n = t.decoder.end();
                        n && n.length && (t.buffer.push(n), t.length += t.objectMode ? 1 : n.length)
                    }
                    t.ended = !0, t.sync ? U(e) : (t.needReadable = !1, t.emittedReadable || (t.emittedReadable = !0, B(e)))
                }
            }

            function U(e) {
                var t = e._readableState;
                f("emitReadable", t.needReadable, t.emittedReadable), t.needReadable = !1, t.emittedReadable || (f("emitReadable", t.flowing), t.emittedReadable = !0, r.nextTick(B, e))
            }

            function B(e) {
                var t = e._readableState;
                f("emitReadable_", t.destroyed, t.length, t.ended), t.destroyed || !t.length && !t.ended || (e.emit("readable"), t.emittedReadable = !1), t.needReadable = !t.flowing && !t.ended && t.length <= t.highWaterMark, Y(e)
            }

            function j(e, t) {
                t.readingMore || (t.readingMore = !0, r.nextTick(F, e, t))
            }

            function F(e, t) {
                while (!t.reading && !t.ended && (t.length < t.highWaterMark || t.flowing && 0 === t.length)) {
                    var n = t.length;
                    if (f("maybeReadMore read 0"), e.read(0), n === t.length) break
                }
                t.readingMore = !1
            }

            function H(e) {
                return function() {
                    var t = e._readableState;
                    f("pipeOnDrain", t.awaitDrain), t.awaitDrain && t.awaitDrain--, 0 === t.awaitDrain && o(e, "data") && (t.flowing = !0, Y(e))
                }
            }

            function G(e) {
                var t = e._readableState;
                t.readableListening = e.listenerCount("readable") > 0, t.resumeScheduled && !t.paused ? t.flowing = !0 : e.listenerCount("data") > 0 && e.resume()
            }

            function W(e) {
                f("readable nexttick read 0"), e.read(0)
            }

            function q(e, t) {
                t.resumeScheduled || (t.resumeScheduled = !0, r.nextTick($, e, t))
            }

            function $(e, t) {
                f("resume", t.reading), t.reading || e.read(0), t.resumeScheduled = !1, e.emit("resume"), Y(e), t.flowing && !t.reading && e.read(0)
            }

            function Y(e) {
                var t = e._readableState;
                f("flow", t.flowing);
                while (t.flowing && null !== e.read());
            }

            function z(e, t) {
                return 0 === t.length ? null : (t.objectMode ? n = t.buffer.shift() : !e || e >= t.length ? (n = t.decoder ? t.buffer.join("") : 1 === t.buffer.length ? t.buffer.first() : t.buffer.concat(t.length), t.buffer.clear()) : n = t.buffer.consume(e, t.decoder), n);
                var n
            }

            function V(e) {
                var t = e._readableState;
                f("endReadable", t.endEmitted), t.endEmitted || (t.ended = !0, r.nextTick(X, t, e))
            }

            function X(e, t) {
                if (f("endReadableNT", e.endEmitted, e.length), !e.endEmitted && 0 === e.length && (e.endEmitted = !0, t.readable = !1, t.emit("end"), e.autoDestroy)) {
                    var n = t._writableState;
                    (!n || n.autoDestroy && n.finished) && t.destroy()
                }
            }

            function K(e, t) {
                for (var n = 0, r = e.length; n < r; n++)
                    if (e[n] === t) return n;
                return -1
            }
            A.prototype.read = function(e) {
                f("read", e), e = parseInt(e, 10);
                var t = this._readableState,
                    n = e;
                if (0 !== e && (t.emittedReadable = !1), 0 === e && t.needReadable && ((0 !== t.highWaterMark ? t.length >= t.highWaterMark : t.length > 0) || t.ended)) return f("read: emitReadable", t.length, t.ended), 0 === t.length && t.ended ? V(this) : U(this), null;
                if (e = M(e, t), 0 === e && t.ended) return 0 === t.length && V(this), null;
                var r, i = t.needReadable;
                return f("need readable", i), (0 === t.length || t.length - e < t.highWaterMark) && (i = !0, f("length less than watermark", i)), t.ended || t.reading ? (i = !1, f("reading or ended", i)) : i && (f("do read"), t.reading = !0, t.sync = !0, 0 === t.length && (t.needReadable = !0), this._read(t.highWaterMark), t.sync = !1, t.reading || (e = M(n, t))), r = e > 0 ? z(e, t) : null, null === r ? (t.needReadable = t.length <= t.highWaterMark, e = 0) : (t.length -= e, t.awaitDrain = 0), 0 === t.length && (t.ended || (t.needReadable = !0), n !== e && t.ended && V(this)), null !== r && this.emit("data", r), r
            }, A.prototype._read = function(e) {
                S(this, new T("_read()"))
            }, A.prototype.pipe = function(e, t) {
                var n = this,
                    i = this._readableState;
                switch (i.pipesCount) {
                    case 0:
                        i.pipes = e;
                        break;
                    case 1:
                        i.pipes = [i.pipes, e];
                        break;
                    default:
                        i.pipes.push(e);
                        break
                }
                i.pipesCount += 1, f("pipe count=%d opts=%j", i.pipesCount, t);
                var s = (!t || !1 !== t.end) && e !== r.stdout && e !== r.stderr,
                    a = s ? h : m;

                function c(e, t) {
                    f("onunpipe"), e === n && t && !1 === t.hasUnpiped && (t.hasUnpiped = !0, l())
                }

                function h() {
                    f("onend"), e.end()
                }
                i.endEmitted ? r.nextTick(a) : n.once("end", a), e.on("unpipe", c);
                var u = H(n);
                e.on("drain", u);
                var d = !1;

                function l() {
                    f("cleanup"), e.removeListener("close", _), e.removeListener("finish", y), e.removeListener("drain", u), e.removeListener("error", g), e.removeListener("unpipe", c), n.removeListener("end", h), n.removeListener("end", m), n.removeListener("data", p), d = !0, !i.awaitDrain || e._writableState && !e._writableState.needDrain || u()
                }

                function p(t) {
                    f("ondata");
                    var r = e.write(t);
                    f("dest.write", r), !1 === r && ((1 === i.pipesCount && i.pipes === e || i.pipesCount > 1 && -1 !== K(i.pipes, e)) && !d && (f("false write response, pause", i.awaitDrain), i.awaitDrain++), n.pause())
                }

                function g(t) {
                    f("onerror", t), m(), e.removeListener("error", g), 0 === o(e, "error") && S(e, t)
                }

                function _() {
                    e.removeListener("finish", y), m()
                }

                function y() {
                    f("onfinish"), e.removeListener("close", _), m()
                }

                function m() {
                    f("unpipe"), n.unpipe(e)
                }
                return n.on("data", p), O(e, "error", g), e.once("close", _), e.once("finish", y), e.emit("pipe", n), i.flowing || (f("pipe resume"), n.resume()), e
            }, A.prototype.unpipe = function(e) {
                var t = this._readableState,
                    n = {
                        hasUnpiped: !1
                    };
                if (0 === t.pipesCount) return this;
                if (1 === t.pipesCount) return e && e !== t.pipes || (e || (e = t.pipes), t.pipes = null, t.pipesCount = 0, t.flowing = !1, e && e.emit("unpipe", this, n)), this;
                if (!e) {
                    var r = t.pipes,
                        i = t.pipesCount;
                    t.pipes = null, t.pipesCount = 0, t.flowing = !1;
                    for (var o = 0; o < i; o++) r[o].emit("unpipe", this, {
                        hasUnpiped: !1
                    });
                    return this
                }
                var s = K(t.pipes, e);
                return -1 === s || (t.pipes.splice(s, 1), t.pipesCount -= 1, 1 === t.pipesCount && (t.pipes = t.pipes[0]), e.emit("unpipe", this, n)), this
            }, A.prototype.on = function(e, t) {
                var n = s.prototype.on.call(this, e, t),
                    i = this._readableState;
                return "data" === e ? (i.readableListening = this.listenerCount("readable") > 0, !1 !== i.flowing && this.resume()) : "readable" === e && (i.endEmitted || i.readableListening || (i.readableListening = i.needReadable = !0, i.flowing = !1, i.emittedReadable = !1, f("on readable", i.length, i.reading), i.length ? U(this) : i.reading || r.nextTick(W, this))), n
            }, A.prototype.addListener = A.prototype.on, A.prototype.removeListener = function(e, t) {
                var n = s.prototype.removeListener.call(this, e, t);
                return "readable" === e && r.nextTick(G, this), n
            }, A.prototype.removeAllListeners = function(e) {
                var t = s.prototype.removeAllListeners.apply(this, arguments);
                return "readable" !== e && void 0 !== e || r.nextTick(G, this), t
            }, A.prototype.resume = function() {
                var e = this._readableState;
                return e.flowing || (f("resume"), e.flowing = !e.readableListening, q(this, e)), e.paused = !1, this
            }, A.prototype.pause = function() {
                return f("call pause flowing=%j", this._readableState.flowing), !1 !== this._readableState.flowing && (f("pause"), this._readableState.flowing = !1, this.emit("pause")), this._readableState.paused = !0, this
            }, A.prototype.wrap = function(e) {
                var t = this,
                    n = this._readableState,
                    r = !1;
                for (var i in e.on("end", (function() {
                        if (f("wrapped end"), n.decoder && !n.ended) {
                            var e = n.decoder.end();
                            e && e.length && t.push(e)
                        }
                        t.push(null)
                    })), e.on("data", (function(i) {
                        if (f("wrapped data"), n.decoder && (i = n.decoder.write(i)), (!n.objectMode || null !== i && void 0 !== i) && (n.objectMode || i && i.length)) {
                            var o = t.push(i);
                            o || (r = !0, e.pause())
                        }
                    })), e) void 0 === this[i] && "function" === typeof e[i] && (this[i] = function(t) {
                    return function() {
                        return e[t].apply(e, arguments)
                    }
                }(i));
                for (var o = 0; o < I.length; o++) e.on(I[o], this.emit.bind(this, I[o]));
                return this._read = function(t) {
                    f("wrapped _read", t), r && (r = !1, e.resume())
                }, this
            }, "function" === typeof Symbol && (A.prototype[Symbol.asyncIterator] = function() {
                return void 0 === p && (p = n("9c0e")), p(this)
            }), Object.defineProperty(A.prototype, "readableHighWaterMark", {
                enumerable: !1,
                get: function() {
                    return this._readableState.highWaterMark
                }
            }), Object.defineProperty(A.prototype, "readableBuffer", {
                enumerable: !1,
                get: function() {
                    return this._readableState && this._readableState.buffer
                }
            }), Object.defineProperty(A.prototype, "readableFlowing", {
                enumerable: !1,
                get: function() {
                    return this._readableState.flowing
                },
                set: function(e) {
                    this._readableState && (this._readableState.flowing = e)
                }
            }), A._fromList = z, Object.defineProperty(A.prototype, "readableLength", {
                enumerable: !1,
                get: function() {
                    return this._readableState.length
                }
            }), "function" === typeof Symbol && (A.from = function(e, t) {
                return void 0 === g && (g = n("07c6")), g(A, e, t)
            })
        }).call(this, n("c8ba"), n("4362"))
    },
    addb: function(e, t) {
        var n = Math.floor,
            r = function(e, t) {
                var s = e.length,
                    a = n(s / 2);
                return s < 8 ? i(e, t) : o(r(e.slice(0, a), t), r(e.slice(a), t), t)
            },
            i = function(e, t) {
                var n, r, i = e.length,
                    o = 1;
                while (o < i) {
                    r = o, n = e[o];
                    while (r && t(e[r - 1], n) > 0) e[r] = e[--r];
                    r !== o++ && (e[r] = n)
                }
                return e
            },
            o = function(e, t, n) {
                var r = e.length,
                    i = t.length,
                    o = 0,
                    s = 0,
                    a = [];
                while (o < r || s < i) o < r && s < i ? a.push(n(e[o], t[s]) <= 0 ? e[o++] : t[s++]) : a.push(o < r ? e[o++] : t[s++]);
                return a
            };
        e.exports = r
    },
    ade3: function(e, t, n) {
        "use strict";

        function r(e, t, n) {
            return t in e ? Object.defineProperty(e, t, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = n, e
        }
        n.d(t, "a", (function() {
            return r
        }))
    },
    af2a: function(e, t, n) {
        "use strict";
        n.d(t, "a", (function() {
            return c
        }));
        var r = n("3d15"),
            i = n("5ff7"),
            o = n("9b16"),
            s = n("d1a0");
        const a = n("34eb")("arc:p2p-client");
        console.log;
        async function c(e = {}) {
            const t = await window.__arc__.brokerIframePromise,
                n = s["c"].markStart("broker.html:establish_rpc");
            let r;
            try {
                r = await Object(o["b"])(t.contentWindow, e, i["a"].CORE_ORIGIN), n()
            } catch (c) {
                a("Failed to establish broker rpc. Error: " + c.message), r = await h()
            }
            return u(r)
        }
        async function h() {
            const {
                Broker: e
            } = await n.e("brokers").then(n.bind(null, "4aad"));
            return new e
        }

        function u(e) {
            const t = {
                get(e, t, n) {
                    return "createStore" === t ? async t => {
                        const n = await e.createStore(t);
                        return new f(n)
                    } : Reflect.get(e, t, n)
                }
            };
            return new Proxy(e, t)
        }
        class f {
            constructor(e) {
                this.proxy = e
            }
            get(e, t, n) {
                this.proxy.get(e, t, r["b"]((e, t) => {
                    if (e) return n(e);
                    n(null, r["c"](t, [t.buffer]))
                }))
            }
            put(e, t, n) {
                this.proxy.put(e, t, r["b"](n))
            }
            remove(e, t) {
                this.proxy.remove(e, r["b"](t))
            }
            close(e) {
                this.proxy.close(r["b"](e))
            }
            destroy(e) {
                this.proxy.destroy(r["b"](e))
            }
        }
    },
    af39: function(e) {
        e.exports = JSON.parse('{"version":"0.107.3-arc-22"}')
    },
    b19a: function(e, t, n) {
        "use strict";
        (function(t) {
            var r = Object.keys || function(e) {
                var t = [];
                for (var n in e) t.push(n);
                return t
            };
            e.exports = h;
            var i = n("ad71"),
                o = n("dc14");
            n("3fb5")(h, i);
            for (var s = r(o.prototype), a = 0; a < s.length; a++) {
                var c = s[a];
                h.prototype[c] || (h.prototype[c] = o.prototype[c])
            }

            function h(e) {
                if (!(this instanceof h)) return new h(e);
                i.call(this, e), o.call(this, e), this.allowHalfOpen = !0, e && (!1 === e.readable && (this.readable = !1), !1 === e.writable && (this.writable = !1), !1 === e.allowHalfOpen && (this.allowHalfOpen = !1, this.once("end", u)))
            }

            function u() {
                this._writableState.ended || t.nextTick(f, this)
            }

            function f(e) {
                e.end()
            }
            Object.defineProperty(h.prototype, "writableHighWaterMark", {
                enumerable: !1,
                get: function() {
                    return this._writableState.highWaterMark
                }
            }), Object.defineProperty(h.prototype, "writableBuffer", {
                enumerable: !1,
                get: function() {
                    return this._writableState && this._writableState.getBuffer()
                }
            }), Object.defineProperty(h.prototype, "writableLength", {
                enumerable: !1,
                get: function() {
                    return this._writableState.length
                }
            }), Object.defineProperty(h.prototype, "destroyed", {
                enumerable: !1,
                get: function() {
                    return void 0 !== this._readableState && void 0 !== this._writableState && (this._readableState.destroyed && this._writableState.destroyed)
                },
                set: function(e) {
                    void 0 !== this._readableState && void 0 !== this._writableState && (this._readableState.destroyed = e, this._writableState.destroyed = e)
                }
            })
        }).call(this, n("4362"))
    },
    b1a6: function(e, t, n) {
        "use strict";
        (function(e) {
            var n = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567",
                r = [255, 255, 26, 27, 28, 29, 30, 31, 255, 255, 255, 255, 255, 255, 255, 255, 255, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 255, 255, 255, 255, 255, 255, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 255, 255, 255, 255, 255];

            function i(e) {
                var t = Math.floor(e.length / 5);
                return e.length % 5 === 0 ? t : t + 1
            }
            t.encode = function(t) {
                e.isBuffer(t) || (t = new e(t));
                var r = 0,
                    o = 0,
                    s = 0,
                    a = 0,
                    c = new e(8 * i(t));
                while (r < t.length) {
                    var h = t[r];
                    s > 3 ? (a = h & 255 >> s, s = (s + 5) % 8, a = a << s | (r + 1 < t.length ? t[r + 1] : 0) >> 8 - s, r++) : (a = h >> 8 - (s + 5) & 31, s = (s + 5) % 8, 0 === s && r++), c[o] = n.charCodeAt(a), o++
                }
                for (r = o; r < c.length; r++) c[r] = 61;
                return c
            }, t.decode = function(t) {
                var n, i = 0,
                    o = 0,
                    s = 0;
                e.isBuffer(t) || (t = new e(t));
                for (var a = new e(Math.ceil(5 * t.length / 8)), c = 0; c < t.length; c++) {
                    if (61 === t[c]) break;
                    var h = t[c] - 48;
                    if (!(h < r.length)) throw new Error("Invalid input - it is not base32 encoded string");
                    o = r[h], i <= 3 ? (i = (i + 5) % 8, 0 === i ? (n |= o, a[s] = n, s++, n = 0) : n |= 255 & o << 8 - i) : (i = (i + 5) % 8, n |= 255 & o >>> i, a[s] = n, s++, n = 255 & o << 8 - i)
                }
                return a.slice(0, s)
            }
        }).call(this, n("b639").Buffer)
    },
    b383: function(e, t, n) {
        "use strict";
        t.decode = t.parse = n("91dd"), t.encode = t.stringify = n("e099")
    },
    b622: function(e, t, n) {
        var r = n("da84"),
            i = n("5692"),
            o = n("5135"),
            s = n("90e3"),
            a = n("4930"),
            c = n("fdbf"),
            h = i("wks"),
            u = r.Symbol,
            f = c ? u : u && u.withoutSetter || s;
        e.exports = function(e) {
            return o(h, e) && (a || "string" == typeof h[e]) || (a && o(u, e) ? h[e] = u[e] : h[e] = f("Symbol." + e)), h[e]
        }
    },
    b639: function(e, t, n) {
        "use strict";
        (function(e) {
            /*!
             * The buffer module from node.js, for the browser.
             *
             * @author   Feross Aboukhadijeh <http://feross.org>
             * @license  MIT
             */
            var r = n("1fb5"),
                i = n("9152"),
                o = n("e3db");

            function s() {
                try {
                    var e = new Uint8Array(1);
                    return e.__proto__ = {
                        __proto__: Uint8Array.prototype,
                        foo: function() {
                            return 42
                        }
                    }, 42 === e.foo() && "function" === typeof e.subarray && 0 === e.subarray(1, 1).byteLength
                } catch (t) {
                    return !1
                }
            }

            function a() {
                return h.TYPED_ARRAY_SUPPORT ? 2147483647 : 1073741823
            }

            function c(e, t) {
                if (a() < t) throw new RangeError("Invalid typed array length");
                return h.TYPED_ARRAY_SUPPORT ? (e = new Uint8Array(t), e.__proto__ = h.prototype) : (null === e && (e = new h(t)), e.length = t), e
            }

            function h(e, t, n) {
                if (!h.TYPED_ARRAY_SUPPORT && !(this instanceof h)) return new h(e, t, n);
                if ("number" === typeof e) {
                    if ("string" === typeof t) throw new Error("If encoding is specified then the first argument must be a string");
                    return l(this, e)
                }
                return u(this, e, t, n)
            }

            function u(e, t, n, r) {
                if ("number" === typeof t) throw new TypeError('"value" argument must not be a number');
                return "undefined" !== typeof ArrayBuffer && t instanceof ArrayBuffer ? _(e, t, n, r) : "string" === typeof t ? p(e, t, n) : y(e, t)
            }

            function f(e) {
                if ("number" !== typeof e) throw new TypeError('"size" argument must be a number');
                if (e < 0) throw new RangeError('"size" argument must not be negative')
            }

            function d(e, t, n, r) {
                return f(t), t <= 0 ? c(e, t) : void 0 !== n ? "string" === typeof r ? c(e, t).fill(n, r) : c(e, t).fill(n) : c(e, t)
            }

            function l(e, t) {
                if (f(t), e = c(e, t < 0 ? 0 : 0 | m(t)), !h.TYPED_ARRAY_SUPPORT)
                    for (var n = 0; n < t; ++n) e[n] = 0;
                return e
            }

            function p(e, t, n) {
                if ("string" === typeof n && "" !== n || (n = "utf8"), !h.isEncoding(n)) throw new TypeError('"encoding" must be a valid string encoding');
                var r = 0 | w(t, n);
                e = c(e, r);
                var i = e.write(t, n);
                return i !== r && (e = e.slice(0, i)), e
            }

            function g(e, t) {
                var n = t.length < 0 ? 0 : 0 | m(t.length);
                e = c(e, n);
                for (var r = 0; r < n; r += 1) e[r] = 255 & t[r];
                return e
            }

            function _(e, t, n, r) {
                if (t.byteLength, n < 0 || t.byteLength < n) throw new RangeError("'offset' is out of bounds");
                if (t.byteLength < n + (r || 0)) throw new RangeError("'length' is out of bounds");
                return t = void 0 === n && void 0 === r ? new Uint8Array(t) : void 0 === r ? new Uint8Array(t, n) : new Uint8Array(t, n, r), h.TYPED_ARRAY_SUPPORT ? (e = t, e.__proto__ = h.prototype) : e = g(e, t), e
            }

            function y(e, t) {
                if (h.isBuffer(t)) {
                    var n = 0 | m(t.length);
                    return e = c(e, n), 0 === e.length ? e : (t.copy(e, 0, 0, n), e)
                }
                if (t) {
                    if ("undefined" !== typeof ArrayBuffer && t.buffer instanceof ArrayBuffer || "length" in t) return "number" !== typeof t.length || te(t.length) ? c(e, 0) : g(e, t);
                    if ("Buffer" === t.type && o(t.data)) return g(e, t.data)
                }
                throw new TypeError("First argument must be a string, Buffer, ArrayBuffer, Array, or array-like object.")
            }

            function m(e) {
                if (e >= a()) throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + a().toString(16) + " bytes");
                return 0 | e
            }

            function b(e) {
                return +e != e && (e = 0), h.alloc(+e)
            }

            function w(e, t) {
                if (h.isBuffer(e)) return e.length;
                if ("undefined" !== typeof ArrayBuffer && "function" === typeof ArrayBuffer.isView && (ArrayBuffer.isView(e) || e instanceof ArrayBuffer)) return e.byteLength;
                "string" !== typeof e && (e = "" + e);
                var n = e.length;
                if (0 === n) return 0;
                for (var r = !1;;) switch (t) {
                    case "ascii":
                    case "latin1":
                    case "binary":
                        return n;
                    case "utf8":
                    case "utf-8":
                    case void 0:
                        return K(e).length;
                    case "ucs2":
                    case "ucs-2":
                    case "utf16le":
                    case "utf-16le":
                        return 2 * n;
                    case "hex":
                        return n >>> 1;
                    case "base64":
                        return Q(e).length;
                    default:
                        if (r) return K(e).length;
                        t = ("" + t).toLowerCase(), r = !0
                }
            }

            function v(e, t, n) {
                var r = !1;
                if ((void 0 === t || t < 0) && (t = 0), t > this.length) return "";
                if ((void 0 === n || n > this.length) && (n = this.length), n <= 0) return "";
                if (n >>>= 0, t >>>= 0, n <= t) return "";
                e || (e = "utf8");
                while (1) switch (e) {
                    case "hex":
                        return U(this, t, n);
                    case "utf8":
                    case "utf-8":
                        return N(this, t, n);
                    case "ascii":
                        return M(this, t, n);
                    case "latin1":
                    case "binary":
                        return D(this, t, n);
                    case "base64":
                        return x(this, t, n);
                    case "ucs2":
                    case "ucs-2":
                    case "utf16le":
                    case "utf-16le":
                        return B(this, t, n);
                    default:
                        if (r) throw new TypeError("Unknown encoding: " + e);
                        e = (e + "").toLowerCase(), r = !0
                }
            }

            function E(e, t, n) {
                var r = e[t];
                e[t] = e[n], e[n] = r
            }

            function T(e, t, n, r, i) {
                if (0 === e.length) return -1;
                if ("string" === typeof n ? (r = n, n = 0) : n > 2147483647 ? n = 2147483647 : n < -2147483648 && (n = -2147483648), n = +n, isNaN(n) && (n = i ? 0 : e.length - 1), n < 0 && (n = e.length + n), n >= e.length) {
                    if (i) return -1;
                    n = e.length - 1
                } else if (n < 0) {
                    if (!i) return -1;
                    n = 0
                }
                if ("string" === typeof t && (t = h.from(t, r)), h.isBuffer(t)) return 0 === t.length ? -1 : R(e, t, n, r, i);
                if ("number" === typeof t) return t &= 255, h.TYPED_ARRAY_SUPPORT && "function" === typeof Uint8Array.prototype.indexOf ? i ? Uint8Array.prototype.indexOf.call(e, t, n) : Uint8Array.prototype.lastIndexOf.call(e, t, n) : R(e, [t], n, r, i);
                throw new TypeError("val must be string, number or Buffer")
            }

            function R(e, t, n, r, i) {
                var o, s = 1,
                    a = e.length,
                    c = t.length;
                if (void 0 !== r && (r = String(r).toLowerCase(), "ucs2" === r || "ucs-2" === r || "utf16le" === r || "utf-16le" === r)) {
                    if (e.length < 2 || t.length < 2) return -1;
                    s = 2, a /= 2, c /= 2, n /= 2
                }

                function h(e, t) {
                    return 1 === s ? e[t] : e.readUInt16BE(t * s)
                }
                if (i) {
                    var u = -1;
                    for (o = n; o < a; o++)
                        if (h(e, o) === h(t, -1 === u ? 0 : o - u)) {
                            if (-1 === u && (u = o), o - u + 1 === c) return u * s
                        } else -1 !== u && (o -= o - u), u = -1
                } else
                    for (n + c > a && (n = a - c), o = n; o >= 0; o--) {
                        for (var f = !0, d = 0; d < c; d++)
                            if (h(e, o + d) !== h(t, d)) {
                                f = !1;
                                break
                            }
                        if (f) return o
                    }
                return -1
            }

            function S(e, t, n, r) {
                n = Number(n) || 0;
                var i = e.length - n;
                r ? (r = Number(r), r > i && (r = i)) : r = i;
                var o = t.length;
                if (o % 2 !== 0) throw new TypeError("Invalid hex string");
                r > o / 2 && (r = o / 2);
                for (var s = 0; s < r; ++s) {
                    var a = parseInt(t.substr(2 * s, 2), 16);
                    if (isNaN(a)) return s;
                    e[n + s] = a
                }
                return s
            }

            function I(e, t, n, r) {
                return ee(K(t, e.length - n), e, n, r)
            }

            function O(e, t, n, r) {
                return ee(J(t), e, n, r)
            }

            function k(e, t, n, r) {
                return O(e, t, n, r)
            }

            function A(e, t, n, r) {
                return ee(Q(t), e, n, r)
            }

            function C(e, t, n, r) {
                return ee(Z(t, e.length - n), e, n, r)
            }

            function x(e, t, n) {
                return 0 === t && n === e.length ? r.fromByteArray(e) : r.fromByteArray(e.slice(t, n))
            }

            function N(e, t, n) {
                n = Math.min(e.length, n);
                var r = [],
                    i = t;
                while (i < n) {
                    var o, s, a, c, h = e[i],
                        u = null,
                        f = h > 239 ? 4 : h > 223 ? 3 : h > 191 ? 2 : 1;
                    if (i + f <= n) switch (f) {
                        case 1:
                            h < 128 && (u = h);
                            break;
                        case 2:
                            o = e[i + 1], 128 === (192 & o) && (c = (31 & h) << 6 | 63 & o, c > 127 && (u = c));
                            break;
                        case 3:
                            o = e[i + 1], s = e[i + 2], 128 === (192 & o) && 128 === (192 & s) && (c = (15 & h) << 12 | (63 & o) << 6 | 63 & s, c > 2047 && (c < 55296 || c > 57343) && (u = c));
                            break;
                        case 4:
                            o = e[i + 1], s = e[i + 2], a = e[i + 3], 128 === (192 & o) && 128 === (192 & s) && 128 === (192 & a) && (c = (15 & h) << 18 | (63 & o) << 12 | (63 & s) << 6 | 63 & a, c > 65535 && c < 1114112 && (u = c))
                    }
                    null === u ? (u = 65533, f = 1) : u > 65535 && (u -= 65536, r.push(u >>> 10 & 1023 | 55296), u = 56320 | 1023 & u), r.push(u), i += f
                }
                return L(r)
            }
            t.Buffer = h, t.SlowBuffer = b, t.INSPECT_MAX_BYTES = 50, h.TYPED_ARRAY_SUPPORT = void 0 !== e.TYPED_ARRAY_SUPPORT ? e.TYPED_ARRAY_SUPPORT : s(), t.kMaxLength = a(), h.poolSize = 8192, h._augment = function(e) {
                return e.__proto__ = h.prototype, e
            }, h.from = function(e, t, n) {
                return u(null, e, t, n)
            }, h.TYPED_ARRAY_SUPPORT && (h.prototype.__proto__ = Uint8Array.prototype, h.__proto__ = Uint8Array, "undefined" !== typeof Symbol && Symbol.species && h[Symbol.species] === h && Object.defineProperty(h, Symbol.species, {
                value: null,
                configurable: !0
            })), h.alloc = function(e, t, n) {
                return d(null, e, t, n)
            }, h.allocUnsafe = function(e) {
                return l(null, e)
            }, h.allocUnsafeSlow = function(e) {
                return l(null, e)
            }, h.isBuffer = function(e) {
                return !(null == e || !e._isBuffer)
            }, h.compare = function(e, t) {
                if (!h.isBuffer(e) || !h.isBuffer(t)) throw new TypeError("Arguments must be Buffers");
                if (e === t) return 0;
                for (var n = e.length, r = t.length, i = 0, o = Math.min(n, r); i < o; ++i)
                    if (e[i] !== t[i]) {
                        n = e[i], r = t[i];
                        break
                    }
                return n < r ? -1 : r < n ? 1 : 0
            }, h.isEncoding = function(e) {
                switch (String(e).toLowerCase()) {
                    case "hex":
                    case "utf8":
                    case "utf-8":
                    case "ascii":
                    case "latin1":
                    case "binary":
                    case "base64":
                    case "ucs2":
                    case "ucs-2":
                    case "utf16le":
                    case "utf-16le":
                        return !0;
                    default:
                        return !1
                }
            }, h.concat = function(e, t) {
                if (!o(e)) throw new TypeError('"list" argument must be an Array of Buffers');
                if (0 === e.length) return h.alloc(0);
                var n;
                if (void 0 === t)
                    for (t = 0, n = 0; n < e.length; ++n) t += e[n].length;
                var r = h.allocUnsafe(t),
                    i = 0;
                for (n = 0; n < e.length; ++n) {
                    var s = e[n];
                    if (!h.isBuffer(s)) throw new TypeError('"list" argument must be an Array of Buffers');
                    s.copy(r, i), i += s.length
                }
                return r
            }, h.byteLength = w, h.prototype._isBuffer = !0, h.prototype.swap16 = function() {
                var e = this.length;
                if (e % 2 !== 0) throw new RangeError("Buffer size must be a multiple of 16-bits");
                for (var t = 0; t < e; t += 2) E(this, t, t + 1);
                return this
            }, h.prototype.swap32 = function() {
                var e = this.length;
                if (e % 4 !== 0) throw new RangeError("Buffer size must be a multiple of 32-bits");
                for (var t = 0; t < e; t += 4) E(this, t, t + 3), E(this, t + 1, t + 2);
                return this
            }, h.prototype.swap64 = function() {
                var e = this.length;
                if (e % 8 !== 0) throw new RangeError("Buffer size must be a multiple of 64-bits");
                for (var t = 0; t < e; t += 8) E(this, t, t + 7), E(this, t + 1, t + 6), E(this, t + 2, t + 5), E(this, t + 3, t + 4);
                return this
            }, h.prototype.toString = function() {
                var e = 0 | this.length;
                return 0 === e ? "" : 0 === arguments.length ? N(this, 0, e) : v.apply(this, arguments)
            }, h.prototype.equals = function(e) {
                if (!h.isBuffer(e)) throw new TypeError("Argument must be a Buffer");
                return this === e || 0 === h.compare(this, e)
            }, h.prototype.inspect = function() {
                var e = "",
                    n = t.INSPECT_MAX_BYTES;
                return this.length > 0 && (e = this.toString("hex", 0, n).match(/.{2}/g).join(" "), this.length > n && (e += " ... ")), "<Buffer " + e + ">"
            }, h.prototype.compare = function(e, t, n, r, i) {
                if (!h.isBuffer(e)) throw new TypeError("Argument must be a Buffer");
                if (void 0 === t && (t = 0), void 0 === n && (n = e ? e.length : 0), void 0 === r && (r = 0), void 0 === i && (i = this.length), t < 0 || n > e.length || r < 0 || i > this.length) throw new RangeError("out of range index");
                if (r >= i && t >= n) return 0;
                if (r >= i) return -1;
                if (t >= n) return 1;
                if (t >>>= 0, n >>>= 0, r >>>= 0, i >>>= 0, this === e) return 0;
                for (var o = i - r, s = n - t, a = Math.min(o, s), c = this.slice(r, i), u = e.slice(t, n), f = 0; f < a; ++f)
                    if (c[f] !== u[f]) {
                        o = c[f], s = u[f];
                        break
                    }
                return o < s ? -1 : s < o ? 1 : 0
            }, h.prototype.includes = function(e, t, n) {
                return -1 !== this.indexOf(e, t, n)
            }, h.prototype.indexOf = function(e, t, n) {
                return T(this, e, t, n, !0)
            }, h.prototype.lastIndexOf = function(e, t, n) {
                return T(this, e, t, n, !1)
            }, h.prototype.write = function(e, t, n, r) {
                if (void 0 === t) r = "utf8", n = this.length, t = 0;
                else if (void 0 === n && "string" === typeof t) r = t, n = this.length, t = 0;
                else {
                    if (!isFinite(t)) throw new Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");
                    t |= 0, isFinite(n) ? (n |= 0, void 0 === r && (r = "utf8")) : (r = n, n = void 0)
                }
                var i = this.length - t;
                if ((void 0 === n || n > i) && (n = i), e.length > 0 && (n < 0 || t < 0) || t > this.length) throw new RangeError("Attempt to write outside buffer bounds");
                r || (r = "utf8");
                for (var o = !1;;) switch (r) {
                    case "hex":
                        return S(this, e, t, n);
                    case "utf8":
                    case "utf-8":
                        return I(this, e, t, n);
                    case "ascii":
                        return O(this, e, t, n);
                    case "latin1":
                    case "binary":
                        return k(this, e, t, n);
                    case "base64":
                        return A(this, e, t, n);
                    case "ucs2":
                    case "ucs-2":
                    case "utf16le":
                    case "utf-16le":
                        return C(this, e, t, n);
                    default:
                        if (o) throw new TypeError("Unknown encoding: " + r);
                        r = ("" + r).toLowerCase(), o = !0
                }
            }, h.prototype.toJSON = function() {
                return {
                    type: "Buffer",
                    data: Array.prototype.slice.call(this._arr || this, 0)
                }
            };
            var P = 4096;

            function L(e) {
                var t = e.length;
                if (t <= P) return String.fromCharCode.apply(String, e);
                var n = "",
                    r = 0;
                while (r < t) n += String.fromCharCode.apply(String, e.slice(r, r += P));
                return n
            }

            function M(e, t, n) {
                var r = "";
                n = Math.min(e.length, n);
                for (var i = t; i < n; ++i) r += String.fromCharCode(127 & e[i]);
                return r
            }

            function D(e, t, n) {
                var r = "";
                n = Math.min(e.length, n);
                for (var i = t; i < n; ++i) r += String.fromCharCode(e[i]);
                return r
            }

            function U(e, t, n) {
                var r = e.length;
                (!t || t < 0) && (t = 0), (!n || n < 0 || n > r) && (n = r);
                for (var i = "", o = t; o < n; ++o) i += X(e[o]);
                return i
            }

            function B(e, t, n) {
                for (var r = e.slice(t, n), i = "", o = 0; o < r.length; o += 2) i += String.fromCharCode(r[o] + 256 * r[o + 1]);
                return i
            }

            function j(e, t, n) {
                if (e % 1 !== 0 || e < 0) throw new RangeError("offset is not uint");
                if (e + t > n) throw new RangeError("Trying to access beyond buffer length")
            }

            function F(e, t, n, r, i, o) {
                if (!h.isBuffer(e)) throw new TypeError('"buffer" argument must be a Buffer instance');
                if (t > i || t < o) throw new RangeError('"value" argument is out of bounds');
                if (n + r > e.length) throw new RangeError("Index out of range")
            }

            function H(e, t, n, r) {
                t < 0 && (t = 65535 + t + 1);
                for (var i = 0, o = Math.min(e.length - n, 2); i < o; ++i) e[n + i] = (t & 255 << 8 * (r ? i : 1 - i)) >>> 8 * (r ? i : 1 - i)
            }

            function G(e, t, n, r) {
                t < 0 && (t = 4294967295 + t + 1);
                for (var i = 0, o = Math.min(e.length - n, 4); i < o; ++i) e[n + i] = t >>> 8 * (r ? i : 3 - i) & 255
            }

            function W(e, t, n, r, i, o) {
                if (n + r > e.length) throw new RangeError("Index out of range");
                if (n < 0) throw new RangeError("Index out of range")
            }

            function q(e, t, n, r, o) {
                return o || W(e, t, n, 4, 34028234663852886e22, -34028234663852886e22), i.write(e, t, n, r, 23, 4), n + 4
            }

            function $(e, t, n, r, o) {
                return o || W(e, t, n, 8, 17976931348623157e292, -17976931348623157e292), i.write(e, t, n, r, 52, 8), n + 8
            }
            h.prototype.slice = function(e, t) {
                var n, r = this.length;
                if (e = ~~e, t = void 0 === t ? r : ~~t, e < 0 ? (e += r, e < 0 && (e = 0)) : e > r && (e = r), t < 0 ? (t += r, t < 0 && (t = 0)) : t > r && (t = r), t < e && (t = e), h.TYPED_ARRAY_SUPPORT) n = this.subarray(e, t), n.__proto__ = h.prototype;
                else {
                    var i = t - e;
                    n = new h(i, void 0);
                    for (var o = 0; o < i; ++o) n[o] = this[o + e]
                }
                return n
            }, h.prototype.readUIntLE = function(e, t, n) {
                e |= 0, t |= 0, n || j(e, t, this.length);
                var r = this[e],
                    i = 1,
                    o = 0;
                while (++o < t && (i *= 256)) r += this[e + o] * i;
                return r
            }, h.prototype.readUIntBE = function(e, t, n) {
                e |= 0, t |= 0, n || j(e, t, this.length);
                var r = this[e + --t],
                    i = 1;
                while (t > 0 && (i *= 256)) r += this[e + --t] * i;
                return r
            }, h.prototype.readUInt8 = function(e, t) {
                return t || j(e, 1, this.length), this[e]
            }, h.prototype.readUInt16LE = function(e, t) {
                return t || j(e, 2, this.length), this[e] | this[e + 1] << 8
            }, h.prototype.readUInt16BE = function(e, t) {
                return t || j(e, 2, this.length), this[e] << 8 | this[e + 1]
            }, h.prototype.readUInt32LE = function(e, t) {
                return t || j(e, 4, this.length), (this[e] | this[e + 1] << 8 | this[e + 2] << 16) + 16777216 * this[e + 3]
            }, h.prototype.readUInt32BE = function(e, t) {
                return t || j(e, 4, this.length), 16777216 * this[e] + (this[e + 1] << 16 | this[e + 2] << 8 | this[e + 3])
            }, h.prototype.readIntLE = function(e, t, n) {
                e |= 0, t |= 0, n || j(e, t, this.length);
                var r = this[e],
                    i = 1,
                    o = 0;
                while (++o < t && (i *= 256)) r += this[e + o] * i;
                return i *= 128, r >= i && (r -= Math.pow(2, 8 * t)), r
            }, h.prototype.readIntBE = function(e, t, n) {
                e |= 0, t |= 0, n || j(e, t, this.length);
                var r = t,
                    i = 1,
                    o = this[e + --r];
                while (r > 0 && (i *= 256)) o += this[e + --r] * i;
                return i *= 128, o >= i && (o -= Math.pow(2, 8 * t)), o
            }, h.prototype.readInt8 = function(e, t) {
                return t || j(e, 1, this.length), 128 & this[e] ? -1 * (255 - this[e] + 1) : this[e]
            }, h.prototype.readInt16LE = function(e, t) {
                t || j(e, 2, this.length);
                var n = this[e] | this[e + 1] << 8;
                return 32768 & n ? 4294901760 | n : n
            }, h.prototype.readInt16BE = function(e, t) {
                t || j(e, 2, this.length);
                var n = this[e + 1] | this[e] << 8;
                return 32768 & n ? 4294901760 | n : n
            }, h.prototype.readInt32LE = function(e, t) {
                return t || j(e, 4, this.length), this[e] | this[e + 1] << 8 | this[e + 2] << 16 | this[e + 3] << 24
            }, h.prototype.readInt32BE = function(e, t) {
                return t || j(e, 4, this.length), this[e] << 24 | this[e + 1] << 16 | this[e + 2] << 8 | this[e + 3]
            }, h.prototype.readFloatLE = function(e, t) {
                return t || j(e, 4, this.length), i.read(this, e, !0, 23, 4)
            }, h.prototype.readFloatBE = function(e, t) {
                return t || j(e, 4, this.length), i.read(this, e, !1, 23, 4)
            }, h.prototype.readDoubleLE = function(e, t) {
                return t || j(e, 8, this.length), i.read(this, e, !0, 52, 8)
            }, h.prototype.readDoubleBE = function(e, t) {
                return t || j(e, 8, this.length), i.read(this, e, !1, 52, 8)
            }, h.prototype.writeUIntLE = function(e, t, n, r) {
                if (e = +e, t |= 0, n |= 0, !r) {
                    var i = Math.pow(2, 8 * n) - 1;
                    F(this, e, t, n, i, 0)
                }
                var o = 1,
                    s = 0;
                this[t] = 255 & e;
                while (++s < n && (o *= 256)) this[t + s] = e / o & 255;
                return t + n
            }, h.prototype.writeUIntBE = function(e, t, n, r) {
                if (e = +e, t |= 0, n |= 0, !r) {
                    var i = Math.pow(2, 8 * n) - 1;
                    F(this, e, t, n, i, 0)
                }
                var o = n - 1,
                    s = 1;
                this[t + o] = 255 & e;
                while (--o >= 0 && (s *= 256)) this[t + o] = e / s & 255;
                return t + n
            }, h.prototype.writeUInt8 = function(e, t, n) {
                return e = +e, t |= 0, n || F(this, e, t, 1, 255, 0), h.TYPED_ARRAY_SUPPORT || (e = Math.floor(e)), this[t] = 255 & e, t + 1
            }, h.prototype.writeUInt16LE = function(e, t, n) {
                return e = +e, t |= 0, n || F(this, e, t, 2, 65535, 0), h.TYPED_ARRAY_SUPPORT ? (this[t] = 255 & e, this[t + 1] = e >>> 8) : H(this, e, t, !0), t + 2
            }, h.prototype.writeUInt16BE = function(e, t, n) {
                return e = +e, t |= 0, n || F(this, e, t, 2, 65535, 0), h.TYPED_ARRAY_SUPPORT ? (this[t] = e >>> 8, this[t + 1] = 255 & e) : H(this, e, t, !1), t + 2
            }, h.prototype.writeUInt32LE = function(e, t, n) {
                return e = +e, t |= 0, n || F(this, e, t, 4, 4294967295, 0), h.TYPED_ARRAY_SUPPORT ? (this[t + 3] = e >>> 24, this[t + 2] = e >>> 16, this[t + 1] = e >>> 8, this[t] = 255 & e) : G(this, e, t, !0), t + 4
            }, h.prototype.writeUInt32BE = function(e, t, n) {
                return e = +e, t |= 0, n || F(this, e, t, 4, 4294967295, 0), h.TYPED_ARRAY_SUPPORT ? (this[t] = e >>> 24, this[t + 1] = e >>> 16, this[t + 2] = e >>> 8, this[t + 3] = 255 & e) : G(this, e, t, !1), t + 4
            }, h.prototype.writeIntLE = function(e, t, n, r) {
                if (e = +e, t |= 0, !r) {
                    var i = Math.pow(2, 8 * n - 1);
                    F(this, e, t, n, i - 1, -i)
                }
                var o = 0,
                    s = 1,
                    a = 0;
                this[t] = 255 & e;
                while (++o < n && (s *= 256)) e < 0 && 0 === a && 0 !== this[t + o - 1] && (a = 1), this[t + o] = (e / s >> 0) - a & 255;
                return t + n
            }, h.prototype.writeIntBE = function(e, t, n, r) {
                if (e = +e, t |= 0, !r) {
                    var i = Math.pow(2, 8 * n - 1);
                    F(this, e, t, n, i - 1, -i)
                }
                var o = n - 1,
                    s = 1,
                    a = 0;
                this[t + o] = 255 & e;
                while (--o >= 0 && (s *= 256)) e < 0 && 0 === a && 0 !== this[t + o + 1] && (a = 1), this[t + o] = (e / s >> 0) - a & 255;
                return t + n
            }, h.prototype.writeInt8 = function(e, t, n) {
                return e = +e, t |= 0, n || F(this, e, t, 1, 127, -128), h.TYPED_ARRAY_SUPPORT || (e = Math.floor(e)), e < 0 && (e = 255 + e + 1), this[t] = 255 & e, t + 1
            }, h.prototype.writeInt16LE = function(e, t, n) {
                return e = +e, t |= 0, n || F(this, e, t, 2, 32767, -32768), h.TYPED_ARRAY_SUPPORT ? (this[t] = 255 & e, this[t + 1] = e >>> 8) : H(this, e, t, !0), t + 2
            }, h.prototype.writeInt16BE = function(e, t, n) {
                return e = +e, t |= 0, n || F(this, e, t, 2, 32767, -32768), h.TYPED_ARRAY_SUPPORT ? (this[t] = e >>> 8, this[t + 1] = 255 & e) : H(this, e, t, !1), t + 2
            }, h.prototype.writeInt32LE = function(e, t, n) {
                return e = +e, t |= 0, n || F(this, e, t, 4, 2147483647, -2147483648), h.TYPED_ARRAY_SUPPORT ? (this[t] = 255 & e, this[t + 1] = e >>> 8, this[t + 2] = e >>> 16, this[t + 3] = e >>> 24) : G(this, e, t, !0), t + 4
            }, h.prototype.writeInt32BE = function(e, t, n) {
                return e = +e, t |= 0, n || F(this, e, t, 4, 2147483647, -2147483648), e < 0 && (e = 4294967295 + e + 1), h.TYPED_ARRAY_SUPPORT ? (this[t] = e >>> 24, this[t + 1] = e >>> 16, this[t + 2] = e >>> 8, this[t + 3] = 255 & e) : G(this, e, t, !1), t + 4
            }, h.prototype.writeFloatLE = function(e, t, n) {
                return q(this, e, t, !0, n)
            }, h.prototype.writeFloatBE = function(e, t, n) {
                return q(this, e, t, !1, n)
            }, h.prototype.writeDoubleLE = function(e, t, n) {
                return $(this, e, t, !0, n)
            }, h.prototype.writeDoubleBE = function(e, t, n) {
                return $(this, e, t, !1, n)
            }, h.prototype.copy = function(e, t, n, r) {
                if (n || (n = 0), r || 0 === r || (r = this.length), t >= e.length && (t = e.length), t || (t = 0), r > 0 && r < n && (r = n), r === n) return 0;
                if (0 === e.length || 0 === this.length) return 0;
                if (t < 0) throw new RangeError("targetStart out of bounds");
                if (n < 0 || n >= this.length) throw new RangeError("sourceStart out of bounds");
                if (r < 0) throw new RangeError("sourceEnd out of bounds");
                r > this.length && (r = this.length), e.length - t < r - n && (r = e.length - t + n);
                var i, o = r - n;
                if (this === e && n < t && t < r)
                    for (i = o - 1; i >= 0; --i) e[i + t] = this[i + n];
                else if (o < 1e3 || !h.TYPED_ARRAY_SUPPORT)
                    for (i = 0; i < o; ++i) e[i + t] = this[i + n];
                else Uint8Array.prototype.set.call(e, this.subarray(n, n + o), t);
                return o
            }, h.prototype.fill = function(e, t, n, r) {
                if ("string" === typeof e) {
                    if ("string" === typeof t ? (r = t, t = 0, n = this.length) : "string" === typeof n && (r = n, n = this.length), 1 === e.length) {
                        var i = e.charCodeAt(0);
                        i < 256 && (e = i)
                    }
                    if (void 0 !== r && "string" !== typeof r) throw new TypeError("encoding must be a string");
                    if ("string" === typeof r && !h.isEncoding(r)) throw new TypeError("Unknown encoding: " + r)
                } else "number" === typeof e && (e &= 255);
                if (t < 0 || this.length < t || this.length < n) throw new RangeError("Out of range index");
                if (n <= t) return this;
                var o;
                if (t >>>= 0, n = void 0 === n ? this.length : n >>> 0, e || (e = 0), "number" === typeof e)
                    for (o = t; o < n; ++o) this[o] = e;
                else {
                    var s = h.isBuffer(e) ? e : K(new h(e, r).toString()),
                        a = s.length;
                    for (o = 0; o < n - t; ++o) this[o + t] = s[o % a]
                }
                return this
            };
            var Y = /[^+\/0-9A-Za-z-_]/g;

            function z(e) {
                if (e = V(e).replace(Y, ""), e.length < 2) return "";
                while (e.length % 4 !== 0) e += "=";
                return e
            }

            function V(e) {
                return e.trim ? e.trim() : e.replace(/^\s+|\s+$/g, "")
            }

            function X(e) {
                return e < 16 ? "0" + e.toString(16) : e.toString(16)
            }

            function K(e, t) {
                var n;
                t = t || 1 / 0;
                for (var r = e.length, i = null, o = [], s = 0; s < r; ++s) {
                    if (n = e.charCodeAt(s), n > 55295 && n < 57344) {
                        if (!i) {
                            if (n > 56319) {
                                (t -= 3) > -1 && o.push(239, 191, 189);
                                continue
                            }
                            if (s + 1 === r) {
                                (t -= 3) > -1 && o.push(239, 191, 189);
                                continue
                            }
                            i = n;
                            continue
                        }
                        if (n < 56320) {
                            (t -= 3) > -1 && o.push(239, 191, 189), i = n;
                            continue
                        }
                        n = 65536 + (i - 55296 << 10 | n - 56320)
                    } else i && (t -= 3) > -1 && o.push(239, 191, 189);
                    if (i = null, n < 128) {
                        if ((t -= 1) < 0) break;
                        o.push(n)
                    } else if (n < 2048) {
                        if ((t -= 2) < 0) break;
                        o.push(n >> 6 | 192, 63 & n | 128)
                    } else if (n < 65536) {
                        if ((t -= 3) < 0) break;
                        o.push(n >> 12 | 224, n >> 6 & 63 | 128, 63 & n | 128)
                    } else {
                        if (!(n < 1114112)) throw new Error("Invalid code point");
                        if ((t -= 4) < 0) break;
                        o.push(n >> 18 | 240, n >> 12 & 63 | 128, n >> 6 & 63 | 128, 63 & n | 128)
                    }
                }
                return o
            }

            function J(e) {
                for (var t = [], n = 0; n < e.length; ++n) t.push(255 & e.charCodeAt(n));
                return t
            }

            function Z(e, t) {
                for (var n, r, i, o = [], s = 0; s < e.length; ++s) {
                    if ((t -= 2) < 0) break;
                    n = e.charCodeAt(s), r = n >> 8, i = n % 256, o.push(i), o.push(r)
                }
                return o
            }

            function Q(e) {
                return r.toByteArray(z(e))
            }

            function ee(e, t, n, r) {
                for (var i = 0; i < r; ++i) {
                    if (i + n >= t.length || i >= e.length) break;
                    t[i + n] = e[i]
                }
                return i
            }

            function te(e) {
                return e !== e
            }
        }).call(this, n("c8ba"))
    },
    b6aa: function(e, t, n) {
        "use strict";

        function r(e, t) {
            for (const n in t) Object.defineProperty(e, n, {
                value: t[n],
                enumerable: !0,
                configurable: !0
            });
            return e
        }

        function i(e, t, n) {
            if (!e || "string" === typeof e) throw new TypeError("Please pass an Error to err-code");
            n || (n = {}), "object" === typeof t && (n = t, t = ""), t && (n.code = t);
            try {
                return r(e, n)
            } catch (i) {
                n.message = e.message, n.stack = e.stack;
                const t = function() {};
                t.prototype = Object.create(Object.getPrototypeOf(e));
                const o = r(new t, n);
                return o
            }
        }
        e.exports = i
    },
    b727: function(e, t, n) {
        var r = n("0366"),
            i = n("44ad"),
            o = n("7b0b"),
            s = n("50c4"),
            a = n("65f0"),
            c = [].push,
            h = function(e) {
                var t = 1 == e,
                    n = 2 == e,
                    h = 3 == e,
                    u = 4 == e,
                    f = 6 == e,
                    d = 7 == e,
                    l = 5 == e || f;
                return function(p, g, _, y) {
                    for (var m, b, w = o(p), v = i(w), E = r(g, _, 3), T = s(v.length), R = 0, S = y || a, I = t ? S(p, T) : n || d ? S(p, 0) : void 0; T > R; R++)
                        if ((l || R in v) && (m = v[R], b = E(m, R, w), e))
                            if (t) I[R] = b;
                            else if (b) switch (e) {
                        case 3:
                            return !0;
                        case 5:
                            return m;
                        case 6:
                            return R;
                        case 2:
                            c.call(I, m)
                    } else switch (e) {
                        case 4:
                            return !1;
                        case 7:
                            c.call(I, m)
                    }
                    return f ? -1 : h || u ? u : I
                }
            };
        e.exports = {
            forEach: h(0),
            map: h(1),
            filter: h(2),
            some: h(3),
            every: h(4),
            find: h(5),
            findIndex: h(6),
            filterReject: h(7)
        }
    },
    b7d1: function(e, t, n) {
        (function(t) {
            function n(e, t) {
                if (r("noDeprecation")) return e;
                var n = !1;

                function i() {
                    if (!n) {
                        if (r("throwDeprecation")) throw new Error(t);
                        r("traceDeprecation") ? console.trace(t) : console.warn(t), n = !0
                    }
                    return e.apply(this, arguments)
                }
                return i
            }

            function r(e) {
                try {
                    if (!t.localStorage) return !1
                } catch (r) {
                    return !1
                }
                var n = t.localStorage[e];
                return null != n && "true" === String(n).toLowerCase()
            }
            e.exports = n
        }).call(this, n("c8ba"))
    },
    b944: function(e, t, n) {
        (function(t, r) { /*! parse-torrent. MIT License. WebTorrent LLC <https://webtorrent.io/opensource> */
            const i = n("8fe2"),
                o = n("4947"),
                s = n("3e8f"),
                a = n("c7ba"),
                c = n("83cc"),
                h = n("df7c"),
                u = n("2a3b");

            function f(e) {
                if ("string" === typeof e && /^(stream-)?magnet:/.test(e)) {
                    const t = c(e);
                    if (!t.infoHash) throw new Error("Invalid torrent identifier");
                    return t
                }
                if ("string" === typeof e && (/^[a-f0-9]{40}$/i.test(e) || /^[a-z2-7]{32}$/i.test(e))) return c("magnet:?xt=urn:btih:" + e);
                if (t.isBuffer(e) && 20 === e.length) return c("magnet:?xt=urn:btih:" + e.toString("hex"));
                if (t.isBuffer(e)) return l(e);
                if (e && e.infoHash) return e.infoHash = e.infoHash.toLowerCase(), e.announce || (e.announce = []), "string" === typeof e.announce && (e.announce = [e.announce]), e.urlList || (e.urlList = []), e;
                throw new Error("Invalid torrent identifier")
            }

            function d(e, t) {
                let n;
                if ("function" !== typeof t) throw new Error("second argument must be a Function");
                try {
                    n = f(e)
                } catch (c) {}

                function i(e) {
                    try {
                        n = f(e)
                    } catch (c) {
                        return t(c)
                    }
                    n && n.infoHash ? t(null, n) : t(new Error("Invalid torrent identifier"))
                }
                n && n.infoHash ? r.nextTick(() => {
                    t(null, n)
                }) : g(e) ? o(e, (e, n) => {
                    if (e) return t(new Error("Error converting Blob: " + e.message));
                    i(n)
                }) : "function" === typeof a && /^https?:/.test(e) ? a.concat({
                    url: e,
                    timeout: 3e4,
                    headers: {
                        "user-agent": "WebTorrent (https://webtorrent.io)"
                    }
                }, (e, n, r) => {
                    if (e) return t(new Error("Error downloading torrent: " + e.message));
                    i(r)
                }) : "function" === typeof s.readFile && "string" === typeof e ? s.readFile(e, (e, n) => {
                    if (e) return t(new Error("Invalid torrent identifier"));
                    i(n)
                }) : r.nextTick(() => {
                    t(new Error("Invalid torrent identifier"))
                })
            }

            function l(e) {
                t.isBuffer(e) && (e = i.decode(e)), m(e.info, "info"), m(e.info["name.utf-8"] || e.info.name, "info.name"), m(e.info["piece length"], "info['piece length']"), m(e.info.pieces, "info.pieces"), e.info.files ? e.info.files.forEach(e => {
                    m("number" === typeof e.length, "info.files[0].length"), m(e["path.utf-8"] || e.path, "info.files[0].path")
                }) : m("number" === typeof e.info.length, "info.length");
                const n = {
                    info: e.info,
                    infoBuffer: i.encode(e.info),
                    name: (e.info["name.utf-8"] || e.info.name).toString(),
                    announce: []
                };
                n.infoHash = u.sync(n.infoBuffer), n.infoHashBuffer = t.from(n.infoHash, "hex"), void 0 !== e.info.private && (n.private = !!e.info.private), e["creation date"] && (n.created = new Date(1e3 * e["creation date"])), e["created by"] && (n.createdBy = e["created by"].toString()), t.isBuffer(e.comment) && (n.comment = e.comment.toString()), Array.isArray(e["announce-list"]) && e["announce-list"].length > 0 ? e["announce-list"].forEach(e => {
                    e.forEach(e => {
                        n.announce.push(e.toString())
                    })
                }) : e.announce && n.announce.push(e.announce.toString()), t.isBuffer(e["url-list"]) && (e["url-list"] = e["url-list"].length > 0 ? [e["url-list"]] : []), n.urlList = (e["url-list"] || []).map(e => e.toString()), n.announce = Array.from(new Set(n.announce)), n.urlList = Array.from(new Set(n.urlList));
                const r = e.info.files || [e.info];
                n.files = r.map((e, t) => {
                    const i = [].concat(n.name, e["path.utf-8"] || e.path || []).map(e => e.toString());
                    return {
                        path: h.join.apply(null, [h.sep].concat(i)).slice(1),
                        name: i[i.length - 1],
                        length: e.length,
                        offset: r.slice(0, t).reduce(_, 0)
                    }
                }), n.length = r.reduce(_, 0);
                const o = n.files[n.files.length - 1];
                return n.pieceLength = e.info["piece length"], n.lastPieceLength = (o.offset + o.length) % n.pieceLength || n.pieceLength, n.pieces = y(e.info.pieces), n
            }

            function p(e) {
                const n = {
                    info: e.info
                };
                return n["announce-list"] = (e.announce || []).map(e => (n.announce || (n.announce = e), e = t.from(e, "utf8"), [e])), n["url-list"] = e.urlList || [], void 0 !== e.private && (n.private = Number(e.private)), e.created && (n["creation date"] = e.created.getTime() / 1e3 | 0), e.createdBy && (n["created by"] = e.createdBy), e.comment && (n.comment = e.comment), i.encode(n)
            }

            function g(e) {
                return "undefined" !== typeof Blob && e instanceof Blob
            }

            function _(e, t) {
                return e + t.length
            }

            function y(e) {
                const t = [];
                for (let n = 0; n < e.length; n += 20) t.push(e.slice(n, n + 20).toString("hex"));
                return t
            }

            function m(e, t) {
                if (!e) throw new Error("Torrent is missing required field: " + t)
            }
            e.exports = f, e.exports.remote = d, e.exports.toMagnetURI = c.encode, e.exports.toTorrentFile = p, (() => {
                t.alloc(0)
            })()
        }).call(this, n("b639").Buffer, n("4362"))
    },
    bcda: function(e, t) {
        class n {
            constructor(e) {
                this._torrent = e, this._numPieces = e.pieces.length, this._pieces = new Array(this._numPieces), this._onWire = e => {
                    this.recalculate(), this._initWire(e)
                }, this._onWireHave = e => {
                    this._pieces[e] += 1
                }, this._onWireBitfield = () => {
                    this.recalculate()
                }, this._torrent.wires.forEach(e => {
                    this._initWire(e)
                }), this._torrent.on("wire", this._onWire), this.recalculate()
            }
            getRarestPiece(e) {
                let t = [],
                    n = 1 / 0;
                for (let r = 0; r < this._numPieces; ++r) {
                    if (e && !e(r)) continue;
                    const i = this._pieces[r];
                    i === n ? t.push(r) : i < n && (t = [r], n = i)
                }
                return t.length ? t[Math.random() * t.length | 0] : -1
            }
            destroy() {
                this._torrent.removeListener("wire", this._onWire), this._torrent.wires.forEach(e => {
                    this._cleanupWireEvents(e)
                }), this._torrent = null, this._pieces = null, this._onWire = null, this._onWireHave = null, this._onWireBitfield = null
            }
            _initWire(e) {
                e._onClose = () => {
                    this._cleanupWireEvents(e);
                    for (let t = 0; t < this._numPieces; ++t) this._pieces[t] -= e.peerPieces.get(t)
                }, e.on("have", this._onWireHave), e.on("bitfield", this._onWireBitfield), e.once("close", e._onClose)
            }
            recalculate() {
                this._pieces.fill(0);
                for (const e of this._torrent.wires)
                    for (let t = 0; t < this._numPieces; ++t) this._pieces[t] += e.peerPieces.get(t)
            }
            _cleanupWireEvents(e) {
                e.removeListener("have", this._onWireHave), e.removeListener("bitfield", this._onWireBitfield), e._onClose && e.removeListener("close", e._onClose), e._onClose = null
            }
        }
        e.exports = n
    },
    bf19: function(e, t, n) {
        "use strict";
        var r = n("23e7");
        r({
            target: "URL",
            proto: !0,
            enumerable: !0
        }, {
            toJSON: function() {
                return URL.prototype.toString.call(this)
            }
        })
    },
    c04e: function(e, t, n) {
        var r = n("861d"),
            i = n("d9b5"),
            o = n("485a"),
            s = n("b622"),
            a = s("toPrimitive");
        e.exports = function(e, t) {
            if (!r(e) || i(e)) return e;
            var n, s = e[a];
            if (void 0 !== s) {
                if (void 0 === t && (t = "default"), n = s.call(e, t), !r(n) || i(n)) return n;
                throw TypeError("Can't convert object to primitive value")
            }
            return void 0 === t && (t = "number"), o(e, t)
        }
    },
    c115: function(e, t, n) {
        (function(t, r) {
            const i = n("326b"),
                o = n("d329"),
                s = n("94e2"),
                a = n("34eb")("webtorrent:torrent"),
                c = n("17f3"),
                h = n("faa1").EventEmitter,
                u = n("3e8f"),
                f = n("2677"),
                d = n("c7ba"),
                l = n("9f6f"),
                p = n("13ee"),
                g = n(11),
                _ = n(12),
                y = n("8cc1"),
                m = n("c3b3"),
                b = n("b944"),
                w = n("df7c"),
                v = n("50cf"),
                E = n("6f59"),
                T = n("616f"),
                R = n("2a3b"),
                S = n("7b03"),
                I = n("175e"),
                O = n("2527"),
                k = n(14),
                A = n("4fdc"),
                C = n("e3a2"),
                x = n("50b2"),
                N = n("bcda"),
                P = n(15),
                L = 131072,
                M = 3e4,
                D = 5e3,
                U = 3 * v.BLOCK_LENGTH,
                B = .5,
                j = 1,
                F = 1e4,
                H = 2,
                G = t.browser ? 1 / 0 : 2,
                W = [1e3, 5e3, 15e3],
                q = n("af39").version,
                $ = `WebTorrent/${q} (https://webtorrent.io)`;
            let Y;
            try {
                Y = w.join(u.statSync("/tmp") && "/tmp", "webtorrent")
            } catch (Z) {
                Y = w.join("function" === typeof _.tmpdir ? _.tmpdir() : "/", "webtorrent")
            }
            class z extends h {
                constructor(e, t, n) {
                    super(), this._debugId = "unknown infohash", this.client = t, this.announce = n.announce, this.urlList = n.urlList, this.path = n.path, this.skipVerify = !!n.skipVerify, this._store = n.store || f, this._getAnnounceOpts = n.getAnnounceOpts, this.strategy = n.strategy || "sequential", this.maxWebConns = n.maxWebConns || 4, this._rechokeNumSlots = !1 === n.uploads || 0 === n.uploads ? 0 : +n.uploads || 10, this._rechokeOptimisticWire = null, this._rechokeOptimisticTime = 0, this._rechokeIntervalId = null, this.ready = !1, this.destroyed = !1, this.paused = !1, this.done = !1, this.metadata = null, this.store = null, this.files = [], this.pieces = [], this._amInterested = !1, this._selections = [], this._critical = [], this.wires = [], this._queue = [], this._peers = {}, this._peersLength = 0, this.received = 0, this.uploaded = 0, this._downloadSpeed = S(), this._uploadSpeed = S(), this._servers = [], this._xsRequests = [], this._fileModtimes = n.fileModtimes, null !== e && this._onTorrentId(e), this._debug("new torrent")
                }
                get timeRemaining() {
                    return this.done ? 0 : 0 === this.downloadSpeed ? 1 / 0 : (this.length - this.downloaded) / this.downloadSpeed * 1e3
                }
                get downloaded() {
                    if (!this.bitfield) return 0;
                    let e = 0;
                    for (let t = 0, n = this.pieces.length; t < n; ++t)
                        if (this.bitfield.get(t)) e += t === n - 1 ? this.lastPieceLength : this.pieceLength;
                        else {
                            const n = this.pieces[t];
                            e += n.length - n.missing
                        }
                    return e
                }
                get downloadSpeed() {
                    return this._downloadSpeed()
                }
                get uploadSpeed() {
                    return this._uploadSpeed()
                }
                get progress() {
                    return this.length ? this.downloaded / this.length : 0
                }
                get ratio() {
                    return this.uploaded / (this.received || 1)
                }
                get numPeers() {
                    return this.wires.length
                }
                get torrentFileBlobURL() {
                    if ("undefined" === typeof window) throw new Error("browser-only property");
                    return this.torrentFile ? URL.createObjectURL(new Blob([this.torrentFile], {
                        type: "application/x-bittorrent"
                    })) : null
                }
                get _numQueued() {
                    return this._queue.length + (this._peersLength - this._numConns)
                }
                get _numConns() {
                    let e = 0;
                    for (const t in this._peers) this._peers[t].connected && (e += 1);
                    return e
                }
                get swarm() {
                    return console.warn("WebTorrent: `torrent.swarm` is deprecated. Use `torrent` directly instead."), this
                }
                _onTorrentId(e) {
                    if (this.destroyed) return;
                    let n;
                    try {
                        n = b(e)
                    } catch (Z) {}
                    n ? (this.infoHash = n.infoHash, this._debugId = n.infoHash.toString("hex").substring(0, 7), t.nextTick(() => {
                        this.destroyed || this._onParsedTorrent(n)
                    })) : b.remote(e, (e, t) => {
                        if (!this.destroyed) return e ? this._destroy(e) : void this._onParsedTorrent(t)
                    })
                }
                _onParsedTorrent(e) {
                    if (!this.destroyed) {
                        if (this._processParsedTorrent(e), !this.infoHash) return this._destroy(new Error("Malformed torrent data: No info hash"));
                        this.path || (this.path = w.join(Y, this.infoHash)), this._rechokeIntervalId = setInterval(() => {
                            this._rechoke()
                        }, F), this._rechokeIntervalId.unref && this._rechokeIntervalId.unref(), this.emit("_infoHash", this.infoHash), this.destroyed || (this.emit("infoHash", this.infoHash), this.destroyed || (this.client.listening ? this._onListening() : this.client.once("listening", () => {
                            this._onListening()
                        })))
                    }
                }
                _processParsedTorrent(e) {
                    this._debugId = e.infoHash.toString("hex").substring(0, 7), this.announce && (e.announce = e.announce.concat(this.announce)), this.client.tracker && r.WEBTORRENT_ANNOUNCE && !this.private && (e.announce = e.announce.concat(r.WEBTORRENT_ANNOUNCE)), this.urlList && (e.urlList = e.urlList.concat(this.urlList)), I(e.announce), I(e.urlList), Object.assign(this, e), this.magnetURI = b.toMagnetURI(e), this.torrentFile = b.toTorrentFile(e)
                }
                _onListening() {
                    if (this.discovery || this.destroyed) return;
                    let e = this.client.tracker;
                    e && (e = Object.assign({}, this.client.tracker, {
                        getAnnounceOpts: () => {
                            const e = {
                                uploaded: this.uploaded,
                                downloaded: this.downloaded,
                                left: Math.max(this.length - this.downloaded, 0)
                            };
                            return this.client.tracker.getAnnounceOpts && Object.assign(e, this.client.tracker.getAnnounceOpts()), this._getAnnounceOpts && Object.assign(e, this._getAnnounceOpts()), e
                        }
                    })), this.discovery = new c({
                        infoHash: this.infoHash,
                        announce: this.announce,
                        peerId: this.client.peerId,
                        dht: !this.private && this.client.dht,
                        tracker: e,
                        port: this.client.torrentPort,
                        userAgent: $
                    }), this.discovery.on("error", e => {
                        this._destroy(e)
                    }), this.discovery.on("peer", e => {
                        "string" === typeof e && this.done || this.addPeer(e)
                    }), this.discovery.on("trackerAnnounce", () => {
                        this.emit("trackerAnnounce"), 0 === this.numPeers && this.emit("noPeers", "tracker")
                    }), this.discovery.on("dhtAnnounce", () => {
                        this.emit("dhtAnnounce"), 0 === this.numPeers && this.emit("noPeers", "dht")
                    }), this.discovery.on("warning", e => {
                        this.emit("warning", e)
                    }), this.info ? this._onMetadata(this) : this.xs && this._getMetadataFromServer()
                }
                _getMetadataFromServer() {
                    const e = this,
                        t = Array.isArray(this.xs) ? this.xs : [this.xs],
                        n = t.map(e => t => {
                            r(e, t)
                        });

                    function r(t, n) {
                        if (0 !== t.indexOf("http://") && 0 !== t.indexOf("https://")) return e.emit("warning", new Error("skipping non-http xs param: " + t)), n(null);
                        const r = {
                            url: t,
                            method: "GET",
                            headers: {
                                "user-agent": $
                            }
                        };
                        let i;
                        try {
                            i = d.concat(r, o)
                        } catch (Z) {
                            return e.emit("warning", new Error("skipping invalid url xs param: " + t)), n(null)
                        }

                        function o(r, i, o) {
                            if (e.destroyed) return n(null);
                            if (e.metadata) return n(null);
                            if (r) return e.emit("warning", new Error("http error from xs param: " + t)), n(null);
                            if (200 !== i.statusCode) return e.emit("warning", new Error(`non-200 status code ${i.statusCode} from xs param: ${t}`)), n(null);
                            let s;
                            try {
                                s = b(o)
                            } catch (r) {}
                            return s ? s.infoHash !== e.infoHash ? (e.emit("warning", new Error("got torrent file with incorrect info hash from xs param: " + t)), n(null)) : (e._onMetadata(s), void n(null)) : (e.emit("warning", new Error("got invalid torrent file from xs param: " + t)), n(null))
                        }
                        e._xsRequests.push(i)
                    }
                    y(n)
                }
                _onMetadata(e) {
                    if (this.metadata || this.destroyed) return;
                    let t;
                    if (this._debug("got metadata"), this._xsRequests.forEach(e => {
                            e.abort()
                        }), this._xsRequests = [], e && e.infoHash) t = e;
                    else try {
                        t = b(e)
                    } catch (Z) {
                        return this._destroy(Z)
                    }
                    if (this._processParsedTorrent(t), this.metadata = this.torrentFile, this.client.enableWebSeeds && this.urlList.forEach(e => {
                            this.addWebSeed(e)
                        }), this._rarityMap = new N(this), this.store = new l(new this._store(this.pieceLength, {
                            torrent: {
                                infoHash: this.infoHash
                            },
                            files: this.files.map(e => ({
                                path: w.join(this.path, e.path),
                                length: e.length,
                                offset: e.offset
                            })),
                            length: this.length,
                            name: this.infoHash
                        })), this.files = this.files.map(e => new C(this, e)), this.so) {
                        const e = A.parse(this.so);
                        this.files.forEach((t, n) => {
                            e.includes(n) && this.files[n].select(!0)
                        })
                    } else 0 !== this.pieces.length && this.select(0, this.pieces.length - 1, !1);
                    if (this._hashes = this.pieces, this.pieces = this.pieces.map((e, t) => {
                            const n = t === this.pieces.length - 1 ? this.lastPieceLength : this.pieceLength;
                            return new v(n)
                        }), this._reservations = this.pieces.map(() => []), this.bitfield = new o(this.pieces.length), this.wires.forEach(e => {
                            e.ut_metadata && e.ut_metadata.setMetadata(this.metadata), this._onWireWithMetadata(e)
                        }), this.skipVerify) this._markAllVerified(), this._onStore();
                    else {
                        const e = e => {
                            if (e) return this._destroy(e);
                            this._debug("done verifying"), this._onStore()
                        };
                        this._debug("verifying existing torrent data"), this._fileModtimes && this._store === f ? this.getFileModtimes((t, n) => {
                            if (t) return this._destroy(t);
                            const r = this.files.map((e, t) => n[t] === this._fileModtimes[t]).every(e => e);
                            r ? (this._markAllVerified(), this._onStore()) : this._verifyPieces(e)
                        }) : this._verifyPieces(e)
                    }
                    this.emit("metadata")
                }
                getFileModtimes(e) {
                    const t = [];
                    m(this.files.map((e, n) => r => {
                        u.stat(w.join(this.path, e.path), (e, i) => {
                            if (e && "ENOENT" !== e.code) return r(e);
                            t[n] = i && i.mtime.getTime(), r(null)
                        })
                    }), G, n => {
                        this._debug("done getting file modtimes"), e(n, t)
                    })
                }
                _verifyPieces(e) {
                    m(this.pieces.map((e, n) => e => {
                        if (this.destroyed) return e(new Error("torrent is destroyed"));
                        this.store.get(n, (r, i) => this.destroyed ? e(new Error("torrent is destroyed")) : r ? t.nextTick(e, null) : void R(i, t => {
                            if (this.destroyed) return e(new Error("torrent is destroyed"));
                            if (t === this._hashes[n]) {
                                if (!this.pieces[n]) return e(null);
                                this._debug("piece verified %s", n), this._markVerified(n)
                            } else this._debug("piece invalid %s", n);
                            e(null)
                        }))
                    }), G, e)
                }
                rescanFiles(e) {
                    if (this.destroyed) throw new Error("torrent is destroyed");
                    e || (e = J), this._verifyPieces(t => {
                        if (t) return this._destroy(t), e(t);
                        this._checkDone(), e(null)
                    })
                }
                _markAllVerified() {
                    for (let e = 0; e < this.pieces.length; e++) this._markVerified(e)
                }
                _markVerified(e) {
                    this.pieces[e] = null, this._reservations[e] = null, this.bitfield.set(e, !0)
                }
                _onStore() {
                    this.destroyed || (this._debug("on store"), this.ready = !0, this.emit("ready"), this._checkDone(), this._updateSelections())
                }
                destroy(e) {
                    this._destroy(null, e)
                }
                _destroy(e, t) {
                    if (this.destroyed) return;
                    this.destroyed = !0, this._debug("destroy"), this.client._remove(this), clearInterval(this._rechokeIntervalId), this._xsRequests.forEach(e => {
                        e.abort()
                    }), this._rarityMap && this._rarityMap.destroy();
                    for (const r in this._peers) this.removePeer(r);
                    this.files.forEach(e => {
                        e instanceof C && e._destroy()
                    });
                    const n = this._servers.map(e => t => {
                        e.destroy(t)
                    });
                    this.discovery && n.push(e => {
                        this.discovery.destroy(e)
                    }), this.store && n.push(e => {
                        this.store.close(e)
                    }), y(n, t), e && (0 === this.listenerCount("error") ? this.client.emit("error", e) : this.emit("error", e)), this.emit("close"), this.client = null, this.files = [], this.discovery = null, this.store = null, this._rarityMap = null, this._peers = null, this._servers = null, this._xsRequests = null
                }
                addPeer(e) {
                    if (this.destroyed) throw new Error("torrent is destroyed");
                    if (!this.infoHash) throw new Error("addPeer() must not be called before the `infoHash` event");
                    if (this.client.blocked) {
                        let t;
                        if ("string" === typeof e) {
                            let r;
                            try {
                                r = i(e)
                            } catch (n) {
                                return this._debug("ignoring peer: invalid %s", e), this.emit("invalidPeer", e), !1
                            }
                            t = r[0]
                        } else "string" === typeof e.remoteAddress && (t = e.remoteAddress);
                        if (t && this.client.blocked.contains(t)) return this._debug("ignoring peer: blocked %s", e), "string" !== typeof e && e.destroy(), this.emit("blockedPeer", e), !1
                    }
                    const t = !!this._addPeer(e);
                    return t ? this.emit("peer", e) : this.emit("invalidPeer", e), t
                }
                _addPeer(e) {
                    if (this.destroyed) return "string" !== typeof e && e.destroy(), null;
                    if ("string" === typeof e && !this._validAddr(e)) return this._debug("ignoring peer: invalid %s", e), null;
                    const t = e && e.id || e;
                    if (this._peers[t]) return this._debug("ignoring peer: duplicate (%s)", t), "string" !== typeof e && e.destroy(), null;
                    if (this.paused) return this._debug("ignoring peer: torrent is paused"), "string" !== typeof e && e.destroy(), null;
                    let n;
                    return this._debug("add peer %s", t), n = "string" === typeof e ? x.createTCPOutgoingPeer(e, this) : x.createWebRTCPeer(e, this), this._peers[n.id] = n, this._peersLength += 1, "string" === typeof e && (this._queue.push(n), this._drain()), n
                }
                addWebSeed(e) {
                    if (this.destroyed) throw new Error("torrent is destroyed");
                    if (!/^https?:\/\/.+/.test(e)) return this.emit("warning", new Error("ignoring invalid web seed: " + e)), void this.emit("invalidPeer", e);
                    if (this._peers[e]) return this.emit("warning", new Error("ignoring duplicate web seed: " + e)), void this.emit("invalidPeer", e);
                    this._debug("add web seed %s", e);
                    const t = x.createWebSeedPeer(e, this);
                    this._peers[t.id] = t, this._peersLength += 1, this.emit("peer", e)
                }
                _addIncomingPeer(e) {
                    return this.destroyed ? e.destroy(new Error("torrent is destroyed")) : this.paused ? e.destroy(new Error("torrent is paused")) : (this._debug("add incoming peer %s", e.id), this._peers[e.id] = e, void(this._peersLength += 1))
                }
                removePeer(e) {
                    const t = e && e.id || e;
                    e = this._peers[t], e && (this._debug("removePeer %s", t), delete this._peers[t], this._peersLength -= 1, e.destroy(), this._drain())
                }
                select(e, t, n, r) {
                    if (this.destroyed) throw new Error("torrent is destroyed");
                    if (e < 0 || t < e || this.pieces.length <= t) throw new Error(`invalid selection ${e} : ${t}`);
                    n = Number(n) || 0, this._debug("select %s-%s (priority %s)", e, t, n), this._selections.push({
                        from: e,
                        to: t,
                        offset: 0,
                        priority: n,
                        notify: r || J
                    }), this._selections.sort((e, t) => t.priority - e.priority), this._updateSelections()
                }
                deselect(e, t, n) {
                    if (this.destroyed) throw new Error("torrent is destroyed");
                    n = Number(n) || 0, this._debug("deselect %s-%s (priority %s)", e, t, n);
                    for (let r = 0; r < this._selections.length; ++r) {
                        const i = this._selections[r];
                        if (i.from === e && i.to === t && i.priority === n) {
                            this._selections.splice(r, 1);
                            break
                        }
                    }
                    this._updateSelections()
                }
                critical(e, t) {
                    if (this.destroyed) throw new Error("torrent is destroyed");
                    this._debug("critical %s-%s", e, t);
                    for (let n = e; n <= t; ++n) this._critical[n] = !0;
                    this._updateSelections()
                }
                _onWire(e, n) {
                    if (this._debug("got wire %s (%s)", e._debugId, n || "Unknown"), e.on("download", e => {
                            this.destroyed || (this.received += e, this._downloadSpeed(e), this.client._downloadSpeed(e), this.emit("download", e), this.client.emit("download", e))
                        }), e.on("upload", e => {
                            this.destroyed || (this.uploaded += e, this._uploadSpeed(e), this.client._uploadSpeed(e), this.emit("upload", e), this.client.emit("upload", e))
                        }), this.wires.push(e), n) {
                        const t = i(n);
                        e.remoteAddress = t[0], e.remotePort = t[1]
                    }
                    this.client.dht && this.client.dht.listening && e.on("port", t => {
                        if (!this.destroyed && !this.client.dht.destroyed) {
                            if (!e.remoteAddress) return this._debug("ignoring PORT from peer with no address");
                            if (0 === t || t > 65536) return this._debug("ignoring invalid PORT from peer");
                            this._debug("port: %s (from %s)", t, n), this.client.dht.addNode({
                                host: e.remoteAddress,
                                port: t
                            })
                        }
                    }), e.on("timeout", () => {
                        this._debug("wire timeout (%s)", n), e.destroy()
                    }), e.setTimeout(M, !0), e.setKeepAlive(!0), this.isFake && e.setFakeData(!0), e.use(O(this.metadata)), e.ut_metadata.on("warning", e => {
                        this._debug("ut_metadata warning: %s", e.message)
                    }), this.metadata || (e.ut_metadata.on("metadata", e => {
                        this._debug("got metadata via ut_metadata"), this._onMetadata(e)
                    }), e.ut_metadata.fetch()), "function" !== typeof k || this.private || (e.use(k()), e.ut_pex.on("peer", e => {
                        this.done || (this._debug("ut_pex: got peer: %s (from %s)", e, n), this.addPeer(e))
                    }), e.ut_pex.on("dropped", e => {
                        const t = this._peers[e];
                        t && !t.connected && (this._debug("ut_pex: dropped peer: %s (from %s)", e, n), this.removePeer(e))
                    }), e.once("close", () => {
                        e.ut_pex.reset()
                    })), this.emit("wire", e, n), this.metadata && t.nextTick(() => {
                        this._onWireWithMetadata(e)
                    })
                }
                _onWireWithMetadata(e) {
                    let t = null;
                    const n = () => {
                        this.destroyed || e.destroyed || (this._numQueued > 2 * (this._numConns - this.numPeers) && e.amInterested ? e.destroy() : (t = setTimeout(n, D), t.unref && t.unref()))
                    };
                    let r;
                    const i = () => {
                        if (e.peerPieces.buffer.length === this.bitfield.buffer.length) {
                            for (r = 0; r < this.pieces.length; ++r)
                                if (!e.peerPieces.get(r)) return;
                            e.isSeeder = !0, e.choke()
                        }
                    };
                    e.on("bitfield", () => {
                        i(), this._update()
                    }), e.on("have", () => {
                        i(), this._update()
                    }), e.once("interested", () => {
                        e.unchoke()
                    }), e.once("close", () => {
                        clearTimeout(t)
                    }), e.on("choke", () => {
                        clearTimeout(t), t = setTimeout(n, D), t.unref && t.unref()
                    }), e.on("unchoke", () => {
                        clearTimeout(t), this._update()
                    }), e.on("request", (t, n, r, i) => {
                        if (r > L) return e.destroy();
                        this.pieces[t] || this.store.get(t, {
                            offset: n,
                            length: r
                        }, i)
                    }), e.bitfield(this.bitfield), e.uninterested(), e.peerExtensions.dht && this.client.dht && this.client.dht.listening && e.port(this.client.dht.address().port), "webSeed" !== e.type ? (t = setTimeout(n, D), t.unref && t.unref()) : e.interested(), e.isSeeder = !1, i()
                }
                _updateSelections() {
                    this.ready && !this.destroyed && (t.nextTick(() => {
                        this._gcSelections()
                    }), this._updateInterest(), this._update())
                }
                _gcSelections() {
                    for (let e = 0; e < this._selections.length; ++e) {
                        const t = this._selections[e],
                            n = t.offset;
                        while (this.bitfield.get(t.from + t.offset) && t.from + t.offset < t.to) t.offset += 1;
                        n !== t.offset && t.notify(), t.to === t.from + t.offset && (this.bitfield.get(t.from + t.offset) && (this._selections.splice(e, 1), e -= 1, t.notify(), this._updateInterest()))
                    }
                    this._selections.length || this.emit("idle")
                }
                _updateInterest() {
                    const e = this._amInterested;
                    this._amInterested = !!this._selections.length, this.wires.forEach(e => {
                        let t = !1;
                        for (let n = 0; n < this.pieces.length; ++n)
                            if (this.pieces[n] && e.peerPieces.get(n)) {
                                t = !0;
                                break
                            }
                        t ? e.interested() : e.uninterested()
                    }), e !== this._amInterested && (this._amInterested ? this.emit("interested") : this.emit("uninterested"))
                }
                _update() {
                    if (this.destroyed) return;
                    const e = T(this.wires);
                    let t;
                    while (t = e()) this._updateWireWrapper(t)
                }
                _updateWireWrapper(e) {
                    const t = this;
                    "undefined" !== typeof window && "function" === typeof window.requestIdleCallback ? window.requestIdleCallback((function() {
                        t._updateWire(e)
                    }), {
                        timeout: 250
                    }) : t._updateWire(e)
                }
                _updateWire(e) {
                    const t = this;
                    if (e.peerChoking) return;
                    if (!e.downloaded) return o();
                    const n = V(e, B);
                    if (e.requests.length >= n) return;
                    const r = V(e, j);

                    function i(t, n, r, i) {
                        return o => o >= t && o <= n && !(o in r) && e.peerPieces.get(o) && (!i || i(o))
                    }

                    function o() {
                        if (e.requests.length) return;
                        let n = t._selections.length;
                        while (n--) {
                            const r = t._selections[n];
                            let o;
                            if ("rarest" === t.strategy) {
                                const n = r.from + r.offset,
                                    s = r.to,
                                    a = s - n + 1,
                                    c = {};
                                let h = 0;
                                const u = i(n, s, c);
                                while (h < a) {
                                    if (o = t._rarityMap.getRarestPiece(u), o < 0) break;
                                    if (t._request(e, o, !1)) return;
                                    c[o] = !0, h += 1
                                }
                            } else
                                for (o = r.to; o >= r.from + r.offset; --o)
                                    if (e.peerPieces.get(o) && t._request(e, o, !1)) return
                        }
                    }

                    function s() {
                        const n = e.downloadSpeed() || 1;
                        if (n > U) return () => !0;
                        const r = Math.max(1, e.requests.length) * v.BLOCK_LENGTH / n;
                        let i = 10,
                            o = 0;
                        return e => {
                            if (!i || t.bitfield.get(e)) return !0;
                            let s = t.pieces[e].missing;
                            for (; o < t.wires.length; o++) {
                                const a = t.wires[o],
                                    c = a.downloadSpeed();
                                if (!(c < U) && (!(c <= n) && a.peerPieces.get(e) && !((s -= c * r) > 0))) return i--, !1
                            }
                            return !0
                        }
                    }

                    function a(e) {
                        let n = e;
                        for (let i = e; i < t._selections.length && t._selections[i].priority; i++) n = i;
                        const r = t._selections[e];
                        t._selections[e] = t._selections[n], t._selections[n] = r
                    }

                    function c(n) {
                        if (e.requests.length >= r) return !0;
                        const o = s();
                        for (let s = 0; s < t._selections.length; s++) {
                            const c = t._selections[s];
                            let h;
                            if ("rarest" === t.strategy) {
                                const u = c.from + c.offset,
                                    f = c.to,
                                    d = f - u + 1,
                                    l = {};
                                let p = 0;
                                const g = i(u, f, l, o);
                                while (p < d) {
                                    if (h = t._rarityMap.getRarestPiece(g), h < 0) break;
                                    while (t._request(e, h, t._critical[h] || n));
                                    if (!(e.requests.length < r)) return c.priority && a(s), !0;
                                    l[h] = !0, p++
                                }
                            } else
                                for (h = c.from + c.offset; h <= c.to; h++)
                                    if (e.peerPieces.get(h) && o(h)) {
                                        while (t._request(e, h, t._critical[h] || n));
                                        if (!(e.requests.length < r)) return c.priority && a(s), !0
                                    }
                        }
                        return !1
                    }
                    c(!1) || c(!0)
                }
                _rechoke() {
                    if (!this.ready) return;
                    this._rechokeOptimisticTime > 0 ? this._rechokeOptimisticTime -= 1 : this._rechokeOptimisticWire = null;
                    const e = [];
                    this.wires.forEach(t => {
                        t.isSeeder || t === this._rechokeOptimisticWire || e.push({
                            wire: t,
                            downloadSpeed: t.downloadSpeed(),
                            uploadSpeed: t.uploadSpeed(),
                            salt: Math.random(),
                            isChoked: !0
                        })
                    }), e.sort(r);
                    let t = 0,
                        n = 0;
                    for (; n < e.length && t < this._rechokeNumSlots; ++n) e[n].isChoked = !1, e[n].wire.peerInterested && (t += 1);
                    if (!this._rechokeOptimisticWire && n < e.length && this._rechokeNumSlots) {
                        const t = e.slice(n).filter(e => e.wire.peerInterested),
                            r = t[K(t.length)];
                        r && (r.isChoked = !1, this._rechokeOptimisticWire = r.wire, this._rechokeOptimisticTime = H)
                    }

                    function r(e, t) {
                        return e.downloadSpeed !== t.downloadSpeed ? t.downloadSpeed - e.downloadSpeed : e.uploadSpeed !== t.uploadSpeed ? t.uploadSpeed - e.uploadSpeed : e.wire.amChoking !== t.wire.amChoking ? e.wire.amChoking ? 1 : -1 : e.salt - t.salt
                    }
                    e.forEach(e => {
                        e.wire.amChoking !== e.isChoked && (e.isChoked ? e.wire.choke() : e.wire.unchoke())
                    })
                }
                _hotswap(e, t) {
                    const n = e.downloadSpeed();
                    if (n < v.BLOCK_LENGTH) return !1;
                    if (!this._reservations[t]) return !1;
                    const r = this._reservations[t];
                    if (!r) return !1;
                    let i, o, s = 1 / 0;
                    for (o = 0; o < r.length; o++) {
                        const t = r[o];
                        if (!t || t === e) continue;
                        const a = t.downloadSpeed();
                        a >= U || (2 * a > n || a > s || (i = t, s = a))
                    }
                    if (!i) return !1;
                    for (o = 0; o < r.length; o++) r[o] === i && (r[o] = null);
                    for (o = 0; o < i.requests.length; o++) {
                        const e = i.requests[o];
                        e.piece === t && this.pieces[t].cancel(e.offset / v.BLOCK_LENGTH | 0)
                    }
                    return this.emit("hotswap", i, e, t), !0
                }
                _request(e, n, r) {
                    const i = this,
                        o = e.requests.length,
                        s = "webSeed" === e.type;
                    if (i.bitfield.get(n)) return !1;
                    const a = s ? Math.min(X(e, j, i.pieceLength), i.maxWebConns) : V(e, j);
                    if (o >= a) return !1;
                    const c = i.pieces[n];
                    let h = s ? c.reserveRemaining() : c.reserve();
                    if (-1 === h && r && i._hotswap(e, n) && (h = s ? c.reserveRemaining() : c.reserve()), -1 === h) return !1;
                    let u = i._reservations[n];
                    u || (u = i._reservations[n] = []);
                    let f = u.indexOf(null); - 1 === f && (f = u.length), u[f] = e;
                    const d = c.chunkOffset(h),
                        l = s ? c.chunkLengthRemaining(h) : c.chunkLength(h);

                    function p() {
                        t.nextTick(() => {
                            i._update()
                        })
                    }
                    return e.request(n, d, l, (function t(r, o) {
                        if (i.destroyed) return;
                        if (!i.ready) return i.once("ready", () => {
                            t(r, o)
                        });
                        if (u[f] === e && (u[f] = null), c !== i.pieces[n]) return p();
                        if (r) return i._debug("error getting piece %s (offset: %s length: %s) from %s: %s", n, d, l, `${e.remoteAddress}:${e.remotePort}`, r.message), s ? c.cancelRemaining(h) : c.cancel(h), void p();
                        if (i._debug("got piece %s (offset: %s length: %s) from %s", n, d, l, `${e.remoteAddress}:${e.remotePort}`), !c.set(h, o, e)) return p();
                        const a = c.flush();
                        R(a, e => {
                            if (!i.destroyed) {
                                if (e === i._hashes[n]) {
                                    if (!i.pieces[n]) return;
                                    i._debug("piece verified %s", n), i.pieces[n] = null, i._reservations[n] = null, i.bitfield.set(n, !0), i.store.put(n, a), i.wires.forEach(e => {
                                        e.have(n)
                                    }), i._checkDone() && !i.destroyed && i.discovery.complete()
                                } else i.pieces[n] = new v(c.length), i.emit("warning", new Error(`Piece ${n} failed verification`));
                                p()
                            }
                        })
                    })), !0
                }
                _checkDone() {
                    if (this.destroyed) return;
                    this.files.forEach(e => {
                        if (!e.done) {
                            for (let t = e._startPiece; t <= e._endPiece; ++t)
                                if (!this.bitfield.get(t)) return;
                            e.done = !0, e.emit("done"), this._debug("file done: " + e.name)
                        }
                    });
                    let e = !0;
                    for (let t = 0; t < this._selections.length; t++) {
                        const n = this._selections[t];
                        for (let t = n.from; t <= n.to; t++)
                            if (!this.bitfield.get(t)) {
                                e = !1;
                                break
                            }
                        if (!e) break
                    }
                    return !this.done && e && (this.done = !0, this._debug("torrent done: " + this.infoHash), this.emit("done")), this._gcSelections(), e
                }
                load(e, t) {
                    if (this.destroyed) throw new Error("torrent is destroyed");
                    if (!this.ready) return this.once("ready", () => {
                        this.load(e, t)
                    });
                    Array.isArray(e) || (e = [e]), t || (t = J);
                    const n = new p(e),
                        r = new s(this.store, this.pieceLength);
                    E(n, r, e => {
                        if (e) return t(e);
                        this._markAllVerified(), this._checkDone(), t(null)
                    })
                }
                createServer(e) {
                    if ("function" !== typeof P) throw new Error("node.js-only method");
                    if (this.destroyed) throw new Error("torrent is destroyed");
                    const t = new P(this, e);
                    return this._servers.push(t), t
                }
                pause() {
                    this.destroyed || (this._debug("pause"), this.paused = !0)
                }
                resume() {
                    this.destroyed || (this._debug("resume"), this.paused = !1, this._drain())
                }
                _debug() {
                    const e = [].slice.call(arguments);
                    e[0] = `[${this.client._debugId}] [${this._debugId}] ${e[0]}`, a(...e)
                }
                _drain() {
                    if (this._debug("_drain numConns %s maxConns %s", this._numConns, this.client.maxConns), "function" !== typeof g.connect || this.destroyed || this.paused || this._numConns >= this.client.maxConns) return;
                    this._debug("drain (%s queued, %s/%s peers)", this._numQueued, this.numPeers, this.client.maxConns);
                    const e = this._queue.shift();
                    if (!e) return;
                    this._debug("tcp connect attempt to %s", e.addr);
                    const t = i(e.addr),
                        n = {
                            host: t[0],
                            port: t[1]
                        },
                        r = e.conn = g.connect(n);
                    r.once("connect", () => {
                        e.onConnect()
                    }), r.once("error", t => {
                        e.destroy(t)
                    }), e.startConnectTimeout(), r.on("close", () => {
                        if (this.destroyed) return;
                        if (e.retries >= W.length) return void this._debug("conn %s closed: will not re-add (max %s attempts)", e.addr, W.length);
                        const t = W[e.retries];
                        this._debug("conn %s closed: will re-add to queue in %sms (attempt %s)", e.addr, t, e.retries + 1);
                        const n = setTimeout(() => {
                            const t = this._addPeer(e.addr);
                            t && (t.retries = e.retries + 1)
                        }, t);
                        n.unref && n.unref()
                    })
                }
                _validAddr(e) {
                    let t;
                    try {
                        t = i(e)
                    } catch (o) {
                        return !1
                    }
                    const n = t[0],
                        r = t[1];
                    return r > 0 && r < 65535 && !("127.0.0.1" === n && r === this.client.torrentPort)
                }
            }

            function V(e, t) {
                return 2 + Math.ceil(t * e.downloadSpeed() / v.BLOCK_LENGTH)
            }

            function X(e, t, n) {
                return 1 + Math.ceil(t * e.downloadSpeed() / n)
            }

            function K(e) {
                return Math.random() * e | 0
            }

            function J() {}
            e.exports = z
        }).call(this, n("4362"), n("c8ba"))
    },
    c3a8: function(e, t, n) {
        (function(t) { /*! stream-with-known-length-to-buffer. MIT License. Feross Aboukhadijeh <https://feross.org/opensource> */
            var r = n("566b");
            e.exports = function(e, n, i) {
                i = r(i);
                var o = t.alloc(n),
                    s = 0;
                e.on("data", (function(e) {
                    e.copy(o, s), s += e.length
                })).on("end", (function() {
                    i(null, o)
                })).on("error", i)
            }
        }).call(this, n("b639").Buffer)
    },
    c3b3: function(e, t, n) {
        /*! run-parallel-limit. MIT License. Feross Aboukhadijeh <https://feross.org/opensource> */
        e.exports = i;
        const r = n("8712");

        function i(e, t, n) {
            if ("number" !== typeof t) throw new Error("second argument must be a Number");
            let i, o, s, a, c, h, u = !0;

            function f(e) {
                function t() {
                    n && n(e, i), n = null
                }
                u ? r(t) : t()
            }

            function d(t, n, r) {
                if (i[t] = r, n && (c = !0), 0 === --s || n) f(n);
                else if (!c && h < o) {
                    let t;
                    a ? (t = a[h], h += 1, e[t]((function(e, n) {
                        d(t, e, n)
                    }))) : (t = h, h += 1, e[t]((function(e, n) {
                        d(t, e, n)
                    })))
                }
            }
            Array.isArray(e) ? (i = [], s = o = e.length) : (a = Object.keys(e), i = {}, s = o = a.length), h = t, s ? a ? a.some((function(n, r) {
                return e[n]((function(e, t) {
                    d(n, e, t)
                })), r === t - 1
            })) : e.some((function(e, n) {
                return e((function(e, t) {
                    d(n, e, t)
                })), n === t - 1
            })) : f(null), u = !1
        }
    },
    c430: function(e, t) {
        e.exports = !1
    },
    c490: function(e, t) {
        e.exports = Sentry
    },
    c4d1: function(e, t, n) {
        "use strict";
        n.d(t, "a", (function() {
            return d
        })), n.d(t, "b", (function() {
            return _
        }));
        var r = n("c490"),
            i = n("5ff7");
        const o = [/arc\.io/i, /arc-widget/i, /arc-sw/i, /widget\.min\.js/i, /widget\/js/i],
            s = [/extensions\//i, /-extension:\/\//i],
            {
                NODE_ENV: a,
                COMMIT_HASH: c
            } = i["a"],
            h = ["SecurityError IDBFactory.open() called in an invalid security context"],
            u = 6e4,
            f = {};
        let d = r;

        function l(e, t) {
            const n = t.originalException;
            if (!n) return null;
            const {
                message: r,
                stack: i
            } = n;
            if (!r || !i) return null;
            const s = o.some(e => e.test(i));
            if (!s) return null;
            if (r in f) return null;
            const a = 30 * u;
            return f[r] = !0, setTimeout(() => {
                delete f[r]
            }, a), e
        }

        function p(e) {
            !d.SDK_NAME && self.Sentry && (d = self.Sentry), d.init({
                dsn: "https://7e5c2fad7a564ff8bffd4effc2abb26d@sentry.arc.io/2",
                enabled: !1,
                environment: a,
                release: c,
                maxBreadcrumbs: 5,
                ignoreErrors: h,
                autoSessionTracking: !1,
                denyUrls: s,
                blacklistUrls: s,
                ...e
            })
        }

        function g() {
            const e = {
                integrations: e => [...e.filter(e => "Breadcrumbs" !== e.name)],
                sampleRate: .01,
                beforeSend: l,
                allowUrls: o,
                whitelistUrls: o
            };
            p(e)
        }

        function _() {
            d.onLoad(g)
        }
    },
    c64e: function(e, t, n) {
        var r = n("e1f4"),
            i = n("2366");

        function o(e, t, n) {
            var o = t && n || 0;
            "string" == typeof e && (t = "binary" === e ? new Array(16) : null, e = null), e = e || {};
            var s = e.random || (e.rng || r)();
            if (s[6] = 15 & s[6] | 64, s[8] = 63 & s[8] | 128, t)
                for (var a = 0; a < 16; ++a) t[o + a] = s[a];
            return t || i(s)
        }
        e.exports = o
    },
    c688: function(e, t, n) {
        "use strict";
        n.d(t, "a", (function() {
            return G
        })), n.d(t, "b", (function() {
            return W
        }));
        var r = n("ced0"),
            i = n("ad2b"),
            o = n.n(i),
            s = n("0e49"),
            a = n.n(s),
            c = n("c4d1"),
            h = n("190a"),
            u = n("a5a5"),
            f = n("0d31"),
            d = n("5de4"),
            l = n("8c32"),
            p = n("d1a0"),
            g = n("c74e"),
            _ = n("af2a"),
            y = n("9b16"),
            m = n("0ecd");
        const b = n("34eb")("arc:p2p-client"),
            w = {};

        function v(e, t) {
            e in w || (w[e] = []), w[e].push(t)
        }

        function E(e, t) {
            T({
                arcEvent: e,
                ...t
            })
        }

        function T(e) {
            if (!("serviceWorker" in navigator)) return;
            const {
                controller: t
            } = navigator.serviceWorker;
            t && t.postMessage(e)
        }

        function R() {
            var e;
            null === (e = navigator.serviceWorker) || void 0 === e || e.addEventListener("message", e => {
                const {
                    arcEvent: t,
                    ...n
                } = e.data;
                if (t && (b(`arcEvent from sw: ${t} `, n), t in w)) {
                    const n = w[t];
                    n.forEach(t => t(e))
                }
            })
        }
        const S = n("34eb")("arc:p2p-client"),
            I = (console.log, "https://developer.mozilla.org/en-US/docs/Web/API/Service_Worker_API/Using_Service_Workers#Why_is_my_service_worker_failing_to_register"),
            {
                P2P_CLIENT_READY: O,
                WIDGET_CONFIG: k,
                STORED_FIDS: A,
                COMLINK_INIT: C,
                NODE_ID: x,
                SW_HEALTH_CHECK: N,
                CLIENT_TEARDOWN: P
            } = u["k"];
        async function L(e) {
            const {
                scope: t
            } = e;
            if (await D()) return void S("Will not install the Arc sw, user already has one.");
            const n = M(e);
            await U(n, t)
        }

        function M(e) {
            const {
                propertyId: t,
                env: n,
                wpPluginVersion: r,
                seeder: i
            } = e, o = "wp" === n, s = r && a()(r, "1.1.4");
            let c = o ? u["q"] : u["n"];
            return o && !s || (c += `?propertyId=${t}&${m["b"]}=${i}`), c
        }
        async function D() {
            const e = [u["n"], u["q"]],
                t = await navigator.serviceWorker.getRegistrations();
            return t.some(t => {
                const {
                    scope: n,
                    active: r
                } = t;
                if (!r) return !1;
                const i = new URL(r.scriptURL).pathname,
                    o = n === window.location.origin + "/",
                    s = !e.includes(i);
                return o && s
            })
        }
        async function U(e, t = "/") {
            try {
                const {
                    serviceWorker: n
                } = navigator, r = {
                    scope: t
                }, i = await n.register(e, r);
                S("Arc sw registration successful.", i);
                const o = "_arc_delete_me_later";
                localStorage.removeItem(o)
            } catch (n) {
                console.warn(`Failed to install Arc's Service Worker.\n\nFor installation help, see ${u["l"]}.\n\nService Worker documentation: ${I}.\n\n`, n.name, n.message)
            }
        }

        function B(e) {
            const t = () => {
                e.reportDataTransferOnUnload(), E(P)
            };
            return window.addEventListener("beforeunload", t, !1), () => window.removeEventListener("beforeunload", t, !1)
        }
        async function j(e) {
            const t = Object(_["a"])();
            h["a"].setPropertyId(e), f["a"].setPropertyId(e);
            const n = B(h["a"]);
            return f["a"].addCleanupFn(n), f["a"].setBrokerPromise(t), f["a"].setReporter(h["a"]), t.then(async e => {
                f["a"].setBroker(e);
                const t = d["i"].get("nodeId", await e.getOrGenerateMyNodeId());
                h["a"].setNodeId(t), f["a"].setNodeId(t), g["a"].setClientId(t), E(x, {
                    nodeId: t
                })
            }), f["a"]
        }
        async function F(e) {
            const t = await e.brokerPromise,
                n = await t.getStoredFids();
            E(A, {
                storedFids: n
            })
        }
        async function H(e) {
            const t = new r["a"](u["b"], u["c"]),
                {
                    seeder: n,
                    propertyId: i
                } = e;
            let o = [r["d"](m["b"], n, t)];
            i && o.push(r["d"]("propertyId", i, t)), await Promise.all(o)
        }
        async function G() {
            const e = new Promise(e => {
                var t;
                if (null !== (t = navigator.serviceWorker) && void 0 !== t && t.controller) return e();
                navigator.serviceWorker.addEventListener("controllerchange", e)
            });
            await Object(l["h"])(e, 3e3).catch(() => {});
            const t = new Promise(e => {
                v(N, e)
            });
            E(N);
            try {
                return await Object(l["h"])(t, 1e3), !0
            } catch (n) {
                return !1
            }
        }
        async function W(e) {
            if ("serviceWorker" in navigator && o.a.WEBRTC_SUPPORT) try {
                R(), S("widgetConfig %o", e);
                const {
                    propertyId: t
                } = e;
                H(e), E(k, {
                    widgetConfig: e
                }), v(k, () => {
                    E(k, {
                        widgetConfig: e
                    })
                }), j(t).then(e => {
                    v(C, t => {
                        Object(y["a"])(e, t.ports)
                    }), v(A, () => {
                        F(e)
                    }), F(e), E(O), window.postMessage({
                        arcEvent: O
                    }, location.origin), window.__arc__.p2pClient = e, p["c"].mark("p2p-client:ready")
                }), await L(e)
            } catch (t) {
                c["a"].captureException(t), S(t)
            }
        }
    },
    c6ae: function(e, t, n) {
        "use strict";

        function r(e, t) {
            var n = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var r = Object.getOwnPropertySymbols(e);
                t && (r = r.filter((function(t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable
                }))), n.push.apply(n, r)
            }
            return n
        }

        function i(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = null != arguments[t] ? arguments[t] : {};
                t % 2 ? r(Object(n), !0).forEach((function(t) {
                    o(e, t, n[t])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : r(Object(n)).forEach((function(t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                }))
            }
            return e
        }

        function o(e, t, n) {
            return t in e ? Object.defineProperty(e, t, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = n, e
        }

        function s(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }

        function a(e, t) {
            for (var n = 0; n < t.length; n++) {
                var r = t[n];
                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
            }
        }

        function c(e, t, n) {
            return t && a(e.prototype, t), n && a(e, n), e
        }
        var h = n("b639"),
            u = h.Buffer,
            f = n(1),
            d = f.inspect,
            l = d && d.custom || "inspect";

        function p(e, t, n) {
            u.prototype.copy.call(e, t, n)
        }
        e.exports = function() {
            function e() {
                s(this, e), this.head = null, this.tail = null, this.length = 0
            }
            return c(e, [{
                key: "push",
                value: function(e) {
                    var t = {
                        data: e,
                        next: null
                    };
                    this.length > 0 ? this.tail.next = t : this.head = t, this.tail = t, ++this.length
                }
            }, {
                key: "unshift",
                value: function(e) {
                    var t = {
                        data: e,
                        next: this.head
                    };
                    0 === this.length && (this.tail = t), this.head = t, ++this.length
                }
            }, {
                key: "shift",
                value: function() {
                    if (0 !== this.length) {
                        var e = this.head.data;
                        return 1 === this.length ? this.head = this.tail = null : this.head = this.head.next, --this.length, e
                    }
                }
            }, {
                key: "clear",
                value: function() {
                    this.head = this.tail = null, this.length = 0
                }
            }, {
                key: "join",
                value: function(e) {
                    if (0 === this.length) return "";
                    var t = this.head,
                        n = "" + t.data;
                    while (t = t.next) n += e + t.data;
                    return n
                }
            }, {
                key: "concat",
                value: function(e) {
                    if (0 === this.length) return u.alloc(0);
                    var t = u.allocUnsafe(e >>> 0),
                        n = this.head,
                        r = 0;
                    while (n) p(n.data, t, r), r += n.data.length, n = n.next;
                    return t
                }
            }, {
                key: "consume",
                value: function(e, t) {
                    var n;
                    return e < this.head.data.length ? (n = this.head.data.slice(0, e), this.head.data = this.head.data.slice(e)) : n = e === this.head.data.length ? this.shift() : t ? this._getString(e) : this._getBuffer(e), n
                }
            }, {
                key: "first",
                value: function() {
                    return this.head.data
                }
            }, {
                key: "_getString",
                value: function(e) {
                    var t = this.head,
                        n = 1,
                        r = t.data;
                    e -= r.length;
                    while (t = t.next) {
                        var i = t.data,
                            o = e > i.length ? i.length : e;
                        if (o === i.length ? r += i : r += i.slice(0, e), e -= o, 0 === e) {
                            o === i.length ? (++n, t.next ? this.head = t.next : this.head = this.tail = null) : (this.head = t, t.data = i.slice(o));
                            break
                        }++n
                    }
                    return this.length -= n, r
                }
            }, {
                key: "_getBuffer",
                value: function(e) {
                    var t = u.allocUnsafe(e),
                        n = this.head,
                        r = 1;
                    n.data.copy(t), e -= n.data.length;
                    while (n = n.next) {
                        var i = n.data,
                            o = e > i.length ? i.length : e;
                        if (i.copy(t, t.length - e, 0, o), e -= o, 0 === e) {
                            o === i.length ? (++r, n.next ? this.head = n.next : this.head = this.tail = null) : (this.head = n, n.data = i.slice(o));
                            break
                        }++r
                    }
                    return this.length -= r, t
                }
            }, {
                key: l,
                value: function(e, t) {
                    return d(this, i({}, t, {
                        depth: 0,
                        customInspect: !1
                    }))
                }
            }]), e
        }()
    },
    c6b6: function(e, t) {
        var n = {}.toString;
        e.exports = function(e) {
            return n.call(e).slice(8, -1)
        }
    },
    c6cd: function(e, t, n) {
        var r = n("da84"),
            i = n("ce4e"),
            o = "__core-js_shared__",
            s = r[o] || i(o, {});
        e.exports = s
    },
    c74e: function(e, t, n) {
        "use strict";
        var r = n("85b1"),
            i = n("5ff7"),
            o = n("d1a0");
        const s = self.performance;
        console.log;
        let a = null,
            c = !1;
        const h = "https://www.google-analytics.com/batch",
            u = {
                v: 1,
                tid: i["a"].GA_TID_USER_TIMING
            },
            f = 20,
            d = 3e3,
            l = .005,
            p = {
                DEFAULT: "measure",
                NETWORK_REQUEST: "networkRequest",
                STATIC_ASSET: "staticAsset"
            },
            g = {
                LOAD: "load",
                LOAD_NETWORK: "load:network",
                LOAD_CACHE: "load:cache",
                CONNECT: "connect"
            },
            _ = [],
            y = Object(r["a"])(() => {
                if (a) {
                    if (!c && "undefined" !== typeof window) {
                        c = !0;
                        const e = {
                            t: "pageview",
                            dl: window.location.href
                        };
                        document.referrer && (e.dr = document.referrer), _.push(e)
                    }
                    while (_.length > 0) {
                        const e = _.splice(0, f).map(e => (e.cid = a, Object.assign(e, u), new URLSearchParams(e).toString())).join("\n"),
                            t = {
                                method: "POST",
                                body: e
                            };
                        i["a"].IS_PROD && fetch(h, t).catch(() => {})
                    }
                }
            }, d);

        function m(e) {
            return e.map(e => e instanceof PerformanceResourceTiming ? b(e) : e instanceof PerformanceMeasure ? w(e) : e instanceof PerformanceMark ? v(e) : null).filter(Boolean).filter(() => Math.random() < l).map(e => (e.utt = Math.round(1e3 * e.utt), e.t = "timing", e))
        }

        function b(e) {
            const {
                name: t,
                duration: n
            } = e;
            if (n < 0 || !t) return null;
            let r;
            try {
                r = new URL(t)
            } catch (c) {
                return null
            }
            const {
                origin: o,
                pathname: s
            } = r, a = {
                utc: p.DEFAULT,
                utt: n
            };
            if (o !== i["a"].GATEWAY_ORIGIN) return null; {
                a.utc = p.NETWORK_REQUEST, a.utv = E(e) ? g.LOAD_CACHE : g.LOAD_NETWORK;
                const [t, n = ""] = s.split("/");
                a.utl = "gateway/" + n;
                const r = ["region", "autoCdnIngest"];
                if (r.includes(n)) return null
            }
            return a
        }

        function w(e) {
            const {
                name: t,
                duration: n
            } = e;
            if (!t.startsWith(o["a"]) || n < 0) return null;
            const [r, i, s] = t.split(":"), a = {
                utc: p.DEFAULT,
                utt: n,
                utv: s,
                utl: i
            };
            return i.includes("tracker") ? a.utc = p.NETWORK_REQUEST : [".js", ".html", ".css"].some(e => i.includes(e)) && (a.utc = p.STATIC_ASSET), a
        }

        function v() {
            return null
        }

        function E(e) {
            return !(e.transferSize > 0) && (e.decodedBodySize > 0 || e.duration < 15)
        }

        function T(e) {
            a = e, y()
        }

        function R() {
            return null !== a
        }

        function S() {
            if (!("PerformanceObserver" in self)) return;
            const e = e => {
                    const t = m(e);
                    _.push(...t), y()
                },
                t = new PerformanceObserver(t => {
                    e(t.getEntries())
                });
            t.observe({
                entryTypes: ["measure", "resource"]
            }), e(s.getEntries())
        }
        t["a"] = {
            init: S,
            hasClientId: R,
            setClientId: T
        }
    },
    c7ba: function(e, t, n) {
        (function(t) {
            e.exports = f;
            const r = n("ff0e"),
                i = n(6),
                o = n("9490"),
                s = n("24f8"),
                a = n("566b"),
                c = n("b383"),
                h = n("cffb"),
                u = e => null !== e && "object" === typeof e && "function" === typeof e.pipe;

            function f(e, n) {
                if (e = Object.assign({
                        maxRedirects: 10
                    }, "string" === typeof e ? {
                        url: e
                    } : e), n = a(n), e.url) {
                    const {
                        hostname: t,
                        port: n,
                        protocol: r,
                        auth: i,
                        path: o
                    } = h.parse(e.url);
                    delete e.url, t || n || r || i ? Object.assign(e, {
                        hostname: t,
                        port: n,
                        protocol: r,
                        auth: i,
                        path: o
                    }) : e.path = o
                }
                const r = {
                    "accept-encoding": "gzip, deflate"
                };
                let d;
                e.headers && Object.keys(e.headers).forEach(t => r[t.toLowerCase()] = e.headers[t]), e.headers = r, e.body ? d = e.json && !u(e.body) ? JSON.stringify(e.body) : e.body : e.form && (d = "string" === typeof e.form ? e.form : c.stringify(e.form), e.headers["content-type"] = "application/x-www-form-urlencoded"), d && (e.method || (e.method = "POST"), u(d) || (e.headers["content-length"] = t.byteLength(d)), e.json && !e.form && (e.headers["content-type"] = "application/json")), delete e.body, delete e.form, e.json && (e.headers.accept = "application/json"), e.method && (e.method = e.method.toUpperCase());
                const l = "https:" === e.protocol ? s : o,
                    p = l.request(e, t => {
                        if (!1 !== e.followRedirects && t.statusCode >= 300 && t.statusCode < 400 && t.headers.location) return e.url = t.headers.location, delete e.headers.host, t.resume(), "POST" === e.method && [301, 302].includes(t.statusCode) && (e.method = "GET", delete e.headers["content-length"], delete e.headers["content-type"]), 0 === e.maxRedirects-- ? n(new Error("too many redirects")) : f(e, n);
                        const r = "function" === typeof i && "HEAD" !== e.method;
                        n(null, r ? i(t) : t)
                    });
                return p.on("timeout", () => {
                    p.abort(), n(new Error("Request timed out"))
                }), p.on("error", n), u(d) ? d.on("error", n).pipe(p) : p.end(d), p
            }
            f.concat = (e, t) => f(e, (n, i) => {
                if (n) return t(n);
                r(i, (n, r) => {
                    if (n) return t(n);
                    if (e.json) try {
                        r = JSON.parse(r.toString())
                    } catch (n) {
                        return t(n, i, r)
                    }
                    t(null, i, r)
                })
            }), ["get", "post", "put", "patch", "head", "delete"].forEach(e => {
                f[e] = (t, n) => ("string" === typeof t && (t = {
                    url: t
                }), f(Object.assign({
                    method: e.toUpperCase()
                }, t), n))
            })
        }).call(this, n("b639").Buffer)
    },
    c8ba: function(e, t) {
        var n;
        n = function() {
            return this
        }();
        try {
            n = n || new Function("return this")()
        } catch (r) {
            "object" === typeof window && (n = window)
        }
        e.exports = n
    },
    c90b: function(e, t, n) {
        (function(e, r, i) {
            var o = n("a9f1"),
                s = n("3fb5"),
                a = n("e372"),
                c = t.readyStates = {
                    UNSENT: 0,
                    OPENED: 1,
                    HEADERS_RECEIVED: 2,
                    LOADING: 3,
                    DONE: 4
                },
                h = t.IncomingMessage = function(t, n, s, c) {
                    var h = this;
                    if (a.Readable.call(h), h._mode = s, h.headers = {}, h.rawHeaders = [], h.trailers = {}, h.rawTrailers = [], h.on("end", (function() {
                            e.nextTick((function() {
                                h.emit("close")
                            }))
                        })), "fetch" === s) {
                        if (h._fetchResponse = n, h.url = n.url, h.statusCode = n.status, h.statusMessage = n.statusText, n.headers.forEach((function(e, t) {
                                h.headers[t.toLowerCase()] = e, h.rawHeaders.push(t, e)
                            })), o.writableStream) {
                            var u = new WritableStream({
                                write: function(e) {
                                    return new Promise((function(t, n) {
                                        h._destroyed ? n() : h.push(new r(e)) ? t() : h._resumeFetch = t
                                    }))
                                },
                                close: function() {
                                    i.clearTimeout(c), h._destroyed || h.push(null)
                                },
                                abort: function(e) {
                                    h._destroyed || h.emit("error", e)
                                }
                            });
                            try {
                                return void n.body.pipeTo(u).catch((function(e) {
                                    i.clearTimeout(c), h._destroyed || h.emit("error", e)
                                }))
                            } catch (_) {}
                        }
                        var f = n.body.getReader();

                        function d() {
                            f.read().then((function(e) {
                                if (!h._destroyed) {
                                    if (e.done) return i.clearTimeout(c), void h.push(null);
                                    h.push(new r(e.value)), d()
                                }
                            })).catch((function(e) {
                                i.clearTimeout(c), h._destroyed || h.emit("error", e)
                            }))
                        }
                        d()
                    } else {
                        h._xhr = t, h._pos = 0, h.url = t.responseURL, h.statusCode = t.status, h.statusMessage = t.statusText;
                        var l = t.getAllResponseHeaders().split(/\r?\n/);
                        if (l.forEach((function(e) {
                                var t = e.match(/^([^:]+):\s*(.*)/);
                                if (t) {
                                    var n = t[1].toLowerCase();
                                    "set-cookie" === n ? (void 0 === h.headers[n] && (h.headers[n] = []), h.headers[n].push(t[2])) : void 0 !== h.headers[n] ? h.headers[n] += ", " + t[2] : h.headers[n] = t[2], h.rawHeaders.push(t[1], t[2])
                                }
                            })), h._charset = "x-user-defined", !o.overrideMimeType) {
                            var p = h.rawHeaders["mime-type"];
                            if (p) {
                                var g = p.match(/;\s*charset=([^;])(;|$)/);
                                g && (h._charset = g[1].toLowerCase())
                            }
                            h._charset || (h._charset = "utf-8")
                        }
                    }
                };
            s(h, a.Readable), h.prototype._read = function() {
                var e = this,
                    t = e._resumeFetch;
                t && (e._resumeFetch = null, t())
            }, h.prototype._onXHRProgress = function() {
                var e = this,
                    t = e._xhr,
                    n = null;
                switch (e._mode) {
                    case "text:vbarray":
                        if (t.readyState !== c.DONE) break;
                        try {
                            n = new i.VBArray(t.responseBody).toArray()
                        } catch (u) {}
                        if (null !== n) {
                            e.push(new r(n));
                            break
                        }
                    case "text":
                        try {
                            n = t.responseText
                        } catch (u) {
                            e._mode = "text:vbarray";
                            break
                        }
                        if (n.length > e._pos) {
                            var o = n.substr(e._pos);
                            if ("x-user-defined" === e._charset) {
                                for (var s = new r(o.length), a = 0; a < o.length; a++) s[a] = 255 & o.charCodeAt(a);
                                e.push(s)
                            } else e.push(o, e._charset);
                            e._pos = n.length
                        }
                        break;
                    case "arraybuffer":
                        if (t.readyState !== c.DONE || !t.response) break;
                        n = t.response, e.push(new r(new Uint8Array(n)));
                        break;
                    case "moz-chunked-arraybuffer":
                        if (n = t.response, t.readyState !== c.LOADING || !n) break;
                        e.push(new r(new Uint8Array(n)));
                        break;
                    case "ms-stream":
                        if (n = t.response, t.readyState !== c.LOADING) break;
                        var h = new i.MSStreamReader;
                        h.onprogress = function() {
                            h.result.byteLength > e._pos && (e.push(new r(new Uint8Array(h.result.slice(e._pos)))), e._pos = h.result.byteLength)
                        }, h.onload = function() {
                            e.push(null)
                        }, h.readAsArrayBuffer(n);
                        break
                }
                e._xhr.readyState === c.DONE && "ms-stream" !== e._mode && e.push(null)
            }
        }).call(this, n("4362"), n("b639").Buffer, n("c8ba"))
    },
    c9b8: function(e, t, n) {
        "use strict";

        function r(e, t) {
            e.prototype = Object.create(t.prototype), e.prototype.constructor = e, e.__proto__ = t
        }
        var i = {};

        function o(e, t, n) {
            function o(e, n, r) {
                return "string" === typeof t ? t : t(e, n, r)
            }
            n || (n = Error);
            var s = function(e) {
                function t(t, n, r) {
                    return e.call(this, o(t, n, r)) || this
                }
                return r(t, e), t
            }(n);
            s.prototype.name = n.name, s.prototype.code = e, i[e] = s
        }

        function s(e, t) {
            if (Array.isArray(e)) {
                var n = e.length;
                return e = e.map((function(e) {
                    return String(e)
                })), n > 2 ? "one of ".concat(t, " ").concat(e.slice(0, n - 1).join(", "), ", or ") + e[n - 1] : 2 === n ? "one of ".concat(t, " ").concat(e[0], " or ").concat(e[1]) : "of ".concat(t, " ").concat(e[0])
            }
            return "of ".concat(t, " ").concat(String(e))
        }

        function a(e, t, n) {
            return e.substr(!n || n < 0 ? 0 : +n, t.length) === t
        }

        function c(e, t, n) {
            return (void 0 === n || n > e.length) && (n = e.length), e.substring(n - t.length, n) === t
        }

        function h(e, t, n) {
            return "number" !== typeof n && (n = 0), !(n + t.length > e.length) && -1 !== e.indexOf(t, n)
        }
        o("ERR_INVALID_OPT_VALUE", (function(e, t) {
            return 'The value "' + t + '" is invalid for option "' + e + '"'
        }), TypeError), o("ERR_INVALID_ARG_TYPE", (function(e, t, n) {
            var r, i;
            if ("string" === typeof t && a(t, "not ") ? (r = "must not be", t = t.replace(/^not /, "")) : r = "must be", c(e, " argument")) i = "The ".concat(e, " ").concat(r, " ").concat(s(t, "type"));
            else {
                var o = h(e, ".") ? "property" : "argument";
                i = 'The "'.concat(e, '" ').concat(o, " ").concat(r, " ").concat(s(t, "type"))
            }
            return i += ". Received type ".concat(typeof n), i
        }), TypeError), o("ERR_STREAM_PUSH_AFTER_EOF", "stream.push() after EOF"), o("ERR_METHOD_NOT_IMPLEMENTED", (function(e) {
            return "The " + e + " method is not implemented"
        })), o("ERR_STREAM_PREMATURE_CLOSE", "Premature close"), o("ERR_STREAM_DESTROYED", (function(e) {
            return "Cannot call " + e + " after a stream was destroyed"
        })), o("ERR_MULTIPLE_CALLBACK", "Callback called multiple times"), o("ERR_STREAM_CANNOT_PIPE", "Cannot pipe, not readable"), o("ERR_STREAM_WRITE_AFTER_END", "write after end"), o("ERR_STREAM_NULL_VALUES", "May not write null values to stream", TypeError), o("ERR_UNKNOWN_ENCODING", (function(e) {
            return "Unknown encoding: " + e
        }), TypeError), o("ERR_STREAM_UNSHIFT_AFTER_END_EVENT", "stream.unshift() after end event"), e.exports.codes = i
    },
    ca84: function(e, t, n) {
        var r = n("5135"),
            i = n("fc6a"),
            o = n("4d64").indexOf,
            s = n("d012");
        e.exports = function(e, t) {
            var n, a = i(e),
                c = 0,
                h = [];
            for (n in a) !r(s, n) && r(a, n) && h.push(n);
            while (t.length > c) r(a, n = t[c++]) && (~o(h, n) || h.push(n));
            return h
        }
    },
    cab7: function(e, t, n) {
        const r = n("34eb")("webtorrent:file-stream"),
            i = n("e372");
        class o extends i.Readable {
            constructor(e, t) {
                super(t), this.destroyed = !1, this._torrent = e._torrent;
                const n = t && t.start || 0,
                    r = t && t.end && t.end < e.length ? t.end : e.length - 1,
                    i = e._torrent.pieceLength;
                this._startPiece = (n + e.offset) / i | 0, this._endPiece = (r + e.offset) / i | 0, this._piece = this._startPiece, this._offset = n + e.offset - this._startPiece * i, this._missing = r - n + 1, this._reading = !1, this._notifying = !1, this._criticalLength = Math.min(1048576 / i | 0, 2)
            }
            _read() {
                this._reading || (this._reading = !0, this._notify())
            }
            _notify() {
                if (!this._reading || 0 === this._missing) return;
                if (!this._torrent.bitfield.get(this._piece)) return this._torrent.critical(this._piece, this._piece + this._criticalLength);
                if (this._notifying) return;
                if (this._notifying = !0, this._torrent.destroyed) return this._destroy(new Error("Torrent removed"));
                const e = this._piece;
                this._torrent.store.get(e, async (t, n) => {
                    if (this._notifying = !1, !this.destroyed) {
                        if (r("read %s (length %s) (err %s)", e, n.length, t && t.message), t) return this._destroy(t);
                        this._torrent._arc_decrypt && (n = await this._torrent._arc_decrypt(n, e)), this._offset && (n = n.slice(this._offset), this._offset = 0), this._missing < n.length && (n = n.slice(0, this._missing)), this._missing -= n.length, r("pushing buffer of length %s", n.length), this._reading = !1, this.push(n), 0 === this._missing && this.push(null)
                    }
                }), this._piece += 1
            }
            destroy(e) {
                this._destroy(null, e)
            }
            _destroy(e, t) {
                this.destroyed || (this.destroyed = !0, this._torrent.destroyed || this._torrent.deselect(this._startPiece, this._endPiece, !0), e && this.emit("error", e), this.emit("close"), t && t())
            }
        }
        e.exports = o
    },
    cc12: function(e, t, n) {
        var r = n("da84"),
            i = n("861d"),
            o = r.document,
            s = i(o) && i(o.createElement);
        e.exports = function(e) {
            return s ? o.createElement(e) : {}
        }
    },
    ce4e: function(e, t, n) {
        var r = n("da84");
        e.exports = function(e, t) {
            try {
                Object.defineProperty(r, e, {
                    value: t,
                    configurable: !0,
                    writable: !0
                })
            } catch (n) {
                r[e] = t
            }
            return t
        }
    },
    ced0: function(e, t, n) {
        "use strict";
        n.d(t, "a", (function() {
            return r
        })), n.d(t, "c", (function() {
            return s
        })), n.d(t, "d", (function() {
            return a
        })), n.d(t, "b", (function() {
            return c
        }));
        class r {
            constructor(e = "keyval-store", t = "keyval") {
                this.storeName = t, this._dbp = new Promise((n, r) => {
                    const i = indexedDB.open(e, 1);
                    i.onerror = () => r(i.error), i.onsuccess = () => n(i.result), i.onupgradeneeded = () => {
                        i.result.createObjectStore(t)
                    }
                })
            }
            _withIDBStore(e, t) {
                return this._dbp.then(n => new Promise((r, i) => {
                    const o = n.transaction(this.storeName, e);
                    o.oncomplete = () => r(), o.onabort = o.onerror = () => i(o.error), t(o.objectStore(this.storeName))
                }))
            }
        }
        let i;

        function o() {
            return i || (i = new r), i
        }

        function s(e, t = o()) {
            let n;
            return t._withIDBStore("readonly", t => {
                n = t.get(e)
            }).then(() => n.result)
        }

        function a(e, t, n = o()) {
            return n._withIDBStore("readwrite", n => {
                n.put(t, e)
            })
        }

        function c(e, t = o()) {
            return t._withIDBStore("readwrite", t => {
                t.delete(e)
            })
        }
    },
    cffb: function(e, t, n) {
        "use strict";
        n.r(t), n.d(t, "parse", (function() {
            return g
        })), n.d(t, "format", (function() {
            return o
        })), n.d(t, "resolve", (function() {
            return m
        })), n.d(t, "resolveObject", (function() {
            return b
        }));
        var r = n("b383"),
            i = /https?|ftp|gopher|file/;

        function o(e) {
            "string" == typeof e && (e = g(e));
            var t = function(e, t, n) {
                var r = e.auth,
                    i = e.hostname,
                    o = e.protocol || "",
                    s = e.pathname || "",
                    a = e.hash || "",
                    c = e.query || "",
                    h = !1;
                r = r ? encodeURIComponent(r).replace(/%3A/i, ":") + "@" : "", e.host ? h = r + e.host : i && (h = r + (~i.indexOf(":") ? "[" + i + "]" : i), e.port && (h += ":" + e.port)), c && "object" == typeof c && (c = t.encode(c));
                var u = e.search || c && "?" + c || "";
                return o && ":" !== o.substr(-1) && (o += ":"), e.slashes || (!o || n.test(o)) && !1 !== h ? (h = "//" + (h || ""), s && "/" !== s[0] && (s = "/" + s)) : h || (h = ""), a && "#" !== a[0] && (a = "#" + a), u && "?" !== u[0] && (u = "?" + u), {
                    protocol: o,
                    host: h,
                    pathname: s = s.replace(/[?#]/g, encodeURIComponent),
                    search: u = u.replace("#", "%23"),
                    hash: a
                }
            }(e, r, i);
            return "" + t.protocol + t.host + t.pathname + t.search + t.hash
        }
        var s = "http://",
            a = "w.w",
            c = s + a,
            h = /^https?|ftp|gopher|file/,
            u = /^(.*?)([#?].*)/,
            f = /^([a-z0-9.+-]*:)(\/{0,3})(.*)/i,
            d = /^([a-z0-9.+-]*:)?\/\/\/*/i,
            l = /^([a-z0-9.+-]*:)(\/{0,2})\[(.*)\]$/i;

        function p(e) {
            try {
                return decodeURI(e)
            } catch (i) {
                return e
            }
        }

        function g(e, t, n) {
            void 0 === t && (t = !1), void 0 === n && (n = !1);
            var i = (e = e.trim()).match(u);
            e = i ? p(i[1]).replace(/\\/g, "/") + i[2] : p(e).replace(/\\/g, "/"), l.test(e) && "/" !== e.slice(-1) && (e += "/");
            var s = !/(^javascript)/.test(e) && e.match(f),
                g = d.test(e),
                _ = "";
            s && (h.test(s[1]) || (_ = s[1].toLowerCase(), e = "" + s[2] + s[3]), s[2] || (g = !1, h.test(s[1]) ? (_ = s[1], e = "" + s[3]) : e = "//" + s[3]), 3 !== s[2].length && 1 !== s[2].length || (_ = s[1], e = "/" + s[3]));
            var y, m = e.match(/(:[0-9]+)/),
                b = "";
            m && m[1] && 3 === m[1].length && (e = e.replace(b = m[1], b + "00"));
            var w = {},
                v = "",
                E = "";
            try {
                y = new URL(e)
            } catch (S) {
                v = S, _ || n || !/^\/\//.test(e) || /^\/\/.+[@.]/.test(e) || (E = "/", e = e.substr(1));
                try {
                    y = new URL(e, c)
                } catch (S) {
                    return w.protocol = _, w.href = _, w
                }
            }
            w.slashes = g && !E, w.host = y.host === a ? "" : y.host, w.hostname = y.hostname === a ? "" : y.hostname.replace(/(\[|\])/g, ""), w.protocol = v ? _ || null : y.protocol, w.search = y.search.replace(/\\/g, "%5C"), w.hash = y.hash.replace(/\\/g, "%5C");
            var T = e.split("#");
            !w.search && ~T[0].indexOf("?") && (w.search = "?"), w.hash || "" !== T[1] || (w.hash = "#"), w.query = t ? r.decode(y.search.substr(1)) : w.search.substr(1), w.pathname = E + p(y.pathname).replace(/"/g, "%22"), "about:" === w.protocol && "blank" === w.pathname && (w.protocol = "", w.pathname = ""), v && "/" !== e[0] && (w.pathname = w.pathname.substr(1)), _ && !h.test(_) && "/" !== e.slice(-1) && "/" === w.pathname && (w.pathname = ""), w.path = w.pathname + w.search, w.auth = [y.username, y.password].map(decodeURIComponent).filter(Boolean).join(":"), w.port = y.port, b && (w.host = w.host.replace(b + "00", b), w.port = w.port.slice(0, -2)), w.href = E ? "" + w.pathname + w.search + w.hash : o(w);
            var R = /^(file)/.test(w.href) ? ["host", "hostname"] : [];
            return Object.keys(w).forEach((function(e) {
                ~R.indexOf(e) || (w[e] = w[e] || null)
            })), w
        }
        var _ = /^([a-z0-9.+-]*:\/\/\/)([a-z0-9.+-]:\/*)?/i,
            y = /https?|ftp|gopher|file/;

        function m(e, t) {
            var n = "string" == typeof e ? g(e) : e;
            e = "object" == typeof e ? o(e) : e;
            var r = g(t),
                i = "";
            n.protocol && !n.slashes && (i = n.protocol, e = e.replace(n.protocol, ""), i += "/" === t[0] || "/" === e[0] ? "/" : ""), i && r.protocol && (i = "", r.slashes || (i = r.protocol, t = t.replace(r.protocol, "")));
            var a = e.match(_);
            a && !r.protocol && (e = e.substr((i = a[1] + (a[2] || "")).length), /^\/\/[^\/]/.test(t) && (i = i.slice(0, -1)));
            var h = new URL(e, c + "/"),
                u = new URL(t, h).toString().replace(c, ""),
                f = r.protocol || n.protocol;
            return f += n.slashes || r.slashes ? "//" : "", !i && f ? u = u.replace(s, f) : i && (u = u.replace(s, "")), y.test(u) || ~t.indexOf(".") || "/" === e.slice(-1) || "/" === t.slice(-1) || "/" !== u.slice(-1) || (u = u.slice(0, -1)), i && (u = i + ("/" === u[0] ? u.substr(1) : u)), u
        }

        function b(e, t) {
            return g(m(e, t))
        }
    },
    d012: function(e, t) {
        e.exports = {}
    },
    d039: function(e, t) {
        e.exports = function(e) {
            try {
                return !!e()
            } catch (t) {
                return !0
            }
        }
    },
    d05a: function(e, t) {
        function n(e, t) {
            if (!(t >= e.length || t < 0)) {
                var n = e.pop();
                if (t < e.length) {
                    var r = e[t];
                    return e[t] = n, r
                }
                return n
            }
        }
        e.exports = n
    },
    d066: function(e, t, n) {
        var r = n("da84"),
            i = function(e) {
                return "function" == typeof e ? e : void 0
            };
        e.exports = function(e, t) {
            return arguments.length < 2 ? i(r[e]) : r[e] && r[e][t]
        }
    },
    d1a0: function(e, t, n) {
        "use strict";
        n.d(t, "a", (function() {
            return r
        })), n.d(t, "b", (function() {
            return a
        }));
        n("bf19");
        const r = "arc:",
            i = ":start",
            o = ":end",
            s = (console.log, self.performance);
        class a {
            constructor(e = {}) {
                const {
                    id: t = "",
                    enabled: n = !0
                } = e;
                this.prefix = r + t, this.prefix.endsWith(":") || (this.prefix += ":"), this.enabled = n, this.mark = this.mark.bind(this), this.markOnce = this.markOnce.bind(this), this.markStart = this.markStart.bind(this), this.toJSON = this.toJSON.bind(this), this.markEndAndMeasure = this.markEndAndMeasure.bind(this)
            }
            enable() {
                this.enabled = !0
            }
            disable() {
                this.enabled = !1
            }
            mark(e) {
                this.enabled && s.mark(this.prefix + e)
            }
            measure(e, t, n) {
                if (this.enabled) try {
                    s.measure(this.prefix + e, t, n)
                } catch (r) {}
            }
            markOnce(e) {
                if (!this.enabled) return;
                const t = this.prefix + e,
                    n = performance.getEntriesByName(t);
                0 === n.length && performance.mark(t)
            }
            markStart(e) {
                if (!this.enabled) return () => {};
                const t = this.prefix + e,
                    n = Math.random().toString(36).substring(2, 5),
                    r = `${t}:${n}`,
                    a = r + i,
                    c = r + o;
                return s.mark(a), () => this.markEndAndMeasure(t, a, c)
            }
            markEndAndMeasure(e, t, n) {
                if (this.enabled) {
                    s.mark(n);
                    try {
                        s.measure(e, t, n)
                    } catch (r) {}
                    s.clearMarks(t), s.clearMarks(n)
                }
            }
            toJSON() {
                if (!this.enabled) return {};
                const e = s.getEntries().filter(e => e.name.startsWith(this.prefix)).map(e => e.toJSON());
                return {
                    entries: e,
                    timeOrigin: s.timeOrigin
                }
            }
        }
        t["c"] = new a
    },
    d1e7: function(e, t, n) {
        "use strict";
        var r = {}.propertyIsEnumerable,
            i = Object.getOwnPropertyDescriptor,
            o = i && !r.call({
                1: 2
            }, 1);
        t.f = o ? function(e) {
            var t = i(this, e);
            return !!t && t.enumerable
        } : r
    },
    d2b7: function(e, t) {
        function n(e, t) {
            if (null != t && "string" !== typeof t) throw new Error("Invalid mimetype, expected string.");
            return new Promise((n, r) => {
                const i = [];
                e.on("data", e => i.push(e)).once("end", () => {
                    const e = null != t ? new Blob(i, {
                        type: t
                    }) : new Blob(i);
                    n(e)
                }).once("error", r)
            })
        }
        /*! stream-to-blob. MIT License. Feross Aboukhadijeh <https://feross.org/opensource> */
        e.exports = n
    },
    d2bb: function(e, t, n) {
        var r = n("825a"),
            i = n("3bbe");
        e.exports = Object.setPrototypeOf || ("__proto__" in {} ? function() {
            var e, t = !1,
                n = {};
            try {
                e = Object.getOwnPropertyDescriptor(Object.prototype, "__proto__").set, e.call(n, []), t = n instanceof Array
            } catch (o) {}
            return function(n, o) {
                return r(n), i(o), t ? e.call(n, o) : n.__proto__ = o, n
            }
        }() : void 0)
    },
    d329: function(e, t, n) {
        function r(e) {
            let t = e >> 3;
            return e % 8 !== 0 && t++, t
        }
        class i {
            constructor(e = 0, t) {
                const n = null != t && t.grow;
                this.grow = n && isFinite(n) && r(n) || n || 0, this.buffer = "number" === typeof e ? new Uint8Array(r(e)) : e
            }
            get(e) {
                const t = e >> 3;
                return t < this.buffer.length && !!(this.buffer[t] & 128 >> e % 8)
            }
            set(e, t = !0) {
                const n = e >> 3;
                if (t) {
                    if (this.buffer.length < n + 1) {
                        const e = Math.max(n + 1, Math.min(2 * this.buffer.length, this.grow));
                        if (e <= this.grow) {
                            const t = new Uint8Array(e);
                            t.set(this.buffer), this.buffer = t
                        }
                    }
                    this.buffer[n] |= 128 >> e % 8
                } else n < this.buffer.length && (this.buffer[n] &= ~(128 >> e % 8))
            }
        }
        e.exports = i
    },
    d44e: function(e, t, n) {
        var r = n("9bf2").f,
            i = n("5135"),
            o = n("b622"),
            s = o("toStringTag");
        e.exports = function(e, t, n) {
            e && !i(e = n ? e : e.prototype, s) && r(e, s, {
                configurable: !0,
                value: t
            })
        }
    },
    d633: function(e, t) {
        function n(e, t) {
            if (e && t) return n(e)(t);
            if ("function" !== typeof e) throw new TypeError("need wrapper function");
            return Object.keys(e).forEach((function(t) {
                r[t] = e[t]
            })), r;

            function r() {
                for (var t = new Array(arguments.length), n = 0; n < t.length; n++) t[n] = arguments[n];
                var r = e.apply(this, t),
                    i = t[t.length - 1];
                return "function" === typeof r && r !== i && Object.keys(i).forEach((function(e) {
                    r[e] = i[e]
                })), r
            }
        }
        e.exports = n
    },
    d938: function(e, t, n) {
        var r = n("b639").Buffer;
        e.exports = function(e) {
            if (e instanceof Uint8Array) {
                if (0 === e.byteOffset && e.byteLength === e.buffer.byteLength) return e.buffer;
                if ("function" === typeof e.buffer.slice) return e.buffer.slice(e.byteOffset, e.byteOffset + e.byteLength)
            }
            if (r.isBuffer(e)) {
                for (var t = new Uint8Array(e.length), n = e.length, i = 0; i < n; i++) t[i] = e[i];
                return t.buffer
            }
            throw new Error("Argument must be a Buffer")
        }
    },
    d998: function(e, t, n) {
        var r = n("342f");
        e.exports = /MSIE|Trident/.test(r)
    },
    d9b5: function(e, t, n) {
        var r = n("d066"),
            i = n("fdbf");
        e.exports = i ? function(e) {
            return "symbol" == typeof e
        } : function(e) {
            var t = r("Symbol");
            return "function" == typeof t && Object(e) instanceof t
        }
    },
    da84: function(e, t, n) {
        (function(t) {
            var n = function(e) {
                return e && e.Math == Math && e
            };
            e.exports = n("object" == typeof globalThis && globalThis) || n("object" == typeof window && window) || n("object" == typeof self && self) || n("object" == typeof t && t) || function() {
                return this
            }() || Function("return this")()
        }).call(this, n("c8ba"))
    },
    dc14: function(e, t, n) {
        "use strict";
        (function(t, r) {
            function i(e) {
                var t = this;
                this.next = null, this.entry = null, this.finish = function() {
                    $(t, e)
                }
            }
            var o;
            e.exports = k, k.WritableState = O;
            var s = {
                    deprecate: n("b7d1")
                },
                a = n("429b"),
                c = n("b639").Buffer,
                h = t.Uint8Array || function() {};

            function u(e) {
                return c.from(e)
            }

            function f(e) {
                return c.isBuffer(e) || e instanceof h
            }
            var d, l = n("4681"),
                p = n("0db6"),
                g = p.getHighWaterMark,
                _ = n("c9b8").codes,
                y = _.ERR_INVALID_ARG_TYPE,
                m = _.ERR_METHOD_NOT_IMPLEMENTED,
                b = _.ERR_MULTIPLE_CALLBACK,
                w = _.ERR_STREAM_CANNOT_PIPE,
                v = _.ERR_STREAM_DESTROYED,
                E = _.ERR_STREAM_NULL_VALUES,
                T = _.ERR_STREAM_WRITE_AFTER_END,
                R = _.ERR_UNKNOWN_ENCODING,
                S = l.errorOrDestroy;

            function I() {}

            function O(e, t, r) {
                o = o || n("b19a"), e = e || {}, "boolean" !== typeof r && (r = t instanceof o), this.objectMode = !!e.objectMode, r && (this.objectMode = this.objectMode || !!e.writableObjectMode), this.highWaterMark = g(this, e, "writableHighWaterMark", r), this.finalCalled = !1, this.needDrain = !1, this.ending = !1, this.ended = !1, this.finished = !1, this.destroyed = !1;
                var s = !1 === e.decodeStrings;
                this.decodeStrings = !s, this.defaultEncoding = e.defaultEncoding || "utf8", this.length = 0, this.writing = !1, this.corked = 0, this.sync = !0, this.bufferProcessing = !1, this.onwrite = function(e) {
                    D(t, e)
                }, this.writecb = null, this.writelen = 0, this.bufferedRequest = null, this.lastBufferedRequest = null, this.pendingcb = 0, this.prefinished = !1, this.errorEmitted = !1, this.emitClose = !1 !== e.emitClose, this.autoDestroy = !!e.autoDestroy, this.bufferedRequestCount = 0, this.corkedRequestsFree = new i(this)
            }

            function k(e) {
                o = o || n("b19a");
                var t = this instanceof o;
                if (!t && !d.call(k, this)) return new k(e);
                this._writableState = new O(e, this, t), this.writable = !0, e && ("function" === typeof e.write && (this._write = e.write), "function" === typeof e.writev && (this._writev = e.writev), "function" === typeof e.destroy && (this._destroy = e.destroy), "function" === typeof e.final && (this._final = e.final)), a.call(this)
            }

            function A(e, t) {
                var n = new T;
                S(e, n), r.nextTick(t, n)
            }

            function C(e, t, n, i) {
                var o;
                return null === n ? o = new E : "string" === typeof n || t.objectMode || (o = new y("chunk", ["string", "Buffer"], n)), !o || (S(e, o), r.nextTick(i, o), !1)
            }

            function x(e, t, n) {
                return e.objectMode || !1 === e.decodeStrings || "string" !== typeof t || (t = c.from(t, n)), t
            }

            function N(e, t, n, r, i, o) {
                if (!n) {
                    var s = x(t, r, i);
                    r !== s && (n = !0, i = "buffer", r = s)
                }
                var a = t.objectMode ? 1 : r.length;
                t.length += a;
                var c = t.length < t.highWaterMark;
                if (c || (t.needDrain = !0), t.writing || t.corked) {
                    var h = t.lastBufferedRequest;
                    t.lastBufferedRequest = {
                        chunk: r,
                        encoding: i,
                        isBuf: n,
                        callback: o,
                        next: null
                    }, h ? h.next = t.lastBufferedRequest : t.bufferedRequest = t.lastBufferedRequest, t.bufferedRequestCount += 1
                } else P(e, t, !1, a, r, i, o);
                return c
            }

            function P(e, t, n, r, i, o, s) {
                t.writelen = r, t.writecb = s, t.writing = !0, t.sync = !0, t.destroyed ? t.onwrite(new v("write")) : n ? e._writev(i, t.onwrite) : e._write(i, o, t.onwrite), t.sync = !1
            }

            function L(e, t, n, i, o) {
                --t.pendingcb, n ? (r.nextTick(o, i), r.nextTick(W, e, t), e._writableState.errorEmitted = !0, S(e, i)) : (o(i), e._writableState.errorEmitted = !0, S(e, i), W(e, t))
            }

            function M(e) {
                e.writing = !1, e.writecb = null, e.length -= e.writelen, e.writelen = 0
            }

            function D(e, t) {
                var n = e._writableState,
                    i = n.sync,
                    o = n.writecb;
                if ("function" !== typeof o) throw new b;
                if (M(n), t) L(e, n, i, t, o);
                else {
                    var s = F(n) || e.destroyed;
                    s || n.corked || n.bufferProcessing || !n.bufferedRequest || j(e, n), i ? r.nextTick(U, e, n, s, o) : U(e, n, s, o)
                }
            }

            function U(e, t, n, r) {
                n || B(e, t), t.pendingcb--, r(), W(e, t)
            }

            function B(e, t) {
                0 === t.length && t.needDrain && (t.needDrain = !1, e.emit("drain"))
            }

            function j(e, t) {
                t.bufferProcessing = !0;
                var n = t.bufferedRequest;
                if (e._writev && n && n.next) {
                    var r = t.bufferedRequestCount,
                        o = new Array(r),
                        s = t.corkedRequestsFree;
                    s.entry = n;
                    var a = 0,
                        c = !0;
                    while (n) o[a] = n, n.isBuf || (c = !1), n = n.next, a += 1;
                    o.allBuffers = c, P(e, t, !0, t.length, o, "", s.finish), t.pendingcb++, t.lastBufferedRequest = null, s.next ? (t.corkedRequestsFree = s.next, s.next = null) : t.corkedRequestsFree = new i(t), t.bufferedRequestCount = 0
                } else {
                    while (n) {
                        var h = n.chunk,
                            u = n.encoding,
                            f = n.callback,
                            d = t.objectMode ? 1 : h.length;
                        if (P(e, t, !1, d, h, u, f), n = n.next, t.bufferedRequestCount--, t.writing) break
                    }
                    null === n && (t.lastBufferedRequest = null)
                }
                t.bufferedRequest = n, t.bufferProcessing = !1
            }

            function F(e) {
                return e.ending && 0 === e.length && null === e.bufferedRequest && !e.finished && !e.writing
            }

            function H(e, t) {
                e._final((function(n) {
                    t.pendingcb--, n && S(e, n), t.prefinished = !0, e.emit("prefinish"), W(e, t)
                }))
            }

            function G(e, t) {
                t.prefinished || t.finalCalled || ("function" !== typeof e._final || t.destroyed ? (t.prefinished = !0, e.emit("prefinish")) : (t.pendingcb++, t.finalCalled = !0, r.nextTick(H, e, t)))
            }

            function W(e, t) {
                var n = F(t);
                if (n && (G(e, t), 0 === t.pendingcb && (t.finished = !0, e.emit("finish"), t.autoDestroy))) {
                    var r = e._readableState;
                    (!r || r.autoDestroy && r.endEmitted) && e.destroy()
                }
                return n
            }

            function q(e, t, n) {
                t.ending = !0, W(e, t), n && (t.finished ? r.nextTick(n) : e.once("finish", n)), t.ended = !0, e.writable = !1
            }

            function $(e, t, n) {
                var r = e.entry;
                e.entry = null;
                while (r) {
                    var i = r.callback;
                    t.pendingcb--, i(n), r = r.next
                }
                t.corkedRequestsFree.next = e
            }
            n("3fb5")(k, a), O.prototype.getBuffer = function() {
                    var e = this.bufferedRequest,
                        t = [];
                    while (e) t.push(e), e = e.next;
                    return t
                },
                function() {
                    try {
                        Object.defineProperty(O.prototype, "buffer", {
                            get: s.deprecate((function() {
                                return this.getBuffer()
                            }), "_writableState.buffer is deprecated. Use _writableState.getBuffer instead.", "DEP0003")
                        })
                    } catch (e) {}
                }(), "function" === typeof Symbol && Symbol.hasInstance && "function" === typeof Function.prototype[Symbol.hasInstance] ? (d = Function.prototype[Symbol.hasInstance], Object.defineProperty(k, Symbol.hasInstance, {
                    value: function(e) {
                        return !!d.call(this, e) || this === k && (e && e._writableState instanceof O)
                    }
                })) : d = function(e) {
                    return e instanceof this
                }, k.prototype.pipe = function() {
                    S(this, new w)
                }, k.prototype.write = function(e, t, n) {
                    var r = this._writableState,
                        i = !1,
                        o = !r.objectMode && f(e);
                    return o && !c.isBuffer(e) && (e = u(e)), "function" === typeof t && (n = t, t = null), o ? t = "buffer" : t || (t = r.defaultEncoding), "function" !== typeof n && (n = I), r.ending ? A(this, n) : (o || C(this, r, e, n)) && (r.pendingcb++, i = N(this, r, o, e, t, n)), i
                }, k.prototype.cork = function() {
                    this._writableState.corked++
                }, k.prototype.uncork = function() {
                    var e = this._writableState;
                    e.corked && (e.corked--, e.writing || e.corked || e.bufferProcessing || !e.bufferedRequest || j(this, e))
                }, k.prototype.setDefaultEncoding = function(e) {
                    if ("string" === typeof e && (e = e.toLowerCase()), !(["hex", "utf8", "utf-8", "ascii", "binary", "base64", "ucs2", "ucs-2", "utf16le", "utf-16le", "raw"].indexOf((e + "").toLowerCase()) > -1)) throw new R(e);
                    return this._writableState.defaultEncoding = e, this
                }, Object.defineProperty(k.prototype, "writableBuffer", {
                    enumerable: !1,
                    get: function() {
                        return this._writableState && this._writableState.getBuffer()
                    }
                }), Object.defineProperty(k.prototype, "writableHighWaterMark", {
                    enumerable: !1,
                    get: function() {
                        return this._writableState.highWaterMark
                    }
                }), k.prototype._write = function(e, t, n) {
                    n(new m("_write()"))
                }, k.prototype._writev = null, k.prototype.end = function(e, t, n) {
                    var r = this._writableState;
                    return "function" === typeof e ? (n = e, e = null, t = null) : "function" === typeof t && (n = t, t = null), null !== e && void 0 !== e && this.write(e, t), r.corked && (r.corked = 1, this.uncork()), r.ending || q(this, r, n), this
                }, Object.defineProperty(k.prototype, "writableLength", {
                    enumerable: !1,
                    get: function() {
                        return this._writableState.length
                    }
                }), Object.defineProperty(k.prototype, "destroyed", {
                    enumerable: !1,
                    get: function() {
                        return void 0 !== this._writableState && this._writableState.destroyed
                    },
                    set: function(e) {
                        this._writableState && (this._writableState.destroyed = e)
                    }
                }), k.prototype.destroy = l.destroy, k.prototype._undestroy = l.undestroy, k.prototype._destroy = function(e, t) {
                    t(e)
                }
        }).call(this, n("c8ba"), n("4362"))
    },
    dc90: function(e, t, n) {
        function r(e) {
            function t(e) {
                let t = 0;
                for (let n = 0; n < e.length; n++) t = (t << 5) - t + e.charCodeAt(n), t |= 0;
                return r.colors[Math.abs(t) % r.colors.length]
            }

            function r(e) {
                let t, n, o, s = null;

                function a(...e) {
                    if (!a.enabled) return;
                    const n = a,
                        i = Number(new Date),
                        o = i - (t || i);
                    n.diff = o, n.prev = t, n.curr = i, t = i, e[0] = r.coerce(e[0]), "string" !== typeof e[0] && e.unshift("%O");
                    let s = 0;
                    e[0] = e[0].replace(/%([a-zA-Z%])/g, (t, i) => {
                        if ("%%" === t) return "%";
                        s++;
                        const o = r.formatters[i];
                        if ("function" === typeof o) {
                            const r = e[s];
                            t = o.call(n, r), e.splice(s, 1), s--
                        }
                        return t
                    }), r.formatArgs.call(n, e);
                    const c = n.log || r.log;
                    c.apply(n, e)
                }
                return a.namespace = e, a.useColors = r.useColors(), a.color = r.selectColor(e), a.extend = i, a.destroy = r.destroy, Object.defineProperty(a, "enabled", {
                    enumerable: !0,
                    configurable: !1,
                    get: () => null !== s ? s : (n !== r.namespaces && (n = r.namespaces, o = r.enabled(e)), o),
                    set: e => {
                        s = e
                    }
                }), "function" === typeof r.init && r.init(a), a
            }

            function i(e, t) {
                const n = r(this.namespace + ("undefined" === typeof t ? ":" : t) + e);
                return n.log = this.log, n
            }

            function o(e) {
                let t;
                r.save(e), r.namespaces = e, r.names = [], r.skips = [];
                const n = ("string" === typeof e ? e : "").split(/[\s,]+/),
                    i = n.length;
                for (t = 0; t < i; t++) n[t] && (e = n[t].replace(/\*/g, ".*?"), "-" === e[0] ? r.skips.push(new RegExp("^" + e.substr(1) + "$")) : r.names.push(new RegExp("^" + e + "$")))
            }

            function s() {
                const e = [...r.names.map(c), ...r.skips.map(c).map(e => "-" + e)].join(",");
                return r.enable(""), e
            }

            function a(e) {
                if ("*" === e[e.length - 1]) return !0;
                let t, n;
                for (t = 0, n = r.skips.length; t < n; t++)
                    if (r.skips[t].test(e)) return !1;
                for (t = 0, n = r.names.length; t < n; t++)
                    if (r.names[t].test(e)) return !0;
                return !1
            }

            function c(e) {
                return e.toString().substring(2, e.toString().length - 2).replace(/\.\*\?$/, "*")
            }

            function h(e) {
                return e instanceof Error ? e.stack || e.message : e
            }

            function u() {
                console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`.")
            }
            return r.debug = r, r.default = r, r.coerce = h, r.disable = s, r.enable = o, r.enabled = a, r.humanize = n("1468"), r.destroy = u, Object.keys(e).forEach(t => {
                r[t] = e[t]
            }), r.names = [], r.skips = [], r.formatters = {}, r.selectColor = t, r.enable(r.load()), r
        }
        e.exports = r
    },
    de83: function(e, t) {
        e.exports = function() {
            if ("undefined" === typeof globalThis) return null;
            var e = {
                RTCPeerConnection: globalThis.RTCPeerConnection || globalThis.mozRTCPeerConnection || globalThis.webkitRTCPeerConnection,
                RTCSessionDescription: globalThis.RTCSessionDescription || globalThis.mozRTCSessionDescription || globalThis.webkitRTCSessionDescription,
                RTCIceCandidate: globalThis.RTCIceCandidate || globalThis.mozRTCIceCandidate || globalThis.webkitRTCIceCandidate
            };
            return e.RTCPeerConnection ? e : null
        }
    },
    df02: function(e, t, n) {
        const r = n("0d7c"),
            {
                MAX_LENGTH: i,
                MAX_SAFE_INTEGER: o
            } = n("fe45"),
            {
                re: s,
                t: a
            } = n("22c0"),
            c = n("e12f"),
            {
                compareIdentifiers: h
            } = n("2874");
        class u {
            constructor(e, t) {
                if (t = c(t), e instanceof u) {
                    if (e.loose === !!t.loose && e.includePrerelease === !!t.includePrerelease) return e;
                    e = e.version
                } else if ("string" !== typeof e) throw new TypeError("Invalid Version: " + e);
                if (e.length > i) throw new TypeError(`version is longer than ${i} characters`);
                r("SemVer", e, t), this.options = t, this.loose = !!t.loose, this.includePrerelease = !!t.includePrerelease;
                const n = e.trim().match(t.loose ? s[a.LOOSE] : s[a.FULL]);
                if (!n) throw new TypeError("Invalid Version: " + e);
                if (this.raw = e, this.major = +n[1], this.minor = +n[2], this.patch = +n[3], this.major > o || this.major < 0) throw new TypeError("Invalid major version");
                if (this.minor > o || this.minor < 0) throw new TypeError("Invalid minor version");
                if (this.patch > o || this.patch < 0) throw new TypeError("Invalid patch version");
                n[4] ? this.prerelease = n[4].split(".").map(e => {
                    if (/^[0-9]+$/.test(e)) {
                        const t = +e;
                        if (t >= 0 && t < o) return t
                    }
                    return e
                }) : this.prerelease = [], this.build = n[5] ? n[5].split(".") : [], this.format()
            }
            format() {
                return this.version = `${this.major}.${this.minor}.${this.patch}`, this.prerelease.length && (this.version += "-" + this.prerelease.join(".")), this.version
            }
            toString() {
                return this.version
            }
            compare(e) {
                if (r("SemVer.compare", this.version, this.options, e), !(e instanceof u)) {
                    if ("string" === typeof e && e === this.version) return 0;
                    e = new u(e, this.options)
                }
                return e.version === this.version ? 0 : this.compareMain(e) || this.comparePre(e)
            }
            compareMain(e) {
                return e instanceof u || (e = new u(e, this.options)), h(this.major, e.major) || h(this.minor, e.minor) || h(this.patch, e.patch)
            }
            comparePre(e) {
                if (e instanceof u || (e = new u(e, this.options)), this.prerelease.length && !e.prerelease.length) return -1;
                if (!this.prerelease.length && e.prerelease.length) return 1;
                if (!this.prerelease.length && !e.prerelease.length) return 0;
                let t = 0;
                do {
                    const n = this.prerelease[t],
                        i = e.prerelease[t];
                    if (r("prerelease compare", t, n, i), void 0 === n && void 0 === i) return 0;
                    if (void 0 === i) return 1;
                    if (void 0 === n) return -1;
                    if (n !== i) return h(n, i)
                } while (++t)
            }
            compareBuild(e) {
                e instanceof u || (e = new u(e, this.options));
                let t = 0;
                do {
                    const n = this.build[t],
                        i = e.build[t];
                    if (r("prerelease compare", t, n, i), void 0 === n && void 0 === i) return 0;
                    if (void 0 === i) return 1;
                    if (void 0 === n) return -1;
                    if (n !== i) return h(n, i)
                } while (++t)
            }
            inc(e, t) {
                switch (e) {
                    case "premajor":
                        this.prerelease.length = 0, this.patch = 0, this.minor = 0, this.major++, this.inc("pre", t);
                        break;
                    case "preminor":
                        this.prerelease.length = 0, this.patch = 0, this.minor++, this.inc("pre", t);
                        break;
                    case "prepatch":
                        this.prerelease.length = 0, this.inc("patch", t), this.inc("pre", t);
                        break;
                    case "prerelease":
                        0 === this.prerelease.length && this.inc("patch", t), this.inc("pre", t);
                        break;
                    case "major":
                        0 === this.minor && 0 === this.patch && 0 !== this.prerelease.length || this.major++, this.minor = 0, this.patch = 0, this.prerelease = [];
                        break;
                    case "minor":
                        0 === this.patch && 0 !== this.prerelease.length || this.minor++, this.patch = 0, this.prerelease = [];
                        break;
                    case "patch":
                        0 === this.prerelease.length && this.patch++, this.prerelease = [];
                        break;
                    case "pre":
                        if (0 === this.prerelease.length) this.prerelease = [0];
                        else {
                            let e = this.prerelease.length;
                            while (--e >= 0) "number" === typeof this.prerelease[e] && (this.prerelease[e]++, e = -2); - 1 === e && this.prerelease.push(0)
                        }
                        t && (this.prerelease[0] === t ? isNaN(this.prerelease[1]) && (this.prerelease = [t, 0]) : this.prerelease = [t, 0]);
                        break;
                    default:
                        throw new Error("invalid increment argument: " + e)
                }
                return this.format(), this.raw = this.version, this
            }
        }
        e.exports = u
    },
    df75: function(e, t, n) {
        var r = n("ca84"),
            i = n("7839");
        e.exports = Object.keys || function(e) {
            return r(e, i)
        }
    },
    df7c: function(e, t, n) {
        (function(e) {
            function n(e, t) {
                for (var n = 0, r = e.length - 1; r >= 0; r--) {
                    var i = e[r];
                    "." === i ? e.splice(r, 1) : ".." === i ? (e.splice(r, 1), n++) : n && (e.splice(r, 1), n--)
                }
                if (t)
                    for (; n--; n) e.unshift("..");
                return e
            }

            function r(e) {
                "string" !== typeof e && (e += "");
                var t, n = 0,
                    r = -1,
                    i = !0;
                for (t = e.length - 1; t >= 0; --t)
                    if (47 === e.charCodeAt(t)) {
                        if (!i) {
                            n = t + 1;
                            break
                        }
                    } else -1 === r && (i = !1, r = t + 1);
                return -1 === r ? "" : e.slice(n, r)
            }

            function i(e, t) {
                if (e.filter) return e.filter(t);
                for (var n = [], r = 0; r < e.length; r++) t(e[r], r, e) && n.push(e[r]);
                return n
            }
            t.resolve = function() {
                for (var t = "", r = !1, o = arguments.length - 1; o >= -1 && !r; o--) {
                    var s = o >= 0 ? arguments[o] : e.cwd();
                    if ("string" !== typeof s) throw new TypeError("Arguments to path.resolve must be strings");
                    s && (t = s + "/" + t, r = "/" === s.charAt(0))
                }
                return t = n(i(t.split("/"), (function(e) {
                    return !!e
                })), !r).join("/"), (r ? "/" : "") + t || "."
            }, t.normalize = function(e) {
                var r = t.isAbsolute(e),
                    s = "/" === o(e, -1);
                return e = n(i(e.split("/"), (function(e) {
                    return !!e
                })), !r).join("/"), e || r || (e = "."), e && s && (e += "/"), (r ? "/" : "") + e
            }, t.isAbsolute = function(e) {
                return "/" === e.charAt(0)
            }, t.join = function() {
                var e = Array.prototype.slice.call(arguments, 0);
                return t.normalize(i(e, (function(e, t) {
                    if ("string" !== typeof e) throw new TypeError("Arguments to path.join must be strings");
                    return e
                })).join("/"))
            }, t.relative = function(e, n) {
                function r(e) {
                    for (var t = 0; t < e.length; t++)
                        if ("" !== e[t]) break;
                    for (var n = e.length - 1; n >= 0; n--)
                        if ("" !== e[n]) break;
                    return t > n ? [] : e.slice(t, n - t + 1)
                }
                e = t.resolve(e).substr(1), n = t.resolve(n).substr(1);
                for (var i = r(e.split("/")), o = r(n.split("/")), s = Math.min(i.length, o.length), a = s, c = 0; c < s; c++)
                    if (i[c] !== o[c]) {
                        a = c;
                        break
                    }
                var h = [];
                for (c = a; c < i.length; c++) h.push("..");
                return h = h.concat(o.slice(a)), h.join("/")
            }, t.sep = "/", t.delimiter = ":", t.dirname = function(e) {
                if ("string" !== typeof e && (e += ""), 0 === e.length) return ".";
                for (var t = e.charCodeAt(0), n = 47 === t, r = -1, i = !0, o = e.length - 1; o >= 1; --o)
                    if (t = e.charCodeAt(o), 47 === t) {
                        if (!i) {
                            r = o;
                            break
                        }
                    } else i = !1;
                return -1 === r ? n ? "/" : "." : n && 1 === r ? "/" : e.slice(0, r)
            }, t.basename = function(e, t) {
                var n = r(e);
                return t && n.substr(-1 * t.length) === t && (n = n.substr(0, n.length - t.length)), n
            }, t.extname = function(e) {
                "string" !== typeof e && (e += "");
                for (var t = -1, n = 0, r = -1, i = !0, o = 0, s = e.length - 1; s >= 0; --s) {
                    var a = e.charCodeAt(s);
                    if (47 !== a) - 1 === r && (i = !1, r = s + 1), 46 === a ? -1 === t ? t = s : 1 !== o && (o = 1) : -1 !== t && (o = -1);
                    else if (!i) {
                        n = s + 1;
                        break
                    }
                }
                return -1 === t || -1 === r || 0 === o || 1 === o && t === r - 1 && t === n + 1 ? "" : e.slice(t, r)
            };
            var o = "b" === "ab".substr(-1) ? function(e, t, n) {
                return e.substr(t, n)
            } : function(e, t, n) {
                return t < 0 && (t = e.length + t), e.substr(t, n)
            }
        }).call(this, n("4362"))
    },
    e099: function(e, t, n) {
        "use strict";
        var r = function(e) {
            switch (typeof e) {
                case "string":
                    return e;
                case "boolean":
                    return e ? "true" : "false";
                case "number":
                    return isFinite(e) ? e : "";
                default:
                    return ""
            }
        };
        e.exports = function(e, t, n, a) {
            return t = t || "&", n = n || "=", null === e && (e = void 0), "object" === typeof e ? o(s(e), (function(s) {
                var a = encodeURIComponent(r(s)) + n;
                return i(e[s]) ? o(e[s], (function(e) {
                    return a + encodeURIComponent(r(e))
                })).join(t) : a + encodeURIComponent(r(e[s]))
            })).join(t) : a ? encodeURIComponent(r(a)) + n + encodeURIComponent(r(e)) : ""
        };
        var i = Array.isArray || function(e) {
            return "[object Array]" === Object.prototype.toString.call(e)
        };

        function o(e, t) {
            if (e.map) return e.map(t);
            for (var n = [], r = 0; r < e.length; r++) n.push(t(e[r], r));
            return n
        }
        var s = Object.keys || function(e) {
            var t = [];
            for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && t.push(n);
            return t
        }
    },
    e12f: function(e, t) {
        const n = ["includePrerelease", "loose", "rtl"],
            r = e => e ? "object" !== typeof e ? {
                loose: !0
            } : n.filter(t => e[t]).reduce((e, t) => (e[t] = !0, e), {}) : {};
        e.exports = r
    },
    e163: function(e, t, n) {
        var r = n("5135"),
            i = n("7b0b"),
            o = n("f772"),
            s = n("e177"),
            a = o("IE_PROTO"),
            c = Object.prototype;
        e.exports = s ? Object.getPrototypeOf : function(e) {
            return e = i(e), r(e, a) ? e[a] : "function" == typeof e.constructor && e instanceof e.constructor ? e.constructor.prototype : e instanceof Object ? c : null
        }
    },
    e177: function(e, t, n) {
        var r = n("d039");
        e.exports = !r((function() {
            function e() {}
            return e.prototype.constructor = null, Object.getPrototypeOf(new e) !== e.prototype
        }))
    },
    e1f4: function(e, t) {
        var n = "undefined" != typeof crypto && crypto.getRandomValues && crypto.getRandomValues.bind(crypto) || "undefined" != typeof msCrypto && "function" == typeof window.msCrypto.getRandomValues && msCrypto.getRandomValues.bind(msCrypto);
        if (n) {
            var r = new Uint8Array(16);
            e.exports = function() {
                return n(r), r
            }
        } else {
            var i = new Array(16);
            e.exports = function() {
                for (var e, t = 0; t < 16; t++) 0 === (3 & t) && (e = 4294967296 * Math.random()), i[t] = e >>> ((3 & t) << 3) & 255;
                return i
            }
        }
    },
    e2cc: function(e, t, n) {
        var r = n("6eeb");
        e.exports = function(e, t, n) {
            for (var i in t) r(e, i, t[i], n);
            return e
        }
    },
    e372: function(e, t, n) {
        t = e.exports = n("ad71"), t.Stream = t, t.Readable = t, t.Writable = n("dc14"), t.Duplex = n("b19a"), t.Transform = n("27bf"), t.PassThrough = n("780f"), t.finished = n("903c"), t.pipeline = n("5d1c")
    },
    e3a2: function(e, t, n) {
        (function(t) {
            const {
                EventEmitter: r
            } = n("faa1"), {
                PassThrough: i
            } = n("e372"), o = n("ab52"), s = n("df7c"), a = n("a999"), c = n("d2b7"), h = n("7c59"), u = n("c3a8"), f = n("cab7");
            class d extends r {
                constructor(e, t) {
                    super(), this._torrent = e, this._destroyed = !1, this.name = t.name, this.path = t.path, this.length = t.length, this.offset = t.offset, this.done = !1;
                    const n = t.offset,
                        r = n + t.length - 1;
                    this._startPiece = n / this._torrent.pieceLength | 0, this._endPiece = r / this._torrent.pieceLength | 0, 0 === this.length && (this.done = !0, this.emit("done"))
                }
                get downloaded() {
                    if (!this._torrent.bitfield) return 0;
                    const {
                        pieces: e,
                        bitfield: t,
                        pieceLength: n
                    } = this._torrent, {
                        _startPiece: r,
                        _endPiece: i
                    } = this, o = e[r];
                    let s = t.get(r) ? n - this.offset % n : Math.max(o.length - o.missing - this.offset, 0);
                    for (let a = r + 1; a <= i; ++a)
                        if (t.get(a)) s += n;
                        else {
                            const t = e[a];
                            s += t.length - t.missing
                        }
                    return Math.min(s, this.length)
                }
                get progress() {
                    return this.length ? this.downloaded / this.length : 0
                }
                select(e) {
                    0 !== this.length && this._torrent.select(this._startPiece, this._endPiece, e)
                }
                deselect() {
                    0 !== this.length && this._torrent.deselect(this._startPiece, this._endPiece, !1)
                }
                createReadStream(e) {
                    if (0 === this.length) {
                        const e = new i;
                        return t.nextTick(() => {
                            e.end()
                        }), e
                    }
                    const n = new f(this, e);
                    return this._torrent.select(n._startPiece, n._endPiece, !0, () => {
                        n._notify()
                    }), o(n, () => {
                        this._destroyed || this._torrent.destroyed || this._torrent.deselect(n._startPiece, n._endPiece, !0)
                    }), n
                }
                getBuffer(e) {
                    u(this.createReadStream(), this.length, e)
                }
                getBlob(e) {
                    if ("undefined" === typeof window) throw new Error("browser-only method");
                    c(this.createReadStream(), this._getMimeType()).then(t => e(null, t), t => e(t))
                }
                getBlobURL(e) {
                    if ("undefined" === typeof window) throw new Error("browser-only method");
                    h(this.createReadStream(), this._getMimeType()).then(t => e(null, t), t => e(t))
                }
                appendTo(e, t, n) {
                    if ("undefined" === typeof window) throw new Error("browser-only method");
                    a.append(this, e, t, n)
                }
                renderTo(e, t, n) {
                    if ("undefined" === typeof window) throw new Error("browser-only method");
                    a.render(this, e, t, n)
                }
                _getMimeType() {
                    return a.mime[s.extname(this.name).toLowerCase()]
                }
                _destroy() {
                    this._destroyed = !0, this._torrent = null
                }
            }
            e.exports = d
        }).call(this, n("4362"))
    },
    e3db: function(e, t) {
        var n = {}.toString;
        e.exports = Array.isArray || function(e) {
            return "[object Array]" == n.call(e)
        }
    },
    e893: function(e, t, n) {
        var r = n("5135"),
            i = n("56ef"),
            o = n("06cf"),
            s = n("9bf2");
        e.exports = function(e, t) {
            for (var n = i(t), a = s.f, c = o.f, h = 0; h < n.length; h++) {
                var u = n[h];
                r(e, u) || a(e, u, c(t, u))
            }
        }
    },
    e8b5: function(e, t, n) {
        var r = n("c6b6");
        e.exports = Array.isArray || function(e) {
            return "Array" == r(e)
        }
    },
    e95a: function(e, t, n) {
        var r = n("b622"),
            i = n("3f8c"),
            o = r("iterator"),
            s = Array.prototype;
        e.exports = function(e) {
            return void 0 !== e && (i.Array === e || s[o] === e)
        }
    },
    ebb5: function(e, t, n) {
        "use strict";
        var r, i, o, s = n("a981"),
            a = n("83ab"),
            c = n("da84"),
            h = n("861d"),
            u = n("5135"),
            f = n("f5df"),
            d = n("9112"),
            l = n("6eeb"),
            p = n("9bf2").f,
            g = n("e163"),
            _ = n("d2bb"),
            y = n("b622"),
            m = n("90e3"),
            b = c.Int8Array,
            w = b && b.prototype,
            v = c.Uint8ClampedArray,
            E = v && v.prototype,
            T = b && g(b),
            R = w && g(w),
            S = Object.prototype,
            I = S.isPrototypeOf,
            O = y("toStringTag"),
            k = m("TYPED_ARRAY_TAG"),
            A = m("TYPED_ARRAY_CONSTRUCTOR"),
            C = s && !!_ && "Opera" !== f(c.opera),
            x = !1,
            N = {
                Int8Array: 1,
                Uint8Array: 1,
                Uint8ClampedArray: 1,
                Int16Array: 2,
                Uint16Array: 2,
                Int32Array: 4,
                Uint32Array: 4,
                Float32Array: 4,
                Float64Array: 8
            },
            P = {
                BigInt64Array: 8,
                BigUint64Array: 8
            },
            L = function(e) {
                if (!h(e)) return !1;
                var t = f(e);
                return "DataView" === t || u(N, t) || u(P, t)
            },
            M = function(e) {
                if (!h(e)) return !1;
                var t = f(e);
                return u(N, t) || u(P, t)
            },
            D = function(e) {
                if (M(e)) return e;
                throw TypeError("Target is not a typed array")
            },
            U = function(e) {
                if (_ && !I.call(T, e)) throw TypeError("Target is not a typed array constructor");
                return e
            },
            B = function(e, t, n) {
                if (a) {
                    if (n)
                        for (var r in N) {
                            var i = c[r];
                            if (i && u(i.prototype, e)) try {
                                delete i.prototype[e]
                            } catch (o) {}
                        }
                    R[e] && !n || l(R, e, n ? t : C && w[e] || t)
                }
            },
            j = function(e, t, n) {
                var r, i;
                if (a) {
                    if (_) {
                        if (n)
                            for (r in N)
                                if (i = c[r], i && u(i, e)) try {
                                    delete i[e]
                                } catch (o) {}
                        if (T[e] && !n) return;
                        try {
                            return l(T, e, n ? t : C && T[e] || t)
                        } catch (o) {}
                    }
                    for (r in N) i = c[r], !i || i[e] && !n || l(i, e, t)
                }
            };
        for (r in N) i = c[r], o = i && i.prototype, o ? d(o, A, i) : C = !1;
        for (r in P) i = c[r], o = i && i.prototype, o && d(o, A, i);
        if ((!C || "function" != typeof T || T === Function.prototype) && (T = function() {
                throw TypeError("Incorrect invocation")
            }, C))
            for (r in N) c[r] && _(c[r], T);
        if ((!C || !R || R === S) && (R = T.prototype, C))
            for (r in N) c[r] && _(c[r].prototype, R);
        if (C && g(E) !== R && _(E, R), a && !u(R, O))
            for (r in x = !0, p(R, O, {
                    get: function() {
                        return h(this) ? this[k] : void 0
                    }
                }), N) c[r] && d(c[r], k, r);
        e.exports = {
            NATIVE_ARRAY_BUFFER_VIEWS: C,
            TYPED_ARRAY_CONSTRUCTOR: A,
            TYPED_ARRAY_TAG: x && k,
            aTypedArray: D,
            aTypedArrayConstructor: U,
            exportTypedArrayMethod: B,
            exportTypedArrayStaticMethod: j,
            isView: L,
            isTypedArray: M,
            TypedArray: T,
            TypedArrayPrototype: R
        }
    },
    f06c: function(e, t, n) {
        const r = n("df02"),
            i = (e, t, n) => new r(e, n).compare(new r(t, n));
        e.exports = i
    },
    f5df: function(e, t, n) {
        var r = n("00ee"),
            i = n("c6b6"),
            o = n("b622"),
            s = o("toStringTag"),
            a = "Arguments" == i(function() {
                return arguments
            }()),
            c = function(e, t) {
                try {
                    return e[t]
                } catch (n) {}
            };
        e.exports = r ? i : function(e) {
            var t, n, r;
            return void 0 === e ? "Undefined" : null === e ? "Null" : "string" == typeof(n = c(t = Object(e), s)) ? n : a ? i(t) : "Object" == (r = i(t)) && "function" == typeof t.callee ? "Arguments" : r
        }
    },
    f772: function(e, t, n) {
        var r = n("5692"),
            i = n("90e3"),
            o = r("keys");
        e.exports = function(e) {
            return o[e] || (o[e] = i(e))
        }
    },
    f8cd: function(e, t, n) {
        var r = n("a691");
        e.exports = function(e) {
            var t = r(e);
            if (t < 0) throw RangeError("The argument can't be less than 0");
            return t
        }
    },
    faa1: function(e, t, n) {
        "use strict";
        var r, i = "object" === typeof Reflect ? Reflect : null,
            o = i && "function" === typeof i.apply ? i.apply : function(e, t, n) {
                return Function.prototype.apply.call(e, t, n)
            };

        function s(e) {
            console && console.warn && console.warn(e)
        }
        r = i && "function" === typeof i.ownKeys ? i.ownKeys : Object.getOwnPropertySymbols ? function(e) {
            return Object.getOwnPropertyNames(e).concat(Object.getOwnPropertySymbols(e))
        } : function(e) {
            return Object.getOwnPropertyNames(e)
        };
        var a = Number.isNaN || function(e) {
            return e !== e
        };

        function c() {
            c.init.call(this)
        }
        e.exports = c, e.exports.once = w, c.EventEmitter = c, c.prototype._events = void 0, c.prototype._eventsCount = 0, c.prototype._maxListeners = void 0;
        var h = 10;

        function u(e) {
            if ("function" !== typeof e) throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof e)
        }

        function f(e) {
            return void 0 === e._maxListeners ? c.defaultMaxListeners : e._maxListeners
        }

        function d(e, t, n, r) {
            var i, o, a;
            if (u(n), o = e._events, void 0 === o ? (o = e._events = Object.create(null), e._eventsCount = 0) : (void 0 !== o.newListener && (e.emit("newListener", t, n.listener ? n.listener : n), o = e._events), a = o[t]), void 0 === a) a = o[t] = n, ++e._eventsCount;
            else if ("function" === typeof a ? a = o[t] = r ? [n, a] : [a, n] : r ? a.unshift(n) : a.push(n), i = f(e), i > 0 && a.length > i && !a.warned) {
                a.warned = !0;
                var c = new Error("Possible EventEmitter memory leak detected. " + a.length + " " + String(t) + " listeners added. Use emitter.setMaxListeners() to increase limit");
                c.name = "MaxListenersExceededWarning", c.emitter = e, c.type = t, c.count = a.length, s(c)
            }
            return e
        }

        function l() {
            if (!this.fired) return this.target.removeListener(this.type, this.wrapFn), this.fired = !0, 0 === arguments.length ? this.listener.call(this.target) : this.listener.apply(this.target, arguments)
        }

        function p(e, t, n) {
            var r = {
                    fired: !1,
                    wrapFn: void 0,
                    target: e,
                    type: t,
                    listener: n
                },
                i = l.bind(r);
            return i.listener = n, r.wrapFn = i, i
        }

        function g(e, t, n) {
            var r = e._events;
            if (void 0 === r) return [];
            var i = r[t];
            return void 0 === i ? [] : "function" === typeof i ? n ? [i.listener || i] : [i] : n ? b(i) : y(i, i.length)
        }

        function _(e) {
            var t = this._events;
            if (void 0 !== t) {
                var n = t[e];
                if ("function" === typeof n) return 1;
                if (void 0 !== n) return n.length
            }
            return 0
        }

        function y(e, t) {
            for (var n = new Array(t), r = 0; r < t; ++r) n[r] = e[r];
            return n
        }

        function m(e, t) {
            for (; t + 1 < e.length; t++) e[t] = e[t + 1];
            e.pop()
        }

        function b(e) {
            for (var t = new Array(e.length), n = 0; n < t.length; ++n) t[n] = e[n].listener || e[n];
            return t
        }

        function w(e, t) {
            return new Promise((function(n, r) {
                function i(n) {
                    e.removeListener(t, o), r(n)
                }

                function o() {
                    "function" === typeof e.removeListener && e.removeListener("error", i), n([].slice.call(arguments))
                }
                E(e, t, o, {
                    once: !0
                }), "error" !== t && v(e, i, {
                    once: !0
                })
            }))
        }

        function v(e, t, n) {
            "function" === typeof e.on && E(e, "error", t, n)
        }

        function E(e, t, n, r) {
            if ("function" === typeof e.on) r.once ? e.once(t, n) : e.on(t, n);
            else {
                if ("function" !== typeof e.addEventListener) throw new TypeError('The "emitter" argument must be of type EventEmitter. Received type ' + typeof e);
                e.addEventListener(t, (function i(o) {
                    r.once && e.removeEventListener(t, i), n(o)
                }))
            }
        }
        Object.defineProperty(c, "defaultMaxListeners", {
            enumerable: !0,
            get: function() {
                return h
            },
            set: function(e) {
                if ("number" !== typeof e || e < 0 || a(e)) throw new RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' + e + ".");
                h = e
            }
        }), c.init = function() {
            void 0 !== this._events && this._events !== Object.getPrototypeOf(this)._events || (this._events = Object.create(null), this._eventsCount = 0), this._maxListeners = this._maxListeners || void 0
        }, c.prototype.setMaxListeners = function(e) {
            if ("number" !== typeof e || e < 0 || a(e)) throw new RangeError('The value of "n" is out of range. It must be a non-negative number. Received ' + e + ".");
            return this._maxListeners = e, this
        }, c.prototype.getMaxListeners = function() {
            return f(this)
        }, c.prototype.emit = function(e) {
            for (var t = [], n = 1; n < arguments.length; n++) t.push(arguments[n]);
            var r = "error" === e,
                i = this._events;
            if (void 0 !== i) r = r && void 0 === i.error;
            else if (!r) return !1;
            if (r) {
                var s;
                if (t.length > 0 && (s = t[0]), s instanceof Error) throw s;
                var a = new Error("Unhandled error." + (s ? " (" + s.message + ")" : ""));
                throw a.context = s, a
            }
            var c = i[e];
            if (void 0 === c) return !1;
            if ("function" === typeof c) o(c, this, t);
            else {
                var h = c.length,
                    u = y(c, h);
                for (n = 0; n < h; ++n) o(u[n], this, t)
            }
            return !0
        }, c.prototype.addListener = function(e, t) {
            return d(this, e, t, !1)
        }, c.prototype.on = c.prototype.addListener, c.prototype.prependListener = function(e, t) {
            return d(this, e, t, !0)
        }, c.prototype.once = function(e, t) {
            return u(t), this.on(e, p(this, e, t)), this
        }, c.prototype.prependOnceListener = function(e, t) {
            return u(t), this.prependListener(e, p(this, e, t)), this
        }, c.prototype.removeListener = function(e, t) {
            var n, r, i, o, s;
            if (u(t), r = this._events, void 0 === r) return this;
            if (n = r[e], void 0 === n) return this;
            if (n === t || n.listener === t) 0 === --this._eventsCount ? this._events = Object.create(null) : (delete r[e], r.removeListener && this.emit("removeListener", e, n.listener || t));
            else if ("function" !== typeof n) {
                for (i = -1, o = n.length - 1; o >= 0; o--)
                    if (n[o] === t || n[o].listener === t) {
                        s = n[o].listener, i = o;
                        break
                    }
                if (i < 0) return this;
                0 === i ? n.shift() : m(n, i), 1 === n.length && (r[e] = n[0]), void 0 !== r.removeListener && this.emit("removeListener", e, s || t)
            }
            return this
        }, c.prototype.off = c.prototype.removeListener, c.prototype.removeAllListeners = function(e) {
            var t, n, r;
            if (n = this._events, void 0 === n) return this;
            if (void 0 === n.removeListener) return 0 === arguments.length ? (this._events = Object.create(null), this._eventsCount = 0) : void 0 !== n[e] && (0 === --this._eventsCount ? this._events = Object.create(null) : delete n[e]), this;
            if (0 === arguments.length) {
                var i, o = Object.keys(n);
                for (r = 0; r < o.length; ++r) i = o[r], "removeListener" !== i && this.removeAllListeners(i);
                return this.removeAllListeners("removeListener"), this._events = Object.create(null), this._eventsCount = 0, this
            }
            if (t = n[e], "function" === typeof t) this.removeListener(e, t);
            else if (void 0 !== t)
                for (r = t.length - 1; r >= 0; r--) this.removeListener(e, t[r]);
            return this
        }, c.prototype.listeners = function(e) {
            return g(this, e, !0)
        }, c.prototype.rawListeners = function(e) {
            return g(this, e, !1)
        }, c.listenerCount = function(e, t) {
            return "function" === typeof e.listenerCount ? e.listenerCount(t) : _.call(e, t)
        }, c.prototype.listenerCount = _, c.prototype.eventNames = function() {
            return this._eventsCount > 0 ? r(this._events) : []
        }
    },
    fc6a: function(e, t, n) {
        var r = n("44ad"),
            i = n("1d80");
        e.exports = function(e) {
            return r(i(e))
        }
    },
    fdbf: function(e, t, n) {
        var r = n("4930");
        e.exports = r && !Symbol.sham && "symbol" == typeof Symbol.iterator
    },
    fe45: function(e, t) {
        const n = "2.0.0",
            r = 256,
            i = Number.MAX_SAFE_INTEGER || 9007199254740991,
            o = 16;
        e.exports = {
            SEMVER_SPEC_VERSION: n,
            MAX_LENGTH: r,
            MAX_SAFE_INTEGER: i,
            MAX_SAFE_COMPONENT_LENGTH: o
        }
    },
    ff0e: function(e, t, n) {
        (function(t) { /*! simple-concat. MIT License. Feross Aboukhadijeh <https://feross.org/opensource> */
            e.exports = function(e, n) {
                var r = [];
                e.on("data", (function(e) {
                    r.push(e)
                })), e.once("end", (function() {
                    n && n(null, t.concat(r)), n = null
                })), e.once("error", (function(e) {
                    n && n(e), n = null
                }))
            }
        }).call(this, n("b639").Buffer)
    }
});
//# sourceMappingURL=core.js.map