(window["arcWidgetJsonp"] = window["arcWidgetJsonp"] || []).push([
    ["chunk-2d2088b3"], {
        a4f0: function(t, e, n) {
            "use strict";
            n.r(e), n.d(e, "runSaturnBenchmarkInterval", (function() {
                return l
            })), n.d(e, "runBenchmark", (function() {
                return h
            }));
            var a = n("c64e"),
                r = n.n(a),
                s = n("8c32"),
                o = n("5de4");
            console.log;
            const c = "https://l1s.strn.pl",
                i = "https://ipfs.io",
                u = 5242880;
            async function l() {
                try {
                    const t = {
                            saturnOrigin: c,
                            untrustedSaturnOrigin: "https://rings.strn.pl",
                            benchmarkReportUrl: "https://afsocse35xksgf3rwwqpkzhzsi0ftpck.lambda-url.us-west-2.on.aws/",
                            logIngestorUrl: "https://twb3qukm2i654i3tnvx36char40aymqq.lambda-url.us-west-2.on.aws/",
                            raceSampleRate: .05,
                            loadSampleRate: .9,
                            untrustedLoadSampleRate: 0,
                            nocacheSampleRate: 0,
                            numLoadRequests: 2,
                            numUntrustedLoadRequests: 0
                        },
                        e = {
                            saturnOrigin: "https://l1s.strn-test.pl",
                            untrustedSaturnOrigin: null,
                            benchmarkReportUrl: "https://ynsnesy3xloaxx2dqiocs46vkm0ncoru.lambda-url.us-west-2.on.aws/",
                            logIngestorUrl: "https://p6wofrb2zgwrf26mcxjpprivie0lshfx.lambda-url.us-west-2.on.aws/",
                            raceSampleRate: .005,
                            loadSampleRate: .02,
                            untrustedLoadSampleRate: 0,
                            nocacheSampleRate: .15,
                            numLoadRequests: 1,
                            numUntrustedLoadRequests: 0
                        };
                    await h(t), await h(e)
                } catch (t) {} finally {
                    setTimeout(l, 6e4)
                }
            }
            async function d() {
                const {
                    cids: t
                } = await n.e("chunk-2d0cf2b3").then(n.t.bind(null, "6322", 3));
                try {
                    const e = "https://orchestrator.strn.pl/random-cids",
                        n = await Object(o["j"])(e).then(t => t.json());
                    return n.length ? n.map(t => ["/ipfs/" + t, 0]) : t
                } catch (e) {
                    return t
                }
            }
            async function h(t) {
                const e = await d();
                let n = [];
                Math.random() < t.raceSampleRate && (n = await f(t, e));
                const a = [];
                for (let o = 0; o < t.numLoadRequests; o++) Math.random() < t.loadSampleRate && (a.push(await m(t, e)), await Object(s["i"])(1e3));
                t.saturnOrigin === c && Math.random() < .5 && (a.push(await m(t, e)), await Object(s["i"])(1e3));
                for (let o = 0; o < t.numUntrustedLoadRequests; o++) {
                    const n = { ...t,
                        saturnOrigin: t.untrustedSaturnOrigin
                    };
                    Math.random() < n.untrustedLoadSampleRate && (a.push(await m(n, e)), await Object(s["i"])(1e3))
                }(n.length || a.length) && (await b(t, {
                    race: n,
                    load: a
                }), await y(t, n.concat(a)));
                const r = a.length && a.every(t => t.ifError || t.httpStatusCode >= 400);
                r && await Object(s["i"])(3e5)
            }
            async function f(t, e) {
                const {
                    cid: n,
                    cidPath: a
                } = R(e), r = "car";
                let s;
                return s = Math.random() > .5 ? [await p(n, a, r), await w(t, n, a, r)] : [await w(t, n, a, r), await p(n, a, r)], s
            }
            async function m(t, e) {
                const {
                    cid: n,
                    cidPath: a
                } = R(e), r = "car", s = await w(t, n, a, r);
                return s
            }

            function p(t, e, n) {
                const a = new URL(i + e);
                return g("ipfs", a, t, n)
            }

            function w(t, e, n, a) {
                const r = new URL(t.saturnOrigin + n);
                r.searchParams.set("clientId", k()), r.searchParams.set("car-scope", "file");
                const s = r.href.includes("saturn-test.network");
                return s && Math.random() < t.nocacheSampleRate && r.searchParams.set("nocache", 1), g("saturn", r, e, a)
            }
            async function g(t, e, n, a = null) {
                a && e.searchParams.set("format", a), e.searchParams.delete("filename");
                const r = {
                    service: t,
                    cid: n,
                    url: e,
                    httpStatusCode: null,
                    httpProtocol: null,
                    nodeId: null,
                    cacheStatus: null,
                    ttfb: null,
                    ttfbAfterDnsMs: null,
                    dnsTimeMs: null,
                    startTime: new Date,
                    endTime: null,
                    transferSize: null,
                    ifError: null
                };
                try {
                    var s;
                    const t = await fetch(e, {
                        cache: "no-store"
                    });
                    r.transferSize = 0;
                    for await (const e of I(t.body)) if (r.ttfb || (r.ttfb = new Date), r.transferSize += e.length, r.transferSize > u) break;
                    const {
                        headers: n
                    } = t;
                    r.httpStatusCode = t.status, r.cacheStatus = n.get("saturn-cache-status"), r.nodeId = null !== (s = n.get("saturn-node-id")) && void 0 !== s ? s : n.get("x-ipfs-pop"), r.transferId = n.get("saturn-transfer-id"), r.httpProtocol = n.get("quic-status")
                } catch (o) {
                    r.ifError = o.message
                } finally {
                    r.endTime = new Date
                }
                if (window.performance) {
                    const t = performance.getEntriesByType("resource").find(t => t.name === e.href);
                    if (t) {
                        const e = t.domainLookupStart,
                            n = t.domainLookupEnd,
                            a = n > 0 && e > 0;
                        a && (r.dnsTimeMs = Math.round(n - e), r.ttfbAfterDnsMs = Math.round(t.responseStart - t.requestStart)), null === r.httpProtocol && t.nextHopProtocol && (r.httpProtocol = t.nextHopProtocol)
                    }
                }
                return r
            }

            function S(t) {
                return {
                    nodeId: t.nodeId,
                    cacheHit: "HIT" === t.cacheStatus,
                    url: t.url,
                    localTime: t.startTime,
                    numBytesSent: t.transferSize,
                    range: null,
                    requestDuration: (t.endTime - t.startTime) / 1e3,
                    requestId: t.transferId,
                    httpStatusCode: t.httpStatusCode,
                    httpProtocol: t.httpProtocol,
                    ifNetworkError: t.ifError,
                    ttfbMs: t.ttfb ? t.ttfb - t.startTime : null
                }
            }
            async function b(t, {
                race: e = [],
                load: n = []
            }) {
                await fetch(t.benchmarkReportUrl, {
                    method: "POST",
                    body: JSON.stringify({
                        race: e,
                        load: n
                    })
                })
            }
            async function y(t, e) {
                const n = e.filter(t => "saturn" === t.service).map(S);
                n.length && await fetch(t.logIngestorUrl, {
                    method: "POST",
                    body: JSON.stringify({
                        bandwidthLogs: n
                    })
                })
            }

            function R(t) {
                var e;
                const n = [],
                    a = [];
                for (const [o, c] of t) n.push(o), a.push(c);
                const {
                    item: r
                } = P(n, a), s = null === (e = r.split("?")[0]) || void 0 === e ? void 0 : e.split("/")[2];
                return {
                    cid: s,
                    cidPath: r
                }
            }

            function k() {
                const t = "saturnClientId";
                let e = localStorage.getItem(t);
                return e || (e = r()(), localStorage.setItem(t, e)), e
            }
            async function* I(t, e = {}) {
                const n = t.getReader();
                try {
                    while (1) {
                        const t = await n.read();
                        if (t.done) return;
                        yield t.value
                    }
                } finally {
                    !0 !== e.preventCancel && n.cancel(), n.releaseLock()
                }
            }

            function P(t, e) {
                if (t.length !== e.length) throw new Error("Items and weights must be of the same size");
                if (!t.length) throw new Error("Items must not be empty");
                const n = [];
                for (let s = 0; s < e.length; s += 1) n[s] = e[s] + (n[s - 1] || 0);
                const a = n[n.length - 1],
                    r = a * Math.random();
                for (let s = 0; s < t.length; s += 1)
                    if (n[s] >= r) return {
                        item: t[s],
                        index: s
                    }
            }
        }
    }
]);
//# sourceMappingURL=chunk-2d2088b3.js.map?d7d4d404