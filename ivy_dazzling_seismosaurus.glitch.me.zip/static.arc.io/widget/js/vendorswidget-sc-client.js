(window["arcWidgetJsonp"] = window["arcWidgetJsonp"] || []).push([
    ["vendors~widget-sc-client"], {
        "11c1": function(t, e, n) {
            var r = n("c437"),
                s = n("c64e"),
                o = s;
            o.v1 = r, o.v4 = s, t.exports = o
        },
        1330: function(t, e, n) {
            const r = n("9925");
            class s extends r {
                constructor(t, e) {
                    super(), this.name = e, this._streamDemux = t
                }
                createConsumer(t) {
                    return this._streamDemux.createConsumer(this.name, t)
                }
            }
            t.exports = s
        },
        1674: function(t, e, n) {
            var r = n("8d40"),
                s = function() {
                    return !this
                }();

            function o(t, e) {
                this.name = "AuthTokenExpiredError", this.message = t, this.expiry = e, Error.captureStackTrace && !s ? Error.captureStackTrace(this, arguments.callee) : this.stack = (new Error).stack
            }

            function i(t) {
                this.name = "AuthTokenInvalidError", this.message = t, Error.captureStackTrace && !s ? Error.captureStackTrace(this, arguments.callee) : this.stack = (new Error).stack
            }

            function a(t, e) {
                this.name = "AuthTokenNotBeforeError", this.message = t, this.date = e, Error.captureStackTrace && !s ? Error.captureStackTrace(this, arguments.callee) : this.stack = (new Error).stack
            }

            function c(t) {
                this.name = "AuthTokenError", this.message = t, Error.captureStackTrace && !s ? Error.captureStackTrace(this, arguments.callee) : this.stack = (new Error).stack
            }

            function u(t) {
                this.name = "AuthError", this.message = t, Error.captureStackTrace && !s ? Error.captureStackTrace(this, arguments.callee) : this.stack = (new Error).stack
            }

            function h(t, e) {
                this.name = "SilentMiddlewareBlockedError", this.message = t, this.type = e, Error.captureStackTrace && !s ? Error.captureStackTrace(this, arguments.callee) : this.stack = (new Error).stack
            }

            function l(t) {
                this.name = "InvalidActionError", this.message = t, Error.captureStackTrace && !s ? Error.captureStackTrace(this, arguments.callee) : this.stack = (new Error).stack
            }

            function p(t) {
                this.name = "InvalidArgumentsError", this.message = t, Error.captureStackTrace && !s ? Error.captureStackTrace(this, arguments.callee) : this.stack = (new Error).stack
            }

            function d(t) {
                this.name = "InvalidOptionsError", this.message = t, Error.captureStackTrace && !s ? Error.captureStackTrace(this, arguments.callee) : this.stack = (new Error).stack
            }

            function m(t) {
                this.name = "InvalidMessageError", this.message = t, Error.captureStackTrace && !s ? Error.captureStackTrace(this, arguments.callee) : this.stack = (new Error).stack
            }

            function f(t, e) {
                this.name = "SocketProtocolError", this.message = t, this.code = e, Error.captureStackTrace && !s ? Error.captureStackTrace(this, arguments.callee) : this.stack = (new Error).stack
            }

            function y(t) {
                this.name = "ServerProtocolError", this.message = t, Error.captureStackTrace && !s ? Error.captureStackTrace(this, arguments.callee) : this.stack = (new Error).stack
            }

            function k(t) {
                this.name = "HTTPServerError", this.message = t, Error.captureStackTrace && !s ? Error.captureStackTrace(this, arguments.callee) : this.stack = (new Error).stack
            }

            function g(t) {
                this.name = "ResourceLimitError", this.message = t, Error.captureStackTrace && !s ? Error.captureStackTrace(this, arguments.callee) : this.stack = (new Error).stack
            }

            function _(t) {
                this.name = "TimeoutError", this.message = t, Error.captureStackTrace && !s ? Error.captureStackTrace(this, arguments.callee) : this.stack = (new Error).stack
            }

            function b(t, e) {
                this.name = "BadConnectionError", this.message = t, this.type = e, Error.captureStackTrace && !s ? Error.captureStackTrace(this, arguments.callee) : this.stack = (new Error).stack
            }

            function C(t) {
                this.name = "BrokerError", this.message = t, Error.captureStackTrace && !s ? Error.captureStackTrace(this, arguments.callee) : this.stack = (new Error).stack
            }

            function E(t, e) {
                this.name = "ProcessExitError", this.message = t, this.code = e, Error.captureStackTrace && !s ? Error.captureStackTrace(this, arguments.callee) : this.stack = (new Error).stack
            }

            function S(t) {
                this.name = "UnknownError", this.message = t, Error.captureStackTrace && !s ? Error.captureStackTrace(this, arguments.callee) : this.stack = (new Error).stack
            }
            o.prototype = Object.create(Error.prototype), i.prototype = Object.create(Error.prototype), a.prototype = Object.create(Error.prototype), c.prototype = Object.create(Error.prototype), u.prototype = Object.create(Error.prototype), h.prototype = Object.create(Error.prototype), l.prototype = Object.create(Error.prototype), p.prototype = Object.create(Error.prototype), d.prototype = Object.create(Error.prototype), m.prototype = Object.create(Error.prototype), f.prototype = Object.create(Error.prototype), y.prototype = Object.create(Error.prototype), k.prototype = Object.create(Error.prototype), g.prototype = Object.create(Error.prototype), _.prototype = Object.create(Error.prototype), b.prototype = Object.create(Error.prototype), C.prototype = Object.create(Error.prototype), E.prototype = Object.create(Error.prototype), S.prototype = Object.create(Error.prototype), t.exports = {
                AuthTokenExpiredError: o,
                AuthTokenInvalidError: i,
                AuthTokenNotBeforeError: a,
                AuthTokenError: c,
                AuthError: u,
                SilentMiddlewareBlockedError: h,
                InvalidActionError: l,
                InvalidArgumentsError: p,
                InvalidOptionsError: d,
                InvalidMessageError: m,
                SocketProtocolError: f,
                ServerProtocolError: y,
                HTTPServerError: k,
                ResourceLimitError: g,
                TimeoutError: _,
                BadConnectionError: b,
                BrokerError: C,
                ProcessExitError: E,
                UnknownError: S
            }, t.exports.socketProtocolErrorStatuses = {
                1001: "Socket was disconnected",
                1002: "A WebSocket protocol error was encountered",
                1003: "Server terminated socket because it received invalid data",
                1005: "Socket closed without status code",
                1006: "Socket hung up",
                1007: "Message format was incorrect",
                1008: "Encountered a policy violation",
                1009: "Message was too big to process",
                1010: "Client ended the connection because the server did not comply with extension requirements",
                1011: "Server encountered an unexpected fatal condition",
                4e3: "Server ping timed out",
                4001: "Client pong timed out",
                4002: "Server failed to sign auth token",
                4003: "Failed to complete handshake",
                4004: "Client failed to save auth token",
                4005: "Did not receive #handshake from client before timeout",
                4006: "Failed to bind socket to message broker",
                4007: "Client connection establishment timed out",
                4008: "Server rejected handshake from client",
                4009: "Server received a message before the client handshake"
            }, t.exports.socketProtocolIgnoreStatuses = {
                1e3: "Socket closed normally",
                1001: "Socket hung up"
            };
            var v = {
                domain: 1,
                domainEmitter: 1,
                domainThrown: 1
            };
            t.exports.dehydrateError = function(t, e) {
                var n;
                if (t && "object" === typeof t)
                    for (var s in n = {
                            message: t.message
                        }, e && (n.stack = t.stack), t) v[s] || (n[s] = t[s]);
                else n = "function" === typeof t ? "[function " + (t.name || "anonymous") + "]" : t;
                return r(n)
            }, t.exports.hydrateError = function(t) {
                var e = null;
                if (null != t)
                    if ("object" === typeof t)
                        for (var n in e = new Error(t.message), t) t.hasOwnProperty(n) && (e[n] = t[n]);
                    else e = t;
                return e
            }, t.exports.decycle = r
        },
        "48f9": function(t, e, n) {
            "use strict";
            t.exports = n("d153")
        },
        "4ceb": function(t, e, n) {
            (function(e) {
                function n() {
                    this._internalStorage = {}, this.isLocalStorageEnabled = this._checkLocalStorageEnabled()
                }
                n.prototype._checkLocalStorageEnabled = function() {
                    let t;
                    try {
                        e.localStorage, e.localStorage.setItem("__scLocalStorageTest", 1), e.localStorage.removeItem("__scLocalStorageTest")
                    } catch (n) {
                        t = n
                    }
                    return !t
                }, n.prototype.saveToken = function(t, n, r) {
                    return this.isLocalStorageEnabled && e.localStorage ? e.localStorage.setItem(t, n) : this._internalStorage[t] = n, Promise.resolve(n)
                }, n.prototype.removeToken = function(t) {
                    let n = this.loadToken(t);
                    return this.isLocalStorageEnabled && e.localStorage ? e.localStorage.removeItem(t) : delete this._internalStorage[t], n
                }, n.prototype.loadToken = function(t) {
                    let n;
                    return n = this.isLocalStorageEnabled && e.localStorage ? e.localStorage.getItem(t) : this._internalStorage[t] || null, Promise.resolve(n)
                }, t.exports = n
            }).call(this, n("c8ba"))
        },
        "50f0": function(t, e, n) {
            (function(e) {
                const r = n("c9fd"),
                    s = n("b383");
                let o, i;
                e.WebSocket ? (o = e.WebSocket, i = function(t, e) {
                    return new o(t)
                }) : (o = n("cbfb"), i = function(t, e) {
                    return new o(t, null, e)
                });
                const a = n("1674"),
                    c = a.TimeoutError,
                    u = a.BadConnectionError;

                function h(t, e, n, r, s) {
                    this.state = this.CLOSED, this.auth = t, this.codec = e, this.options = n, this.wsOptions = r, this.protocolVersion = n.protocolVersion, this.connectTimeout = n.connectTimeout, this.pingTimeout = n.pingTimeout, this.pingTimeoutDisabled = !!n.pingTimeoutDisabled, this.callIdGenerator = n.callIdGenerator, this.authTokenName = n.authTokenName, this.isBufferingBatch = !1, this._pingTimeoutTicker = null, this._callbackMap = {}, this._batchBuffer = [], s || (s = {}), this._onOpenHandler = s.onOpen || function() {}, this._onOpenAbortHandler = s.onOpenAbort || function() {}, this._onCloseHandler = s.onClose || function() {}, this._onEventHandler = s.onEvent || function() {}, this._onErrorHandler = s.onError || function() {}, this._onInboundInvokeHandler = s.onInboundInvoke || function() {}, this._onInboundTransmitHandler = s.onInboundTransmit || function() {}, this.state = this.CONNECTING;
                    let o = this.uri(),
                        a = i(o, r);
                    a.binaryType = this.options.binaryType, this.socket = a, a.onopen = () => {
                        this._onOpen()
                    }, a.onclose = async t => {
                        let e;
                        e = null == t.code ? 1005 : t.code, this._destroy(e, t.reason)
                    }, a.onmessage = (t, e) => {
                        this._onMessage(t.data)
                    }, a.onerror = t => {
                        this.state === this.CONNECTING && this._destroy(1006)
                    }, this._connectTimeoutRef = setTimeout(() => {
                        this._destroy(4007), this.socket.close(4007)
                    }, this.connectTimeout), 1 === this.protocolVersion ? this._handlePing = t => "#1" === t && (this._resetPingTimeout(), this.socket.readyState === this.socket.OPEN && this.send("#2"), !0) : this._handlePing = t => "" === t && (this._resetPingTimeout(), this.socket.readyState === this.socket.OPEN && this.send(""), !0)
                }
                h.CONNECTING = h.prototype.CONNECTING = "connecting", h.OPEN = h.prototype.OPEN = "open", h.CLOSED = h.prototype.CLOSED = "closed", h.prototype.uri = function() {
                    let t, e, n, r = this.options.query || {};
                    if (t = null == this.options.protocolScheme ? this.options.secure ? "wss" : "ws" : this.options.protocolScheme, this.options.timestampRequests && (r[this.options.timestampParam] = (new Date).getTime()), r = s.encode(r), r.length && (r = "?" + r), null == this.options.socketPath) {
                        if (this.options.host) e = this.options.host;
                        else {
                            let n = "";
                            this.options.port && ("wss" === t && 443 !== this.options.port || "ws" === t && 80 !== this.options.port) && (n = ":" + this.options.port), e = this.options.hostname + n
                        }
                        n = this.options.path
                    } else e = this.options.socketPath, n = ":" + this.options.path;
                    return t + "://" + e + n + r
                }, h.prototype._onOpen = async function() {
                    let t;
                    clearTimeout(this._connectTimeoutRef), this._resetPingTimeout();
                    try {
                        t = await this._handshake()
                    } catch (e) {
                        return null == e.statusCode && (e.statusCode = 4003), this._onError(e), this._destroy(e.statusCode, e.toString()), void this.socket.close(e.statusCode)
                    }
                    this.state = this.OPEN, t && (this.pingTimeout = t.pingTimeout), this._resetPingTimeout(), this._onOpenHandler(t)
                }, h.prototype._handshake = async function() {
                    let t = await this.auth.loadToken(this.authTokenName),
                        e = {
                            force: !0
                        },
                        n = await this.invoke("#handshake", {
                            authToken: t
                        }, e);
                    return n && (n.authToken = t, n.authError && (n.authError = a.hydrateError(n.authError))), n
                }, h.prototype._abortAllPendingEventsDueToBadConnection = function(t) {
                    Object.keys(this._callbackMap || {}).forEach(e => {
                        let n = this._callbackMap[e];
                        delete this._callbackMap[e], clearTimeout(n.timeout), delete n.timeout;
                        let r = `Event "${n.event}" was aborted due to a bad connection`,
                            s = new u(r, t),
                            o = n.callback;
                        o && (delete n.callback, o.call(n, s, n))
                    })
                }, h.prototype._destroy = function(t, e) {
                    a.socketProtocolErrorStatuses[t];
                    !e && a.socketProtocolErrorStatuses[t] && (e = a.socketProtocolErrorStatuses[t]), delete this.socket.onopen, delete this.socket.onclose, delete this.socket.onmessage, delete this.socket.onerror, clearTimeout(this._connectTimeoutRef), clearTimeout(this._pingTimeoutTicker), this.state === this.OPEN ? (this.state = this.CLOSED, this._abortAllPendingEventsDueToBadConnection("disconnect"), this._onCloseHandler({
                        code: t,
                        reason: e
                    })) : this.state === this.CONNECTING ? (this.state = this.CLOSED, this._abortAllPendingEventsDueToBadConnection("connectAbort"), this._onOpenAbortHandler({
                        code: t,
                        reason: e
                    })) : this.state === this.CLOSED && this._abortAllPendingEventsDueToBadConnection("connectAbort")
                }, h.prototype._processInboundPacket = function(t, e) {
                    if (t && null != t.event)
                        if (null == t.cid) this._onInboundTransmitHandler({ ...t
                        });
                        else {
                            let e = new r(this, t.cid, t.event, t.data);
                            this._onInboundInvokeHandler(e)
                        }
                    else if (t && null != t.rid) {
                        let e = this._callbackMap[t.rid];
                        if (e && (clearTimeout(e.timeout), delete e.timeout, delete this._callbackMap[t.rid], e.callback)) {
                            let n = a.hydrateError(t.error);
                            e.callback(n, t.data)
                        }
                    } else this._onEventHandler({
                        event: "raw",
                        data: {
                            message: e
                        }
                    })
                }, h.prototype._onMessage = function(t) {
                    if (this._onEventHandler({
                            event: "message",
                            data: {
                                message: t
                            }
                        }), this._handlePing(t)) return;
                    let e = this.decode(t);
                    if (Array.isArray(e)) {
                        let n = e.length;
                        for (let r = 0; r < n; r++) this._processInboundPacket(e[r], t)
                    } else this._processInboundPacket(e, t)
                }, h.prototype._onError = function(t) {
                    this._onErrorHandler({
                        error: t
                    })
                }, h.prototype._resetPingTimeout = function() {
                    if (this.pingTimeoutDisabled) return;
                    (new Date).getTime();
                    clearTimeout(this._pingTimeoutTicker), this._pingTimeoutTicker = setTimeout(() => {
                        this._destroy(4e3), this.socket.close(4e3)
                    }, this.pingTimeout)
                }, h.prototype.clearAllListeners = function() {
                    this._onOpenHandler = function() {}, this._onOpenAbortHandler = function() {}, this._onCloseHandler = function() {}, this._onEventHandler = function() {}, this._onErrorHandler = function() {}, this._onInboundInvokeHandler = function() {}, this._onInboundTransmitHandler = function() {}
                }, h.prototype.startBatch = function() {
                    this.isBufferingBatch = !0, this._batchBuffer = []
                }, h.prototype.flushBatch = function() {
                    if (this.isBufferingBatch = !1, !this._batchBuffer.length) return;
                    let t = this.serializeObject(this._batchBuffer);
                    this._batchBuffer = [], this.send(t)
                }, h.prototype.cancelBatch = function() {
                    this.isBufferingBatch = !1, this._batchBuffer = []
                }, h.prototype.getBytesReceived = function() {
                    return this.socket.bytesReceived
                }, h.prototype.close = function(t, e) {
                    this.state !== this.OPEN && this.state !== this.CONNECTING || (t = t || 1e3, this._destroy(t, e), this.socket.close(t, e))
                }, h.prototype.transmitObject = function(t) {
                    let e = {
                        event: t.event,
                        data: t.data
                    };
                    return t.callback && (e.cid = t.cid = this.callIdGenerator(), this._callbackMap[t.cid] = t), this.sendObject(e), t.cid || null
                }, h.prototype._handleEventAckTimeout = function(t) {
                    t.cid && delete this._callbackMap[t.cid], delete t.timeout;
                    let e = t.callback;
                    if (e) {
                        delete t.callback;
                        let n = new c(`Event response for "${t.event}" timed out`);
                        e.call(t, n, t)
                    }
                }, h.prototype.transmit = function(t, e, n) {
                    let r = {
                        event: t,
                        data: e
                    };
                    return (this.state === this.OPEN || n.force) && this.transmitObject(r), Promise.resolve()
                }, h.prototype.invokeRaw = function(t, e, n, r) {
                    let s = {
                        event: t,
                        data: e,
                        callback: r
                    };
                    n.noTimeout || (s.timeout = setTimeout(() => {
                        this._handleEventAckTimeout(s)
                    }, this.options.ackTimeout));
                    let o = null;
                    return (this.state === this.OPEN || n.force) && (o = this.transmitObject(s)), o
                }, h.prototype.invoke = function(t, e, n) {
                    return new Promise((r, s) => {
                        this.invokeRaw(t, e, n, (t, e) => {
                            t ? s(t) : r(e)
                        })
                    })
                }, h.prototype.cancelPendingResponse = function(t) {
                    delete this._callbackMap[t]
                }, h.prototype.decode = function(t) {
                    return this.codec.decode(t)
                }, h.prototype.encode = function(t) {
                    return this.codec.encode(t)
                }, h.prototype.send = function(t) {
                    this.socket.readyState !== this.socket.OPEN ? this._destroy(1005) : this.socket.send(t)
                }, h.prototype.serializeObject = function(t) {
                    let e;
                    try {
                        e = this.encode(t)
                    } catch (n) {
                        return this._onError(n), null
                    }
                    return e
                }, h.prototype.sendObject = function(t) {
                    if (this.isBufferingBatch) return void this._batchBuffer.push(t);
                    let e = this.serializeObject(t);
                    null != e && this.send(e)
                }, t.exports = h
            }).call(this, n("c8ba"))
        },
        "513f": function(t, e, n) {
            (function(e) {
                var n = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
                    r = /^[ \n\r\t]*[{\[]/,
                    s = function(t) {
                        for (var e = new Uint8Array(t), r = e.length, s = "", o = 0; o < r; o += 3) s += n[e[o] >> 2], s += n[(3 & e[o]) << 4 | e[o + 1] >> 4], s += n[(15 & e[o + 1]) << 2 | e[o + 2] >> 6], s += n[63 & e[o + 2]];
                        return r % 3 === 2 ? s = s.substring(0, s.length - 1) + "=" : r % 3 === 1 && (s = s.substring(0, s.length - 2) + "=="), s
                    },
                    o = function(t, n) {
                        if (e.ArrayBuffer && n instanceof e.ArrayBuffer) return {
                            base64: !0,
                            data: s(n)
                        };
                        if (e.Buffer) {
                            if (n instanceof e.Buffer) return {
                                base64: !0,
                                data: n.toString("base64")
                            };
                            var r;
                            if (n && "Buffer" === n.type && Array.isArray(n.data)) return r = e.Buffer.from ? e.Buffer.from(n.data) : new e.Buffer(n.data), {
                                base64: !0,
                                data: r.toString("base64")
                            }
                        }
                        return n
                    };
                t.exports.decode = function(t) {
                    if (null == t) return null;
                    if ("#1" === t || "#2" === t) return t;
                    var e = t.toString();
                    if (!r.test(e)) return e;
                    try {
                        return JSON.parse(e)
                    } catch (n) {}
                    return e
                }, t.exports.encode = function(t) {
                    return "#1" === t || "#2" === t ? t : JSON.stringify(t, o)
                }
            }).call(this, n("c8ba"))
        },
        "52f6": function(t, e, n) {
            "use strict";
            (function(e) {
                /*!
                 * shallow-clone <https://github.com/jonschlinkert/shallow-clone>
                 *
                 * Copyright (c) 2015-present, Jon Schlinkert.
                 * Released under the MIT License.
                 */
                const r = Symbol.prototype.valueOf,
                    s = n("ef5d");

                function o(t, e) {
                    switch (s(t)) {
                        case "array":
                            return t.slice();
                        case "object":
                            return Object.assign({}, t);
                        case "date":
                            return new t.constructor(Number(t));
                        case "map":
                            return new Map(t);
                        case "set":
                            return new Set(t);
                        case "buffer":
                            return u(t);
                        case "symbol":
                            return h(t);
                        case "arraybuffer":
                            return a(t);
                        case "float32array":
                        case "float64array":
                        case "int16array":
                        case "int32array":
                        case "int8array":
                        case "uint16array":
                        case "uint32array":
                        case "uint8clampedarray":
                        case "uint8array":
                            return c(t);
                        case "regexp":
                            return i(t);
                        case "error":
                            return Object.create(t);
                        default:
                            return t
                    }
                }

                function i(t) {
                    const e = void 0 !== t.flags ? t.flags : /\w+$/.exec(t) || void 0,
                        n = new t.constructor(t.source, e);
                    return n.lastIndex = t.lastIndex, n
                }

                function a(t) {
                    const e = new t.constructor(t.byteLength);
                    return new Uint8Array(e).set(new Uint8Array(t)), e
                }

                function c(t, e) {
                    return new t.constructor(t.buffer, t.byteOffset, t.length)
                }

                function u(t) {
                    const n = t.length,
                        r = e.allocUnsafe ? e.allocUnsafe(n) : e.from(n);
                    return t.copy(r), r
                }

                function h(t) {
                    return r ? Object(r.call(t)) : {}
                }
                t.exports = o
            }).call(this, n("b639").Buffer)
        },
        "5fa9": function(t, e, n) {
            const r = n("9925");
            class s extends r {
                constructor(t, e, n, r) {
                    super(), this.PENDING = s.PENDING, this.SUBSCRIBED = s.SUBSCRIBED, this.UNSUBSCRIBED = s.UNSUBSCRIBED, this.name = t, this.client = e, this._eventDemux = n, this._dataStream = r.stream(this.name)
                }
                createConsumer(t) {
                    return this._dataStream.createConsumer(t)
                }
                listener(t) {
                    return this._eventDemux.stream(`${this.name}/${t}`)
                }
                close() {
                    this.client.closeChannel(this.name)
                }
                kill() {
                    this.client.killChannel(this.name)
                }
                killOutputConsumer(t) {
                    this.hasOutputConsumer(t) && this.client.killChannelOutputConsumer(t)
                }
                killListenerConsumer(t) {
                    this.hasAnyListenerConsumer(t) && this.client.killChannelListenerConsumer(t)
                }
                getOutputConsumerStats(t) {
                    if (this.hasOutputConsumer(t)) return this.client.getChannelOutputConsumerStats(t)
                }
                getListenerConsumerStats(t) {
                    if (this.hasAnyListenerConsumer(t)) return this.client.getChannelListenerConsumerStats(t)
                }
                getBackpressure() {
                    return this.client.getChannelBackpressure(this.name)
                }
                getListenerConsumerBackpressure(t) {
                    return this.hasAnyListenerConsumer(t) ? this.client.getChannelListenerConsumerBackpressure(t) : 0
                }
                getOutputConsumerBackpressure(t) {
                    return this.hasOutputConsumer(t) ? this.client.getChannelOutputConsumerBackpressure(t) : 0
                }
                closeOutput() {
                    this.client.channelCloseOutput(this.name)
                }
                closeListener(t) {
                    this.client.channelCloseListener(this.name, t)
                }
                closeAllListeners() {
                    this.client.channelCloseAllListeners(this.name)
                }
                killOutput() {
                    this.client.channelKillOutput(this.name)
                }
                killListener(t) {
                    this.client.channelKillListener(this.name, t)
                }
                killAllListeners() {
                    this.client.channelKillAllListeners(this.name)
                }
                getOutputConsumerStatsList() {
                    return this.client.channelGetOutputConsumerStatsList(this.name)
                }
                getListenerConsumerStatsList(t) {
                    return this.client.channelGetListenerConsumerStatsList(this.name, t)
                }
                getAllListenersConsumerStatsList() {
                    return this.client.channelGetAllListenersConsumerStatsList(this.name)
                }
                getOutputBackpressure() {
                    return this.client.channelGetOutputBackpressure(this.name)
                }
                getListenerBackpressure(t) {
                    return this.client.channelGetListenerBackpressure(this.name, t)
                }
                getAllListenersBackpressure() {
                    return this.client.channelGetAllListenersBackpressure(this.name)
                }
                hasOutputConsumer(t) {
                    return this.client.channelHasOutputConsumer(this.name, t)
                }
                hasListenerConsumer(t, e) {
                    return this.client.channelHasListenerConsumer(this.name, t, e)
                }
                hasAnyListenerConsumer(t) {
                    return this.client.channelHasAnyListenerConsumer(this.name, t)
                }
                get state() {
                    return this.client.getChannelState(this.name)
                }
                set state(t) {
                    throw new Error("Cannot directly set channel state")
                }
                get options() {
                    return this.client.getChannelOptions(this.name)
                }
                set options(t) {
                    throw new Error("Cannot directly set channel options")
                }
                subscribe(t) {
                    this.client.subscribe(this.name, t)
                }
                unsubscribe() {
                    this.client.unsubscribe(this.name)
                }
                isSubscribed(t) {
                    return this.client.isSubscribed(this.name, t)
                }
                transmitPublish(t) {
                    return this.client.transmitPublish(this.name, t)
                }
                invokePublish(t) {
                    return this.client.invokePublish(this.name, t)
                }
            }
            s.PENDING = "pending", s.SUBSCRIBED = "subscribed", s.UNSUBSCRIBED = "unsubscribed", t.exports = s
        },
        "638e": function(t, e, n) {
            (function(e) {
                const r = n("89b6"),
                    s = n("bd04"),
                    o = n("5fa9"),
                    i = n("4ceb"),
                    a = n("513f"),
                    c = n("50f0"),
                    u = n("b383"),
                    h = n("48f9"),
                    l = n("9675"),
                    p = n("b639").Buffer,
                    d = n("c73f"),
                    m = n("1674"),
                    f = m.InvalidArgumentsError,
                    y = m.InvalidMessageError,
                    k = (m.InvalidActionError, m.SocketProtocolError),
                    g = m.TimeoutError,
                    _ = m.BadConnectionError,
                    b = "undefined" !== typeof window;

                function C(t) {
                    s.call(this);
                    let n = {
                            path: "/socketcluster/",
                            secure: !1,
                            protocolScheme: null,
                            socketPath: null,
                            autoConnect: !0,
                            autoReconnect: !0,
                            autoSubscribeOnConnect: !0,
                            connectTimeout: 2e4,
                            ackTimeout: 1e4,
                            timestampRequests: !1,
                            timestampParam: "t",
                            authTokenName: "socketcluster.authToken",
                            binaryType: "arraybuffer",
                            batchOnHandshake: !1,
                            batchOnHandshakeDuration: 100,
                            batchInterval: 50,
                            protocolVersion: 2,
                            wsOptions: {},
                            cloneData: !1
                        },
                        o = Object.assign(n, t);
                    this.id = null, this.version = o.version || null, this.protocolVersion = o.protocolVersion, this.state = this.CLOSED, this.authState = this.UNAUTHENTICATED, this.signedAuthToken = null, this.authToken = null, this.pendingReconnect = !1, this.pendingReconnectTimeout = null, this.preparingPendingSubscriptions = !1, this.clientId = o.clientId, this.wsOptions = o.wsOptions, this.connectTimeout = o.connectTimeout, this.ackTimeout = o.ackTimeout, this.channelPrefix = o.channelPrefix || null, this.disconnectOnUnload = null == o.disconnectOnUnload || o.disconnectOnUnload, this.authTokenName = o.authTokenName, o.pingTimeout = o.connectTimeout, this.pingTimeout = o.pingTimeout, this.pingTimeoutDisabled = !!o.pingTimeoutDisabled;
                    let c = Math.pow(2, 31) - 1,
                        l = t => {
                            if (this[t] > c) throw new f(`The ${t} value provided exceeded the maximum amount allowed`)
                        };
                    if (l("connectTimeout"), l("ackTimeout"), l("pingTimeout"), this.connectAttempts = 0, this.isBatching = !1, this.batchOnHandshake = o.batchOnHandshake, this.batchOnHandshakeDuration = o.batchOnHandshakeDuration, this._batchingIntervalId = null, this._outboundBuffer = new h, this._channelMap = {}, this._channelEventDemux = new r, this._channelDataDemux = new r, this._receiverDemux = new r, this._procedureDemux = new r, this.options = o, this._cid = 1, this.options.callIdGenerator = () => this._cid++, this.options.autoReconnect) {
                        null == this.options.autoReconnectOptions && (this.options.autoReconnectOptions = {});
                        let t = this.options.autoReconnectOptions;
                        null == t.initialDelay && (t.initialDelay = 1e4), null == t.randomness && (t.randomness = 1e4), null == t.multiplier && (t.multiplier = 1.5), null == t.maxDelay && (t.maxDelay = 6e4)
                    }
                    if (null == this.options.subscriptionRetryOptions && (this.options.subscriptionRetryOptions = {}), this.options.authEngine ? this.auth = this.options.authEngine : this.auth = new i, this.options.codecEngine ? this.codec = this.options.codecEngine : this.codec = a, this.options.protocol) {
                        let t = new f('The "protocol" option does not affect socketcluster-client - If you want to utilize SSL/TLS, use "secure" option instead');
                        this._onError(t)
                    }
                    this.options.query = o.query || {}, "string" === typeof this.options.query && (this.options.query = u.parse(this.options.query)), b && this.disconnectOnUnload && e.addEventListener && e.removeEventListener && this._handleBrowserUnload(), this.options.autoConnect && this.connect()
                }
                C.prototype = Object.create(s.prototype), C.CONNECTING = C.prototype.CONNECTING = c.prototype.CONNECTING, C.OPEN = C.prototype.OPEN = c.prototype.OPEN, C.CLOSED = C.prototype.CLOSED = c.prototype.CLOSED, C.AUTHENTICATED = C.prototype.AUTHENTICATED = "authenticated", C.UNAUTHENTICATED = C.prototype.UNAUTHENTICATED = "unauthenticated", C.SUBSCRIBED = C.prototype.SUBSCRIBED = o.SUBSCRIBED, C.PENDING = C.prototype.PENDING = o.PENDING, C.UNSUBSCRIBED = C.prototype.UNSUBSCRIBED = o.UNSUBSCRIBED, C.ignoreStatuses = m.socketProtocolIgnoreStatuses, C.errorStatuses = m.socketProtocolErrorStatuses, Object.defineProperty(C.prototype, "isBufferingBatch", {
                    get: function() {
                        return this.transport.isBufferingBatch
                    }
                }), C.prototype.getBackpressure = function() {
                    return Math.max(this.getAllListenersBackpressure(), this.getAllReceiversBackpressure(), this.getAllProceduresBackpressure(), this.getAllChannelsBackpressure())
                }, C.prototype._handleBrowserUnload = async function() {
                    let t = () => {
                            this.disconnect()
                        },
                        n = !1,
                        r = () => {
                            n || (n = !0, e.addEventListener("beforeunload", t, !1))
                        },
                        s = () => {
                            n && (n = !1, e.removeEventListener("beforeunload", t, !1))
                        };
                    (async () => {
                        let t = this.listener("connecting").createConsumer();
                        while (1) {
                            let e = await t.next();
                            if (e.done) break;
                            r()
                        }
                    })(), (async () => {
                        let t = this.listener("close").createConsumer();
                        while (1) {
                            let e = await t.next();
                            if (e.done) break;
                            s()
                        }
                    })()
                }, C.prototype._setAuthToken = function(t) {
                    this._changeToAuthenticatedState(t.token), (async () => {
                        try {
                            await this.auth.saveToken(this.authTokenName, t.token, {})
                        } catch (e) {
                            this._onError(e)
                        }
                    })()
                }, C.prototype._removeAuthToken = function(t) {
                    (async () => {
                        let t;
                        try {
                            t = await this.auth.removeToken(this.authTokenName)
                        } catch (e) {
                            return void this._onError(e)
                        }
                        this.emit("removeAuthToken", {
                            oldAuthToken: t
                        })
                    })(), this._changeToUnauthenticatedStateAndClearTokens()
                }, C.prototype._privateDataHandlerMap = {
                    "#publish": function(t) {
                        let e = this._undecorateChannelName(t.channel),
                            n = this.isSubscribed(e, !0);
                        n && this._channelDataDemux.write(e, t.data)
                    },
                    "#kickOut": function(t) {
                        let e = this._undecorateChannelName(t.channel),
                            n = this._channelMap[e];
                        n && (this.emit("kickOut", {
                            channel: e,
                            message: t.message
                        }), this._channelEventDemux.write(e + "/kickOut", {
                            message: t.message
                        }), this._triggerChannelUnsubscribe(n))
                    },
                    "#setAuthToken": function(t) {
                        t && this._setAuthToken(t)
                    },
                    "#removeAuthToken": function(t) {
                        this._removeAuthToken(t)
                    }
                }, C.prototype._privateRPCHandlerMap = {
                    "#setAuthToken": function(t, e) {
                        t ? (this._setAuthToken(t), e.end()) : e.error(new y("No token data provided by #setAuthToken event"))
                    },
                    "#removeAuthToken": function(t, e) {
                        this._removeAuthToken(t), e.end()
                    }
                }, C.prototype.getState = function() {
                    return this.state
                }, C.prototype.getBytesReceived = function() {
                    return this.transport.getBytesReceived()
                }, C.prototype.deauthenticate = async function() {
                    (async () => {
                        let t;
                        try {
                            t = await this.auth.removeToken(this.authTokenName)
                        } catch (e) {
                            return void this._onError(e)
                        }
                        this.emit("removeAuthToken", {
                            oldAuthToken: t
                        })
                    })(), this.state !== this.CLOSED && this.transmit("#removeAuthToken"), this._changeToUnauthenticatedStateAndClearTokens(), await d(0)
                }, C.prototype.connect = function() {
                    if (this.state === this.CLOSED) {
                        this.pendingReconnect = !1, this.pendingReconnectTimeout = null, clearTimeout(this._reconnectTimeoutRef), this.state = this.CONNECTING, this.emit("connecting", {}), this.transport && this.transport.clearAllListeners();
                        let t = {
                            onOpen: t => {
                                this.state = this.OPEN, this._onOpen(t)
                            },
                            onOpenAbort: t => {
                                this.state !== this.CLOSED && (this.state = this.CLOSED, this._destroy(t.code, t.reason, !0))
                            },
                            onClose: t => {
                                this.state !== this.CLOSED && (this.state = this.CLOSED, this._destroy(t.code, t.reason))
                            },
                            onEvent: t => {
                                this.emit(t.event, t.data)
                            },
                            onError: t => {
                                this._onError(t.error)
                            },
                            onInboundInvoke: t => {
                                this._onInboundInvoke(t)
                            },
                            onInboundTransmit: t => {
                                this._onInboundTransmit(t.event, t.data)
                            }
                        };
                        this.transport = new c(this.auth, this.codec, this.options, this.wsOptions, t)
                    }
                }, C.prototype.reconnect = function(t, e) {
                    this.disconnect(t, e), this.connect()
                }, C.prototype.disconnect = function(t, e) {
                    if (t = t || 1e3, "number" !== typeof t) throw new f("If specified, the code argument must be a number");
                    let n = this.state === this.CONNECTING;
                    n || this.state === this.OPEN ? (this.state = this.CLOSED, this._destroy(t, e, n), this.transport.close(t, e)) : (this.pendingReconnect = !1, this.pendingReconnectTimeout = null, clearTimeout(this._reconnectTimeoutRef))
                }, C.prototype._changeToUnauthenticatedStateAndClearTokens = function() {
                    if (this.authState !== this.UNAUTHENTICATED) {
                        let t = this.authState,
                            e = this.authToken,
                            n = this.signedAuthToken;
                        this.authState = this.UNAUTHENTICATED, this.signedAuthToken = null, this.authToken = null;
                        let r = {
                            oldAuthState: t,
                            newAuthState: this.authState
                        };
                        this.emit("authStateChange", r), this.emit("deauthenticate", {
                            oldSignedAuthToken: n,
                            oldAuthToken: e
                        })
                    }
                }, C.prototype._changeToAuthenticatedState = function(t) {
                    if (this.signedAuthToken = t, this.authToken = this._extractAuthTokenData(t), this.authState !== this.AUTHENTICATED) {
                        let e = this.authState;
                        this.authState = this.AUTHENTICATED;
                        let n = {
                            oldAuthState: e,
                            newAuthState: this.authState,
                            signedAuthToken: t,
                            authToken: this.authToken
                        };
                        this.preparingPendingSubscriptions || this.processPendingSubscriptions(), this.emit("authStateChange", n)
                    }
                    this.emit("authenticate", {
                        signedAuthToken: t,
                        authToken: this.authToken
                    })
                }, C.prototype.decodeBase64 = function(t) {
                    return p.from(t, "base64").toString("utf8")
                }, C.prototype.encodeBase64 = function(t) {
                    return p.from(t, "utf8").toString("base64")
                }, C.prototype._extractAuthTokenData = function(t) {
                    let e = (t || "").split("."),
                        n = e[1];
                    if (null != n) {
                        let t = n;
                        try {
                            return t = this.decodeBase64(t), JSON.parse(t)
                        } catch (r) {
                            return t
                        }
                    }
                    return null
                }, C.prototype.getAuthToken = function() {
                    return this.authToken
                }, C.prototype.getSignedAuthToken = function() {
                    return this.signedAuthToken
                }, C.prototype.authenticate = async function(t) {
                    let e;
                    try {
                        e = await this.invoke("#authenticate", t)
                    } catch (n) {
                        throw "BadConnectionError" !== n.name && "TimeoutError" !== n.name && this._changeToUnauthenticatedStateAndClearTokens(), await d(0), n
                    }
                    return e && null != e.isAuthenticated ? e.authError && (e.authError = m.hydrateError(e.authError)) : e = {
                        isAuthenticated: this.authState,
                        authError: null
                    }, e.isAuthenticated ? this._changeToAuthenticatedState(t) : this._changeToUnauthenticatedStateAndClearTokens(), (async () => {
                        try {
                            await this.auth.saveToken(this.authTokenName, t, {})
                        } catch (n) {
                            this._onError(n)
                        }
                    })(), await d(0), e
                }, C.prototype._tryReconnect = function(t) {
                    let e, n = this.connectAttempts++,
                        r = this.options.autoReconnectOptions;
                    if (null == t || n > 0) {
                        let t = Math.round(r.initialDelay + (r.randomness || 0) * Math.random());
                        e = Math.round(t * Math.pow(r.multiplier, n))
                    } else e = t;
                    e > r.maxDelay && (e = r.maxDelay), clearTimeout(this._reconnectTimeoutRef), this.pendingReconnect = !0, this.pendingReconnectTimeout = e, this._reconnectTimeoutRef = setTimeout(() => {
                        this.connect()
                    }, e)
                }, C.prototype._onOpen = function(t) {
                    this.isBatching ? this._startBatching() : this.batchOnHandshake && (this._startBatching(), setTimeout(() => {
                        this.isBatching || this._stopBatching()
                    }, this.batchOnHandshakeDuration)), this.preparingPendingSubscriptions = !0, t ? (this.id = t.id, this.pingTimeout = t.pingTimeout, t.isAuthenticated ? this._changeToAuthenticatedState(t.authToken) : this._changeToUnauthenticatedStateAndClearTokens()) : this._changeToUnauthenticatedStateAndClearTokens(), this.connectAttempts = 0, this.options.autoSubscribeOnConnect && this.processPendingSubscriptions(), this.emit("connect", { ...t,
                        processPendingSubscriptions: () => {
                            this.processPendingSubscriptions()
                        }
                    }), this.state === this.OPEN && this._flushOutboundBuffer()
                }, C.prototype._onError = function(t) {
                    this.emit("error", {
                        error: t
                    })
                }, C.prototype._suspendSubscriptions = function() {
                    Object.keys(this._channelMap).forEach(t => {
                        let e = this._channelMap[t];
                        this._triggerChannelUnsubscribe(e, !0)
                    })
                }, C.prototype._abortAllPendingEventsDueToBadConnection = function(t) {
                    let e, n = this._outboundBuffer.head;
                    while (n) {
                        e = n.next;
                        let r = n.data;
                        clearTimeout(r.timeout), delete r.timeout, n.detach(), n = e;
                        let s = r.callback;
                        if (s) {
                            delete r.callback;
                            let e = `Event "${r.event}" was aborted due to a bad connection`,
                                n = new _(e, t);
                            s.call(r, n, r)
                        }
                        r.cid && this.transport.cancelPendingResponse(r.cid)
                    }
                }, C.prototype._destroy = function(t, e, n) {
                    if (this.id = null, this._cancelBatching(), this.transport && this.transport.clearAllListeners(), this.pendingReconnect = !1, this.pendingReconnectTimeout = null, clearTimeout(this._reconnectTimeoutRef), this._suspendSubscriptions(), n ? this.emit("connectAbort", {
                            code: t,
                            reason: e
                        }) : this.emit("disconnect", {
                            code: t,
                            reason: e
                        }), this.emit("close", {
                            code: t,
                            reason: e
                        }), !C.ignoreStatuses[t]) {
                        let n;
                        n = e ? "Socket connection closed with status code " + t + " and reason: " + e : "Socket connection closed with status code " + t;
                        let r = new k(C.errorStatuses[t] || n, t);
                        this._onError(r)
                    }
                    this._abortAllPendingEventsDueToBadConnection(n ? "connectAbort" : "disconnect"), this.options.autoReconnect && (4e3 === t || 4001 === t || 1005 === t ? this._tryReconnect(0) : 1e3 !== t && t < 4500 && this._tryReconnect())
                }, C.prototype._onInboundTransmit = function(t, e) {
                    let n = this._privateDataHandlerMap[t];
                    n ? n.call(this, e) : this._receiverDemux.write(t, e)
                }, C.prototype._onInboundInvoke = function(t) {
                    let {
                        procedure: e,
                        data: n
                    } = t, r = this._privateRPCHandlerMap[e];
                    r ? r.call(this, n, t) : this._procedureDemux.write(e, t)
                }, C.prototype.decode = function(t) {
                    return this.transport.decode(t)
                }, C.prototype.encode = function(t) {
                    return this.transport.encode(t)
                }, C.prototype._flushOutboundBuffer = function() {
                    let t, e = this._outboundBuffer.head;
                    while (e) {
                        t = e.next;
                        let n = e.data;
                        e.detach(), this.transport.transmitObject(n), e = t
                    }
                }, C.prototype._handleEventAckTimeout = function(t, e) {
                    e && e.detach(), delete t.timeout;
                    let n = t.callback;
                    if (n) {
                        delete t.callback;
                        let e = new g(`Event response for "${t.event}" timed out`);
                        n.call(t, e, t)
                    }
                    t.cid && this.transport.cancelPendingResponse(t.cid)
                }, C.prototype._processOutboundEvent = function(t, e, n, r) {
                    n = n || {}, this.state === this.CLOSED && this.connect();
                    let s, o = {
                        event: t
                    };
                    s = r ? new Promise((t, e) => {
                        o.callback = (n, r) => {
                            n ? e(n) : t(r)
                        }
                    }) : Promise.resolve();
                    let i = new h.Item;
                    this.options.cloneData ? o.data = l(e) : o.data = e, i.data = o;
                    let a = null == n.ackTimeout ? this.ackTimeout : n.ackTimeout;
                    return o.timeout = setTimeout(() => {
                        this._handleEventAckTimeout(o, i)
                    }, a), this._outboundBuffer.append(i), this.state === this.OPEN && this._flushOutboundBuffer(), s
                }, C.prototype.send = function(t) {
                    this.transport.send(t)
                }, C.prototype.transmit = function(t, e, n) {
                    return this._processOutboundEvent(t, e, n)
                }, C.prototype.invoke = function(t, e, n) {
                    return this._processOutboundEvent(t, e, n, !0)
                }, C.prototype.transmitPublish = function(t, e) {
                    let n = {
                        channel: this._decorateChannelName(t),
                        data: e
                    };
                    return this.transmit("#publish", n)
                }, C.prototype.invokePublish = function(t, e) {
                    let n = {
                        channel: this._decorateChannelName(t),
                        data: e
                    };
                    return this.invoke("#publish", n)
                }, C.prototype._triggerChannelSubscribe = function(t, e) {
                    let n = t.name;
                    if (t.state !== o.SUBSCRIBED) {
                        let r = t.state;
                        t.state = o.SUBSCRIBED;
                        let s = {
                            oldChannelState: r,
                            newChannelState: t.state,
                            subscriptionOptions: e
                        };
                        this._channelEventDemux.write(n + "/subscribeStateChange", s), this._channelEventDemux.write(n + "/subscribe", {
                            subscriptionOptions: e
                        }), this.emit("subscribeStateChange", {
                            channel: n,
                            ...s
                        }), this.emit("subscribe", {
                            channel: n,
                            subscriptionOptions: e
                        })
                    }
                }, C.prototype._triggerChannelSubscribeFail = function(t, e, n) {
                    let r = e.name,
                        s = !e.options.waitForAuth || this.authState === this.AUTHENTICATED,
                        o = !!this._channelMap[r];
                    o && s && (delete this._channelMap[r], this._channelEventDemux.write(r + "/subscribeFail", {
                        error: t,
                        subscriptionOptions: n
                    }), this.emit("subscribeFail", {
                        error: t,
                        channel: r,
                        subscriptionOptions: n
                    }))
                }, C.prototype._cancelPendingSubscribeCallback = function(t) {
                    null != t._pendingSubscriptionCid && (this.transport.cancelPendingResponse(t._pendingSubscriptionCid), delete t._pendingSubscriptionCid)
                }, C.prototype._decorateChannelName = function(t) {
                    return this.channelPrefix && (t = this.channelPrefix + t), t
                }, C.prototype._undecorateChannelName = function(t) {
                    return this.channelPrefix && 0 === t.indexOf(this.channelPrefix) ? t.replace(this.channelPrefix, "") : t
                }, C.prototype.startBatch = function() {
                    this.transport.startBatch()
                }, C.prototype.flushBatch = function() {
                    this.transport.flushBatch()
                }, C.prototype.cancelBatch = function() {
                    this.transport.cancelBatch()
                }, C.prototype._startBatching = function() {
                    null == this._batchingIntervalId && (this.startBatch(), this._batchingIntervalId = setInterval(() => {
                        this.flushBatch(), this.startBatch()
                    }, this.options.batchInterval))
                }, C.prototype.startBatching = function() {
                    this.isBatching = !0, this._startBatching()
                }, C.prototype._stopBatching = function() {
                    null != this._batchingIntervalId && clearInterval(this._batchingIntervalId), this._batchingIntervalId = null, this.flushBatch()
                }, C.prototype.stopBatching = function() {
                    this.isBatching = !1, this._stopBatching()
                }, C.prototype._cancelBatching = function() {
                    null != this._batchingIntervalId && clearInterval(this._batchingIntervalId), this._batchingIntervalId = null, this.cancelBatch()
                }, C.prototype.cancelBatching = function() {
                    this.isBatching = !1, this._cancelBatching()
                }, C.prototype._trySubscribe = function(t) {
                    let e = !t.options.waitForAuth || this.authState === this.AUTHENTICATED;
                    if (this.state === this.OPEN && !this.preparingPendingSubscriptions && null == t._pendingSubscriptionCid && e) {
                        let e = {
                                noTimeout: !0
                            },
                            n = {};
                        t.options.waitForAuth && (e.waitForAuth = !0, n.waitForAuth = e.waitForAuth), t.options.data && (n.data = t.options.data), t._pendingSubscriptionCid = this.transport.invokeRaw("#subscribe", {
                            channel: this._decorateChannelName(t.name),
                            ...n
                        }, e, e => {
                            if (e) {
                                if ("BadConnectionError" === e.name) return;
                                delete t._pendingSubscriptionCid, this._triggerChannelSubscribeFail(e, t, n)
                            } else delete t._pendingSubscriptionCid, this._triggerChannelSubscribe(t, n)
                        }), this.emit("subscribeRequest", {
                            channel: t.name,
                            subscriptionOptions: n
                        })
                    }
                }, C.prototype.subscribe = function(t, e) {
                    e = e || {};
                    let n = this._channelMap[t],
                        r = {
                            waitForAuth: !!e.waitForAuth
                        };
                    null != e.priority && (r.priority = e.priority), void 0 !== e.data && (r.data = e.data), n ? e && (n.options = r) : (n = {
                        name: t,
                        state: o.PENDING,
                        options: r
                    }, this._channelMap[t] = n, this._trySubscribe(n));
                    let s = new o(t, this, this._channelEventDemux, this._channelDataDemux);
                    return s
                }, C.prototype._triggerChannelUnsubscribe = function(t, e) {
                    let n = t.name;
                    if (this._cancelPendingSubscribeCallback(t), t.state === o.SUBSCRIBED) {
                        let r = {
                            oldChannelState: t.state,
                            newChannelState: e ? o.PENDING : o.UNSUBSCRIBED
                        };
                        this._channelEventDemux.write(n + "/subscribeStateChange", r), this._channelEventDemux.write(n + "/unsubscribe", {}), this.emit("subscribeStateChange", {
                            channel: n,
                            ...r
                        }), this.emit("unsubscribe", {
                            channel: n
                        })
                    }
                    e ? t.state = o.PENDING : delete this._channelMap[n]
                }, C.prototype._tryUnsubscribe = function(t) {
                    if (this.state === this.OPEN) {
                        let e = {
                            noTimeout: !0
                        };
                        this._cancelPendingSubscribeCallback(t);
                        let n = this._decorateChannelName(t.name);
                        this.transport.transmit("#unsubscribe", n, e)
                    }
                }, C.prototype.unsubscribe = function(t) {
                    let e = this._channelMap[t];
                    e && (this._triggerChannelUnsubscribe(e), this._tryUnsubscribe(e))
                }, C.prototype.receiver = function(t) {
                    return this._receiverDemux.stream(t)
                }, C.prototype.closeReceiver = function(t) {
                    this._receiverDemux.close(t)
                }, C.prototype.closeAllReceivers = function() {
                    this._receiverDemux.closeAll()
                }, C.prototype.killReceiver = function(t) {
                    this._receiverDemux.kill(t)
                }, C.prototype.killAllReceivers = function() {
                    this._receiverDemux.killAll()
                }, C.prototype.killReceiverConsumer = function(t) {
                    this._receiverDemux.killConsumer(t)
                }, C.prototype.getReceiverConsumerStats = function(t) {
                    return this._receiverDemux.getConsumerStats(t)
                }, C.prototype.getReceiverConsumerStatsList = function(t) {
                    return this._receiverDemux.getConsumerStatsList(t)
                }, C.prototype.getAllReceiversConsumerStatsList = function() {
                    return this._receiverDemux.getConsumerStatsListAll()
                }, C.prototype.getReceiverBackpressure = function(t) {
                    return this._receiverDemux.getBackpressure(t)
                }, C.prototype.getAllReceiversBackpressure = function() {
                    return this._receiverDemux.getBackpressureAll()
                }, C.prototype.getReceiverConsumerBackpressure = function(t) {
                    return this._receiverDemux.getConsumerBackpressure(t)
                }, C.prototype.hasReceiverConsumer = function(t, e) {
                    return this._receiverDemux.hasConsumer(t, e)
                }, C.prototype.hasAnyReceiverConsumer = function(t) {
                    return this._receiverDemux.hasConsumerAll(t)
                }, C.prototype.procedure = function(t) {
                    return this._procedureDemux.stream(t)
                }, C.prototype.closeProcedure = function(t) {
                    this._procedureDemux.close(t)
                }, C.prototype.closeAllProcedures = function() {
                    this._procedureDemux.closeAll()
                }, C.prototype.killProcedure = function(t) {
                    this._procedureDemux.kill(t)
                }, C.prototype.killAllProcedures = function() {
                    this._procedureDemux.killAll()
                }, C.prototype.killProcedureConsumer = function(t) {
                    this._procedureDemux.killConsumer(t)
                }, C.prototype.getProcedureConsumerStats = function(t) {
                    return this._procedureDemux.getConsumerStats(t)
                }, C.prototype.getProcedureConsumerStatsList = function(t) {
                    return this._procedureDemux.getConsumerStatsList(t)
                }, C.prototype.getAllProceduresConsumerStatsList = function() {
                    return this._procedureDemux.getConsumerStatsListAll()
                }, C.prototype.getProcedureBackpressure = function(t) {
                    return this._procedureDemux.getBackpressure(t)
                }, C.prototype.getAllProceduresBackpressure = function() {
                    return this._procedureDemux.getBackpressureAll()
                }, C.prototype.getProcedureConsumerBackpressure = function(t) {
                    return this._procedureDemux.getConsumerBackpressure(t)
                }, C.prototype.hasProcedureConsumer = function(t, e) {
                    return this._procedureDemux.hasConsumer(t, e)
                }, C.prototype.hasAnyProcedureConsumer = function(t) {
                    return this._procedureDemux.hasConsumerAll(t)
                }, C.prototype.channel = function(t) {
                    this._channelMap[t];
                    let e = new o(t, this, this._channelEventDemux, this._channelDataDemux);
                    return e
                }, C.prototype.closeChannel = function(t) {
                    this.channelCloseOutput(t), this.channelCloseAllListeners(t)
                }, C.prototype.closeAllChannelOutputs = function() {
                    this._channelDataDemux.closeAll()
                }, C.prototype.closeAllChannelListeners = function() {
                    this._channelEventDemux.closeAll()
                }, C.prototype.closeAllChannels = function() {
                    this.closeAllChannelOutputs(), this.closeAllChannelListeners()
                }, C.prototype.killChannel = function(t) {
                    this.channelKillOutput(t), this.channelKillAllListeners(t)
                }, C.prototype.killAllChannelOutputs = function() {
                    this._channelDataDemux.killAll()
                }, C.prototype.killAllChannelListeners = function() {
                    this._channelEventDemux.killAll()
                }, C.prototype.killAllChannels = function() {
                    this.killAllChannelOutputs(), this.killAllChannelListeners()
                }, C.prototype.killChannelOutputConsumer = function(t) {
                    this._channelDataDemux.killConsumer(t)
                }, C.prototype.killChannelListenerConsumer = function(t) {
                    this._channelEventDemux.killConsumer(t)
                }, C.prototype.getChannelOutputConsumerStats = function(t) {
                    return this._channelDataDemux.getConsumerStats(t)
                }, C.prototype.getChannelListenerConsumerStats = function(t) {
                    return this._channelEventDemux.getConsumerStats(t)
                }, C.prototype.getAllChannelOutputsConsumerStatsList = function() {
                    return this._channelDataDemux.getConsumerStatsListAll()
                }, C.prototype.getAllChannelListenersConsumerStatsList = function() {
                    return this._channelEventDemux.getConsumerStatsListAll()
                }, C.prototype.getChannelBackpressure = function(t) {
                    return Math.max(this.channelGetOutputBackpressure(t), this.channelGetAllListenersBackpressure(t))
                }, C.prototype.getAllChannelOutputsBackpressure = function() {
                    return this._channelDataDemux.getBackpressureAll()
                }, C.prototype.getAllChannelListenersBackpressure = function() {
                    return this._channelEventDemux.getBackpressureAll()
                }, C.prototype.getAllChannelsBackpressure = function() {
                    return Math.max(this.getAllChannelOutputsBackpressure(), this.getAllChannelListenersBackpressure())
                }, C.prototype.getChannelListenerConsumerBackpressure = function(t) {
                    return this._channelEventDemux.getConsumerBackpressure(t)
                }, C.prototype.getChannelOutputConsumerBackpressure = function(t) {
                    return this._channelDataDemux.getConsumerBackpressure(t)
                }, C.prototype.hasAnyChannelOutputConsumer = function(t) {
                    return this._channelDataDemux.hasConsumerAll(t)
                }, C.prototype.hasAnyChannelListenerConsumer = function(t) {
                    return this._channelEventDemux.hasConsumerAll(t)
                }, C.prototype.getChannelState = function(t) {
                    let e = this._channelMap[t];
                    return e ? e.state : o.UNSUBSCRIBED
                }, C.prototype.getChannelOptions = function(t) {
                    let e = this._channelMap[t];
                    return e ? { ...e.options
                    } : {}
                }, C.prototype._getAllChannelStreamNames = function(t) {
                    let e = this._channelEventDemux.getConsumerStatsListAll().filter(e => 0 === e.stream.indexOf(t + "/")).reduce((t, e) => (t[e.stream] = !0, t), {});
                    return Object.keys(e)
                }, C.prototype.channelCloseOutput = function(t) {
                    this._channelDataDemux.close(t)
                }, C.prototype.channelCloseListener = function(t, e) {
                    this._channelEventDemux.close(`${t}/${e}`)
                }, C.prototype.channelCloseAllListeners = function(t) {
                    this._getAllChannelStreamNames(t).forEach(t => {
                        this._channelEventDemux.close(t)
                    })
                }, C.prototype.channelKillOutput = function(t) {
                    this._channelDataDemux.kill(t)
                }, C.prototype.channelKillListener = function(t, e) {
                    this._channelEventDemux.kill(`${t}/${e}`)
                }, C.prototype.channelKillAllListeners = function(t) {
                    this._getAllChannelStreamNames(t).forEach(t => {
                        this._channelEventDemux.kill(t)
                    })
                }, C.prototype.channelGetOutputConsumerStatsList = function(t) {
                    return this._channelDataDemux.getConsumerStatsList(t)
                }, C.prototype.channelGetListenerConsumerStatsList = function(t, e) {
                    return this._channelEventDemux.getConsumerStatsList(`${t}/${e}`)
                }, C.prototype.channelGetAllListenersConsumerStatsList = function(t) {
                    return this._getAllChannelStreamNames(t).map(t => this._channelEventDemux.getConsumerStatsList(t)).reduce((t, e) => (e.forEach(e => {
                        t.push(e)
                    }), t), [])
                }, C.prototype.channelGetOutputBackpressure = function(t) {
                    return this._channelDataDemux.getBackpressure(t)
                }, C.prototype.channelGetListenerBackpressure = function(t, e) {
                    return this._channelEventDemux.getBackpressure(`${t}/${e}`)
                }, C.prototype.channelGetAllListenersBackpressure = function(t) {
                    let e = this._getAllChannelStreamNames(t).map(t => this._channelEventDemux.getBackpressure(t));
                    return Math.max(...e.concat(0))
                }, C.prototype.channelHasOutputConsumer = function(t, e) {
                    return this._channelDataDemux.hasConsumer(t, e)
                }, C.prototype.channelHasListenerConsumer = function(t, e, n) {
                    return this._channelEventDemux.hasConsumer(`${t}/${e}`, n)
                }, C.prototype.channelHasAnyListenerConsumer = function(t, e) {
                    return this._getAllChannelStreamNames(t).some(t => this._channelEventDemux.hasConsumer(t, e))
                }, C.prototype.subscriptions = function(t) {
                    let e = [];
                    return Object.keys(this._channelMap).forEach(n => {
                        (t || this._channelMap[n].state === o.SUBSCRIBED) && e.push(n)
                    }), e
                }, C.prototype.isSubscribed = function(t, e) {
                    let n = this._channelMap[t];
                    return e ? !!n : !!n && n.state === o.SUBSCRIBED
                }, C.prototype.processPendingSubscriptions = function() {
                    this.preparingPendingSubscriptions = !1;
                    let t = [];
                    Object.keys(this._channelMap).forEach(e => {
                        let n = this._channelMap[e];
                        n.state === o.PENDING && t.push(n)
                    }), t.sort((t, e) => {
                        let n = t.options.priority || 0,
                            r = e.options.priority || 0;
                        return n > r ? -1 : n < r ? 1 : 0
                    }), t.forEach(t => {
                        this._trySubscribe(t)
                    })
                }, t.exports = C
            }).call(this, n("c8ba"))
        },
        7812: function(t, e, n) {
            const r = n("638e"),
                s = n("e56d"),
                o = "16.0.4";
            t.exports.factory = s, t.exports.AGClientSocket = r, t.exports.create = function(t) {
                return s.create({ ...t,
                    version: o
                })
            }, t.exports.version = o
        },
        "85bf": function(t, e, n) {
            const r = n("9925"),
                s = n("db70");
            class o extends r {
                constructor() {
                    super(), this.nextConsumerId = 1, this._consumers = {}, this._tailNode = {
                        next: null,
                        data: {
                            value: void 0,
                            done: !1
                        }
                    }
                }
                _write(t, e, n) {
                    let r = {
                        data: {
                            value: t,
                            done: e
                        },
                        next: null
                    };
                    n && (r.consumerId = n), this._tailNode.next = r, this._tailNode = r;
                    let s = Object.values(this._consumers),
                        o = s.length;
                    for (let i = 0; i < o; i++) {
                        let t = s[i];
                        t.write(r.data)
                    }
                }
                write(t) {
                    this._write(t, !1)
                }
                close(t) {
                    this._write(t, !0)
                }
                writeToConsumer(t, e) {
                    this._write(e, !1, t)
                }
                closeConsumer(t, e) {
                    this._write(e, !0, t)
                }
                kill(t) {
                    let e = Object.keys(this._consumers),
                        n = e.length;
                    for (let r = 0; r < n; r++) this.killConsumer(e[r], t)
                }
                killConsumer(t, e) {
                    let n = this._consumers[t];
                    n && n.kill(e)
                }
                getBackpressure() {
                    let t = Object.values(this._consumers),
                        e = t.length,
                        n = 0;
                    for (let r = 0; r < e; r++) {
                        let e = t[r],
                            s = e.getBackpressure();
                        s > n && (n = s)
                    }
                    return n
                }
                getConsumerBackpressure(t) {
                    let e = this._consumers[t];
                    return e ? e.getBackpressure() : 0
                }
                hasConsumer(t) {
                    return !!this._consumers[t]
                }
                setConsumer(t, e) {
                    this._consumers[t] = e, e.currentNode || (e.currentNode = this._tailNode)
                }
                removeConsumer(t) {
                    delete this._consumers[t]
                }
                getConsumerStats(t) {
                    let e = this._consumers[t];
                    if (e) return e.getStats()
                }
                getConsumerStatsList() {
                    let t = [],
                        e = Object.values(this._consumers),
                        n = e.length;
                    for (let r = 0; r < n; r++) {
                        let n = e[r];
                        t.push(n.getStats())
                    }
                    return t
                }
                createConsumer(t) {
                    return new s(this, this.nextConsumerId++, this._tailNode, t)
                }
            }
            t.exports = o
        },
        "89b6": function(t, e, n) {
            const r = n("85bf"),
                s = n("1330");
            class o {
                constructor() {
                    this._mainStream = new r
                }
                write(t, e) {
                    this._mainStream.write({
                        stream: t,
                        data: {
                            value: e,
                            done: !1
                        }
                    })
                }
                close(t, e) {
                    this._mainStream.write({
                        stream: t,
                        data: {
                            value: e,
                            done: !0
                        }
                    })
                }
                closeAll(t) {
                    this._mainStream.close(t)
                }
                writeToConsumer(t, e) {
                    this._mainStream.writeToConsumer(t, {
                        consumerId: t,
                        data: {
                            value: e,
                            done: !1
                        }
                    })
                }
                closeConsumer(t, e) {
                    this._mainStream.closeConsumer(t, {
                        consumerId: t,
                        data: {
                            value: e,
                            done: !0
                        }
                    })
                }
                getConsumerStats(t) {
                    return this._mainStream.getConsumerStats(t)
                }
                getConsumerStatsList(t) {
                    let e = this._mainStream.getConsumerStatsList();
                    return e.filter(e => e.stream === t)
                }
                getConsumerStatsListAll() {
                    return this._mainStream.getConsumerStatsList()
                }
                kill(t, e) {
                    let n = this.getConsumerStatsList(t),
                        r = n.length;
                    for (let s = 0; s < r; s++) this.killConsumer(n[s].id, e)
                }
                killAll(t) {
                    this._mainStream.kill(t)
                }
                killConsumer(t, e) {
                    this._mainStream.killConsumer(t, e)
                }
                getBackpressure(t) {
                    let e = this.getConsumerStatsList(t),
                        n = e.length,
                        r = 0;
                    for (let s = 0; s < n; s++) {
                        let t = e[s];
                        t.backpressure > r && (r = t.backpressure)
                    }
                    return r
                }
                getBackpressureAll() {
                    return this._mainStream.getBackpressure()
                }
                getConsumerBackpressure(t) {
                    return this._mainStream.getConsumerBackpressure(t)
                }
                hasConsumer(t, e) {
                    let n = this._mainStream.getConsumerStats(e);
                    return !!n && n.stream === t
                }
                hasConsumerAll(t) {
                    return this._mainStream.hasConsumer(t)
                }
                createConsumer(t, e) {
                    let n = this._mainStream.createConsumer(e),
                        r = n.next;
                    n.next = async function() {
                        while (1) {
                            let e = await r.apply(this, arguments);
                            if (e.value && (e.value.stream === t || e.value.consumerId === this.id)) return e.value.data.done && this.return(), e.value.data;
                            if (e.done) return e
                        }
                    };
                    let s = n.getStats;
                    n.getStats = function() {
                        let e = s.apply(this, arguments);
                        return e.stream = t, e
                    };
                    let o = n.applyBackpressure;
                    n.applyBackpressure = function(e) {
                        !e.value || e.value.stream !== t && e.value.consumerId !== this.id ? e.done && o.apply(this, arguments) : o.apply(this, arguments)
                    };
                    let i = n.releaseBackpressure;
                    return n.releaseBackpressure = function(e) {
                        !e.value || e.value.stream !== t && e.value.consumerId !== this.id ? e.done && i.apply(this, arguments) : i.apply(this, arguments)
                    }, n
                }
                stream(t) {
                    return new s(this, t)
                }
            }
            t.exports = o
        },
        "8d40": function(t, e) {
            t.exports = function(t) {
                var e = [],
                    n = [];
                return function t(r, s) {
                    var o, i, a;
                    if ("object" === typeof r && null !== r && !(r instanceof Boolean) && !(r instanceof Date) && !(r instanceof Number) && !(r instanceof RegExp) && !(r instanceof String)) {
                        for (o = 0; o < e.length; o += 1)
                            if (e[o] === r) return {
                                $ref: n[o]
                            };
                        if (e.push(r), n.push(s), "[object Array]" === Object.prototype.toString.apply(r))
                            for (a = [], o = 0; o < r.length; o += 1) a[o] = t(r[o], s + "[" + o + "]");
                        else
                            for (i in a = {}, r) Object.prototype.hasOwnProperty.call(r, i) && (a[i] = t(r[i], s + "[" + JSON.stringify(i) + "]"));
                        return a
                    }
                    return r
                }(t, "$")
            }
        },
        9675: function(t, e, n) {
            "use strict";
            const r = n("52f6"),
                s = n("ef5d"),
                o = n("fb48");

            function i(t, e) {
                switch (s(t)) {
                    case "object":
                        return a(t, e);
                    case "array":
                        return c(t, e);
                    default:
                        return r(t)
                }
            }

            function a(t, e) {
                if ("function" === typeof e) return e(t);
                if (e || o(t)) {
                    const n = new t.constructor;
                    for (let r in t) n[r] = i(t[r], e);
                    return n
                }
                return t
            }

            function c(t, e) {
                const n = new t.constructor(t.length);
                for (let r = 0; r < t.length; r++) n[r] = i(t[r], e);
                return n
            }
            t.exports = i
        },
        9925: function(t, e) {
            class n {
                async next(t) {
                    let e = this.createConsumer(t),
                        n = await e.next();
                    return e.return(), n
                }
                async once(t) {
                    let e = await this.next(t);
                    return e.done && await new Promise(() => {}), e.value
                }
                createConsumer() {
                    throw new TypeError("Method must be overriden by subclass")
                }[Symbol.asyncIterator]() {
                    return this.createConsumer()
                }
            }
            t.exports = n
        },
        a832: function(t, e, n) {
            "use strict";
            /*!
             * isobject <https://github.com/jonschlinkert/isobject>
             *
             * Copyright (c) 2014-2017, Jon Schlinkert.
             * Released under the MIT License.
             */
            t.exports = function(t) {
                return null != t && "object" === typeof t && !1 === Array.isArray(t)
            }
        },
        bd04: function(t, e, n) {
            const r = n("89b6");

            function s() {
                this._listenerDemux = new r
            }
            s.prototype.emit = function(t, e) {
                this._listenerDemux.write(t, e)
            }, s.prototype.listener = function(t) {
                return this._listenerDemux.stream(t)
            }, s.prototype.closeListener = function(t) {
                this._listenerDemux.close(t)
            }, s.prototype.closeAllListeners = function() {
                this._listenerDemux.closeAll()
            }, s.prototype.getListenerConsumerStats = function(t) {
                return this._listenerDemux.getConsumerStats(t)
            }, s.prototype.getListenerConsumerStatsList = function(t) {
                return this._listenerDemux.getConsumerStatsList(t)
            }, s.prototype.getAllListenersConsumerStatsList = function() {
                return this._listenerDemux.getConsumerStatsListAll()
            }, s.prototype.killListener = function(t) {
                this._listenerDemux.kill(t)
            }, s.prototype.killAllListeners = function() {
                this._listenerDemux.killAll()
            }, s.prototype.killListenerConsumer = function(t) {
                this._listenerDemux.killConsumer(t)
            }, s.prototype.getListenerBackpressure = function(t) {
                return this._listenerDemux.getBackpressure(t)
            }, s.prototype.getAllListenersBackpressure = function() {
                return this._listenerDemux.getBackpressureAll()
            }, s.prototype.getListenerConsumerBackpressure = function(t) {
                return this._listenerDemux.getConsumerBackpressure(t)
            }, s.prototype.hasListenerConsumer = function(t, e) {
                return this._listenerDemux.hasConsumer(t, e)
            }, s.prototype.hasAnyListenerConsumer = function(t) {
                return this._listenerDemux.hasConsumerAll(t)
            }, t.exports = s
        },
        c437: function(t, e, n) {
            var r, s, o = n("e1f4"),
                i = n("2366"),
                a = 0,
                c = 0;

            function u(t, e, n) {
                var u = e && n || 0,
                    h = e || [];
                t = t || {};
                var l = t.node || r,
                    p = void 0 !== t.clockseq ? t.clockseq : s;
                if (null == l || null == p) {
                    var d = o();
                    null == l && (l = r = [1 | d[0], d[1], d[2], d[3], d[4], d[5]]), null == p && (p = s = 16383 & (d[6] << 8 | d[7]))
                }
                var m = void 0 !== t.msecs ? t.msecs : (new Date).getTime(),
                    f = void 0 !== t.nsecs ? t.nsecs : c + 1,
                    y = m - a + (f - c) / 1e4;
                if (y < 0 && void 0 === t.clockseq && (p = p + 1 & 16383), (y < 0 || m > a) && void 0 === t.nsecs && (f = 0), f >= 1e4) throw new Error("uuid.v1(): Can't create more than 10M uuids/sec");
                a = m, c = f, s = p, m += 122192928e5;
                var k = (1e4 * (268435455 & m) + f) % 4294967296;
                h[u++] = k >>> 24 & 255, h[u++] = k >>> 16 & 255, h[u++] = k >>> 8 & 255, h[u++] = 255 & k;
                var g = m / 4294967296 * 1e4 & 268435455;
                h[u++] = g >>> 8 & 255, h[u++] = 255 & g, h[u++] = g >>> 24 & 15 | 16, h[u++] = g >>> 16 & 255, h[u++] = p >>> 8 | 128, h[u++] = 255 & p;
                for (var _ = 0; _ < 6; ++_) h[u + _] = l[_];
                return e || i(h)
            }
            t.exports = u
        },
        c73f: function(t, e) {
            function n(t) {
                return new Promise(e => {
                    setTimeout(() => {
                        e()
                    }, t)
                })
            }
            t.exports = n
        },
        c9fd: function(t, e, n) {
            const r = n("1674"),
                s = r.InvalidActionError;

            function o(t, e, n, o) {
                this.socket = t, this.id = e, this.procedure = n, this.data = o, this.sent = !1, this._respond = (t, e) => {
                    if (this.sent) throw new s(`Response to request ${this.id} has already been sent`);
                    this.sent = !0, this.socket.sendObject(t, e)
                }, this.end = (t, e) => {
                    let n = {
                        rid: this.id
                    };
                    void 0 !== t && (n.data = t), this._respond(n, e)
                }, this.error = (t, e) => {
                    let n = {
                        rid: this.id,
                        error: r.dehydrateError(t)
                    };
                    this._respond(n, e)
                }
            }
            t.exports = o
        },
        cbfb: function(t, e) {
            let n;
            n = "undefined" !== typeof WorkerGlobalScope ? self : "undefined" !== typeof window && window || function() {
                return this
            }();
            const r = n.WebSocket || n.MozWebSocket;

            function s(t, e, n) {
                let s;
                return s = e ? new r(t, e) : new r(t), s
            }
            r && (s.prototype = r.prototype), t.exports = r ? s : null
        },
        d153: function(t, e, n) {
            "use strict";
            var r, s;

            function o() {
                if (arguments.length) return o.from(arguments)
            }

            function i() {}
            r = "An argument without append, prepend, or detach methods was given to `List", s = o.prototype, o.of = function() {
                return o.from.call(this, arguments)
            }, o.from = function(t) {
                var e, n, r, s = new this;
                if (t && (e = t.length)) {
                    n = -1;
                    while (++n < e) r = t[n], null !== r && void 0 !== r && s.append(r)
                }
                return s
            }, s.head = null, s.tail = null, s.toArray = function() {
                var t = this.head,
                    e = [];
                while (t) e.push(t), t = t.next;
                return e
            }, s.prepend = function(t) {
                if (!t) return !1;
                if (!t.append || !t.prepend || !t.detach) throw new Error(r + "#prepend`.");
                var e, n;
                return e = this, n = e.head, n ? n.prepend(t) : (t.detach(), t.list = e, e.head = t, t)
            }, s.append = function(t) {
                if (!t) return !1;
                if (!t.append || !t.prepend || !t.detach) throw new Error(r + "#append`.");
                var e, n, s;
                return e = this, s = e.tail, s ? s.append(t) : (n = e.head, n ? n.append(t) : (t.detach(), t.list = e, e.head = t, t))
            }, o.Item = i;
            var a = i.prototype;
            a.next = null, a.prev = null, a.list = null, a.detach = function() {
                var t = this,
                    e = t.list,
                    n = t.prev,
                    r = t.next;
                return e ? (e.tail === t && (e.tail = n), e.head === t && (e.head = r), e.tail === e.head && (e.tail = null), n && (n.next = r), r && (r.prev = n), t.prev = t.next = t.list = null, t) : t
            }, a.prepend = function(t) {
                if (!t || !t.append || !t.prepend || !t.detach) throw new Error(r + "Item#prepend`.");
                var e = this,
                    n = e.list,
                    s = e.prev;
                return !!n && (t.detach(), s && (t.prev = s, s.next = t), t.next = e, t.list = n, e.prev = t, e === n.head && (n.head = t), n.tail || (n.tail = e), t)
            }, a.append = function(t) {
                if (!t || !t.append || !t.prepend || !t.detach) throw new Error(r + "Item#append`.");
                var e = this,
                    n = e.list,
                    s = e.next;
                return !!n && (t.detach(), s && (t.next = s, s.prev = t), t.prev = e, t.list = n, e.next = t, e !== n.tail && n.tail || (n.tail = t), t)
            }, t.exports = o
        },
        db70: function(t, e) {
            class n {
                constructor(t, e, n, r) {
                    this.id = e, this._backpressure = 0, this.stream = t, this.currentNode = n, this.timeout = r, this.isAlive = !0, this.stream.setConsumer(this.id, this)
                }
                getStats() {
                    let t = {
                        id: this.id,
                        backpressure: this._backpressure
                    };
                    return null != this.timeout && (t.timeout = this.timeout), t
                }
                _resetBackpressure() {
                    this._backpressure = 0
                }
                applyBackpressure(t) {
                    this._backpressure++
                }
                releaseBackpressure(t) {
                    this._backpressure--
                }
                getBackpressure() {
                    return this._backpressure
                }
                write(t) {
                    void 0 !== this._timeoutId && (clearTimeout(this._timeoutId), delete this._timeoutId), this.applyBackpressure(t), this._resolve && (this._resolve(), delete this._resolve)
                }
                kill(t) {
                    void 0 !== this._timeoutId && (clearTimeout(this._timeoutId), delete this._timeoutId), this._killPacket = {
                        value: t,
                        done: !0
                    }, this._destroy(), this._resolve && (this._resolve(), delete this._resolve)
                }
                _destroy() {
                    this.isAlive = !1, this._resetBackpressure(), this.stream.removeConsumer(this.id)
                }
                async _waitForNextItem(t) {
                    return new Promise((e, n) => {
                        let s;
                        if (this._resolve = e, void 0 !== t) {
                            let e = new Error("Stream consumer iteration timed out");
                            (async () => {
                                let o = r(t);
                                s = o.timeoutId, await o.promise, e.name = "TimeoutError", delete this._resolve, n(e)
                            })()
                        }
                        this._timeoutId = s
                    })
                }
                async next() {
                    this.stream.setConsumer(this.id, this);
                    while (1) {
                        if (!this.currentNode.next) try {
                            await this._waitForNextItem(this.timeout)
                        } catch (t) {
                            throw this._destroy(), t
                        }
                        if (this._killPacket) {
                            this._destroy();
                            let t = this._killPacket;
                            return delete this._killPacket, t
                        }
                        if (this.currentNode = this.currentNode.next, this.releaseBackpressure(this.currentNode.data), !this.currentNode.consumerId || this.currentNode.consumerId === this.id) return this.currentNode.data.done && this._destroy(), this.currentNode.data
                    }
                }
                return () {
                    return delete this.currentNode, this._destroy(), {}
                }[Symbol.asyncIterator]() {
                    return this
                }
            }

            function r(t) {
                let e, n = new Promise(n => {
                    e = setTimeout(n, t)
                });
                return {
                    timeoutId: e,
                    promise: n
                }
            }
            t.exports = n
        },
        e56d: function(t, e, n) {
            (function(e) {
                const r = n("638e"),
                    s = n("11c1"),
                    o = n("1674"),
                    i = o.InvalidArgumentsError;

                function a() {
                    return e.location && "https:" === location.protocol
                }

                function c(t, n) {
                    let r = null == t.secure ? n : t.secure;
                    return t.port || (e.location && location.port ? location.port : r ? 443 : 80)
                }

                function u(t) {
                    if (t = t || {}, t.host && !t.host.match(/[^:]+:\d{2,5}/)) throw new i('The host option should include both the hostname and the port number in the format "hostname:port"');
                    if (t.host && t.hostname) throw new i('The host option should already include the hostname and the port number in the format "hostname:port" - Because of this, you should never use host and hostname options together');
                    if (t.host && t.port) throw new i('The host option should already include the hostname and the port number in the format "hostname:port" - Because of this, you should never use host and port options together');
                    let n = a(),
                        o = {
                            clientId: s.v4(),
                            port: c(t, n),
                            hostname: e.location && location.hostname || "localhost",
                            secure: n
                        };
                    return Object.assign(o, t), new r(o)
                }
                t.exports = {
                    create: u
                }
            }).call(this, n("c8ba"))
        },
        ef5d: function(t, e) {
            var n = Object.prototype.toString;

            function r(t) {
                return "function" === typeof t.constructor ? t.constructor.name : null
            }

            function s(t) {
                return Array.isArray ? Array.isArray(t) : t instanceof Array
            }

            function o(t) {
                return t instanceof Error || "string" === typeof t.message && t.constructor && "number" === typeof t.constructor.stackTraceLimit
            }

            function i(t) {
                return t instanceof Date || "function" === typeof t.toDateString && "function" === typeof t.getDate && "function" === typeof t.setDate
            }

            function a(t) {
                return t instanceof RegExp || "string" === typeof t.flags && "boolean" === typeof t.ignoreCase && "boolean" === typeof t.multiline && "boolean" === typeof t.global
            }

            function c(t, e) {
                return "GeneratorFunction" === r(t)
            }

            function u(t) {
                return "function" === typeof t.throw && "function" === typeof t.return && "function" === typeof t.next
            }

            function h(t) {
                try {
                    if ("number" === typeof t.length && "function" === typeof t.callee) return !0
                } catch (e) {
                    if (-1 !== e.message.indexOf("callee")) return !0
                }
                return !1
            }

            function l(t) {
                return !(!t.constructor || "function" !== typeof t.constructor.isBuffer) && t.constructor.isBuffer(t)
            }
            t.exports = function(t) {
                if (void 0 === t) return "undefined";
                if (null === t) return "null";
                var e = typeof t;
                if ("boolean" === e) return "boolean";
                if ("string" === e) return "string";
                if ("number" === e) return "number";
                if ("symbol" === e) return "symbol";
                if ("function" === e) return c(t) ? "generatorfunction" : "function";
                if (s(t)) return "array";
                if (l(t)) return "buffer";
                if (h(t)) return "arguments";
                if (i(t)) return "date";
                if (o(t)) return "error";
                if (a(t)) return "regexp";
                switch (r(t)) {
                    case "Symbol":
                        return "symbol";
                    case "Promise":
                        return "promise";
                    case "WeakMap":
                        return "weakmap";
                    case "WeakSet":
                        return "weakset";
                    case "Map":
                        return "map";
                    case "Set":
                        return "set";
                    case "Int8Array":
                        return "int8array";
                    case "Uint8Array":
                        return "uint8array";
                    case "Uint8ClampedArray":
                        return "uint8clampedarray";
                    case "Int16Array":
                        return "int16array";
                    case "Uint16Array":
                        return "uint16array";
                    case "Int32Array":
                        return "int32array";
                    case "Uint32Array":
                        return "uint32array";
                    case "Float32Array":
                        return "float32array";
                    case "Float64Array":
                        return "float64array"
                }
                if (u(t)) return "generator";
                switch (e = n.call(t), e) {
                    case "[object Object]":
                        return "object";
                    case "[object Map Iterator]":
                        return "mapiterator";
                    case "[object Set Iterator]":
                        return "setiterator";
                    case "[object String Iterator]":
                        return "stringiterator";
                    case "[object Array Iterator]":
                        return "arrayiterator"
                }
                return e.slice(8, -1).toLowerCase().replace(/\s/g, "")
            }
        },
        fb48: function(t, e, n) {
            "use strict";
            /*!
             * is-plain-object <https://github.com/jonschlinkert/is-plain-object>
             *
             * Copyright (c) 2014-2017, Jon Schlinkert.
             * Released under the MIT License.
             */
            var r = n("a832");

            function s(t) {
                return !0 === r(t) && "[object Object]" === Object.prototype.toString.call(t)
            }
            t.exports = function(t) {
                var e, n;
                return !1 !== s(t) && (e = t.constructor, "function" === typeof e && (n = e.prototype, !1 !== s(n) && !1 !== n.hasOwnProperty("isPrototypeOf")))
            }
        }
    }
]);
//# sourceMappingURL=vendors~widget-sc-client.js.map?35fccb86