(() => {
    "use strict";
    self.__osana$config = {
        bare: `${location.origin}/bare/`,
        prefix: "/service/~osana/",
        codec: self.__osana$bundle.codecs.none,
        files: {
            config: "/osana/osana.config.js",
            client: "/osana/osana.client.js",
            bundle: "/osana/osana.bundle.js",
            worker: "/osana/osana.worker.js"
        },
        blacklist: [/^(www\.)?netflix\.com/, /^accounts\.google\.com/]
    }
})();
//# sourceMappingURL=osana.config.js.map